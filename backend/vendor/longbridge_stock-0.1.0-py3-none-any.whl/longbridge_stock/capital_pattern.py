from __future__ import annotations

from typing import Any


CAPITAL_PATTERN_LABELS = {
    "high_turnover": "高位换手",
    "dip_support": "下跌承接",
    "short_cover": "空头回补",
    "passive_bid": "被动接盘",
    "distribution_after_push": "边拉边派发",
    "accumulation": "主动吸筹",
    "breakout": "强势拉升",
    "neutral": "形态不明",
}


def classify_capital_pattern(row: dict[str, Any]) -> dict[str, Any]:
    """Classify capital-flow pattern from observable market features.

    This is an evidence classifier, not an attribution engine. It separates
    directly observed signals (large orders, net flow, short-sale data) from
    inferred patterns such as passive bid or short covering.
    """

    ctx = _context(row)
    scores = {
        "breakout": _score_breakout(ctx),
        "accumulation": _score_accumulation(ctx),
        "dip_support": _score_dip_support(ctx),
        "passive_bid": _score_passive_bid(ctx),
        "high_turnover": _score_high_turnover(ctx),
        "distribution_after_push": _score_distribution_after_push(ctx),
        "short_cover": _score_short_cover(ctx),
    }
    pattern_key = max(scores, key=scores.get)
    best_score = scores[pattern_key]
    if best_score < 42:
        pattern_key = "neutral"
        best_score = 35

    evidence = _evidence(pattern_key, ctx)
    confidence = max(25.0, min(95.0, float(best_score)))
    if pattern_key == "short_cover" and not ctx["has_short_data"]:
        confidence = min(confidence, 55.0)

    return {
        "pattern": CAPITAL_PATTERN_LABELS[pattern_key],
        "patternKey": pattern_key,
        "confidence": round(confidence, 1),
        "direction": _direction(pattern_key),
        "risk": _risk(pattern_key, ctx),
        "evidence": evidence[:5],
        "scores": {CAPITAL_PATTERN_LABELS[key]: round(value, 1) for key, value in scores.items()},
    }


def capital_pattern_text(result: dict[str, Any]) -> str:
    pattern = str(result.get("pattern") or "形态不明")
    confidence = _num(result.get("confidence"))
    risk = str(result.get("risk") or "-")
    evidence = result.get("evidence")
    evidence_text = "；".join(str(item) for item in evidence[:3]) if isinstance(evidence, list) else ""
    return f"{pattern}（置信度{confidence:.0f}%，风险{risk}）：{evidence_text or '证据不足'}"


def _context(row: dict[str, Any]) -> dict[str, Any]:
    change_pct = _num_or_none(row.get("changePct") or row.get("change_pct"))
    from_open_pct = _num_or_none(row.get("fromOpenPct") or row.get("from_open_pct"))
    close_position = _num_or_none(row.get("closeLocation") or row.get("close_position") or row.get("intraday_position"))
    total_net = _num_or_none(row.get("totalNet") or row.get("total_net"))
    large_net = _num_or_none(row.get("largeNet") or row.get("large_net"))
    large_net_ratio = _num_or_none(row.get("largeNetRatio") or row.get("large_net_ratio"))
    flow_30m = _num_or_none(row.get("flow30m") or row.get("flow_30m"))
    turnover_ratio = _num_or_none(row.get("turnoverRatio20") or row.get("turnover_ratio_20d") or row.get("volumeRatio20"))
    return_5d = _return_pct(row, "return_5d", "ret5_pct", "ret_5d")
    return_10d = _return_pct(row, "return_10d", "ret10_pct", "ret_10d")
    return_20d = _return_pct(row, "return_20d", "ret20_pct", "ret_20d")
    return_60d = _return_pct(row, "return_60d", "ret60_pct", "ret_60d")
    close_to_ma20 = _return_pct(row, "close_to_ma20", "ma20_pct", "price_ma20_gap")
    hmm_transition_risk = _num_or_none(row.get("hmm_transition_risk"))
    anomaly = str(row.get("anomaly") or row.get("anomaly_type") or "").lower()
    price_regime = str(row.get("price_regime") or "").lower()
    capital_regime = str(row.get("capital_regime") or "").lower()
    short_selling_ratio = _num_or_none(row.get("short_selling_ratio"))
    ssr_5d_sma = _num_or_none(row.get("ssr_5d_sma"))
    short_rate = _num_or_none(row.get("short_rate") or row.get("rate"))
    short_turnover = _num_or_none(row.get("short_turnover"))
    turnover = _num_or_none(row.get("turnover"))

    capital_windows = [_num_or_none(row.get(f"capital_net_{days}d")) for days in (5, 10, 20, 60)]
    large_capital_windows = [_num_or_none(row.get(f"large_capital_net_{days}d")) for days in (5, 10, 20, 60)]
    capital_positive_count = sum(1 for value in capital_windows if value is not None and value > 0)
    large_capital_positive_count = sum(1 for value in large_capital_windows if value is not None and value > 0)
    capital_negative_count = sum(1 for value in capital_windows if value is not None and value < 0)
    large_capital_negative_count = sum(1 for value in large_capital_windows if value is not None and value < 0)

    high_position = (
        (return_20d is not None and return_20d >= 25)
        or (return_60d is not None and return_60d >= 60)
        or (close_to_ma20 is not None and close_to_ma20 >= 12)
    )
    price_down = (change_pct is not None and change_pct <= -0.7) or (return_5d is not None and return_5d <= -5)
    price_up = (change_pct is not None and change_pct >= 0.7) or (from_open_pct is not None and from_open_pct >= 0.8)
    weak_close = close_position is not None and close_position <= 0.35
    strong_close = close_position is not None and close_position >= 0.65
    heavy_turnover = turnover_ratio is not None and turnover_ratio >= 1.4
    short_selling_down = (
        short_selling_ratio is not None
        and ssr_5d_sma not in (None, 0)
        and short_selling_ratio <= ssr_5d_sma * 0.85
    )
    short_selling_up = (
        short_selling_ratio is not None
        and ssr_5d_sma not in (None, 0)
        and short_selling_ratio >= ssr_5d_sma * 1.15
    )
    has_short_data = any(value is not None for value in (short_selling_ratio, ssr_5d_sma, short_rate, short_turnover))

    return {
        "change_pct": change_pct,
        "from_open_pct": from_open_pct,
        "close_position": close_position,
        "total_net": total_net,
        "large_net": large_net,
        "large_net_ratio": large_net_ratio,
        "flow_30m": flow_30m,
        "turnover": turnover,
        "turnover_ratio": turnover_ratio,
        "return_5d": return_5d,
        "return_10d": return_10d,
        "return_20d": return_20d,
        "return_60d": return_60d,
        "close_to_ma20": close_to_ma20,
        "hmm_transition_risk": hmm_transition_risk,
        "anomaly": anomaly,
        "price_regime": price_regime,
        "capital_regime": capital_regime,
        "capital_positive_count": capital_positive_count,
        "large_capital_positive_count": large_capital_positive_count,
        "capital_negative_count": capital_negative_count,
        "large_capital_negative_count": large_capital_negative_count,
        "high_position": high_position,
        "price_down": price_down,
        "price_up": price_up,
        "weak_close": weak_close,
        "strong_close": strong_close,
        "heavy_turnover": heavy_turnover,
        "short_selling_ratio": short_selling_ratio,
        "ssr_5d_sma": ssr_5d_sma,
        "short_selling_down": short_selling_down,
        "short_selling_up": short_selling_up,
        "has_short_data": has_short_data,
    }


def _score_breakout(ctx: dict[str, Any]) -> float:
    score = 30.0
    score += 14 if ctx["price_up"] else 0
    score += 12 if ctx["strong_close"] else 0
    score += 12 if _positive(ctx["total_net"]) else 0
    score += 12 if _positive(ctx["large_net"]) else 0
    score += 8 if ctx["large_capital_positive_count"] >= 3 else 0
    score += 8 if ctx["capital_positive_count"] >= 3 else 0
    score -= 10 if ctx["high_position"] and ctx["weak_close"] else 0
    score -= 12 if _risk_high(ctx) else 0
    score -= 10 if ctx["short_selling_down"] else 0
    return score


def _score_accumulation(ctx: dict[str, Any]) -> float:
    score = 28.0
    score += 14 if _positive(ctx["total_net"]) else 0
    score += 12 if _positive(ctx["large_net"]) else 0
    score += 10 if ctx["capital_positive_count"] >= 3 else 0
    score += 8 if ctx["large_capital_positive_count"] >= 2 else 0
    score += 8 if not ctx["price_up"] else 0
    score += 6 if not ctx["high_position"] else 0
    score -= 10 if ctx["weak_close"] else 0
    score -= 8 if _risk_high(ctx) else 0
    return score


def _score_dip_support(ctx: dict[str, Any]) -> float:
    score = 26.0
    score += 16 if ctx["price_down"] else 0
    score += 14 if _positive(ctx["total_net"]) else 0
    score += 12 if _positive(ctx["large_net"]) else 0
    score += 8 if ctx["capital_positive_count"] >= 2 else 0
    score += 6 if not ctx["weak_close"] else 0
    score -= 8 if ctx["high_position"] and _risk_high(ctx) else 0
    return score


def _score_passive_bid(ctx: dict[str, Any]) -> float:
    score = 24.0
    score += 16 if ctx["price_down"] else 0
    score += 12 if _positive(ctx["total_net"]) else 0
    score += 12 if ctx["weak_close"] else 0
    score += 10 if _negative(ctx["large_net"]) else 0
    score += 8 if _risk_high(ctx) else 0
    score += 6 if ctx["short_selling_up"] else 0
    return score


def _score_high_turnover(ctx: dict[str, Any]) -> float:
    score = 24.0
    score += 18 if ctx["high_position"] else 0
    score += 12 if ctx["heavy_turnover"] else 0
    score += 10 if ctx["capital_positive_count"] >= 3 else 0
    score += 10 if _risk_high(ctx) else 0
    score += 10 if "rollover" in ctx["anomaly"] or "distribution" in ctx["capital_regime"] else 0
    score += 6 if ctx["weak_close"] else 0
    score -= 8 if ctx["strong_close"] and _positive(ctx["large_net"]) else 0
    return score


def _score_distribution_after_push(ctx: dict[str, Any]) -> float:
    score = 24.0
    score += 14 if ctx["price_up"] or ctx["high_position"] else 0
    score += 16 if _negative(ctx["large_net"]) else 0
    score += 12 if _negative(ctx["total_net"]) else 0
    score += 8 if ctx["weak_close"] else 0
    score += 8 if ctx["large_capital_negative_count"] >= 2 else 0
    score += 8 if ctx["heavy_turnover"] else 0
    return score


def _score_short_cover(ctx: dict[str, Any]) -> float:
    score = 22.0
    score += 28 if ctx["short_selling_down"] else 0
    score += 12 if ctx["price_up"] else 0
    score += 8 if _positive(ctx["total_net"]) else 0
    score += 8 if not _strong_large_in(ctx) else 0
    score += 6 if ctx["strong_close"] else 0
    if not ctx["has_short_data"]:
        score -= 12
    return score


def _evidence(pattern_key: str, ctx: dict[str, Any]) -> list[str]:
    evidence: list[str] = []
    if ctx["change_pct"] is not None:
        evidence.append(f"当日涨跌{ctx['change_pct']:+.2f}%")
    if ctx["return_5d"] is not None or ctx["return_20d"] is not None:
        evidence.append(f"5日/20日收益{_fmt_pct(ctx['return_5d'])}/{_fmt_pct(ctx['return_20d'])}")
    if ctx["total_net"] is not None or ctx["large_net"] is not None:
        evidence.append(f"总资金/大单{_fmt_money(ctx['total_net'])}/{_fmt_money(ctx['large_net'])}")
    if ctx["capital_positive_count"] or ctx["large_capital_positive_count"]:
        evidence.append(f"资金周期流入{ctx['capital_positive_count']}/4，大单流入{ctx['large_capital_positive_count']}/4")
    if ctx["capital_negative_count"] or ctx["large_capital_negative_count"]:
        evidence.append(f"资金周期流出{ctx['capital_negative_count']}/4，大单流出{ctx['large_capital_negative_count']}/4")
    if ctx["short_selling_ratio"] is not None:
        evidence.append(f"短卖比率{ctx['short_selling_ratio']:.2f}，5日均值{_fmt_num(ctx['ssr_5d_sma'])}")
    if ctx["hmm_transition_risk"] is not None:
        evidence.append(f"HMM转弱风险{ctx['hmm_transition_risk']:.1f}%")
    if pattern_key == "short_cover" and not ctx["has_short_data"]:
        evidence.append("缺少短卖数据，空头回补只能弱推断")
    if pattern_key == "neutral" and not evidence:
        evidence.append("资金、价格、短卖信号不足")
    return evidence


def _direction(pattern_key: str) -> str:
    return {
        "breakout": "breakout",
        "accumulation": "accumulation",
        "dip_support": "support",
        "passive_bid": "passive_bid",
        "high_turnover": "distribution_risk",
        "distribution_after_push": "distribution",
        "short_cover": "short_cover",
        "neutral": "neutral",
    }[pattern_key]


def _risk(pattern_key: str, ctx: dict[str, Any]) -> str:
    if pattern_key in {"passive_bid", "distribution_after_push"}:
        return "高"
    if pattern_key == "high_turnover" or _risk_high(ctx):
        return "中高"
    if pattern_key in {"breakout", "accumulation"} and not ctx["high_position"]:
        return "中"
    return "中"


def _risk_high(ctx: dict[str, Any]) -> bool:
    risk = ctx.get("hmm_transition_risk")
    return (risk is not None and risk >= 65) or "rollover" in str(ctx.get("anomaly") or "")


def _strong_large_in(ctx: dict[str, Any]) -> bool:
    large_ratio = ctx.get("large_net_ratio")
    return _positive(ctx.get("large_net")) and (large_ratio is None or large_ratio >= 0.08)


def _return_pct(row: dict[str, Any], *keys: str) -> float | None:
    for key in keys:
        value = _num_or_none(row.get(key))
        if value is None:
            continue
        if abs(value) <= 1.5:
            return value * 100
        return value
    return None


def _positive(value: Any) -> bool:
    parsed = _num_or_none(value)
    return parsed is not None and parsed > 0


def _negative(value: Any) -> bool:
    parsed = _num_or_none(value)
    return parsed is not None and parsed < 0


def _num(value: Any) -> float:
    parsed = _num_or_none(value)
    return 0.0 if parsed is None else parsed


def _num_or_none(value: Any) -> float | None:
    if value is None or value == "":
        return None
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def _fmt_pct(value: Any) -> str:
    parsed = _num_or_none(value)
    return "-" if parsed is None else f"{parsed:+.1f}%"


def _fmt_money(value: Any) -> str:
    amount = _num_or_none(value)
    if amount is None:
        return "-"
    sign = "+" if amount > 0 else ""
    abs_amount = abs(amount)
    if abs_amount >= 10_000:
        return f"{sign}{amount / 10_000:.2f}亿"
    return f"{sign}{amount:.0f}万"


def _fmt_num(value: Any) -> str:
    parsed = _num_or_none(value)
    return "-" if parsed is None else f"{parsed:.2f}"
