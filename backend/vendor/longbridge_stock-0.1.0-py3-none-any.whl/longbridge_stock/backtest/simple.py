from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import pandas as pd


@dataclass(frozen=True)
class BacktestResult:
    daily: pd.DataFrame
    positions: pd.DataFrame
    metrics: dict[str, float]


def run_topk_backtest(
    market_data: pd.DataFrame,
    scores: pd.Series,
    top_k: int = 30,
    cost_rate: float = 0.0015,
) -> BacktestResult:
    """Run a simple daily equal-weight top-k factor backtest."""
    if top_k <= 0:
        raise ValueError("top_k must be positive")

    data = market_data[["close"]].join(scores.rename("score"), how="inner").dropna()
    close = data["close"].groupby(level="instrument", group_keys=False)
    data["next_return"] = close.pct_change(fill_method=None).groupby(level="instrument", group_keys=False).shift(-1)
    data = data.dropna(subset=["score", "next_return"])

    positions = _select_topk(data["score"], top_k=top_k)
    selected = data.join(positions.rename("weight"), how="inner")
    daily_return = selected.groupby(level="datetime").apply(lambda frame: (frame["weight"] * frame["next_return"]).sum())
    turnover = _turnover(positions)
    net_return = daily_return.sub(turnover.reindex(daily_return.index, fill_value=0.0) * cost_rate, fill_value=0.0)

    benchmark = data.groupby(level="datetime")["next_return"].mean().reindex(net_return.index)
    daily = pd.DataFrame(
        {
            "return": daily_return,
            "turnover": turnover.reindex(daily_return.index, fill_value=0.0),
            "net_return": net_return,
            "benchmark_return": benchmark,
        }
    )
    daily["equity"] = (1.0 + daily["net_return"]).cumprod()
    daily["benchmark_equity"] = (1.0 + daily["benchmark_return"].fillna(0.0)).cumprod()
    return BacktestResult(daily=daily, positions=positions.to_frame("weight"), metrics=_metrics(daily))


def _select_topk(scores: pd.Series, top_k: int) -> pd.Series:
    selected = []
    for dt, frame in scores.groupby(level="datetime"):
        top = frame.sort_values(ascending=False).head(top_k)
        if top.empty:
            continue
        weight = pd.Series(1.0 / len(top), index=top.index, name="weight")
        selected.append(weight)
    if not selected:
        raise ValueError("No positions selected; check score coverage and date range.")
    return pd.concat(selected).sort_index()


def _turnover(positions: pd.Series) -> pd.Series:
    wide = positions.unstack("instrument").fillna(0.0).sort_index()
    return wide.diff().abs().sum(axis=1).fillna(wide.abs().sum(axis=1))


def _metrics(daily: pd.DataFrame) -> dict[str, float]:
    returns = daily["net_return"].dropna()
    if returns.empty:
        return {}
    annual_return = (1.0 + returns).prod() ** (252.0 / len(returns)) - 1.0
    volatility = returns.std(ddof=0) * np.sqrt(252.0)
    sharpe = annual_return / volatility if volatility else np.nan
    drawdown = daily["equity"] / daily["equity"].cummax() - 1.0
    benchmark = daily["benchmark_return"].dropna()
    benchmark_annual_return = (1.0 + benchmark).prod() ** (252.0 / len(benchmark)) - 1.0 if not benchmark.empty else np.nan
    return {
        "annual_return": float(annual_return),
        "volatility": float(volatility),
        "sharpe": float(sharpe),
        "max_drawdown": float(drawdown.min()),
        "win_rate": float((returns > 0).mean()),
        "avg_turnover": float(daily["turnover"].mean()),
        "benchmark_annual_return": float(benchmark_annual_return),
    }
