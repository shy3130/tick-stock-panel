from __future__ import annotations

import hashlib
import json
from datetime import date, datetime, timezone
from pathlib import Path
from typing import Any
from zoneinfo import ZoneInfo

import psycopg
from psycopg.types.json import Jsonb

from longbridge_stock.realtime_sinks import RealtimeSinkRouter

SHANGHAI_TZ = ZoneInfo("Asia/Shanghai")


class LongbridgePostgresStore:
    def __init__(self, dsn: str) -> None:
        self.dsn = dsn
        self.realtime_sinks = RealtimeSinkRouter()

    def upsert_dataset(self, symbol: str, market: str, dataset: str, payload: Any, fetched_at: datetime | None = None) -> None:
        fetched_at = fetched_at or _now()
        with psycopg.connect(self.dsn) as conn:
            self._insert_raw_snapshot(conn, symbol, market, dataset, payload, fetched_at)
            if dataset == "kline":
                self._upsert_daily_bars(conn, symbol, market, payload, fetched_at)
            elif dataset == "static":
                self._upsert_symbol(conn, symbol, market, payload, fetched_at)
            elif dataset == "calc_index":
                self._upsert_calc_index(conn, symbol, market, payload, fetched_at.date(), fetched_at)
            elif dataset == "valuation":
                self._upsert_valuation(conn, symbol, market, payload, fetched_at.date(), fetched_at)
            elif dataset == "financial_report":
                self._upsert_financial_report(conn, symbol, market, payload, fetched_at)
            elif dataset == "company":
                self._upsert_company_profile(conn, symbol, market, payload, fetched_at)
            elif dataset == "executive":
                self._upsert_executives(conn, symbol, market, payload, fetched_at)
            elif dataset == "invest_relation":
                self._upsert_invest_relations(conn, symbol, market, payload, fetched_at)
            elif dataset == "operating":
                self._upsert_operating_reviews(conn, symbol, market, payload, fetched_at)
            elif dataset == "dividend":
                self._upsert_dividends(conn, symbol, market, payload, fetched_at)
            elif dataset == "institution_rating":
                self._upsert_institution_rating(conn, symbol, market, payload, fetched_at)
            elif dataset == "consensus":
                self._upsert_consensus(conn, symbol, market, payload, fetched_at)

    def import_raw_tree(self, data_root: str | Path) -> dict[str, int]:
        data_root = Path(data_root)
        counters: dict[str, int] = {}
        for dataset_dir in sorted((data_root / "raw").iterdir()):
            if not dataset_dir.is_dir() or dataset_dir.name == "errors":
                continue
            for path in sorted(dataset_dir.glob("*/*.json")):
                document = json.loads(path.read_text(encoding="utf-8"))
                dataset = str(document.get("dataset") or dataset_dir.name)
                market = str(document.get("market") or path.parent.name)
                symbol = str(document.get("symbol") or path.stem.replace("_", "."))
                payload = document.get("payload")
                updated_at = _parse_datetime(document.get("updated_at")) or _now()
                self.upsert_dataset(symbol, market, dataset, payload, updated_at)
                counters[dataset] = counters.get(dataset, 0) + 1
        return counters

    def ensure_external_daily_bar_table(self) -> None:
        with psycopg.connect(self.dsn) as conn:
            conn.execute(
                """
                create table if not exists lb_external_daily_bars (
                  source text not null,
                  symbol text not null,
                  market text not null,
                  trade_date date not null,
                  open numeric,
                  high numeric,
                  low numeric,
                  close numeric,
                  volume numeric,
                  turnover numeric,
                  adjusted boolean not null default true,
                  payload jsonb,
                  fetched_at timestamptz not null,
                  updated_at timestamptz not null default now(),
                  primary key (source, symbol, trade_date)
                )
                """
            )
            conn.execute(
                """
                create index if not exists idx_lb_external_daily_bars_symbol_date
                on lb_external_daily_bars (symbol, trade_date desc)
                """
            )
            conn.execute(
                """
                create index if not exists idx_lb_external_daily_bars_source_date
                on lb_external_daily_bars (source, trade_date desc)
                """
            )

    def upsert_external_daily_bars(
        self,
        source: str,
        symbol: str,
        market: str,
        payload: list[dict[str, Any]],
        fetched_at: datetime | None = None,
    ) -> int:
        fetched_at = fetched_at or _now()
        self.ensure_external_daily_bar_table()
        written = 0
        with psycopg.connect(self.dsn) as conn:
            for row in _ensure_rows(payload):
                trade_date = _parse_trade_date(row.get("time") or row.get("date") or row.get("timestamp"), market=market)
                if trade_date is None:
                    continue
                conn.execute(
                    """
                    insert into lb_external_daily_bars
                      (source, symbol, market, trade_date, open, high, low, close, volume, turnover,
                       adjusted, payload, fetched_at, updated_at)
                    values (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, true, %s, %s, now())
                    on conflict (source, symbol, trade_date) do update set
                      market = excluded.market,
                      open = excluded.open,
                      high = excluded.high,
                      low = excluded.low,
                      close = excluded.close,
                      volume = excluded.volume,
                      turnover = excluded.turnover,
                      adjusted = excluded.adjusted,
                      payload = excluded.payload,
                      fetched_at = excluded.fetched_at,
                      updated_at = excluded.updated_at
                    """,
                    (
                        source,
                        symbol,
                        market,
                        trade_date,
                        _num(row.get("open")),
                        _num(row.get("high")),
                        _num(row.get("low")),
                        _num(row.get("close") or row.get("last")),
                        _num(row.get("volume")),
                        _num(row.get("turnover")),
                        Jsonb(row),
                        fetched_at,
                    ),
                )
                written += 1
        return written

    def ensure_realtime_quote_table(self) -> None:
        if not self.realtime_sinks.config.postgres_enabled:
            self.realtime_sinks.ensure_schema()
            return
        with psycopg.connect(self.dsn) as conn:
            conn.execute(
                """
                create table if not exists lb_realtime_quotes (
                  snapshot_minute timestamptz not null,
                  symbol text not null,
                  market text not null,
                  last_done numeric,
                  prev_close numeric,
                  open numeric,
                  high numeric,
                  low numeric,
                  change_value numeric,
                  change_percentage numeric,
                  volume numeric,
                  turnover numeric,
                  trade_status text,
                  payload jsonb,
                  fetched_at timestamptz not null,
                  updated_at timestamptz not null default now(),
                  primary key (snapshot_minute, symbol)
                )
                """
            )
            conn.execute(
                """
                create index if not exists idx_lb_realtime_quotes_symbol_minute
                on lb_realtime_quotes (symbol, snapshot_minute desc)
                """
            )
            conn.execute(
                """
                create index if not exists idx_lb_realtime_quotes_market_minute
                on lb_realtime_quotes (market, snapshot_minute desc)
                """
            )

    def upsert_realtime_quotes(
        self,
        rows: list[dict[str, Any]],
        snapshot_minute: datetime,
        fetched_at: datetime,
    ) -> int:
        if not rows:
            return 0
        self.realtime_sinks.write_quotes(rows, snapshot_minute, fetched_at)
        if not self.realtime_sinks.config.postgres_enabled:
            return len([row for row in rows if row.get("symbol")])
        written = 0
        with psycopg.connect(self.dsn) as conn:
            for row in rows:
                symbol = str(row.get("symbol") or "")
                if not symbol:
                    continue
                market = _market_from_symbol(symbol)
                last_done = _num(row.get("last") or row.get("last_done"))
                prev_close = _num(row.get("prev_close") or row.get("prev_close_price"))
                conn.execute(
                    """
                    insert into lb_realtime_quotes
                      (snapshot_minute, symbol, market, last_done, prev_close, open, high, low,
                       change_value, change_percentage, volume, turnover, trade_status, payload, fetched_at, updated_at)
                    values (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, now())
                    on conflict (snapshot_minute, symbol) do update set
                      market = excluded.market,
                      last_done = excluded.last_done,
                      prev_close = excluded.prev_close,
                      open = excluded.open,
                      high = excluded.high,
                      low = excluded.low,
                      change_value = excluded.change_value,
                      change_percentage = excluded.change_percentage,
                      volume = excluded.volume,
                      turnover = excluded.turnover,
                      trade_status = excluded.trade_status,
                      payload = excluded.payload,
                      fetched_at = excluded.fetched_at,
                      updated_at = excluded.updated_at
                    """,
                    (
                        snapshot_minute,
                        symbol,
                        market,
                        last_done,
                        prev_close,
                        _num(row.get("open")),
                        _num(row.get("high")),
                        _num(row.get("low")),
                        _num(row.get("change_value")),
                        _change_pct_text(row.get("change_percentage"), last_done, prev_close),
                        _num(row.get("volume")),
                        _num(row.get("turnover")),
                        row.get("status") or row.get("trade_status"),
                        Jsonb(row),
                        fetched_at,
                    ),
                )
                written += 1
        return written

    def ensure_realtime_capital_table(self) -> None:
        if not self.realtime_sinks.config.postgres_enabled:
            self.realtime_sinks.ensure_schema()
            return
        with psycopg.connect(self.dsn) as conn:
            conn.execute(
                """
                create table if not exists lb_realtime_capital (
                  snapshot_minute timestamptz not null,
                  symbol text not null,
                  market text not null,
                  large_in numeric,
                  large_out numeric,
                  large_net numeric,
                  medium_in numeric,
                  medium_out numeric,
                  medium_net numeric,
                  small_in numeric,
                  small_out numeric,
                  small_net numeric,
                  total_in numeric,
                  total_out numeric,
                  total_net numeric,
                  large_net_ratio numeric,
                  small_net_ratio numeric,
                  provider_timestamp timestamptz,
                  payload jsonb,
                  flow_payload jsonb,
                  fetched_at timestamptz not null,
                  updated_at timestamptz not null default now(),
                  primary key (snapshot_minute, symbol)
                )
                """
            )
            conn.execute(
                """
                create index if not exists idx_lb_realtime_capital_symbol_minute
                on lb_realtime_capital (symbol, snapshot_minute desc)
                """
            )
            conn.execute(
                """
                create index if not exists idx_lb_realtime_capital_market_minute
                on lb_realtime_capital (market, snapshot_minute desc)
                """
            )
            conn.execute(
                """
                create table if not exists lb_realtime_capital_flow (
                  symbol text not null,
                  market text not null,
                  flow_time timestamptz not null,
                  inflow numeric,
                  payload jsonb,
                  fetched_at timestamptz not null,
                  updated_at timestamptz not null default now(),
                  primary key (symbol, flow_time)
                )
                """
            )
            conn.execute(
                """
                create index if not exists idx_lb_realtime_capital_flow_market_time
                on lb_realtime_capital_flow (market, flow_time desc)
                """
            )

    def ensure_realtime_microstructure_tables(self) -> None:
        if not self.realtime_sinks.config.postgres_enabled:
            self.realtime_sinks.ensure_schema()
            return
        with psycopg.connect(self.dsn) as conn:
            conn.execute("select pg_advisory_xact_lock(hashtext('lb_realtime_microstructure_schema'))")
            conn.execute(
                """
                create table if not exists lb_realtime_depth (
                  snapshot_minute timestamptz not null,
                  symbol text not null,
                  market text not null,
                  bid_volume numeric,
                  ask_volume numeric,
                  bid_order_count numeric,
                  ask_order_count numeric,
                  imbalance numeric,
                  payload jsonb,
                  fetched_at timestamptz not null,
                  updated_at timestamptz not null default now(),
                  primary key (snapshot_minute, symbol)
                )
                """
            )
            conn.execute(
                """
                create index if not exists idx_lb_realtime_depth_market_minute
                on lb_realtime_depth (market, snapshot_minute desc)
                """
            )
            conn.execute(
                """
                create table if not exists lb_realtime_trades (
                  symbol text not null,
                  market text not null,
                  trade_time timestamptz not null,
                  price numeric,
                  volume numeric,
                  trade_type text,
                  direction text,
                  trade_session text,
                  payload jsonb,
                  fetched_at timestamptz not null,
                  updated_at timestamptz not null default now(),
                  primary key (symbol, trade_time, price, volume, direction)
                )
                """
            )
            conn.execute(
                """
                create index if not exists idx_lb_realtime_trades_market_time
                on lb_realtime_trades (market, trade_time desc)
                """
            )
            conn.execute(
                """
                create table if not exists lb_intraday_lines (
                  symbol text not null,
                  market text not null,
                  line_time timestamptz not null,
                  price numeric,
                  avg_price numeric,
                  volume numeric,
                  turnover numeric,
                  payload jsonb,
                  fetched_at timestamptz not null,
                  updated_at timestamptz not null default now(),
                  primary key (symbol, line_time)
                )
                """
            )
            conn.execute(
                """
                create index if not exists idx_lb_intraday_lines_market_time
                on lb_intraday_lines (market, line_time desc)
                """
            )
            conn.execute(
                """
                create table if not exists lb_market_temperature (
                  market text not null,
                  observed_at timestamptz not null,
                  temperature numeric,
                  valuation numeric,
                  sentiment numeric,
                  description text,
                  payload jsonb,
                  fetched_at timestamptz not null,
                  updated_at timestamptz not null default now(),
                  primary key (market, observed_at)
                )
                """
            )
            conn.execute(
                """
                create index if not exists idx_lb_market_temperature_time
                on lb_market_temperature (observed_at desc)
                """
            )

    def upsert_realtime_depth(
        self,
        symbol: str,
        payload: dict[str, Any],
        snapshot_minute: datetime,
        fetched_at: datetime,
    ) -> bool:
        market = _market_from_symbol(symbol)
        bids = payload.get("bids") if isinstance(payload.get("bids"), list) else []
        asks = payload.get("asks") if isinstance(payload.get("asks"), list) else []
        bid_volume = _decimal_sum(*[_num(item.get("volume")) for item in bids if isinstance(item, dict)])
        ask_volume = _decimal_sum(*[_num(item.get("volume")) for item in asks if isinstance(item, dict)])
        bid_orders = _decimal_sum(*[_num(item.get("order_num")) for item in bids if isinstance(item, dict)])
        ask_orders = _decimal_sum(*[_num(item.get("order_num")) for item in asks if isinstance(item, dict)])
        imbalance = _book_imbalance(bid_volume, ask_volume)
        row = {
            "snapshot_minute": snapshot_minute,
            "symbol": symbol,
            "market": market,
            "bid_volume": bid_volume,
            "ask_volume": ask_volume,
            "bid_order_count": bid_orders,
            "ask_order_count": ask_orders,
            "imbalance": imbalance,
        }
        self.realtime_sinks.write_depth(row, payload, fetched_at)
        if not self.realtime_sinks.config.postgres_enabled:
            return True
        with psycopg.connect(self.dsn) as conn:
            conn.execute(
                """
                insert into lb_realtime_depth
                  (snapshot_minute, symbol, market, bid_volume, ask_volume, bid_order_count,
                   ask_order_count, imbalance, payload, fetched_at, updated_at)
                values (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, now())
                on conflict (snapshot_minute, symbol) do update set
                  market = excluded.market,
                  bid_volume = excluded.bid_volume,
                  ask_volume = excluded.ask_volume,
                  bid_order_count = excluded.bid_order_count,
                  ask_order_count = excluded.ask_order_count,
                  imbalance = excluded.imbalance,
                  payload = excluded.payload,
                  fetched_at = excluded.fetched_at,
                  updated_at = excluded.updated_at
                """,
                (
                    snapshot_minute,
                    symbol,
                    market,
                    bid_volume,
                    ask_volume,
                    bid_orders,
                    ask_orders,
                    imbalance,
                    Jsonb(payload),
                    fetched_at,
                ),
            )
        return True

    def upsert_realtime_trades(self, symbol: str, payload: Any, fetched_at: datetime) -> int:
        rows = _trade_rows(symbol, payload)
        if not rows:
            return 0
        self.realtime_sinks.write_trades(rows, fetched_at)
        if not self.realtime_sinks.config.postgres_enabled:
            return len(rows)
        with psycopg.connect(self.dsn) as conn:
            with conn.cursor() as cur:
                cur.executemany(
                    """
                    insert into lb_realtime_trades
                      (symbol, market, trade_time, price, volume, trade_type, direction,
                       trade_session, payload, fetched_at, updated_at)
                    values (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, now())
                    on conflict (symbol, trade_time, price, volume, direction) do update set
                      market = excluded.market,
                      trade_type = excluded.trade_type,
                      trade_session = excluded.trade_session,
                      payload = excluded.payload,
                      fetched_at = excluded.fetched_at,
                      updated_at = excluded.updated_at
                    """,
                    [
                        (
                            row["symbol"],
                            row["market"],
                            row["trade_time"],
                            row["price"],
                            row["volume"],
                            row["trade_type"],
                            row["direction"],
                            row["trade_session"],
                            Jsonb(row["payload"]),
                            fetched_at,
                        )
                        for row in rows
                    ],
                )
        return len(rows)

    def upsert_intraday_lines(self, symbol: str, payload: Any, fetched_at: datetime) -> int:
        rows = _intraday_rows(symbol, payload)
        if not rows:
            return 0
        self.realtime_sinks.write_intraday_lines(rows, fetched_at)
        if not self.realtime_sinks.config.postgres_enabled:
            return len(rows)
        with psycopg.connect(self.dsn) as conn:
            with conn.cursor() as cur:
                cur.executemany(
                    """
                    insert into lb_intraday_lines
                      (symbol, market, line_time, price, avg_price, volume, turnover, payload, fetched_at, updated_at)
                    values (%s, %s, %s, %s, %s, %s, %s, %s, %s, now())
                    on conflict (symbol, line_time) do update set
                      market = excluded.market,
                      price = excluded.price,
                      avg_price = excluded.avg_price,
                      volume = excluded.volume,
                      turnover = excluded.turnover,
                      payload = excluded.payload,
                      fetched_at = excluded.fetched_at,
                      updated_at = excluded.updated_at
                    """,
                    [
                        (
                            row["symbol"],
                            row["market"],
                            row["line_time"],
                            row["price"],
                            row["avg_price"],
                            row["volume"],
                            row["turnover"],
                            Jsonb(row["payload"]),
                            fetched_at,
                        )
                        for row in rows
                    ],
                )
        return len(rows)

    def upsert_market_temperature(self, market: str, payload: dict[str, Any], fetched_at: datetime) -> bool:
        observed_at = _parse_datetime(payload.get("updated_at")) or fetched_at
        with psycopg.connect(self.dsn) as conn:
            conn.execute(
                """
                insert into lb_market_temperature
                  (market, observed_at, temperature, valuation, sentiment, description, payload, fetched_at, updated_at)
                values (%s, %s, %s, %s, %s, %s, %s, %s, now())
                on conflict (market, observed_at) do update set
                  temperature = excluded.temperature,
                  valuation = excluded.valuation,
                  sentiment = excluded.sentiment,
                  description = excluded.description,
                  payload = excluded.payload,
                  fetched_at = excluded.fetched_at,
                  updated_at = excluded.updated_at
                """,
                (
                    market.lower(),
                    observed_at,
                    _num(payload.get("temperature")),
                    _num(payload.get("valuation")),
                    _num(payload.get("sentiment")),
                    payload.get("description"),
                    Jsonb(payload),
                    fetched_at,
                ),
            )
        return True

    def upsert_realtime_capital(
        self,
        symbol: str,
        payload: dict[str, Any],
        flow_payload: Any,
        snapshot_minute: datetime,
        fetched_at: datetime,
    ) -> bool:
        row = _capital_row(symbol, payload)
        if row is None:
            return False
        flow_rows = _capital_flow_rows(row["symbol"], row["market"], flow_payload)
        self.realtime_sinks.write_capital(row, payload, flow_rows, snapshot_minute, fetched_at)
        if not self.realtime_sinks.config.postgres_enabled:
            return True
        wrote_capital = False
        wrote_flow = 0
        with psycopg.connect(self.dsn) as conn:
            if not self._is_repeated_realtime_capital(conn, row, snapshot_minute):
                conn.execute(
                    """
                    insert into lb_realtime_capital
                      (snapshot_minute, symbol, market, large_in, large_out, large_net,
                       medium_in, medium_out, medium_net, small_in, small_out, small_net,
                       total_in, total_out, total_net, large_net_ratio, small_net_ratio,
                       provider_timestamp, payload, flow_payload, fetched_at, updated_at)
                    values (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, now())
                    on conflict (snapshot_minute, symbol) do update set
                      market = excluded.market,
                      large_in = excluded.large_in,
                      large_out = excluded.large_out,
                      large_net = excluded.large_net,
                      medium_in = excluded.medium_in,
                      medium_out = excluded.medium_out,
                      medium_net = excluded.medium_net,
                      small_in = excluded.small_in,
                      small_out = excluded.small_out,
                      small_net = excluded.small_net,
                      total_in = excluded.total_in,
                      total_out = excluded.total_out,
                      total_net = excluded.total_net,
                      large_net_ratio = excluded.large_net_ratio,
                      small_net_ratio = excluded.small_net_ratio,
                      provider_timestamp = excluded.provider_timestamp,
                      payload = excluded.payload,
                      flow_payload = excluded.flow_payload,
                      fetched_at = excluded.fetched_at,
                      updated_at = excluded.updated_at
                    """,
                    (
                        snapshot_minute,
                        row["symbol"],
                        row["market"],
                        row["large_in"],
                        row["large_out"],
                        row["large_net"],
                        row["medium_in"],
                        row["medium_out"],
                        row["medium_net"],
                        row["small_in"],
                        row["small_out"],
                        row["small_net"],
                        row["total_in"],
                        row["total_out"],
                        row["total_net"],
                        row["large_net_ratio"],
                        row["small_net_ratio"],
                        row["provider_timestamp"],
                        Jsonb(payload),
                        Jsonb(flow_payload),
                        fetched_at,
                    ),
                )
                wrote_capital = True
            wrote_flow = self._upsert_realtime_capital_flow_rows(conn, flow_rows, fetched_at)
        return wrote_capital or wrote_flow > 0

    def _is_repeated_realtime_capital(
        self,
        conn: psycopg.Connection,
        row: dict[str, Any],
        snapshot_minute: datetime,
    ) -> bool:
        latest = conn.execute(
            """
            select provider_timestamp, large_in, large_out, medium_in, medium_out, small_in, small_out
            from lb_realtime_capital
            where symbol = %s
              and snapshot_minute >= ((%s at time zone 'Asia/Shanghai')::date at time zone 'Asia/Shanghai')
              and snapshot_minute < (((%s at time zone 'Asia/Shanghai')::date + interval '1 day') at time zone 'Asia/Shanghai')
            order by snapshot_minute desc
            limit 1
            """,
            (row["symbol"], snapshot_minute, snapshot_minute),
        ).fetchone()
        if latest is None:
            return False
        provider_timestamp = row.get("provider_timestamp")
        if provider_timestamp is not None and latest[0] is not None:
            return latest[0] == provider_timestamp
        return (
            latest[1] == row["large_in"]
            and latest[2] == row["large_out"]
            and latest[3] == row["medium_in"]
            and latest[4] == row["medium_out"]
            and latest[5] == row["small_in"]
            and latest[6] == row["small_out"]
        )

    def _upsert_realtime_capital_flow(
        self,
        conn: psycopg.Connection,
        symbol: str,
        market: str,
        flow_payload: Any,
        fetched_at: datetime,
    ) -> int:
        rows = _capital_flow_rows(symbol, market, flow_payload)
        return self._upsert_realtime_capital_flow_rows(conn, rows, fetched_at)

    def _upsert_realtime_capital_flow_rows(
        self,
        conn: psycopg.Connection,
        rows: list[dict[str, Any]],
        fetched_at: datetime,
    ) -> int:
        if not rows:
            return 0
        with conn.cursor() as cur:
            cur.executemany(
                """
                insert into lb_realtime_capital_flow
                  (symbol, market, flow_time, inflow, payload, fetched_at, updated_at)
                values (%s, %s, %s, %s, %s, %s, now())
                on conflict (symbol, flow_time) do update set
                  market = excluded.market,
                  inflow = excluded.inflow,
                  payload = excluded.payload,
                  fetched_at = excluded.fetched_at,
                  updated_at = excluded.updated_at
                """,
                [
                    (
                        row["symbol"],
                        row["market"],
                        row["flow_time"],
                        row["inflow"],
                        Jsonb(row["payload"]),
                        fetched_at,
                    )
                    for row in rows
                ],
            )
        return len(rows)

    def _insert_raw_snapshot(
        self,
        conn: psycopg.Connection,
        symbol: str,
        market: str,
        dataset: str,
        payload: Any,
        fetched_at: datetime,
    ) -> None:
        payload_hash = hashlib.sha256(json.dumps(payload, sort_keys=True, ensure_ascii=False).encode("utf-8")).hexdigest()
        conn.execute(
            """
            insert into lb_raw_snapshots (symbol, market, dataset, fetched_at, payload_hash, payload)
            values (%s, %s, %s, %s, %s, %s)
            """,
            (symbol, market, dataset, fetched_at, payload_hash, Jsonb(payload)),
        )

    def _upsert_daily_bars(
        self, conn: psycopg.Connection, symbol: str, market: str, payload: Any, updated_at: datetime
    ) -> None:
        for row in _ensure_rows(payload):
            trade_date = _parse_trade_date(row.get("time") or row.get("date") or row.get("timestamp"), market=market)
            if trade_date is None:
                continue
            conn.execute(
                """
                insert into lb_daily_bars
                  (symbol, market, trade_date, open, high, low, close, volume, turnover, adjusted, payload, updated_at)
                values (%s, %s, %s, %s, %s, %s, %s, %s, %s, true, %s, %s)
                on conflict (symbol, trade_date) do update set
                  market = excluded.market,
                  open = excluded.open,
                  high = excluded.high,
                  low = excluded.low,
                  close = excluded.close,
                  volume = excluded.volume,
                  turnover = excluded.turnover,
                  adjusted = excluded.adjusted,
                  payload = excluded.payload,
                  updated_at = excluded.updated_at
                """,
                (
                    symbol,
                    market,
                    trade_date,
                    _num(row.get("open")),
                    _num(row.get("high")),
                    _num(row.get("low")),
                    _num(row.get("close") or row.get("last")),
                    _num(row.get("volume")),
                    _num(row.get("turnover")),
                    Jsonb(row),
                    updated_at,
                ),
            )

    def _upsert_symbol(
        self, conn: psycopg.Connection, symbol: str, market: str, payload: Any, updated_at: datetime
    ) -> None:
        row = _first_row(payload)
        conn.execute(
            """
            insert into lb_symbols
              (symbol, market, name, exchange, currency, lot_size, total_shares, circulating_shares,
               eps, eps_ttm, bps, dividend, payload, updated_at)
            values (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
            on conflict (symbol) do update set
              market = excluded.market,
              name = excluded.name,
              exchange = excluded.exchange,
              currency = excluded.currency,
              lot_size = excluded.lot_size,
              total_shares = excluded.total_shares,
              circulating_shares = excluded.circulating_shares,
              eps = excluded.eps,
              eps_ttm = excluded.eps_ttm,
              bps = excluded.bps,
              dividend = excluded.dividend,
              payload = excluded.payload,
              updated_at = excluded.updated_at
            """,
            (
                symbol,
                market,
                row.get("name"),
                row.get("exchange"),
                row.get("currency"),
                _num(row.get("lot_size")),
                _num(row.get("total_shares")),
                _num(row.get("circulating_shares") or row.get("circ._shares")),
                _num(row.get("eps")),
                _num(row.get("eps_ttm")),
                _num(row.get("bps")),
                _num(row.get("dividend")),
                Jsonb(payload),
                updated_at,
            ),
        )

    def _upsert_calc_index(
        self, conn: psycopg.Connection, symbol: str, market: str, payload: Any, trade_date: date, updated_at: datetime
    ) -> None:
        row = _first_row(payload)
        conn.execute(
            """
            insert into lb_calc_index
              (symbol, market, trade_date, last_done, turnover, turnover_rate, mktcap, amplitude, volume_ratio,
               pe, pb, dps_rate, five_day_change_rate, ten_day_change_rate, half_year_change_rate, payload, updated_at)
            values (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
            on conflict (symbol, trade_date) do update set
              market = excluded.market,
              last_done = excluded.last_done,
              turnover = excluded.turnover,
              turnover_rate = excluded.turnover_rate,
              mktcap = excluded.mktcap,
              amplitude = excluded.amplitude,
              volume_ratio = excluded.volume_ratio,
              pe = excluded.pe,
              pb = excluded.pb,
              dps_rate = excluded.dps_rate,
              five_day_change_rate = excluded.five_day_change_rate,
              ten_day_change_rate = excluded.ten_day_change_rate,
              half_year_change_rate = excluded.half_year_change_rate,
              payload = excluded.payload,
              updated_at = excluded.updated_at
            """,
            (
                symbol,
                market,
                trade_date,
                _num(row.get("last_done")),
                _num(row.get("turnover")),
                _num(row.get("turnover_rate")),
                _num(row.get("mktcap")),
                _num(row.get("amplitude")),
                _num(row.get("volume_ratio")),
                _num(row.get("pe")),
                _num(row.get("pb")),
                _num(row.get("dps_rate")),
                _num(row.get("five_day_change_rate")),
                _num(row.get("ten_day_change_rate")),
                _num(row.get("half_year_change_rate")),
                Jsonb(payload),
                updated_at,
            ),
        )

    def _upsert_valuation(
        self, conn: psycopg.Connection, symbol: str, market: str, payload: Any, trade_date: date, updated_at: datetime
    ) -> None:
        row = _valuation_row(payload, symbol=symbol)
        self._upsert_valuation_row(conn, symbol, market, trade_date, row, payload, updated_at)
        for history_row in _valuation_history_rows(payload):
            history_date = history_row.pop("trade_date", None)
            if history_date is not None:
                self._upsert_valuation_row(conn, symbol, market, history_date, history_row, payload, updated_at)

    def _upsert_valuation_row(
        self,
        conn: psycopg.Connection,
        symbol: str,
        market: str,
        trade_date: date,
        row: dict[str, Any],
        payload: Any,
        updated_at: datetime,
    ) -> None:
        conn.execute(
            """
            insert into lb_valuation
              (symbol, market, trade_date, pe, pb, ps, roe, roa, net_margin, liabilities_assets, leverage,
               market_value, sales, net_income, industry_median_pe, industry_rank, payload, updated_at)
            values (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
            on conflict (symbol, trade_date) do update set
              market = excluded.market,
              pe = coalesce(excluded.pe, lb_valuation.pe),
              pb = coalesce(excluded.pb, lb_valuation.pb),
              ps = coalesce(excluded.ps, lb_valuation.ps),
              roe = coalesce(excluded.roe, lb_valuation.roe),
              roa = coalesce(excluded.roa, lb_valuation.roa),
              net_margin = coalesce(excluded.net_margin, lb_valuation.net_margin),
              liabilities_assets = coalesce(excluded.liabilities_assets, lb_valuation.liabilities_assets),
              leverage = coalesce(excluded.leverage, lb_valuation.leverage),
              market_value = coalesce(excluded.market_value, lb_valuation.market_value),
              sales = coalesce(excluded.sales, lb_valuation.sales),
              net_income = coalesce(excluded.net_income, lb_valuation.net_income),
              industry_median_pe = coalesce(excluded.industry_median_pe, lb_valuation.industry_median_pe),
              industry_rank = coalesce(excluded.industry_rank, lb_valuation.industry_rank),
              payload = coalesce(excluded.payload, lb_valuation.payload),
              updated_at = excluded.updated_at
            """,
            (
                symbol,
                market,
                trade_date,
                _num(row.get("pe")),
                _num(row.get("pb")),
                _num(row.get("ps")),
                _num(row.get("roe")),
                _num(row.get("roa")),
                _num(row.get("net_margin")),
                _num(row.get("liabilities_assets")),
                _num(row.get("leverage")),
                _num(row.get("market_value")),
                _num(row.get("sales")),
                _num(row.get("net_income")),
                _num(row.get("industry_median_pe")),
                row.get("industry_rank"),
                Jsonb(payload),
                updated_at,
            ),
        )

    def _upsert_financial_report(
        self, conn: psycopg.Connection, symbol: str, market: str, payload: Any, updated_at: datetime
    ) -> None:
        for item in _financial_report_items(payload):
            conn.execute(
                """
                insert into lb_financial_report
                  (symbol, market, report_type, report_period, fiscal_year, fp_end, field, name, value, ratio, yoy,
                   percent, industry_ranking, ranking_code, currency, payload, updated_at)
                values (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                on conflict (symbol, report_type, field, report_period, fiscal_year) do update set
                  market = excluded.market,
                  fp_end = excluded.fp_end,
                  name = excluded.name,
                  value = excluded.value,
                  ratio = excluded.ratio,
                  yoy = excluded.yoy,
                  percent = excluded.percent,
                  industry_ranking = excluded.industry_ranking,
                  ranking_code = excluded.ranking_code,
                  currency = excluded.currency,
                  payload = excluded.payload,
                  updated_at = excluded.updated_at
                """,
                (
                    symbol,
                    market,
                    item["report_type"],
                    item["report_period"],
                    item["fiscal_year"],
                    item["fp_end"],
                    item["field"],
                    item["name"],
                    _num(item["value"]),
                    item["ratio"],
                    item["yoy"],
                    item["percent"],
                    item["industry_ranking"],
                    item["ranking_code"],
                    item["currency"],
                    Jsonb(item["payload"]),
                    updated_at,
                ),
            )

    def _upsert_company_profile(
        self, conn: psycopg.Connection, symbol: str, market: str, payload: Any, updated_at: datetime
    ) -> None:
        self._ensure_company_tables(conn)
        row = payload if isinstance(payload, dict) else {}
        conn.execute(
            """
            insert into lb_company_profiles
              (symbol, market, company_name, name, ticker, region, exchange_market, category, founded, listing_date,
               employees, issue_price, shares_offered, chairman, manager, secretary, website, email, phone, fax,
               office_address, address, profile, icon, payload, updated_at)
            values (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
            on conflict (symbol) do update set
              market = excluded.market,
              company_name = excluded.company_name,
              name = excluded.name,
              ticker = excluded.ticker,
              region = excluded.region,
              exchange_market = excluded.exchange_market,
              category = excluded.category,
              founded = excluded.founded,
              listing_date = excluded.listing_date,
              employees = excluded.employees,
              issue_price = excluded.issue_price,
              shares_offered = excluded.shares_offered,
              chairman = excluded.chairman,
              manager = excluded.manager,
              secretary = excluded.secretary,
              website = excluded.website,
              email = excluded.email,
              phone = excluded.phone,
              fax = excluded.fax,
              office_address = excluded.office_address,
              address = excluded.address,
              profile = excluded.profile,
              icon = excluded.icon,
              payload = excluded.payload,
              updated_at = excluded.updated_at
            """,
            (
                symbol,
                market,
                row.get("company_name"),
                row.get("name"),
                row.get("ticker"),
                row.get("region"),
                row.get("market"),
                row.get("category"),
                _parse_date_text(row.get("founded")),
                _parse_date_text(row.get("listing_date")),
                _num(row.get("employees")),
                _num(row.get("issue_price")),
                _num(row.get("shares_offered")),
                row.get("chairman"),
                row.get("manager"),
                row.get("secretary"),
                row.get("website"),
                row.get("email"),
                row.get("Phone") or row.get("phone"),
                row.get("fax"),
                row.get("office_address"),
                row.get("address"),
                row.get("profile"),
                row.get("icon"),
                Jsonb(payload),
                updated_at,
            ),
        )

    def _upsert_executives(self, conn: psycopg.Connection, symbol: str, market: str, payload: Any, updated_at: datetime) -> None:
        self._ensure_company_tables(conn)
        conn.execute("delete from lb_company_executives where symbol = %s", (symbol,))
        for item in _executive_items(payload):
            conn.execute(
                """
                insert into lb_company_executives
                  (symbol, market, executive_id, name, name_en, name_zhcn, title, biography, photo, wiki_url, payload, updated_at)
                values (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                """,
                (
                    symbol,
                    market,
                    item.get("id") or f"{item.get('name', '')}:{item.get('title', '')}",
                    item.get("name"),
                    item.get("name_en"),
                    item.get("name_zhcn"),
                    item.get("title"),
                    item.get("biography"),
                    item.get("photo"),
                    item.get("wiki_url"),
                    Jsonb(item),
                    updated_at,
                ),
            )

    def _upsert_invest_relations(
        self, conn: psycopg.Connection, symbol: str, market: str, payload: Any, updated_at: datetime
    ) -> None:
        self._ensure_company_tables(conn)
        conn.execute("delete from lb_invest_relations where symbol = %s", (symbol,))
        for item in _list_items(payload, "invest_securities"):
            counter_id = str(item.get("counter_id") or "")
            conn.execute(
                """
                insert into lb_invest_relations
                  (symbol, market, related_symbol, related_counter_id, company_name, company_name_en, company_name_zhcn,
                   currency, percent_of_shares, shares_rank, shares_value, payload, updated_at)
                values (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                """,
                (
                    symbol,
                    market,
                    _counter_id_to_symbol(counter_id) if counter_id else None,
                    counter_id or None,
                    item.get("company_name"),
                    item.get("company_name_en"),
                    item.get("company_name_zhcn"),
                    item.get("currency"),
                    _num(item.get("percent_of_shares")),
                    _int(item.get("shares_rank")),
                    _num(item.get("shares_value")),
                    Jsonb(item),
                    updated_at,
                ),
            )

    def _upsert_operating_reviews(
        self, conn: psycopg.Connection, symbol: str, market: str, payload: Any, updated_at: datetime
    ) -> None:
        self._ensure_company_tables(conn)
        conn.execute("delete from lb_operating_reviews where symbol = %s", (symbol,))
        for item in _list_items(payload, "list"):
            financial = item.get("financial") if isinstance(item.get("financial"), dict) else {}
            conn.execute(
                """
                insert into lb_operating_reviews
                  (symbol, market, review_id, title, report, latest, review_text, web_url, currency, indicators, payload, updated_at)
                values (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                """,
                (
                    symbol,
                    market,
                    str(item.get("id") or ""),
                    item.get("title"),
                    item.get("report"),
                    bool(item.get("latest")),
                    item.get("txt"),
                    item.get("web_url"),
                    financial.get("currency"),
                    Jsonb(financial.get("indicators") or []),
                    Jsonb(item),
                    updated_at,
                ),
            )

    def _upsert_dividends(self, conn: psycopg.Connection, symbol: str, market: str, payload: Any, updated_at: datetime) -> None:
        self._ensure_company_tables(conn)
        conn.execute("delete from lb_dividends where symbol = %s", (symbol,))
        for item in _list_items(payload, "list"):
            conn.execute(
                """
                insert into lb_dividends
                  (symbol, market, dividend_id, counter_id, description, ex_date, record_date, payment_date, payload, updated_at)
                values (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                """,
                (
                    symbol,
                    market,
                    str(item.get("id") or ""),
                    item.get("counter_id"),
                    item.get("desc"),
                    _parse_date_text(item.get("ex_date")),
                    _parse_date_text(item.get("record_date")),
                    _parse_date_text(item.get("payment_date")),
                    Jsonb(item),
                    updated_at,
                ),
            )

    def _upsert_institution_rating(
        self, conn: psycopg.Connection, symbol: str, market: str, payload: Any, updated_at: datetime
    ) -> None:
        self._ensure_company_tables(conn)
        row = payload if isinstance(payload, dict) else {}
        instratings = row.get("instratings") if isinstance(row.get("instratings"), dict) else {}
        analyst = row.get("analyst") if isinstance(row.get("analyst"), dict) else {}
        evaluate = instratings.get("evaluate") if isinstance(instratings.get("evaluate"), dict) else {}
        conn.execute(
            """
            insert into lb_institution_ratings
              (symbol, market, updated_text, recommend, target_price, target_change, strong_buy, buy, hold, underperform, sell,
               analyst_total, industry_name, industry_rank, industry_total, payload, updated_at)
            values (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
            on conflict (symbol) do update set
              market = excluded.market,
              updated_text = excluded.updated_text,
              recommend = excluded.recommend,
              target_price = excluded.target_price,
              target_change = excluded.target_change,
              strong_buy = excluded.strong_buy,
              buy = excluded.buy,
              hold = excluded.hold,
              underperform = excluded.underperform,
              sell = excluded.sell,
              analyst_total = excluded.analyst_total,
              industry_name = excluded.industry_name,
              industry_rank = excluded.industry_rank,
              industry_total = excluded.industry_total,
              payload = excluded.payload,
              updated_at = excluded.updated_at
            """,
            (
                symbol,
                market,
                instratings.get("updated_at"),
                instratings.get("recommend"),
                _num(instratings.get("target")),
                _num(instratings.get("change")),
                _int(evaluate.get("strong_buy")),
                _int(evaluate.get("buy")),
                _int(evaluate.get("hold")),
                _int(evaluate.get("under")),
                _int(evaluate.get("sell")),
                _int((analyst.get("evaluate") or {}).get("total") if isinstance(analyst.get("evaluate"), dict) else None),
                analyst.get("industry_name"),
                _int(analyst.get("industry_rank")),
                _int(analyst.get("industry_total")),
                Jsonb(payload),
                updated_at,
            ),
        )

    def _upsert_consensus(self, conn: psycopg.Connection, symbol: str, market: str, payload: Any, updated_at: datetime) -> None:
        self._ensure_company_tables(conn)
        conn.execute("delete from lb_consensus where symbol = %s", (symbol,))
        currency = payload.get("currency") if isinstance(payload, dict) else None
        for period in _list_items(payload, "list"):
            for detail in period.get("details", []):
                if not isinstance(detail, dict):
                    continue
                conn.execute(
                    """
                    insert into lb_consensus
                      (symbol, market, fiscal_year, fiscal_period, period_text, metric_key, metric_name, currency,
                       actual, estimate, comp, comp_desc, comp_value, is_released, description, payload, updated_at)
                    values (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                    """,
                    (
                        symbol,
                        market,
                        _int(period.get("fiscal_year")),
                        str(period.get("fiscal_period") or ""),
                        period.get("period_text"),
                        detail.get("key"),
                        detail.get("name"),
                        currency,
                        _num(detail.get("actual")),
                        _num(detail.get("estimate")),
                        detail.get("comp"),
                        detail.get("comp_desc"),
                        _num(detail.get("comp_value")),
                        bool(detail.get("is_released")),
                        detail.get("description"),
                        Jsonb({"period": period, "detail": detail}),
                        updated_at,
                    ),
                )

    def _ensure_company_tables(self, conn: psycopg.Connection) -> None:
        conn.execute(
            """
            create table if not exists lb_company_profiles (
              symbol text primary key,
              market text not null,
              company_name text,
              name text,
              ticker text,
              region text,
              exchange_market text,
              category text,
              founded date,
              listing_date date,
              employees numeric,
              issue_price numeric,
              shares_offered numeric,
              chairman text,
              manager text,
              secretary text,
              website text,
              email text,
              phone text,
              fax text,
              office_address text,
              address text,
              profile text,
              icon text,
              payload jsonb not null,
              updated_at timestamptz not null
            )
            """
        )
        conn.execute(
            """
            create table if not exists lb_company_executives (
              id bigserial primary key,
              symbol text not null,
              market text not null,
              executive_id text,
              name text,
              name_en text,
              name_zhcn text,
              title text,
              biography text,
              photo text,
              wiki_url text,
              payload jsonb not null,
              updated_at timestamptz not null
            )
            """
        )
        conn.execute("create index if not exists idx_lb_company_executives_symbol on lb_company_executives(symbol)")
        conn.execute(
            """
            create table if not exists lb_invest_relations (
              id bigserial primary key,
              symbol text not null,
              market text not null,
              related_symbol text,
              related_counter_id text,
              company_name text,
              company_name_en text,
              company_name_zhcn text,
              currency text,
              percent_of_shares numeric,
              shares_rank integer,
              shares_value numeric,
              payload jsonb not null,
              updated_at timestamptz not null
            )
            """
        )
        conn.execute("create index if not exists idx_lb_invest_relations_symbol on lb_invest_relations(symbol)")
        conn.execute(
            """
            create table if not exists lb_operating_reviews (
              id bigserial primary key,
              symbol text not null,
              market text not null,
              review_id text,
              title text,
              report text,
              latest boolean,
              review_text text,
              web_url text,
              currency text,
              indicators jsonb not null,
              payload jsonb not null,
              updated_at timestamptz not null
            )
            """
        )
        conn.execute("create index if not exists idx_lb_operating_reviews_symbol on lb_operating_reviews(symbol)")
        conn.execute(
            """
            create table if not exists lb_dividends (
              id bigserial primary key,
              symbol text not null,
              market text not null,
              dividend_id text,
              counter_id text,
              description text,
              ex_date date,
              record_date date,
              payment_date date,
              payload jsonb not null,
              updated_at timestamptz not null
            )
            """
        )
        conn.execute("create index if not exists idx_lb_dividends_symbol on lb_dividends(symbol)")
        conn.execute(
            """
            create table if not exists lb_institution_ratings (
              symbol text primary key,
              market text not null,
              updated_text text,
              recommend text,
              target_price numeric,
              target_change numeric,
              strong_buy integer,
              buy integer,
              hold integer,
              underperform integer,
              sell integer,
              analyst_total integer,
              industry_name text,
              industry_rank integer,
              industry_total integer,
              payload jsonb not null,
              updated_at timestamptz not null
            )
            """
        )
        conn.execute(
            """
            create table if not exists lb_consensus (
              id bigserial primary key,
              symbol text not null,
              market text not null,
              fiscal_year integer,
              fiscal_period text,
              period_text text,
              metric_key text,
              metric_name text,
              currency text,
              actual numeric,
              estimate numeric,
              comp text,
              comp_desc text,
              comp_value numeric,
              is_released boolean,
              description text,
              payload jsonb not null,
              updated_at timestamptz not null
            )
            """
        )
        conn.execute("create index if not exists idx_lb_consensus_symbol on lb_consensus(symbol)")


def _ensure_rows(payload: Any) -> list[dict[str, Any]]:
    if isinstance(payload, list):
        return [row for row in payload if isinstance(row, dict)]
    if isinstance(payload, dict):
        return [payload]
    return []


def _first_row(payload: Any) -> dict[str, Any]:
    rows = _ensure_rows(payload)
    return rows[0] if rows else {}


def _valuation_row(payload: Any, symbol: str | None = None) -> dict[str, Any]:
    if isinstance(payload, dict):
        rows = payload.get("list")
        if isinstance(rows, list) and rows:
            first = dict(rows[0])
        else:
            first = {}
        overview_metrics = payload.get("overview", {}).get("metrics", {})
        if isinstance(overview_metrics, dict):
            for metric_name in ("pe", "pb", "ps", "roe", "roa", "net_margin", "liabilities_assets", "leverage"):
                metric_payload = overview_metrics.get(metric_name)
                if isinstance(metric_payload, dict):
                    metric_value = _metric_number_text(metric_payload.get("metric") or metric_payload.get("value"))
                    if metric_value is not None:
                        first.setdefault(metric_name, metric_value)
        overview_pe = overview_metrics.get("pe", {}) if isinstance(overview_metrics, dict) else {}
        if isinstance(overview_pe, dict):
            first.setdefault("industry_median_pe", overview_pe.get("industry_median"))
            first.setdefault("industry_rank", _industry_rank_from_desc(overview_pe.get("desc")))
        market_value = _market_cap_from_valuation_stocks(payload.get("stocks"), symbol)
        if market_value is not None:
            first.setdefault("market_value", market_value)
        return first
    return {}


def _valuation_history_rows(payload: Any) -> list[dict[str, Any]]:
    if not isinstance(payload, dict):
        return []
    history = payload.get("history")
    metrics = history.get("metrics") if isinstance(history, dict) else None
    if not isinstance(metrics, dict):
        return []

    rows_by_date: dict[date, dict[str, Any]] = {}
    for metric_name in ("pe", "pb", "ps"):
        metric_payload = metrics.get(metric_name)
        points = metric_payload.get("list") if isinstance(metric_payload, dict) else None
        if not isinstance(points, list):
            continue
        for point in points:
            if not isinstance(point, dict):
                continue
            trade_date = _date_from_epoch(point.get("timestamp"))
            metric_value = _metric_number_text(point.get("value"))
            if trade_date is None or metric_value is None:
                continue
            rows_by_date.setdefault(trade_date, {"trade_date": trade_date})[metric_name] = metric_value

    return [rows_by_date[trade_date] for trade_date in sorted(rows_by_date)]


def _metric_number_text(value: Any) -> str | None:
    if value is None:
        return None
    text = str(value).strip().replace(",", "")
    for suffix in ("x", "X", "%"):
        if text.endswith(suffix):
            text = text[: -len(suffix)]
    text = text.strip()
    return text or None


def _market_cap_from_valuation_stocks(stocks: Any, symbol: str | None) -> Any:
    if not isinstance(stocks, dict) or not symbol:
        return None
    candidates = {_symbol_to_counter_id(symbol), f"ST/{symbol[-2:]}/{symbol[:-3]}"}
    for key in candidates:
        row = stocks.get(key)
        if isinstance(row, dict) and row.get("market_cap") is not None:
            return row.get("market_cap")
    return None


def _symbol_to_counter_id(symbol: str) -> str:
    code, _, market = symbol.partition(".")
    return f"ST/{market}/{code}" if code and market else symbol


def _financial_report_items(payload: Any) -> list[dict[str, Any]]:
    items: list[dict[str, Any]] = []
    report_root = payload.get("list", {}) if isinstance(payload, dict) else {}
    for report_type, report_payload in report_root.items():
        indicators = report_payload.get("indicators", []) if isinstance(report_payload, dict) else []
        for indicator in indicators:
            currency = indicator.get("currency")
            for account in indicator.get("accounts", []):
                for value in account.get("values", []):
                    items.append(
                        {
                            "report_type": str(report_type),
                            "report_period": value.get("period"),
                            "fiscal_year": _int(value.get("year")),
                            "fp_end": _date_from_epoch(value.get("fp_end")),
                            "field": str(account.get("field") or ""),
                            "name": account.get("name"),
                            "value": value.get("value"),
                            "ratio": value.get("ratio"),
                            "yoy": value.get("yoy"),
                            "percent": bool(account.get("percent")),
                            "industry_ranking": account.get("industry_ranking"),
                            "ranking_code": account.get("ranking_code"),
                            "currency": currency,
                            "payload": {"indicator": indicator.get("title"), "account": account, "value": value},
                        }
                    )
    return [item for item in items if item["field"]]


def _list_items(payload: Any, key: str) -> list[dict[str, Any]]:
    if not isinstance(payload, dict):
        return []
    items = payload.get(key)
    return [item for item in items if isinstance(item, dict)] if isinstance(items, list) else []


def _executive_items(payload: Any) -> list[dict[str, Any]]:
    items: list[dict[str, Any]] = []
    for group in _list_items(payload, "professional_list"):
        professionals = group.get("professionals")
        if isinstance(professionals, list):
            items.extend(item for item in professionals if isinstance(item, dict))
    return items


def _num(value: Any) -> Any:
    if value is None:
        return None
    try:
        cleaned = str(value).strip().replace(",", "")
    except Exception:
        return None
    if cleaned in {"", "-", "--", "N/A", "n/a", "null", "None"}:
        return None
    return cleaned


def _change_pct_text(value: Any, last_done: Any, prev_close: Any) -> str | None:
    parsed = _float_or_none(value)
    if parsed is None:
        last_num = _float_or_none(last_done)
        prev_num = _float_or_none(prev_close)
        if last_num is None or prev_num in (None, 0):
            return None
        parsed = (last_num - prev_num) / prev_num * 100
    return f"{parsed:.4f}"


def _float_or_none(value: Any) -> float | None:
    if value is None:
        return None
    try:
        return float(str(value).strip().replace(",", ""))
    except (TypeError, ValueError):
        return None


def _capital_row(symbol: str, payload: dict[str, Any]) -> dict[str, Any] | None:
    capital_in = payload.get("capital_in") if isinstance(payload.get("capital_in"), dict) else {}
    capital_out = payload.get("capital_out") if isinstance(payload.get("capital_out"), dict) else {}
    large_in = _num(capital_in.get("large"))
    large_out = _num(capital_out.get("large"))
    medium_in = _num(capital_in.get("medium"))
    medium_out = _num(capital_out.get("medium"))
    small_in = _num(capital_in.get("small"))
    small_out = _num(capital_out.get("small"))
    values = [large_in, large_out, medium_in, medium_out, small_in, small_out]
    if all(value is None for value in values):
        return None

    large_net = _decimal_diff(large_in, large_out)
    medium_net = _decimal_diff(medium_in, medium_out)
    small_net = _decimal_diff(small_in, small_out)
    total_in = _decimal_sum(large_in, medium_in, small_in)
    total_out = _decimal_sum(large_out, medium_out, small_out)
    total_net = _decimal_diff(total_in, total_out)
    return {
        "symbol": str(payload.get("symbol") or symbol),
        "market": _market_from_symbol(str(payload.get("symbol") or symbol)),
        "large_in": large_in,
        "large_out": large_out,
        "large_net": large_net,
        "medium_in": medium_in,
        "medium_out": medium_out,
        "medium_net": medium_net,
        "small_in": small_in,
        "small_out": small_out,
        "small_net": small_net,
        "total_in": total_in,
        "total_out": total_out,
        "total_net": total_net,
        "large_net_ratio": _decimal_ratio(large_net, total_in),
        "small_net_ratio": _decimal_ratio(small_net, total_in),
        "provider_timestamp": _parse_datetime(payload.get("timestamp")),
    }


def _capital_flow_rows(symbol: str, market: str, payload: Any) -> list[dict[str, Any]]:
    if not isinstance(payload, list):
        return []
    rows: list[dict[str, Any]] = []
    for item in payload:
        if not isinstance(item, dict):
            continue
        flow_time = _parse_flow_datetime(item.get("time") or item.get("timestamp"))
        if flow_time is None:
            continue
        rows.append(
            {
                "symbol": symbol,
                "market": market,
                "flow_time": flow_time,
                "inflow": _num(item.get("inflow")),
                "payload": item,
            }
        )
    return rows


def _trade_rows(symbol: str, payload: Any) -> list[dict[str, Any]]:
    if not isinstance(payload, list):
        return []
    market = _market_from_symbol(symbol)
    rows: list[dict[str, Any]] = []
    for item in payload:
        if not isinstance(item, dict):
            continue
        trade_time = _parse_flow_datetime(item.get("timestamp") or item.get("time"))
        if trade_time is None:
            continue
        rows.append(
            {
                "symbol": symbol,
                "market": market,
                "trade_time": trade_time,
                "price": _num(item.get("price")),
                "volume": _num(item.get("volume")),
                "trade_type": item.get("trade_type"),
                "direction": str(item.get("direction") or ""),
                "trade_session": str(item.get("trade_session") or ""),
                "payload": item,
            }
        )
    return rows


def _intraday_rows(symbol: str, payload: Any) -> list[dict[str, Any]]:
    if not isinstance(payload, list):
        return []
    market = _market_from_symbol(symbol)
    rows: list[dict[str, Any]] = []
    for item in payload:
        if not isinstance(item, dict):
            continue
        line_time = _parse_flow_datetime(item.get("timestamp") or item.get("time"))
        if line_time is None:
            continue
        rows.append(
            {
                "symbol": symbol,
                "market": market,
                "line_time": line_time,
                "price": _num(item.get("price")),
                "avg_price": _num(item.get("avg_price")),
                "volume": _num(item.get("volume")),
                "turnover": _num(item.get("turnover")),
                "payload": item,
            }
        )
    return rows


def _book_imbalance(bid_volume: Any, ask_volume: Any) -> str | None:
    from decimal import Decimal, InvalidOperation

    if bid_volume is None or ask_volume is None:
        return None
    try:
        bid = Decimal(str(bid_volume))
        ask = Decimal(str(ask_volume))
        total = bid + ask
        if total == 0:
            return None
        return str((bid - ask) / total)
    except InvalidOperation:
        return None


def _decimal_sum(*values: Any) -> str | None:
    from decimal import Decimal, InvalidOperation

    total = Decimal("0")
    seen = False
    for value in values:
        if value is None:
            continue
        try:
            total += Decimal(str(value))
        except InvalidOperation:
            continue
        seen = True
    return str(total) if seen else None


def _decimal_diff(left: Any, right: Any) -> str | None:
    from decimal import Decimal, InvalidOperation

    if left is None or right is None:
        return None
    try:
        return str(Decimal(str(left)) - Decimal(str(right)))
    except InvalidOperation:
        return None


def _decimal_ratio(numerator: Any, denominator: Any) -> str | None:
    from decimal import Decimal, InvalidOperation

    if numerator is None or denominator is None:
        return None
    try:
        base = Decimal(str(denominator))
        if base == 0:
            return None
        return str(Decimal(str(numerator)) / base)
    except InvalidOperation:
        return None


def _int(value: Any) -> int | None:
    try:
        return int(value)
    except (TypeError, ValueError):
        return None


def _parse_date_text(value: Any) -> date | None:
    if not value:
        return None
    text = str(value).strip().replace(".", "-").replace("/", "-")
    try:
        return datetime.strptime(text[:10], "%Y-%m-%d").date()
    except ValueError:
        return None


def _counter_id_to_symbol(counter_id: str) -> str:
    parts = str(counter_id).split("/")
    if len(parts) < 3:
        return str(counter_id)
    market = parts[1].upper()
    code = parts[2]
    suffix = {"SH": "SH", "SZ": "SZ", "HK": "HK", "US": "US", "SG": "SG"}.get(market, market)
    return f"{int(code)}.{suffix}" if market == "HK" and code.isdigit() else f"{code}.{suffix}"


def _market_from_symbol(symbol: str) -> str:
    suffix = symbol.rsplit(".", 1)[-1].lower() if "." in symbol else ""
    if suffix in {"sh", "sz"}:
        return "cn"
    return suffix


def _parse_datetime(value: Any) -> datetime | None:
    if not value:
        return None
    text = str(value).strip()
    if text.isdigit():
        return datetime.fromtimestamp(int(text), tz=timezone.utc)
    try:
        parsed = datetime.fromisoformat(text.replace("Z", "+00:00"))
    except ValueError:
        return None
    if parsed.tzinfo is None:
        return parsed.replace(tzinfo=SHANGHAI_TZ)
    return parsed


def _parse_flow_datetime(value: Any) -> datetime | None:
    if not value:
        return None
    text = str(value).strip().replace("Z", "+00:00")
    if text.isdigit():
        return datetime.fromtimestamp(int(text), tz=timezone.utc)
    try:
        parsed = datetime.fromisoformat(text)
    except ValueError:
        try:
            parsed = datetime.strptime(text, "%Y-%m-%d %H:%M:%S")
        except ValueError:
            return None
    if parsed.tzinfo is None:
        return parsed.replace(tzinfo=SHANGHAI_TZ)
    return parsed


def _parse_trade_date(value: Any, market: str | None = None) -> date | None:
    if not value:
        return None
    text = str(value)
    if text.isdigit():
        parsed = datetime.fromtimestamp(int(text), tz=timezone.utc)
        return _market_trade_date(parsed, market)
    try:
        parsed = datetime.fromisoformat(text.replace("Z", "+00:00"))
        return _market_trade_date(parsed, market)
    except ValueError:
        try:
            return datetime.strptime(text[:10], "%Y-%m-%d").date()
        except ValueError:
            return None


def _market_trade_date(value: datetime, market: str | None) -> date:
    if value.tzinfo is None:
        value = value.replace(tzinfo=timezone.utc)
    market_key = str(market or "").lower()
    if market_key in {"cn", "hk"}:
        return value.astimezone(ZoneInfo("Asia/Shanghai")).date()
    if market_key == "sg":
        return value.astimezone(ZoneInfo("Asia/Singapore")).date()
    if market_key == "us":
        return value.astimezone(ZoneInfo("America/New_York")).date()
    return value.date()


def _date_from_epoch(value: Any) -> date | None:
    if not value:
        return None
    try:
        return datetime.fromtimestamp(int(value), tz=timezone.utc).date()
    except (TypeError, ValueError):
        return None


def _industry_rank_from_desc(desc: Any) -> str | None:
    if not desc:
        return None
    import re

    match = re.search(r"行业排名\s*<strong>([^<]+)</strong>", str(desc))
    return match.group(1) if match else None


def _now() -> datetime:
    return datetime.now(timezone.utc).astimezone()
