from __future__ import annotations

import json
import os
from html import escape as html_escape
from datetime import datetime
from typing import Any

import psycopg

from longbridge_stock import clickhouse_realtime
from longbridge_stock.market_sessions import SHANGHAI_TZ
from longbridge_stock.quant_regime import quant_regime_text


DEFAULT_DSN = os.getenv("POSTGRES_DSN") or os.getenv("LONGBRIDGE_PG_DSN") or "dbname=longbridge_stock user=alwin host=/var/run/postgresql"


def generate_notification_content(payload: dict[str, Any]) -> dict[str, Any]:
    now = datetime.now(SHANGHAI_TZ)
    markets = normalize_markets(payload.get("markets") or [])
    strategies = normalize_strategies(payload.get("strategies") or payload.get("services") or [])
    limit = max(1, min(int(payload.get("limit") or 5), 10))
    sections: list[dict[str, Any]] = []

    if wants_strategy(strategies, ["us_fast", "美股fast", "美股 fast"]):
        sections.append(build_us_fast_section(limit=limit))

    if wants_strategy(strategies, ["top3", "盘中强势池", "盘中推荐"]):
        for market in [item for item in markets if item in {"hk", "cn"}]:
            sections.append(build_intraday_pool_section(market=market, limit=limit))

    if wants_strategy(strategies, ["52w", "52周", "新高"]):
        for market in [item for item in markets if item in {"hk", "cn"}]:
            sections.append(build_52w_section(market=market, limit=limit))

    if wants_strategy(strategies, ["capital", "资金", "潜伏", "ambush"]):
        for market in markets or ["cn", "hk", "us"]:
            sections.append(build_capital_ambush_section(market=market, limit=limit))

    if not sections:
        for market in markets:
            if market == "us":
                sections.append(build_us_fast_section(limit=limit))
            elif market in {"hk", "cn"}:
                sections.append(build_intraday_pool_section(market=market, limit=limit))

    sections = [section for section in sections if section]
    item_count = sum(len(section.get("rows") or []) for section in sections)
    title = str(payload.get("rule_name") or "股票策略提醒").strip() or "股票策略提醒"
    markdown = render_markdown(title=title, sections=sections, now=now)
    html = render_html(title=title, sections=sections, now=now)
    return {
        "success": True,
        "subject": f"{title}：{item_count}只候选股票" if item_count else f"{title}：本轮无达标股票",
        "markdown": markdown,
        "html": html,
        "sections": sections,
        "item_count": item_count,
        "generated_at": now.isoformat(timespec="seconds"),
    }


def normalize_markets(raw: list[Any]) -> list[str]:
    output: list[str] = []
    for item in raw:
        value = str(item or "").strip().lower()
        mapped = {"us": "us", "hk": "hk", "cn": "cn", "a": "cn", "all": ""}.get(value, value)
        if value == "all":
            output.extend(["us", "hk", "cn"])
        elif mapped in {"us", "hk", "cn"} and mapped not in output:
            output.append(mapped)
    return output


def normalize_strategies(raw: list[Any]) -> list[str]:
    output: list[str] = []
    for item in raw:
        if isinstance(item, dict):
            text = " ".join(str(item.get(key) or "") for key in ["strategy_id", "id", "title", "name"])
        else:
            text = str(item or "")
        text = text.strip().lower()
        if text:
            output.append(text)
    return output


def wants_strategy(strategies: list[str], keywords: list[str]) -> bool:
    if not strategies:
        return False
    lowered = [keyword.lower() for keyword in keywords]
    return any(any(keyword in item for keyword in lowered) for item in strategies)


def load_sector_map(symbols: list[str]) -> dict[str, str]:
    clean_symbols = []
    seen = set()
    for symbol in symbols:
        key = normalize_symbol_key(symbol)
        if key and key not in seen:
            clean_symbols.append(key)
            seen.add(key)
    if not clean_symbols:
        return {}

    try:
        board_info = clickhouse_realtime.fetch_eastmoney_stock_board_info(clean_symbols)
    except Exception:
        board_info = {}

    try:
        profile_industries = clickhouse_realtime.fetch_eastmoney_profile_industries(clean_symbols)
    except Exception:
        profile_industries = {}

    output: dict[str, str] = {}
    for symbol in clean_symbols:
        info = board_info.get(symbol) or {}
        sector = format_sector_info(info, fallback=profile_industries.get(symbol))
        if sector != "-":
            output[symbol] = sector
    return output


def normalize_symbol_key(symbol: Any) -> str:
    return str(symbol or "").strip().upper()


def format_sector_info(info: dict[str, Any] | None, *, fallback: Any = None) -> str:
    info = info or {}
    industry = clean_sector_text(info.get("industry") or fallback)
    region = clean_sector_text(info.get("region_board"))
    concepts = [
        item
        for item in normalize_concepts(info.get("concepts"))
        if item and item not in {industry, region}
    ][:2]

    parts = []
    if industry:
        parts.append(industry)
    if concepts:
        parts.append("、".join(concepts))
    elif region:
        parts.append(region)
    return "；".join(parts) if parts else "-"


def normalize_concepts(value: Any) -> list[str]:
    if value is None:
        return []
    if isinstance(value, str):
        parsed = None
        if value.strip().startswith("["):
            try:
                parsed = json.loads(value)
            except (TypeError, ValueError):
                parsed = None
        if isinstance(parsed, list):
            raw_items = parsed
        else:
            raw_items = value.replace("，", ",").replace("、", ",").split(",")
    elif isinstance(value, (list, tuple, set)):
        raw_items = list(value)
    else:
        raw_items = [value]

    items = []
    seen = set()
    for item in raw_items:
        text = clean_sector_text(item)
        if text and text not in seen:
            items.append(text)
            seen.add(text)
    return items


def clean_sector_text(value: Any) -> str:
    text = str(value or "").strip()
    return "" if text.lower() in {"", "-", "none", "null", "nan", "未知"} else text


def build_us_fast_section(*, limit: int) -> dict[str, Any]:
    rows: list[dict[str, Any]] = []
    try:
        with psycopg.connect(DEFAULT_DSN) as conn:
            db_rows = conn.execute(
                """
                with latest as (
                  select max(run_time) as run_time
                  from lb_us_fast_candidate_pool
                  where trade_date = (now() at time zone 'Asia/Shanghai')::date
                )
                select p.symbol, p.name, p.score, p.output_stage, p.decision, p.risk_score,
                       p.profit_probability, p.expected_return, p.entry_price, p.status, p.payload
                from lb_us_fast_candidate_pool p
                join latest l on p.run_time = l.run_time
                where p.trade_date = (now() at time zone 'Asia/Shanghai')::date
                  and coalesce(p.decision, '') <> 'avoid'
                  and coalesce(p.status, '') <> 'blocked'
                order by p.rank asc
                limit %s
                """,
                (limit,),
            ).fetchall()
    except Exception as exc:
        return empty_section("美股 Fast 盘中推荐", f"读取美股候选池失败：{exc}")

    sector_by_symbol = load_sector_map([str(row[0]) for row in db_rows])
    for row in db_rows:
        symbol, name, score, stage, decision, risk_score, probability, expected_return, price, status, payload = row
        detail = payload if isinstance(payload, dict) else safe_json(payload)
        symbol_key = normalize_symbol_key(symbol)
        rows.append(
            {
                "symbol": str(symbol),
                "name": str(name or symbol),
                "price": num(price),
                "change_pct": num(detail.get("change_pct")),
                "sector": sector_by_symbol.get(symbol_key) or str(detail.get("industry") or "-"),
                "opportunity": us_opportunity_text(probability, expected_return, stage),
                "reason": compact_reason(
                    [
                        f"胜率{pct(probability)}",
                        f"预期收益{pct(expected_return)}" if expected_return is not None else "",
                        technical_position(detail),
                    ]
                ),
                "risk": risk_text(risk_score, detail),
                "score": num(score),
                "status": str(status or decision or stage or ""),
            }
        )
    return {"title": "美股 Fast 盘中推荐", "market": "US", "rows": rows, "empty": "本轮没有达到买入条件的美股。"}


def build_intraday_pool_section(*, market: str, limit: int) -> dict[str, Any]:
    label = market_label(market)
    try:
        rows = clickhouse_realtime.fetch_intraday_candidate_pool_entries(
            trade_date=datetime.now(SHANGHAI_TZ).date(),
            market=market,
            max_rank=limit,
        )
    except Exception as exc:
        return empty_section(f"{label}盘中推荐", f"读取盘中候选池失败：{exc}")

    rendered = []
    sector_by_symbol = load_sector_map([str(row.get("symbol") or "") for row in rows[:limit]])
    for row in rows[:limit]:
        payload = safe_json(row.get("payload"))
        source = payload.get("source") if isinstance(payload.get("source"), dict) else {}
        shape = payload.get("shape") if isinstance(payload.get("shape"), dict) else {}
        quant_regime = payload.get("quant_regime") if isinstance(payload.get("quant_regime"), dict) else {}
        symbol_key = normalize_symbol_key(row.get("symbol"))
        rendered.append(
            {
                "symbol": str(row.get("symbol") or ""),
                "name": str(row.get("name") or row.get("symbol") or ""),
                "price": num(row.get("last")),
                "change_pct": num(row.get("change_pct")),
                "sector": sector_by_symbol.get(symbol_key) or str(source.get("industry") or "-"),
                "opportunity": pool_stage_text(payload, row),
                "shape": shape_text(shape),
                "quant_regime": quant_regime_text(quant_regime),
                "reason": compact_reason([str(row.get("reason") or ""), fund_text(row), buy_zone_text(row)]),
                "risk": f"跌破{fmt(row.get('risk_line'))}先退出观察。",
                "score": num(row.get("score")),
            }
        )
    return {"title": f"{label}盘中推荐", "market": market.upper(), "rows": rendered, "empty": f"本轮{label}没有达标股票。"}


def build_52w_section(*, market: str, limit: int) -> dict[str, Any]:
    label = market_label(market)
    database = clickhouse_realtime._ident(clickhouse_realtime._database())
    market_sql = clickhouse_realtime._sql_string(market)
    try:
        rows = clickhouse_realtime._query_json_each_row(
            f"""
            select *
            from {database}.lb_52w_high_model_recommendations final
            where trade_date = today()
              and market = {market_sql}
              and snapshot_minute = (
                select max(snapshot_minute)
                from {database}.lb_52w_high_model_recommendations final
                where trade_date = today()
                  and market = {market_sql}
              )
            order by confidence desc, close_break_pct desc
            limit {limit}
            """
        )
    except Exception as exc:
        return empty_section(f"{label}52周新高推荐", f"读取52周新高结果失败：{exc}")

    rendered = []
    sector_by_symbol = load_sector_map([str(row.get("symbol") or "") for row in rows])
    for row in rows:
        payload = safe_json(row.get("payload"))
        symbol_key = normalize_symbol_key(row.get("symbol"))
        rendered.append(
            {
                "symbol": str(row.get("symbol") or ""),
                "name": str(row.get("name") or row.get("symbol") or ""),
                "price": num(row.get("close")),
                "change_pct": num(payload.get("change_pct")),
                "sector": sector_by_symbol.get(symbol_key) or str(payload.get("industry") or "-"),
                "opportunity": f"突破52周前高，模型置信度{pct(row.get('confidence'))}",
                "reason": compact_reason(
                    [
                        f"现价高于前高{fmt(row.get('prev_high'))}",
                        f"突破幅度{pct(row.get('close_break_pct'), scale=False)}",
                        f"量能约{fmt(row.get('turnover_ratio20'))}倍",
                        f"收盘位置{pct(row.get('close_pos'))}",
                    ]
                ),
                "risk": "如果冲高回落到前高线下方，先降级为观察。",
                "score": num(row.get("confidence")),
            }
        )
    return {"title": f"{label}52周新高推荐", "market": market.upper(), "rows": rendered, "empty": f"本轮{label}没有52周新高达标股票。"}


def build_capital_ambush_section(*, market: str, limit: int) -> dict[str, Any]:
    label = market_label(market)
    database = clickhouse_realtime._ident(clickhouse_realtime._database())
    market_sql = clickhouse_realtime._sql_string(market)
    try:
        rows = clickhouse_realtime._query_json_each_row(
            f"""
            select *
            from {database}.lb_factor_candidate_snapshots final
            where trade_date = today()
              and market = {market_sql}
              and source = 'capital_ambush'
              and signal_time = (
                select max(signal_time)
                from {database}.lb_factor_candidate_snapshots final
                where trade_date = today()
                  and market = {market_sql}
                  and source = 'capital_ambush'
              )
            order by score desc nulls last
            limit {limit}
            """
        )
    except Exception as exc:
        return empty_section(f"{label}资金持续流入观察", f"读取资金潜伏结果失败：{exc}")

    rendered = []
    sector_by_symbol = load_sector_map([str(row.get("symbol") or "") for row in rows])
    for row in rows:
        features = safe_json(row.get("features"))
        symbol_key = normalize_symbol_key(row.get("symbol"))
        rendered.append(
            {
                "symbol": str(row.get("symbol") or ""),
                "name": str(row.get("name") or row.get("symbol") or ""),
                "price": num(row.get("entry_price")),
                "change_pct": num(features.get("change_pct")),
                "sector": sector_by_symbol.get(symbol_key) or "-",
                "opportunity": "资金持续流入，但涨幅还没有完全释放。",
                "reason": compact_reason([fund_text(features), f"资金占成交{pct(features.get('net_turnover_ratio'), scale=False)}", f"日内位置{pct(features.get('close_pos'))}"]),
                "risk": "这是埋伏观察，不是追高买入；放量突破或回踩不破再确认。",
                "score": num(row.get("score")),
            }
        )
    return {"title": f"{label}资金持续流入观察", "market": market.upper(), "rows": rendered, "empty": f"本轮{label}没有资金潜伏候选。"}


def render_markdown(*, title: str, sections: list[dict[str, Any]], now: datetime) -> str:
    lines = [
        f"# {title}",
        "",
        f"> 更新时间：{now.strftime('%Y-%m-%d %H:%M')}。只展示当前策略筛出的股票；没有达标会明确写出来。",
        "",
    ]
    if not sections:
        lines.append("本轮没有可展示的策略结果。")
        return "\n".join(lines)

    for section in sections:
        rows = section.get("rows") or []
        lines.extend([f"## {section.get('title')}", ""])
        if not rows:
            lines.extend([str(section.get("empty") or "本轮无达标股票。"), ""])
            continue
        lines.extend(["| 股票 | 现价 | 板块 | 机会 | 形态 | 长期 | 买入理由 | 风险 |", "| --- | --- | --- | --- | --- | --- | --- | --- |"])
        for row in rows:
            stock = f"{row.get('symbol')} {row.get('name')}".strip()
            price = fmt(row.get("price"))
            if row.get("change_pct") is not None:
                price = f"{price}（{pct(row.get('change_pct'), scale=False)}）"
            lines.append(
                "| "
                + " | ".join(
                    escape_cell(value)
                    for value in [
                        stock,
                        price,
                        row.get("sector") or "-",
                        row.get("opportunity") or "-",
                        row.get("shape") or "-",
                        row.get("quant_regime") or "-",
                        row.get("reason") or "-",
                        row.get("risk") or "-",
                    ]
                )
                + " |"
            )
        lines.append("")
    lines.append("提示：以上是策略提醒，不等于无脑买入。优先小仓位、看承接，跌破风险位要及时退出。")
    return "\n".join(lines).strip() + "\n"


def render_html(*, title: str, sections: list[dict[str, Any]], now: datetime) -> str:
    style = """
body{margin:0;padding:0;background:#f5f7fb;color:#111827;font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Arial,"Microsoft YaHei",sans-serif;line-height:1.55}
.wrap{max-width:980px;margin:0 auto;padding:24px}
.panel{background:#fff;border:1px solid #e5e7eb;border-radius:10px;padding:20px}
h1{font-size:22px;margin:0 0 10px;color:#111827}
h2{font-size:17px;margin:24px 0 10px;color:#111827}
.meta{margin:0 0 18px;color:#4b5563;font-size:13px}
.empty{padding:12px 14px;background:#f9fafb;border:1px solid #e5e7eb;border-radius:8px;color:#4b5563}
table{width:100%;border-collapse:collapse;margin:8px 0 18px;font-size:13px}
th{background:#f3f4f6;color:#374151;font-weight:700;text-align:left}
th,td{border:1px solid #e5e7eb;padding:9px 10px;vertical-align:top}
td.stock{font-weight:700;color:#111827;white-space:nowrap}
td.price{white-space:nowrap;color:#111827}
.field-label{display:none}
.field-value{display:inline}
.tip{margin-top:16px;padding:12px 14px;background:#fff7ed;border:1px solid #fed7aa;border-radius:8px;color:#7c2d12;font-size:13px}
@media screen and (max-width:640px){
  .wrap{padding:10px}
  .panel{border-radius:8px;padding:12px}
  h1{font-size:18px;line-height:1.35}
  h2{font-size:15px;margin:18px 0 8px}
  table,thead,tbody,tr,td{display:block;width:100%;box-sizing:border-box}
  table{border:0;margin:8px 0 14px;font-size:14px}
  thead{display:none}
  tr{margin:0 0 12px;border:1px solid #dbe3ef;border-radius:8px;background:#ffffff;overflow:hidden}
  td{border:0;border-bottom:1px solid #eef2f7;padding:9px 10px;white-space:normal!important;word-break:break-word}
  td:last-child{border-bottom:0}
  .field-label{display:block;margin-bottom:3px;color:#6b7280;font-size:12px;font-weight:700}
  .field-value{display:block;color:#111827}
  td.stock .field-value{font-size:15px;font-weight:800}
  td.price .field-value{font-weight:700;color:#b45309}
}
""".strip()
    parts = [
        "<!doctype html>",
        '<html lang="zh-CN">',
        "<head>",
        '<meta charset="utf-8">',
        f"<title>{html_escape(title)}</title>",
        f"<style>{style}</style>",
        "</head>",
        "<body>",
        '<div class="wrap"><div class="panel">',
        f"<h1>{html_escape(title)}</h1>",
        f'<p class="meta">更新时间：{html_escape(now.strftime("%Y-%m-%d %H:%M"))}。只展示当前策略筛出的股票；没有达标会明确写出来。</p>',
    ]
    if not sections:
        parts.append('<p class="empty">本轮没有可展示的策略结果。</p>')
    for section in sections:
        rows = section.get("rows") or []
        parts.append(f"<h2>{html_escape(str(section.get('title') or '策略结果'))}</h2>")
        if not rows:
            parts.append(f'<p class="empty">{html_escape(str(section.get("empty") or "本轮无达标股票。"))}</p>')
            continue
        parts.extend(
            [
                "<table>",
                "<thead><tr><th>股票</th><th>现价</th><th>板块</th><th>机会</th><th>形态</th><th>长期</th><th>买入理由</th><th>风险</th></tr></thead>",
                "<tbody>",
            ]
        )
        for row in rows:
            stock = f"{row.get('symbol')} {row.get('name')}".strip()
            price = fmt(row.get("price"))
            if row.get("change_pct") is not None:
                price = f"{price}（{pct(row.get('change_pct'), scale=False)}）"
            parts.append(
                "<tr>"
                f'<td class="stock"><span class="field-label">股票</span><span class="field-value">{html_escape(stock)}</span></td>'
                f'<td class="price"><span class="field-label">现价</span><span class="field-value">{html_escape(price)}</span></td>'
                f'<td><span class="field-label">板块</span><span class="field-value">{html_escape(str(row.get("sector") or "-"))}</span></td>'
                f'<td><span class="field-label">机会</span><span class="field-value">{html_escape(str(row.get("opportunity") or "-"))}</span></td>'
                f'<td><span class="field-label">形态</span><span class="field-value">{html_escape(str(row.get("shape") or "-"))}</span></td>'
                f'<td><span class="field-label">长期</span><span class="field-value">{html_escape(str(row.get("quant_regime") or "-"))}</span></td>'
                f'<td><span class="field-label">买入理由</span><span class="field-value">{html_escape(str(row.get("reason") or "-"))}</span></td>'
                f'<td><span class="field-label">风险</span><span class="field-value">{html_escape(str(row.get("risk") or "-"))}</span></td>'
                "</tr>"
            )
        parts.extend(["</tbody>", "</table>"])
    parts.append('<div class="tip">提示：以上是策略提醒，不等于无脑买入。优先小仓位、看承接，跌破风险位要及时退出。</div>')
    parts.extend(["</div></div>", "</body>", "</html>"])
    return "\n".join(parts)


def empty_section(title: str, message: str) -> dict[str, Any]:
    return {"title": title, "rows": [], "empty": message}


def safe_json(value: Any) -> dict[str, Any]:
    if isinstance(value, dict):
        return value
    if not value:
        return {}
    try:
        parsed = json.loads(str(value))
    except (TypeError, ValueError):
        return {}
    return parsed if isinstance(parsed, dict) else {}


def num(value: Any) -> float | None:
    try:
        if value is None or value == "":
            return None
        return float(value)
    except (TypeError, ValueError):
        return None


def fmt(value: Any, digits: int = 2) -> str:
    number = num(value)
    if number is None:
        return "-"
    return f"{number:.{digits}f}"


def pct(value: Any, *, scale: bool = True) -> str:
    number = num(value)
    if number is None:
        return "-"
    if scale and abs(number) <= 1:
        number *= 100
    return f"{number:+.1f}%" if number < 0 else f"{number:.1f}%"


def shape_text(shape: dict[str, Any]) -> str:
    if not isinstance(shape, dict) or not shape:
        return "-"
    label = str(shape.get("label") or "").strip()
    parts = [label] if label else []
    transition_risk = num(shape.get("hmm_transition_risk"))
    state_prob = num(shape.get("hmm_state_prob"))
    momentum = num(shape.get("hmm_state_momentum"))
    if transition_risk is not None:
        parts.append(f"转弱风险 {transition_risk * 100:.1f}%")
    if state_prob is not None:
        parts.append(f"状态置信 {state_prob * 100:.1f}%")
    if momentum is not None:
        parts.append(f"形态动量 {momentum * 100:+.1f}%")
    return "；".join(parts) if parts else "-"


def market_label(market: str) -> str:
    return {"us": "美股", "hk": "港股", "cn": "A股"}.get(str(market).lower(), str(market).upper())


def compact_reason(parts: list[str]) -> str:
    return "；".join(part.strip("；; ") for part in parts if str(part or "").strip()) or "-"


def escape_cell(value: Any) -> str:
    return str(value if value is not None else "-").replace("|", "/").replace("\n", "；")


def fund_text(row: dict[str, Any]) -> str:
    total = num(row.get("total_net"))
    large = num(row.get("large_net"))
    if total is None and large is None:
        return ""
    return f"资金净流入{money_10k(total)}，大单{money_10k(large)}"


def money_10k(value: Any) -> str:
    number = num(value)
    if number is None:
        return "-"
    return f"{number:.0f}万"


def buy_zone_text(row: dict[str, Any]) -> str:
    low = row.get("zone_low")
    high = row.get("zone_high")
    confirm = row.get("confirm_price")
    if low is None and high is None and confirm is None:
        return ""
    return f"低吸区{fmt(low)}-{fmt(high)}，突破确认{fmt(confirm)}"


def pool_stage_text(payload: dict[str, Any], row: dict[str, Any]) -> str:
    if payload.get("observation_only"):
        return "观察池，等突破或回踩确认。"
    status = str(row.get("status") or "")
    if status == "buy_zone":
        return "进入买点区，可以小仓试买。"
    if status == "breakout":
        return "放量突破，适合趋势跟随。"
    return "候选池，等待买点确认。"


def us_opportunity_text(probability: Any, expected_return: Any, stage: Any) -> str:
    prob = num(probability)
    exp = num(expected_return)
    if prob is not None and prob >= 0.8 and (exp is None or exp >= 0):
        return "模型胜率较高，可小仓观察买点。"
    if str(stage or "") in {"buy_zone", "technical_breakout_watch"}:
        return "技术形态进入观察区，等放量确认。"
    return "候选池观察，暂不追高。"


def technical_position(row: dict[str, Any]) -> str:
    price = num(row.get("entry_price"))
    ma5 = num(row.get("ma5"))
    ma60 = num(row.get("ma60"))
    parts = []
    if price and ma5:
        parts.append("站上5日线" if price >= ma5 else "低于5日线")
    if price and ma60:
        parts.append("中期趋势线上方" if price >= ma60 else "仍低于60日线")
    return "，".join(parts)


def risk_text(risk_score: Any, row: dict[str, Any]) -> str:
    risk = num(risk_score)
    if risk is not None and risk >= 60:
        return f"风险分{risk:.0f}偏高，只观察不追。"
    if num(row.get("expected_return")) is not None and num(row.get("expected_return")) < 0:
        return "预期收益还没转正，等价格结构改善。"
    return "跌破短线均线或放量回落，先退出观察。"
