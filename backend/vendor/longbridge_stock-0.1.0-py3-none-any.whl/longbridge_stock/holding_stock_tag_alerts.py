from __future__ import annotations

import json
import time
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any, Callable, Iterable

from longbridge_stock.market_sessions import SHANGHAI_TZ, filter_symbols_for_trading_time, markets_from_symbols
from longbridge_stock.realtime_alerts import OpenClawNotifier, RealtimeAlert
from longbridge_stock.stock_tags import build_stock_tags

DEFAULT_STATE_PATH = "/home/alwin/data/longbridge/holding_stock_tag_alert_state.json"

TAG_FIELD_LABELS = {
    "mainForce": "主力",
    "divergence": "背离",
    "boxStructure": "箱体",
    "intradayTrendState": "盘中趋势",
    "intradayMainForce": "盘中主力",
    "capitalState": "资金",
    "tradeAdvice": "建议",
    "macdState": "盘中MACD",
}


@dataclass(frozen=True)
class HoldingStockTagChangeConfig:
    symbols: list[str]
    lookback_days: int = 60
    max_alerts_per_run: int = 20
    check_trading_time: bool = True
    notify_on_first_run: bool = False

    @property
    def markets(self) -> list[str]:
        return markets_from_symbols(self.symbols)


class StockTagChangeState:
    def __init__(self, path: str | Path) -> None:
        self.path = Path(path)
        self._data = self._load()

    def previous_fingerprint(self, symbol: str) -> dict[str, str] | None:
        row = self._data.get("symbols", {}).get(symbol)
        fingerprint = row.get("fingerprint") if isinstance(row, dict) else None
        return fingerprint if isinstance(fingerprint, dict) else None

    def update(self, symbol: str, fingerprint: dict[str, str], *, now: datetime) -> None:
        symbols = self._data.setdefault("symbols", {})
        symbols[symbol] = {
            "fingerprint": fingerprint,
            "updatedAt": now.astimezone(SHANGHAI_TZ).isoformat(),
        }
        self._save()

    def _load(self) -> dict[str, Any]:
        if not self.path.exists():
            return {"symbols": {}}
        try:
            data = json.loads(self.path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            return {"symbols": {}}
        if not isinstance(data, dict):
            return {"symbols": {}}
        if not isinstance(data.get("symbols"), dict):
            data["symbols"] = {}
        return data

    def _save(self) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.path.write_text(json.dumps(self._data, ensure_ascii=False, indent=2), encoding="utf-8")


class HoldingStockTagChangeMonitor:
    def __init__(
        self,
        *,
        config: HoldingStockTagChangeConfig,
        notifier: OpenClawNotifier,
        state: StockTagChangeState,
        tag_fetcher: Callable[..., dict[str, Any]] = build_stock_tags,
        names_by_symbol: dict[str, str] | None = None,
    ) -> None:
        self.config = config
        self.notifier = notifier
        self.state = state
        self.tag_fetcher = tag_fetcher
        self.names_by_symbol = names_by_symbol or {}

    def run_once(self, now: datetime | None = None) -> dict[str, Any]:
        current = now or datetime.now(SHANGHAI_TZ)
        active_symbols = self.config.symbols
        if self.config.check_trading_time:
            active_symbols = filter_symbols_for_trading_time(self.config.symbols, current)
        if self.config.check_trading_time and not active_symbols:
            return {"status": "outside_trading_time", "checked": 0, "alerts": 0, "sent": 0, "baselined": 0}

        payload = self.tag_fetcher(active_symbols, lookback_days=self.config.lookback_days)
        items = payload.get("items") if isinstance(payload, dict) else []
        alerts: list[RealtimeAlert] = []
        baselined = 0
        for item in items if isinstance(items, list) else []:
            symbol = str(item.get("symbol") or "").strip().upper()
            if not symbol:
                continue
            current_fingerprint = stock_tag_fingerprint(item)
            previous = self.state.previous_fingerprint(symbol)
            if previous is None:
                baselined += 1
                if self.config.notify_on_first_run:
                    alerts.append(build_stock_tag_change_alert(item, previous_fingerprint={}, name=self.names_by_symbol.get(symbol, symbol)))
                self.state.update(symbol, current_fingerprint, now=current)
                continue
            if current_fingerprint != previous:
                alerts.append(
                    build_stock_tag_change_alert(
                        item,
                        previous_fingerprint=previous,
                        name=self.names_by_symbol.get(symbol, symbol),
                    )
                )
                self.state.update(symbol, current_fingerprint, now=current)

        sent = 0
        deferred = 0
        errors: list[str] = []
        for alert in alerts:
            if sent >= self.config.max_alerts_per_run:
                deferred += 1
                continue
            try:
                self.notifier.send(alert.message)
            except Exception as exc:
                errors.append(f"{alert.dedupe_key}: {exc}")
                continue
            sent += 1
        return {
            "status": "ok",
            "checked": len(items) if isinstance(items, list) else 0,
            "activeSymbols": active_symbols,
            "skippedClosedSymbols": [symbol for symbol in self.config.symbols if symbol not in set(active_symbols)],
            "alerts": len(alerts),
            "sent": sent,
            "deferred": deferred,
            "baselined": baselined,
            "errors": errors,
        }

    def run_forever(self, interval_seconds: int) -> None:
        if interval_seconds <= 0:
            raise ValueError("interval_seconds must be positive")
        while True:
            started = time.monotonic()
            result = self.run_once()
            print(json.dumps(result, ensure_ascii=False), flush=True)
            time.sleep(max(0, interval_seconds - (time.monotonic() - started)))


def stock_tag_fingerprint(item: dict[str, Any]) -> dict[str, str]:
    intraday = item.get("intraday") if isinstance(item.get("intraday"), dict) else {}
    capital = item.get("capitalFlow") if isinstance(item.get("capitalFlow"), dict) else {}
    trade_advice = item.get("tradeAdvice") if isinstance(item.get("tradeAdvice"), dict) else {}
    tags = intraday.get("tags") if isinstance(intraday.get("tags"), dict) else {}
    return {
        "mainForce": _text(item.get("mainForce")),
        "divergence": _text(item.get("divergence")),
        "boxStructure": _text(item.get("boxStructure")),
        "intradayTrendState": _text(intraday.get("intradayTrendState")),
        "intradayMainForce": _text(intraday.get("intradayMainForce")),
        "capitalState": _text(capital.get("state") or intraday.get("intradayCapital")),
        "tradeAdvice": _text(trade_advice.get("action")),
        "macdState": _text(tags.get("macdState")),
    }


def build_stock_tag_change_alert(
    item: dict[str, Any],
    *,
    previous_fingerprint: dict[str, str],
    name: str,
) -> RealtimeAlert:
    symbol = str(item.get("symbol") or "-").strip().upper()
    market = symbol.rsplit(".", 1)[-1] if "." in symbol else ""
    current = stock_tag_fingerprint(item)
    changed = [
        f"{TAG_FIELD_LABELS.get(key, key)}：{previous_fingerprint.get(key, '-')} -> {value}"
        for key, value in current.items()
        if previous_fingerprint.get(key) != value
    ]
    capital = item.get("capitalFlow") if isinstance(item.get("capitalFlow"), dict) else {}
    trade_advice = item.get("tradeAdvice") if isinstance(item.get("tradeAdvice"), dict) else {}
    price_zone = trade_advice.get("priceZone") if isinstance(trade_advice.get("priceZone"), dict) else {}
    confidence_text = _confidence_text(trade_advice)
    technical_text = _technical_text(current, trade_advice)
    key_price_text = _key_price_text(current["tradeAdvice"], price_zone)
    message = "\n".join(
        [
            f"【持仓标签变化】{symbol} {name}",
            "",
            "| 项目 | 当前 |",
            "|---|---|",
            f"| 建议 | {current['tradeAdvice']} |",
            f"| 置信度 | {confidence_text} |",
            f"| 资金 | {_capital_summary_text(current['capitalState'], capital)} |",
            f"| 技术 | {technical_text} |",
            f"| 关键价位 | {key_price_text} |",
            f"| 风险线 | {_price_or_dash(price_zone.get('riskLine'))} |",
            f"| 原因 | {trade_advice.get('reason', '-')} |",
            "",
            "变化：",
            *[f"- {line}" for line in changed],
            "",
            "说明：仅提示状态变化，不构成自动交易指令。",
        ]
    )
    return RealtimeAlert(
        alert_type="holding_stock_tag_change",
        symbol=symbol,
        market=market,
        name=name,
        title=f"{symbol} {name} 持仓标签变化",
        message=message,
        score=None,
        signal="holding_stock_tag_change",
    )


def _money_wan(value: Any) -> str:
    number = _number(value)
    if number is None:
        return "-"
    sign = "+" if number > 0 else ""
    if abs(number) >= 10_000:
        return f"{sign}{number / 10_000:.2f}亿"
    return f"{sign}{number:.0f}万"


def _capital_summary_text(state: str, capital: dict[str, Any]) -> str:
    parts = [f"净额{_money_wan(capital.get('totalNet'))}"]
    if capital.get("largeNet") is not None:
        parts.append(f"大单{_money_wan(capital.get('largeNet'))}")
    return f"{state}（{'；'.join(parts)}）"


def _confidence_text(trade_advice: dict[str, Any]) -> str:
    signal_confidence = trade_advice.get("signalConfidence") if isinstance(trade_advice.get("signalConfidence"), dict) else {}
    confidence = trade_advice.get("confidence", "-")
    grade = signal_confidence.get("grade")
    return f"{confidence}/{grade}" if grade else str(confidence)


def _technical_text(current: dict[str, str], trade_advice: dict[str, Any] | None = None) -> str:
    macd = current.get("macdState") or "-"
    trend = current.get("intradayTrendState") or "-"
    drivers = trade_advice.get("drivers") if isinstance(trade_advice, dict) and isinstance(trade_advice.get("drivers"), dict) else {}
    if macd in {"-", "MACD数据不足"} and trend in {"-", "盘中数据不足"}:
        daily_macd = str(drivers.get("macd") or "")
        daily_trend = str(drivers.get("trend") or "")
        fallback = "，".join(part for part in [daily_macd, daily_trend] if part)
        return fallback or "技术数据不足"
    if macd == "-" or macd == "MACD数据不足":
        return trend
    return f"{macd}，{trend}"


def _key_price_text(advice: str, price_zone: dict[str, Any]) -> str:
    if advice in {"加仓/低吸", "继续持有", "暂不操作"}:
        return f"买入{_price_range(price_zone.get('buyLow'), price_zone.get('buyHigh'))}"
    if advice in {"做T高抛", "减仓避险"}:
        return f"卖出{_price_range(price_zone.get('sellLow'), price_zone.get('sellHigh'))}"
    return _price_range(price_zone.get("buyLow"), price_zone.get("buyHigh"))


def _price_range(low: Any, high: Any) -> str:
    low_text = _price_or_dash(low)
    high_text = _price_or_dash(high)
    if low_text == "-" and high_text == "-":
        return "-"
    return f"{low_text}-{high_text}"


def _price_or_dash(value: Any) -> str:
    number = _number(value)
    if number is None:
        return "-"
    return f"{number:g}"


def _number(value: Any) -> float | None:
    if value is None:
        return None
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def _text(value: Any) -> str:
    text = str(value or "").strip()
    return text or "-"
