from __future__ import annotations

import argparse
import json
import os
from pathlib import Path

import pandas as pd

from longbridge_stock.config import load_data_config, load_experiment_config
from longbridge_stock.data import load_market_data
from longbridge_stock.experiments import create_experiment_dir, save_backtest_result
from longbridge_stock.external import AkshareDailySync, EastmoneyExternalSync, EastmoneyF10Sync
from longbridge_stock.factors import compute_factor_set, list_factors
from longbridge_stock.backtest import run_monte_carlo_backtest, run_topk_backtest
from longbridge_stock.collection_monitor import ensure_monitoring_schema, refresh_collection_alerts, sweep_stale_jobs
from longbridge_stock.company_fundamental_tags import (
    CompanyFundamentalTagConfig,
    build_company_fundamental_tags,
    refresh_company_fundamental_tag_store,
)
from longbridge_stock.longbridge_sync import (
    LongbridgeDataSync,
    LongbridgeCliClient,
    load_longbridge_sync_config,
    read_sync_status,
)
from longbridge_stock.llm import LLMClient
from longbridge_stock.limit_up import (
    fetch_limit_up_candidates,
    predict_limit_up_candidates,
    refresh_limit_up_events,
    summary_to_dict,
    train_limit_up_model_from_db,
)
from longbridge_stock.limit_reversal_line import (
    backtest_limit_reversal_lines,
    current_limit_reversal_candidates,
    summary_to_dict as limit_reversal_summary_to_dict,
)
from longbridge_stock.multibagger import (
    BacktestGateConfig,
    MultibaggerScanConfig,
    build_after_close_message as build_multibagger_after_close_message,
    evaluate_backtest_gate,
    scan_multibagger_candidates,
)
from longbridge_stock.limit_reversal_alerts import (
    DEFAULT_STATE_PATH as LIMIT_REVERSAL_ALERT_STATE_PATH,
    LimitReversalAlertConfig,
    LimitReversalAlertMonitor,
    parse_markets,
)
from longbridge_stock.market_macro_trend import MacroTrendConfig, build_market_macro_report
from longbridge_stock.holding_capital_alerts import HoldingCapitalAlertConfig, HoldingCapitalAlertMonitor
from longbridge_stock.holding_stock_tag_alerts import (
    DEFAULT_STATE_PATH as HOLDING_STOCK_TAG_ALERT_STATE_PATH,
    HoldingStockTagChangeConfig,
    HoldingStockTagChangeMonitor,
    StockTagChangeState,
)
from longbridge_stock.holding_symbols import resolve_equity_holding_symbols, resolve_hk_holding_symbols, run_positions_json
from longbridge_stock.pool_gain import (
    fetch_pool_gain_predictions,
    predict_pool_gain_candidates,
    summary_to_dict as pool_gain_summary_to_dict,
    train_pool_gain_model_from_db,
)
from longbridge_stock.postgres_store import LongbridgePostgresStore
from longbridge_stock.qlib_native import QlibWorkflowSpec, save_qlib_workflow_config, start_local_qrun
from longbridge_stock.research_snapshots import (
    CombinedNewsFetcher,
    GoogleNewsRssFetcher,
    LongbridgeNewsFetcher,
    PostgresResearchSnapshotRepository,
    generate_research_snapshot_batch,
)
from longbridge_stock.realtime_capital import RealtimeCapitalSync
from longbridge_stock.realtime_alerts import (
    DEFAULT_STATE_PATH,
    AlertState,
    RealtimeAlertConfig,
    RealtimeAlertMonitor,
    build_default_notifier,
)
from longbridge_stock.realtime_profit import (
    backfill_realtime_profit_actuals,
    predict_realtime_profit,
    review_realtime_profit_2pct_outcomes,
    summary_to_dict as realtime_profit_summary_to_dict,
    train_realtime_profit_model,
)
from longbridge_stock.realtime_quotes import RealtimeQuoteSync
from longbridge_stock.realtime_microstructure import MarketTemperatureSync, RealtimeMicrostructureSync
from longbridge_stock.sdk_client import LongbridgeSdkClient
from longbridge_stock.stock_pool_snapshot import refresh_stock_pool_snapshots
from longbridge_stock.us_fast_alerts import (
    DEFAULT_DSN as US_FAST_DEFAULT_DSN,
    DEFAULT_STATE_PATH as US_FAST_ALERT_STATE_PATH,
    USFastAlertConfig,
    build_default_us_fast_monitor,
)


def _market_data_client(mode: str, rate_limit_per_second: float):
    resolved = os.getenv("LONGBRIDGE_CLIENT", "").strip().lower() if mode == "auto" else mode
    if resolved == "sdk":
        return LongbridgeSdkClient(rate_limit_per_second=rate_limit_per_second)
    return LongbridgeCliClient(rate_limit_per_second=rate_limit_per_second)


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="longbridge-stock")
    parser.add_argument("--data-config", default="configs/data.yaml")
    parser.add_argument("--experiment-config", default="configs/experiment.yaml")
    sub = parser.add_subparsers(dest="command", required=True)

    inspect_parser = sub.add_parser("inspect-data", help="Load market data and print a compact summary.")
    inspect_parser.add_argument("--source", choices=["auto", "qlib", "csv"], default="auto")

    sub.add_parser("list-factors", help="List built-in factor names.")

    run_parser = sub.add_parser("run-baseline", help="Run the configured simple top-k factor baseline.")
    run_parser.add_argument("--source", choices=["auto", "qlib", "csv"], default="auto")
    run_parser.add_argument("--output-dir", default="experiments")

    monte_carlo_parser = sub.add_parser(
        "run-monte-carlo",
        help="Run TopK historical backtest, then bootstrap daily returns into Monte Carlo paths.",
    )
    monte_carlo_parser.add_argument("--source", choices=["auto", "qlib", "csv"], default="auto")
    monte_carlo_parser.add_argument("--simulations", type=int, default=1000)
    monte_carlo_parser.add_argument("--horizon-days", type=int)
    monte_carlo_parser.add_argument("--seed", type=int, default=42)

    standard_parser = sub.add_parser(
        "run-standard-backtest",
        help="Run the standard TopK + Qlib + Monte Carlo evaluation bundle and print one report.",
    )
    standard_parser.add_argument("--source", choices=["auto", "qlib", "csv"], default="auto")
    standard_parser.add_argument("--output-dir", default="experiments")
    standard_parser.add_argument("--simulations", type=int, default=1000)
    standard_parser.add_argument("--horizon-days", type=int)
    standard_parser.add_argument("--seed", type=int, default=42)
    standard_parser.add_argument("--qlib-handler", default="Alpha158")
    standard_parser.add_argument("--qlib-model", default="LGBModel")
    standard_parser.add_argument("--qlib-strategy", default="TopkDropoutStrategy")
    standard_parser.add_argument("--start-qlib", action="store_true")
    standard_parser.add_argument("--qlib-run-root", default="/home/alwin/data/longbridge/qlib_runs")

    sync_parser = sub.add_parser("sync-longbridge", help="Fetch Longbridge data into the permanent raw data store.")
    sync_parser.add_argument("--sync-config", default="configs/longbridge_sync.yaml")
    sync_parser.add_argument("--client", choices=["auto", "cli", "sdk"], default="auto")
    sync_parser.add_argument("--once", action="store_true", help="Run one sync cycle and exit.")
    sync_parser.add_argument("--interval-seconds", type=int, default=24 * 60 * 60)

    status_parser = sub.add_parser("sync-status", help="Print the latest Longbridge sync status.")
    status_parser.add_argument("--data-root", default="/home/alwin/data/longbridge")

    pg_parser = sub.add_parser("sync-postgres", help="Import saved Longbridge raw JSON files into PostgreSQL tables.")
    pg_parser.add_argument("--data-root", default="/home/alwin/data/longbridge")
    pg_parser.add_argument("--dsn", default="dbname=longbridge_stock user=alwin host=/var/run/postgresql")

    akshare_daily_parser = sub.add_parser(
        "sync-akshare-daily",
        help="Supplement lb_daily_bars with AKShare A-share/ETF daily bars.",
    )
    akshare_daily_parser.add_argument("--dsn", default="dbname=longbridge_stock user=alwin host=/var/run/postgresql")
    akshare_daily_parser.add_argument("--symbols", help="Comma-separated symbols, for example 000001.SZ,510300.SH.")
    akshare_daily_parser.add_argument("--start-date")
    akshare_daily_parser.add_argument("--end-date")
    akshare_daily_parser.add_argument("--limit", type=int)
    akshare_daily_parser.add_argument("--adjust", choices=["qfq", "hfq", ""], default="qfq")
    akshare_daily_parser.add_argument(
        "--merge-to-daily",
        action="store_true",
        help="Also merge AKShare bars into lb_daily_bars. Default keeps them isolated in lb_external_daily_bars.",
    )

    eastmoney_parser = sub.add_parser(
        "sync-eastmoney-external",
        help="Sync Eastmoney supplemental data: limit pools, fund flow, industry and concept boards.",
    )
    eastmoney_parser.add_argument("--dsn", default="dbname=longbridge_stock user=alwin host=/var/run/postgresql")
    eastmoney_parser.add_argument("--date", dest="trade_date")
    eastmoney_parser.add_argument(
        "--datasets",
        default="limit-pool,fund-flow,industry,concept",
        help="Comma-separated: limit-pool,fund-flow,industry,concept.",
    )
    eastmoney_parser.add_argument("--include-components", action="store_true")
    eastmoney_parser.add_argument("--component-limit", type=int)

    eastmoney_f10_parser = sub.add_parser(
        "sync-eastmoney-f10",
        help="Sync Eastmoney F10 company profiles, business segments, reviews, and HK industry ranks.",
    )
    eastmoney_f10_parser.add_argument("--dsn", default="dbname=longbridge_stock user=alwin host=/var/run/postgresql")
    eastmoney_f10_parser.add_argument("--markets", default="cn,hk,us", help="Comma-separated: cn,hk,us.")
    eastmoney_f10_parser.add_argument("--symbols", help="Comma-separated symbols, for example 688182.SH,700.HK,NBIS.US.")
    eastmoney_f10_parser.add_argument("--limit", type=int)
    eastmoney_f10_parser.add_argument("--max-workers", type=int, default=5)
    eastmoney_f10_parser.add_argument("--request-interval-seconds", type=float, default=0.05)
    eastmoney_f10_parser.add_argument("--timeout-seconds", type=int, default=15)

    realtime_quote_parser = sub.add_parser(
        "sync-realtime-quotes",
        help="Poll Longbridge real-time quotes in batches and store minute snapshots.",
    )
    realtime_quote_parser.add_argument("--dsn", default="dbname=longbridge_stock user=alwin host=/var/run/postgresql")
    realtime_quote_parser.add_argument("--markets", default="cn,hk")
    realtime_quote_parser.add_argument("--batch-size", type=int, default=500)
    realtime_quote_parser.add_argument("--interval-seconds", type=int, default=60)
    realtime_quote_parser.add_argument("--rate-limit-per-second", type=float, default=5.0)
    realtime_quote_parser.add_argument("--client", choices=["auto", "cli", "sdk"], default="auto")
    realtime_quote_parser.add_argument("--limit", type=int)
    realtime_quote_parser.add_argument("--priority-only", action="store_true")
    realtime_quote_parser.add_argument("--once", action="store_true")

    realtime_capital_parser = sub.add_parser(
        "sync-realtime-capital",
        help="Poll Longbridge intraday capital distribution and store minute snapshots.",
    )
    realtime_capital_parser.add_argument("--dsn", default="dbname=longbridge_stock user=alwin host=/var/run/postgresql")
    realtime_capital_parser.add_argument("--markets", default="cn")
    realtime_capital_parser.add_argument("--interval-seconds", type=int, default=300)
    realtime_capital_parser.add_argument("--rate-limit-per-second", type=float, default=5.0)
    realtime_capital_parser.add_argument("--client", choices=["auto", "cli", "sdk"], default="auto")
    realtime_capital_parser.add_argument("--limit", type=int)
    realtime_capital_parser.add_argument("--priority-only", action="store_true")
    realtime_capital_parser.add_argument("--include-flow", action="store_true")
    realtime_capital_parser.add_argument("--once", action="store_true")

    microstructure_parser = sub.add_parser(
        "sync-realtime-microstructure",
        help="Poll priority symbols for intraday lines, recent trades, and order book depth.",
    )
    microstructure_parser.add_argument("--dsn", default="dbname=longbridge_stock user=alwin host=/var/run/postgresql")
    microstructure_parser.add_argument("--markets", default="cn,hk")
    microstructure_parser.add_argument("--datasets", default="intraday,trades,depth")
    microstructure_parser.add_argument("--interval-seconds", type=int, default=60)
    microstructure_parser.add_argument("--rate-limit-per-second", type=float, default=10.0)
    microstructure_parser.add_argument("--limit", type=int)
    microstructure_parser.add_argument("--all-symbols", action="store_true")
    microstructure_parser.add_argument("--trade-count", type=int, default=100)
    microstructure_parser.add_argument("--once", action="store_true")

    market_temperature_parser = sub.add_parser(
        "sync-market-temperature",
        help="Poll market temperature for CN/HK/US/SG through the SDK HTTP client.",
    )
    market_temperature_parser.add_argument("--dsn", default="dbname=longbridge_stock user=alwin host=/var/run/postgresql")
    market_temperature_parser.add_argument("--markets", default="cn,hk,us")
    market_temperature_parser.add_argument("--interval-seconds", type=int, default=900)
    market_temperature_parser.add_argument("--rate-limit-per-second", type=float, default=10.0)
    market_temperature_parser.add_argument("--once", action="store_true")

    realtime_alert_parser = sub.add_parser(
        "alert-realtime",
        help="Push A-share and HK real-time buy/sell alerts through OpenClaw during trading sessions.",
    )
    realtime_alert_parser.add_argument("--dsn", default="dbname=longbridge_stock user=alwin host=/var/run/postgresql")
    realtime_alert_parser.add_argument("--markets", default="cn,hk")
    realtime_alert_parser.add_argument(
        "--pool",
        choices=["all", "score_pool", "early_signal", "trend_compounder", "limit_up"],
        default="all",
    )
    realtime_alert_parser.add_argument("--limit", type=int, default=80)
    realtime_alert_parser.add_argument("--interval-seconds", type=int, default=60)
    realtime_alert_parser.add_argument("--buy-score", type=float, default=75.0)
    realtime_alert_parser.add_argument("--strong-buy-score", type=float, default=85.0)
    realtime_alert_parser.add_argument("--max-alerts-per-run", type=int, default=10)
    realtime_alert_parser.add_argument("--state-path", default=str(DEFAULT_STATE_PATH))
    realtime_alert_parser.add_argument("--targets", help="OpenClaw targets, for example qqbot=...,wecom=ZhangTao")
    realtime_alert_parser.add_argument("--once", action="store_true")

    us_fast_alert_parser = sub.add_parser(
        "alert-us-fast",
        help="Push US three-trading-day +2% buy and sell advisories through OpenClaw.",
    )
    us_fast_alert_parser.add_argument("--dsn", default=US_FAST_DEFAULT_DSN)
    us_fast_alert_parser.add_argument("--profile", choices=["us_fast_15"], default="us_fast_15")
    us_fast_alert_parser.add_argument("--limit", type=int, default=100)
    us_fast_alert_parser.add_argument("--interval-seconds", type=int, default=60)
    us_fast_alert_parser.add_argument("--min-probability", type=float, default=0.70)
    us_fast_alert_parser.add_argument("--sell-probability", type=float, default=0.60)
    us_fast_alert_parser.add_argument("--max-alerts-per-run", type=int, default=5)
    us_fast_alert_parser.add_argument("--execution-lookback-days", type=int, default=10)
    us_fast_alert_parser.add_argument("--state-path", default=US_FAST_ALERT_STATE_PATH)
    us_fast_alert_parser.add_argument("--targets", help="OpenClaw targets, for example qqbot=...")
    us_fast_alert_parser.add_argument("--once", action="store_true")

    reversal_alert_parser = sub.add_parser(
        "alert-limit-reversal",
        help="Monitor 10%% gain 0/1/2/3-line watchlist intraday red candles and push OpenClaw alerts.",
    )
    reversal_alert_parser.add_argument("--dsn", default="dbname=longbridge_stock user=alwin host=/var/run/postgresql")
    reversal_alert_parser.add_argument("--markets", default="cn,hk,us")
    reversal_alert_parser.add_argument("--event-threshold", type=float, default=0.10)
    reversal_alert_parser.add_argument("--lookback-days", type=int, default=45)
    reversal_alert_parser.add_argument("--limit", type=int, default=300)
    reversal_alert_parser.add_argument("--interval-seconds", type=int, default=60)
    reversal_alert_parser.add_argument("--min-red-pct", type=float, default=0.0)
    reversal_alert_parser.add_argument("--max-quote-age-minutes", type=int, default=20)
    reversal_alert_parser.add_argument("--max-alerts-per-run", type=int, default=20)
    reversal_alert_parser.add_argument("--state-path", default=str(LIMIT_REVERSAL_ALERT_STATE_PATH))
    reversal_alert_parser.add_argument("--targets", help="OpenClaw targets, for example qqbot=...")
    reversal_alert_parser.add_argument("--once", action="store_true")

    holding_capital_alert_parser = sub.add_parser(
        "alert-holding-capital",
        help="Monitor current holdings' intraday capital-flow anomalies and push OpenClaw alerts.",
    )
    holding_capital_alert_parser.add_argument("--dsn", default="dbname=longbridge_stock user=alwin host=/var/run/postgresql")
    holding_capital_alert_parser.add_argument(
        "--symbols",
        default="auto",
        help="Comma-separated holding symbols, or auto to read current HK holdings.",
    )
    holding_capital_alert_parser.add_argument(
        "--fallback-symbols",
        default="9988.HK,981.HK,9618.HK,700.HK,6869.HK,3690.HK,2513.HK,2476.HK,2382.HK,1347.HK",
        help="Manual HK holding symbols used only when --symbols auto cannot read positions.",
    )
    holding_capital_alert_parser.add_argument("--interval-seconds", type=int, default=60)
    holding_capital_alert_parser.add_argument("--max-quote-age-minutes", type=int, default=25)
    holding_capital_alert_parser.add_argument("--large-net-ratio-threshold", type=float, default=0.05)
    holding_capital_alert_parser.add_argument("--flow-30m-threshold", type=float, default=50_000.0)
    holding_capital_alert_parser.add_argument("--max-alerts-per-run", type=int, default=20)
    holding_capital_alert_parser.add_argument(
        "--state-path",
        default="/home/alwin/data/longbridge/holding_capital_alert_state.json",
    )
    holding_capital_alert_parser.add_argument("--targets", help="OpenClaw targets, for example qqbot=...")
    holding_capital_alert_parser.add_argument("--once", action="store_true")

    holding_stock_tag_alert_parser = sub.add_parser(
        "alert-holding-stock-tags",
        help="Monitor current holdings' stock-tag state changes and push one changed stock at a time.",
    )
    holding_stock_tag_alert_parser.add_argument(
        "--symbols",
        default="auto",
        help="Comma-separated holding symbols, or auto to read current stock/ETF holdings.",
    )
    holding_stock_tag_alert_parser.add_argument(
        "--fallback-symbols",
        default="700.HK,NVDA.US,TSLA.US,PDD.US,9988.HK,981.HK,9618.HK",
        help="Manual symbols used only when --symbols auto cannot read positions.",
    )
    holding_stock_tag_alert_parser.add_argument("--lookback-days", type=int, default=60)
    holding_stock_tag_alert_parser.add_argument("--interval-seconds", type=int, default=60)
    holding_stock_tag_alert_parser.add_argument("--max-alerts-per-run", type=int, default=20)
    holding_stock_tag_alert_parser.add_argument("--state-path", default=HOLDING_STOCK_TAG_ALERT_STATE_PATH)
    holding_stock_tag_alert_parser.add_argument("--targets", help="OpenClaw targets, for example qqbot=...")
    holding_stock_tag_alert_parser.add_argument("--notify-on-first-run", action="store_true")
    holding_stock_tag_alert_parser.add_argument("--ignore-trading-time", action="store_true")
    holding_stock_tag_alert_parser.add_argument("--once", action="store_true")

    monitor_parser = sub.add_parser("monitor-maintenance", help="Create monitoring tables and sweep stale collection jobs.")
    monitor_parser.add_argument("--dsn", default="dbname=longbridge_stock user=alwin host=/var/run/postgresql")
    monitor_parser.add_argument("--sweep-stale-jobs", action="store_true")
    monitor_parser.add_argument("--timeout-seconds", type=int, default=300)
    monitor_parser.add_argument("--stale-alert-seconds", type=int, default=600)

    research_parser = sub.add_parser(
        "generate-research-snapshots",
        help="Batch-generate financial/news/hotspot/LLM research snapshots into PostgreSQL.",
    )
    research_parser.add_argument("--dsn", default="dbname=longbridge_stock user=alwin host=/var/run/postgresql")
    research_parser.add_argument("--market", choices=["all", "hk", "us", "cn"], default="all")
    research_parser.add_argument("--limit", type=int, default=100)
    research_parser.add_argument("--stale-hours", type=int, default=24)
    research_parser.add_argument("--news-limit", type=int, default=5)
    research_parser.add_argument("--refresh-financials", action="store_true")
    research_parser.add_argument("--fetch-missing-financials", action="store_true")
    research_parser.add_argument("--rate-limit-per-second", type=float, default=5.0)
    research_parser.add_argument("--client", choices=["auto", "cli", "sdk"], default="auto")
    research_parser.add_argument("--use-ozon-config", action="store_true")
    research_parser.add_argument("--no-llm", action="store_true")
    research_parser.add_argument("--dry-run", action="store_true")

    limit_up_events_parser = sub.add_parser(
        "build-limit-up-events",
        help="Build labeled A-share limit-up open-buy events from PostgreSQL daily bars.",
    )
    limit_up_events_parser.add_argument("--dsn", default="dbname=longbridge_stock user=alwin host=/var/run/postgresql")
    limit_up_events_parser.add_argument("--start-date")
    limit_up_events_parser.add_argument("--end-date")

    train_limit_up_parser = sub.add_parser(
        "train-limit-up-model",
        help="Train the A-share limit-up next-open buy model from labeled events.",
    )
    train_limit_up_parser.add_argument("--dsn", default="dbname=longbridge_stock user=alwin host=/var/run/postgresql")
    train_limit_up_parser.add_argument("--model-root", default="/home/alwin/data/longbridge/limit_up_models")
    train_limit_up_parser.add_argument("--validation-ratio", type=float, default=0.2)
    train_limit_up_parser.add_argument("--min-events", type=int, default=20)

    predict_limit_up_parser = sub.add_parser(
        "predict-limit-up",
        help="Predict ranked next-open candidates for one A-share limit-up day.",
    )
    predict_limit_up_parser.add_argument("--dsn", default="dbname=longbridge_stock user=alwin host=/var/run/postgresql")
    predict_limit_up_parser.add_argument("--event-date")
    predict_limit_up_parser.add_argument("--model-root", default="/home/alwin/data/longbridge/limit_up_models")
    predict_limit_up_parser.add_argument("--limit", type=int, default=50)

    limit_up_candidates_parser = sub.add_parser(
        "limit-up-candidates",
        help="Print stored ranked A-share limit-up candidates.",
    )
    limit_up_candidates_parser.add_argument("--dsn", default="dbname=longbridge_stock user=alwin host=/var/run/postgresql")
    limit_up_candidates_parser.add_argument("--event-date")
    limit_up_candidates_parser.add_argument("--limit", type=int, default=50)

    train_pool_gain_parser = sub.add_parser(
        "train-pool-gain-model",
        help="Train a stock-pool classifier for next 5 trading days reaching +5%%.",
    )
    train_pool_gain_parser.add_argument("--dsn", default="dbname=longbridge_stock user=alwin host=/var/run/postgresql")
    train_pool_gain_parser.add_argument("--model-root", default="/home/alwin/data/longbridge/pool_gain_models")
    train_pool_gain_parser.add_argument("--start-date", default="2024-01-01")
    train_pool_gain_parser.add_argument("--validation-ratio", type=float, default=0.2)
    train_pool_gain_parser.add_argument("--max-rows", type=int)

    predict_pool_gain_parser = sub.add_parser(
        "predict-pool-gain",
        help="Rank current stock-pool candidates by probability of reaching +5%% in next 5 trading days.",
    )
    predict_pool_gain_parser.add_argument("--dsn", default="dbname=longbridge_stock user=alwin host=/var/run/postgresql")
    predict_pool_gain_parser.add_argument("--model-root", default="/home/alwin/data/longbridge/pool_gain_models")
    predict_pool_gain_parser.add_argument("--as-of-date")
    predict_pool_gain_parser.add_argument("--limit", type=int, default=50)

    pool_gain_candidates_parser = sub.add_parser(
        "pool-gain-candidates",
        help="Print stored ranked stock-pool +5%%/5d candidates.",
    )
    pool_gain_candidates_parser.add_argument("--dsn", default="dbname=longbridge_stock user=alwin host=/var/run/postgresql")
    pool_gain_candidates_parser.add_argument("--as-of-date")
    pool_gain_candidates_parser.add_argument("--limit", type=int, default=50)

    train_realtime_profit_parser = sub.add_parser(
        "train-realtime-profit-model",
        help="Train HK/US intraday realtime profit probability models from realtime microstructure data.",
    )
    train_realtime_profit_parser.add_argument("--dsn", default="dbname=longbridge_stock user=alwin host=/var/run/postgresql")
    train_realtime_profit_parser.add_argument("--market", choices=["hk", "us", "cn"], default="hk")
    train_realtime_profit_parser.add_argument("--model-root", default="/home/alwin/data/longbridge/realtime_profit_models")
    train_realtime_profit_parser.add_argument("--lookback-days", type=int, default=30)
    train_realtime_profit_parser.add_argument("--horizon-minutes", type=int)
    train_realtime_profit_parser.add_argument("--target-return", type=float)
    train_realtime_profit_parser.add_argument("--max-rows", type=int, default=50000)
    train_realtime_profit_parser.add_argument("--profile", choices=["realtime", "top3_fast", "us_fast_15"], default="realtime")
    train_realtime_profit_parser.add_argument("--as-of-date", help="Only use historical replay snapshots up to this date for fast-profile training.")
    train_realtime_profit_parser.add_argument("--target-direction", choices=["long", "short"], default="long")

    predict_realtime_profit_parser = sub.add_parser(
        "predict-realtime-profit",
        help="Predict HK/US realtime profit probability for latest intraday candidates.",
    )
    predict_realtime_profit_parser.add_argument("--dsn", default="dbname=longbridge_stock user=alwin host=/var/run/postgresql")
    predict_realtime_profit_parser.add_argument("--market", choices=["hk", "us", "cn"], default="hk")
    predict_realtime_profit_parser.add_argument("--model-root", default="/home/alwin/data/longbridge/realtime_profit_models")
    predict_realtime_profit_parser.add_argument("--limit", type=int, default=3000)
    predict_realtime_profit_parser.add_argument("--profile", choices=["realtime", "top3_fast", "us_fast_15"], default="realtime")
    predict_realtime_profit_parser.add_argument("--target-direction", choices=["long", "short"], default="long")

    validate_realtime_profit_parser = sub.add_parser(
        "validate-realtime-profit",
        help="Backfill actual future returns for matured realtime profit predictions.",
    )
    validate_realtime_profit_parser.add_argument("--dsn", default="dbname=longbridge_stock user=alwin host=/var/run/postgresql")
    validate_realtime_profit_parser.add_argument("--market", choices=["hk", "us", "cn", "all"], default="hk")
    validate_realtime_profit_parser.add_argument("--limit", type=int, default=500)
    validate_realtime_profit_parser.add_argument("--max-age-days", type=int, default=3)

    review_realtime_profit_parser = sub.add_parser(
        "review-realtime-profit-2pct",
        help="Review historical +2%% realtime profit predictions: hit rate, max return, and drawdown.",
    )
    review_realtime_profit_parser.add_argument("--market", choices=["hk", "us", "cn", "all"], default="all")
    review_realtime_profit_parser.add_argument("--profile", default="all")
    review_realtime_profit_parser.add_argument("--lookback-days", type=int, default=30)
    review_realtime_profit_parser.add_argument("--min-probability", type=float, default=0.70)
    review_realtime_profit_parser.add_argument("--target-return", type=float, default=0.02)
    review_realtime_profit_parser.add_argument("--limit", type=int, default=100)

    stock_pool_snapshot_parser = sub.add_parser(
        "refresh-stock-pool-snapshot",
        help="Materialize stock-pool strategy leaderboards into a small frontend snapshot table.",
    )
    stock_pool_snapshot_parser.add_argument("--dsn", default="dbname=longbridge_stock user=alwin host=/var/run/postgresql")
    stock_pool_snapshot_parser.add_argument("--markets", default="all,cn,hk,us")
    stock_pool_snapshot_parser.add_argument("--strategies", default="trend_follow,early_signal,trend_compounder,limit_up,volume_breakout")
    stock_pool_snapshot_parser.add_argument("--limit", type=int, default=300)

    macro_trend_parser = sub.add_parser(
        "analyze-market-macro-trend",
        help="Analyze broad market macro trend from Longbridge indices, sectors, anomalies, and news catalysts.",
    )
    macro_trend_parser.add_argument("--market", choices=["HK", "US", "CN", "SG"], default="HK")
    macro_trend_parser.add_argument("--index-symbols", help="Comma-separated index symbols; defaults by market.")
    macro_trend_parser.add_argument("--industry-count", type=int, default=12)
    macro_trend_parser.add_argument("--top-mover-count", type=int, default=8)
    macro_trend_parser.add_argument("--anomaly-count", type=int, default=8)
    macro_trend_parser.add_argument("--constituent-limit", type=int, default=50)
    macro_trend_parser.add_argument("--news-per-symbol", type=int, default=3)
    macro_trend_parser.add_argument("--no-news", action="store_true", help="Skip per-symbol Longbridge news lookups.")
    macro_trend_parser.add_argument("--format", choices=["json", "summary"], default="json")

    company_tag_parser = sub.add_parser(
        "tag-company-fundamentals",
        help="Classify companies by financial-report quality, valuation, market cap, and shareholder-return tags.",
    )
    company_tag_parser.add_argument("symbols", nargs="+", help="Symbols such as 700.HK NVDA.US 600519.SH.")
    company_tag_parser.add_argument("--format", choices=["json", "summary"], default="json")
    company_tag_parser.add_argument("--no-valuation", action="store_true", help="Skip the slower valuation analysis call.")

    company_tag_refresh_parser = sub.add_parser(
        "refresh-company-fundamental-tags",
        help="Refresh company-fundamental profile tags into PostgreSQL for daily company portraits.",
    )
    company_tag_refresh_parser.add_argument("--dsn", default="dbname=longbridge_stock user=alwin host=/var/run/postgresql")
    company_tag_refresh_parser.add_argument("--symbols", help="Comma-separated symbols; defaults to lb_company_profiles by market.")
    company_tag_refresh_parser.add_argument("--markets", default="hk,us,cn", help="Comma-separated markets used when --symbols is omitted.")
    company_tag_refresh_parser.add_argument("--limit-per-market", type=int, default=0, help="0 means all symbols per market.")
    company_tag_refresh_parser.add_argument("--batch-size", type=int, default=200, help="Offline-table query batch size.")
    company_tag_refresh_parser.add_argument("--include-valuation", action="store_true", help="Also call the slower valuation endpoint when --live-api is used.")
    company_tag_refresh_parser.add_argument("--live-api", action="store_true", help="Fetch each symbol from Longbridge live API instead of offline tables.")

    multibagger_parser = sub.add_parser(
        "screen-multibagger-candidates",
        help="Screen daily multibagger candidates and optionally push an after-close QQ summary.",
    )
    multibagger_parser.add_argument("--market", choices=["us", "hk", "cn", "all"], default="us")
    multibagger_parser.add_argument("--dsn", default="dbname=longbridge_stock user=alwin host=/var/run/postgresql")
    multibagger_parser.add_argument("--start-date", default="2026-01-01")
    multibagger_parser.add_argument("--limit", type=int, default=30)
    multibagger_parser.add_argument("--min-turnover", type=float, default=10_000_000.0)
    multibagger_parser.add_argument("--min-close", type=float, default=2.0)
    multibagger_parser.add_argument("--format", choices=["json", "table"], default="json")
    multibagger_parser.add_argument("--input-csv")
    multibagger_parser.add_argument("--send-openclaw", action="store_true")
    multibagger_parser.add_argument("--dry-run", action="store_true")
    multibagger_parser.add_argument("--targets", help="OpenClaw targets, for example qqbot=...")
    multibagger_parser.add_argument("--push-limit", type=int, default=5)
    multibagger_parser.add_argument("--backtest-evaluated-signals", type=int, default=0)
    multibagger_parser.add_argument("--backtest-precision-at-top5", type=float)

    reversal_backtest_parser = sub.add_parser(
        "backtest-limit-reversal-line",
        help="Backtest the limit-up pullback 0/1/2/3-line red-candle buy pattern.",
    )
    reversal_backtest_parser.add_argument("--dsn", default="dbname=longbridge_stock user=alwin host=/var/run/postgresql")
    reversal_backtest_parser.add_argument("--start-date")
    reversal_backtest_parser.add_argument("--end-date")
    reversal_backtest_parser.add_argument("--output-dir", default="reports")

    reversal_candidates_parser = sub.add_parser(
        "limit-reversal-line-candidates",
        help="Print current A-share candidates matching the limit-up 0/1/2/3-line red-candle pattern.",
    )
    reversal_candidates_parser.add_argument("--dsn", default="dbname=longbridge_stock user=alwin host=/var/run/postgresql")
    reversal_candidates_parser.add_argument("--as-of-date")
    reversal_candidates_parser.add_argument("--lookback-days", type=int, default=90)
    reversal_candidates_parser.add_argument("--limit", type=int, default=50)

    args = parser.parse_args(argv)

    if args.command == "list-factors":
        for name in list_factors():
            print(name)
        return 0

    if args.command == "sync-longbridge":
        sync_config = load_longbridge_sync_config(args.sync_config)
        client = _market_data_client(args.client, sync_config.rate_limit_per_second)
        sync = LongbridgeDataSync(
            sync_config,
            client=client,
            client_factory=lambda: _market_data_client(args.client, sync_config.rate_limit_per_second),
        )
        if args.once:
            results = sync.sync_once()
            ok = sum(1 for item in results if item.ok)
            failed = len(results) - ok
            print(json.dumps({"ok": ok, "failed": failed, "total": len(results)}, indent=2, ensure_ascii=False))
            return 1 if failed else 0
        sync.run_forever(args.interval_seconds)
        return 0

    if args.command == "sync-status":
        status = read_sync_status(args.data_root)
        print(json.dumps(status or {}, indent=2, ensure_ascii=False))
        return 0

    if args.command == "sync-postgres":
        counters = LongbridgePostgresStore(args.dsn).import_raw_tree(args.data_root)
        print(json.dumps(counters, indent=2, ensure_ascii=False))
        return 0

    if args.command == "sync-akshare-daily":
        sync = AkshareDailySync(args.dsn)
        if args.symbols:
            symbols = [item.strip().upper() for item in args.symbols.split(",") if item.strip()]
        else:
            symbols = sync.load_symbols(limit=args.limit)
        summary = sync.sync_once(
            symbols,
            start_date=args.start_date,
            end_date=args.end_date,
            adjust=args.adjust,
            merge_to_daily=args.merge_to_daily,
        )
        print(json.dumps(summary.to_dict(), indent=2, ensure_ascii=False))
        return 1 if summary.failed and summary.written == 0 else 0

    if args.command == "sync-eastmoney-external":
        datasets = [item.strip() for item in args.datasets.split(",") if item.strip()]
        sync = EastmoneyExternalSync(args.dsn)
        summary = sync.sync_once(
            trade_date=args.trade_date,
            datasets=datasets,
            include_components=args.include_components,
            component_limit=args.component_limit,
        )
        print(json.dumps(summary.to_dict(), indent=2, ensure_ascii=False))
        return 1 if summary.failed and not summary.written else 0

    if args.command == "sync-eastmoney-f10":
        markets = [item.strip() for item in args.markets.split(",") if item.strip()]
        symbols = [item.strip() for item in args.symbols.split(",") if item.strip()] if args.symbols else None
        sync = EastmoneyF10Sync(
            args.dsn,
            max_workers=args.max_workers,
            request_interval_seconds=args.request_interval_seconds,
            timeout_seconds=args.timeout_seconds,
        )
        summary = sync.sync_once(markets=markets, symbols=symbols, limit=args.limit)
        print(json.dumps(summary.to_dict(), indent=2, ensure_ascii=False))
        return 1 if summary.failed and summary.succeeded == 0 else 0

    if args.command == "sync-realtime-quotes":
        sync = RealtimeQuoteSync(
            dsn=args.dsn,
            client=_market_data_client(args.client, args.rate_limit_per_second),
            batch_size=args.batch_size,
        )
        markets = [item.strip() for item in args.markets.split(",") if item.strip()]
        symbols = sync.load_symbols(markets, limit=args.limit, priority_only=args.priority_only)
        if args.once:
            summary = sync.sync_once(symbols)
            print(json.dumps(summary.to_dict(), indent=2, ensure_ascii=False))
            return 0 if summary.written else 1
        sync.run_forever(symbols, interval_seconds=args.interval_seconds)
        return 0

    if args.command == "sync-realtime-capital":
        sync = RealtimeCapitalSync(
            dsn=args.dsn,
            client=_market_data_client(args.client, args.rate_limit_per_second),
            include_flow=args.include_flow,
        )
        markets = [item.strip() for item in args.markets.split(",") if item.strip()]
        symbols = sync.load_symbols(markets, limit=args.limit, priority_only=args.priority_only)
        if args.once:
            summary = sync.sync_once(symbols)
            print(json.dumps(summary.to_dict(), indent=2, ensure_ascii=False))
            return 0 if summary.written else 1
        sync.run_forever(symbols, interval_seconds=args.interval_seconds)
        return 0

    if args.command == "sync-realtime-microstructure":
        sync = RealtimeMicrostructureSync(
            dsn=args.dsn,
            client=LongbridgeSdkClient(rate_limit_per_second=args.rate_limit_per_second),
            trade_count=args.trade_count,
        )
        markets = [item.strip() for item in args.markets.split(",") if item.strip()]
        datasets = [item.strip() for item in args.datasets.split(",") if item.strip()]
        limit = args.limit if args.limit is not None else (None if args.all_symbols else 200)
        symbols = sync.load_symbols(markets, limit=limit, priority_only=not args.all_symbols)
        if args.once:
            summary = sync.sync_once(symbols, datasets)
            print(json.dumps(summary.to_dict(), indent=2, ensure_ascii=False))
            return 0 if summary.written_symbols else 1
        sync.run_forever(symbols, datasets=datasets, interval_seconds=args.interval_seconds)
        return 0

    if args.command == "sync-market-temperature":
        sync = MarketTemperatureSync(
            dsn=args.dsn,
            client=LongbridgeSdkClient(rate_limit_per_second=args.rate_limit_per_second),
        )
        markets = [item.strip() for item in args.markets.split(",") if item.strip()]
        if args.once:
            summary = sync.sync_once(markets)
            print(json.dumps(summary.to_dict(), indent=2, ensure_ascii=False))
            return 0 if summary.written else 1
        while True:
            summary = sync.sync_once(markets)
            print(json.dumps(summary.to_dict(), ensure_ascii=False), flush=True)
            import time

            time.sleep(max(args.interval_seconds, 1))

    if args.command == "alert-realtime":
        markets = [item.strip().lower() for item in args.markets.split(",") if item.strip()]
        monitor = RealtimeAlertMonitor(
            dsn=args.dsn,
            config=RealtimeAlertConfig(
                markets=markets,
                buy_score=args.buy_score,
                strong_buy_score=args.strong_buy_score,
                limit=args.limit,
                pool=args.pool,
                max_alerts_per_run=args.max_alerts_per_run,
            ),
            notifier=build_default_notifier(args.targets),
            state=AlertState(args.state_path),
        )
        if args.once:
            summary = monitor.run_once()
            print(json.dumps(summary, indent=2, ensure_ascii=False))
            return 1 if summary.get("errors") else 0
        monitor.run_forever(args.interval_seconds)
        return 0

    if args.command == "alert-us-fast":
        monitor = build_default_us_fast_monitor(
            dsn=args.dsn,
            config=USFastAlertConfig(
                profile=args.profile,
                min_probability=args.min_probability,
                sell_probability=args.sell_probability,
                limit=args.limit,
                max_alerts_per_run=args.max_alerts_per_run,
                execution_lookback_days=args.execution_lookback_days,
            ),
            state_path=args.state_path,
            targets=args.targets,
        )
        if args.once:
            summary = monitor.run_once()
            print(json.dumps(summary, indent=2, ensure_ascii=False))
            return 1 if summary.get("errors") else 0
        monitor.run_forever(args.interval_seconds)
        return 0

    if args.command == "alert-limit-reversal":
        monitor = LimitReversalAlertMonitor(
            dsn=args.dsn,
            config=LimitReversalAlertConfig(
                markets=parse_markets(args.markets),
                event_threshold=args.event_threshold,
                lookback_days=args.lookback_days,
                limit=args.limit,
                min_red_pct=args.min_red_pct,
                max_quote_age_minutes=args.max_quote_age_minutes,
                max_alerts_per_run=args.max_alerts_per_run,
            ),
            notifier=build_default_notifier(args.targets),
            state=AlertState(args.state_path),
        )
        if args.once:
            summary = monitor.run_once()
            print(json.dumps(summary, indent=2, ensure_ascii=False))
            return 1 if summary.get("errors") else 0
        monitor.run_forever(args.interval_seconds)
        return 0

    if args.command == "alert-holding-capital":
        symbols = resolve_hk_holding_symbols(args.symbols, fallback_symbols_arg=args.fallback_symbols)
        monitor = HoldingCapitalAlertMonitor(
            dsn=args.dsn,
            config=HoldingCapitalAlertConfig(
                symbols=symbols,
                max_quote_age_minutes=args.max_quote_age_minutes,
                large_net_ratio_threshold=args.large_net_ratio_threshold,
                flow_30m_threshold=args.flow_30m_threshold,
                max_alerts_per_run=args.max_alerts_per_run,
            ),
            notifier=build_default_notifier(args.targets),
            state=AlertState(args.state_path),
        )
        if args.once:
            summary = monitor.run_once()
            print(json.dumps(summary, indent=2, ensure_ascii=False))
            return 1 if summary.get("errors") else 0
        monitor.run_forever(args.interval_seconds)
        return 0

    if args.command == "alert-holding-stock-tags":
        symbols = resolve_equity_holding_symbols(args.symbols, fallback_symbols_arg=args.fallback_symbols)
        monitor = HoldingStockTagChangeMonitor(
            config=HoldingStockTagChangeConfig(
                symbols=symbols,
                lookback_days=args.lookback_days,
                max_alerts_per_run=args.max_alerts_per_run,
                check_trading_time=not args.ignore_trading_time,
                notify_on_first_run=args.notify_on_first_run,
            ),
            notifier=build_default_notifier(args.targets),
            state=StockTagChangeState(args.state_path),
            names_by_symbol=load_equity_holding_names(symbols),
        )
        if args.once:
            summary = monitor.run_once()
            print(json.dumps(summary, indent=2, ensure_ascii=False))
            return 1 if summary.get("errors") else 0
        monitor.run_forever(args.interval_seconds)
        return 0

    if args.command == "monitor-maintenance":
        ensure_monitoring_schema(args.dsn)
        swept = sweep_stale_jobs(args.dsn, timeout_seconds=args.timeout_seconds) if args.sweep_stale_jobs else 0
        alerts = refresh_collection_alerts(args.dsn, stale_after_seconds=args.stale_alert_seconds)
        print(json.dumps({"ok": True, "staleJobsSwept": swept, "openAlertsTouched": alerts}, indent=2, ensure_ascii=False))
        return 0

    if args.command == "generate-research-snapshots":
        financial_fetcher = (
            _market_data_client(args.client, args.rate_limit_per_second)
            if args.fetch_missing_financials or args.refresh_financials
            else None
        )
        repository = PostgresResearchSnapshotRepository(
            args.dsn,
            financial_fetcher=financial_fetcher,
            rate_limit_per_second=args.rate_limit_per_second,
        )
        llm_client = None
        if not args.no_llm:
            llm_client = LLMClient.from_ozon_config() if args.use_ozon_config else LLMClient()
        results = generate_research_snapshot_batch(
            repository=repository,
            news_fetcher=CombinedNewsFetcher(LongbridgeNewsFetcher(), GoogleNewsRssFetcher()),
            llm_client=llm_client,
            market=args.market,
            limit=args.limit,
            stale_hours=args.stale_hours,
            news_limit=args.news_limit,
            refresh_financials=args.refresh_financials,
            dry_run=args.dry_run,
        )
        ok = sum(1 for item in results if item.get("ok"))
        failed = len(results) - ok
        print(json.dumps({"ok": ok, "failed": failed, "results": results}, indent=2, ensure_ascii=False))
        return 1 if failed else 0

    if args.command == "build-limit-up-events":
        summary = refresh_limit_up_events(dsn=args.dsn, start_date=args.start_date, end_date=args.end_date)
        print(json.dumps(summary_to_dict(summary), indent=2, ensure_ascii=False))
        return 0

    if args.command == "train-limit-up-model":
        summary = train_limit_up_model_from_db(
            dsn=args.dsn,
            model_root=args.model_root,
            validation_ratio=args.validation_ratio,
            min_events=args.min_events,
        )
        print(json.dumps(summary_to_dict(summary), indent=2, ensure_ascii=False))
        return 0

    if args.command == "predict-limit-up":
        summary = predict_limit_up_candidates(
            dsn=args.dsn,
            event_date=args.event_date,
            model_root=args.model_root,
            limit=args.limit,
        )
        print(json.dumps(summary_to_dict(summary), indent=2, ensure_ascii=False))
        return 0

    if args.command == "limit-up-candidates":
        frame = fetch_limit_up_candidates(dsn=args.dsn, event_date=args.event_date, limit=args.limit)
        print(json.dumps(frame.to_dict("records"), indent=2, ensure_ascii=False, default=str))
        return 0

    if args.command == "train-pool-gain-model":
        summary = train_pool_gain_model_from_db(
            dsn=args.dsn,
            model_root=args.model_root,
            start_date=args.start_date,
            validation_ratio=args.validation_ratio,
            max_rows=args.max_rows,
        )
        print(json.dumps(pool_gain_summary_to_dict(summary), indent=2, ensure_ascii=False))
        return 0

    if args.command == "predict-pool-gain":
        summary = predict_pool_gain_candidates(
            dsn=args.dsn,
            model_root=args.model_root,
            as_of_date=args.as_of_date,
            limit=args.limit,
        )
        print(json.dumps(pool_gain_summary_to_dict(summary), indent=2, ensure_ascii=False, default=str))
        return 0

    if args.command == "pool-gain-candidates":
        frame = fetch_pool_gain_predictions(dsn=args.dsn, as_of_date=args.as_of_date, limit=args.limit)
        print(json.dumps(frame.to_dict("records"), indent=2, ensure_ascii=False, default=str))
        return 0

    if args.command == "train-realtime-profit-model":
        summary = train_realtime_profit_model(
            dsn=args.dsn,
            market=args.market,
            model_root=args.model_root,
            lookback_days=args.lookback_days,
            horizon_minutes=args.horizon_minutes,
            target_return=args.target_return,
            max_rows=args.max_rows,
            profile=args.profile,
            as_of_date=args.as_of_date,
            target_direction=args.target_direction,
        )
        print(json.dumps(realtime_profit_summary_to_dict(summary), indent=2, ensure_ascii=False, default=str))
        return 0

    if args.command == "predict-realtime-profit":
        summary = predict_realtime_profit(
            dsn=args.dsn,
            market=args.market,
            model_root=args.model_root,
            limit=args.limit,
            profile=args.profile,
            target_direction=args.target_direction,
        )
        print(json.dumps(realtime_profit_summary_to_dict(summary), indent=2, ensure_ascii=False, default=str))
        return 0

    if args.command == "validate-realtime-profit":
        summary = backfill_realtime_profit_actuals(
            dsn=args.dsn,
            market=args.market,
            limit=args.limit,
            max_age_days=args.max_age_days,
        )
        print(json.dumps(realtime_profit_summary_to_dict(summary), indent=2, ensure_ascii=False, default=str))
        return 0

    if args.command == "review-realtime-profit-2pct":
        summary = review_realtime_profit_2pct_outcomes(
            market=args.market,
            profile=args.profile,
            lookback_days=args.lookback_days,
            min_probability=args.min_probability,
            target_return=args.target_return,
            limit=args.limit,
        )
        print(json.dumps(realtime_profit_summary_to_dict(summary), indent=2, ensure_ascii=False, default=str))
        return 0

    if args.command == "refresh-stock-pool-snapshot":
        summary = refresh_stock_pool_snapshots(
            dsn=args.dsn,
            markets=[item.strip() for item in args.markets.split(",") if item.strip()],
            strategies=[item.strip() for item in args.strategies.split(",") if item.strip()],
            limit=args.limit,
        )
        print(json.dumps(summary.__dict__, indent=2, ensure_ascii=False, default=str))
        return 0

    if args.command == "analyze-market-macro-trend":
        index_symbols = tuple(symbol.strip().upper() for symbol in (args.index_symbols or "").split(",") if symbol.strip()) or None
        report = build_market_macro_report(
            MacroTrendConfig(
                market=args.market,
                index_symbols=index_symbols,
                industry_count=args.industry_count,
                top_mover_count=args.top_mover_count,
                anomaly_count=args.anomaly_count,
                constituent_limit=args.constituent_limit,
                news_per_symbol=args.news_per_symbol,
                include_news=not args.no_news,
            )
        )
        if args.format == "summary":
            print(report.get("summary") or "")
        else:
            print(json.dumps(report, indent=2, ensure_ascii=False, default=str))
        return 0

    if args.command == "tag-company-fundamentals":
        report = build_company_fundamental_tags(
            CompanyFundamentalTagConfig(
                symbols=[item.strip().upper() for item in args.symbols if item.strip()],
                include_valuation=not args.no_valuation,
            )
        )
        if args.format == "summary":
            print(_format_company_fundamental_summary(report))
        else:
            print(json.dumps(report, indent=2, ensure_ascii=False, default=str))
        return 0

    if args.command == "refresh-company-fundamental-tags":
        summary = refresh_company_fundamental_tag_store(
            dsn=args.dsn,
            symbols=[item.strip().upper() for item in args.symbols.split(",") if item.strip()] if args.symbols else None,
            markets=[item.strip().lower() for item in args.markets.split(",") if item.strip()],
            limit_per_market=args.limit_per_market if args.limit_per_market > 0 else None,
            batch_size=args.batch_size,
            include_valuation=args.include_valuation,
            use_offline=not args.live_api,
        )
        print(json.dumps(summary, indent=2, ensure_ascii=False, default=str))
        return 1 if summary.get("updated", 0) == 0 and summary.get("failed") else 0

    if args.command == "screen-multibagger-candidates":
        bars = load_multibagger_bars(args)
        report = scan_multibagger_candidates(
            bars,
            MultibaggerScanConfig(
                min_close=args.min_close,
                min_turnover=args.min_turnover,
                limit=args.limit,
            ),
        )
        report["backtest_gate"] = evaluate_backtest_gate(
            {
                "evaluated_signals": args.backtest_evaluated_signals,
                "precision_at_top5": args.backtest_precision_at_top5,
            },
            BacktestGateConfig(),
        )
        if args.send_openclaw:
            message = build_multibagger_after_close_message(report, top_n=args.push_limit)
            if args.dry_run:
                print(json.dumps({"dry_run_openclaw": message}, ensure_ascii=False))
            else:
                build_default_notifier(args.targets).send(message)
                print(json.dumps({"sent_openclaw": True, "message_preview": message[:200]}, ensure_ascii=False))
            return 0
        if args.format == "table":
            print(_format_multibagger_table(report))
        else:
            print(json.dumps(report, indent=2, ensure_ascii=False, default=str))
        return 0

    if args.command == "backtest-limit-reversal-line":
        summary = backtest_limit_reversal_lines(
            dsn=args.dsn,
            start_date=args.start_date,
            end_date=args.end_date,
            output_dir=args.output_dir,
        )
        print(json.dumps(limit_reversal_summary_to_dict(summary), indent=2, ensure_ascii=False, default=str))
        return 0

    if args.command == "limit-reversal-line-candidates":
        frame = current_limit_reversal_candidates(
            dsn=args.dsn,
            as_of_date=args.as_of_date,
            lookback_days=args.lookback_days,
            limit=args.limit,
        )
        print(json.dumps(frame.to_dict("records"), indent=2, ensure_ascii=False, default=str))
        return 0

    data_config = load_data_config(args.data_config)

    experiment = load_experiment_config(args.experiment_config)
    data = load_market_data(data_config, experiment.start_time, experiment.end_time, source=args.source)

    if args.command == "inspect-data":
        print(_inspect_data(data))
        return 0

    factors = compute_factor_set(data, experiment.factor_set)
    scores = _weighted_score(factors, experiment.score_weights)
    test_start = experiment.test_start_time or experiment.start_time
    test_end = experiment.test_end_time or experiment.end_time
    test_mask = (scores.index.get_level_values("datetime") >= pd.Timestamp(test_start)) & (
        scores.index.get_level_values("datetime") <= pd.Timestamp(test_end)
    )
    result = run_topk_backtest(
        market_data=data.loc[test_mask],
        scores=scores.loc[test_mask],
        top_k=experiment.backtest.top_k,
        cost_rate=experiment.backtest.cost_rate,
    )
    if args.command == "run-monte-carlo":
        monte_carlo = run_monte_carlo_backtest(
            result.daily,
            simulations=args.simulations,
            horizon_days=args.horizon_days,
            seed=args.seed,
        )
        print(
            json.dumps(
                {
                    "backtest_metrics": result.metrics,
                    "monte_carlo_metrics": monte_carlo.metrics,
                },
                indent=2,
                ensure_ascii=False,
            )
        )
        return 0

    if args.command == "run-standard-backtest":
        out = create_experiment_dir(args.output_dir, f"{experiment.name}_standard")
        save_backtest_result(out, result, scores.loc[test_mask])
        qlib_spec = QlibWorkflowSpec(
            handler=args.qlib_handler,
            model=args.qlib_model,
            strategy=args.qlib_strategy,
            topk=experiment.backtest.top_k,
            close_cost=experiment.backtest.cost_rate,
        )
        qlib_config = save_qlib_workflow_config(out / "qlib_workflow.yaml", data_config, experiment, qlib_spec)
        qlib_report: dict[str, object] = {
            "status": "config_ready",
            "config_path": str(qlib_config),
            "handler": args.qlib_handler,
            "model": args.qlib_model,
            "strategy": args.qlib_strategy,
        }
        if args.start_qlib:
            run = start_local_qrun(qlib_config, local_root=args.qlib_run_root, experiment_name=f"{experiment.name}_standard")
            qlib_report.update(
                {
                    "status": "started",
                    "run_id": run.run_id,
                    "run_dir": run.remote_dir,
                    "log_path": run.log_path,
                    "pid": run.pid,
                }
            )
        monte_carlo = run_monte_carlo_backtest(
            result.daily,
            simulations=args.simulations,
            horizon_days=args.horizon_days,
            seed=args.seed,
        )
        report = {
            "standard_backtest": {
                "output_dir": str(out),
                "topk_backtest": {
                    "status": "completed",
                    "metrics": result.metrics,
                },
                "qlib_backtest": qlib_report,
                "monte_carlo": {
                    "status": "completed",
                    "metrics": monte_carlo.metrics,
                },
                "composite": _standard_backtest_composite(result.metrics, monte_carlo.metrics, qlib_report),
            }
        }
        print(json.dumps(report, indent=2, ensure_ascii=False))
        return 0

    out = create_experiment_dir(args.output_dir, experiment.name)
    save_backtest_result(out, result, scores.loc[test_mask])
    print(json.dumps({"output_dir": str(out), "metrics": result.metrics}, indent=2, ensure_ascii=False))
    return 0


def _weighted_score(factors: pd.DataFrame, weights: dict[str, float]) -> pd.Series:
    missing = [name for name in weights if name not in factors.columns]
    if missing:
        raise KeyError(f"Score weights reference unknown factors: {', '.join(missing)}")
    normalized = factors[list(weights)].groupby(level="datetime").rank(pct=True)
    score = sum(normalized[name].fillna(0.5) * weight for name, weight in weights.items())
    return score.rename("score")


def _inspect_data(data: pd.DataFrame) -> str:
    dates = data.index.get_level_values("datetime")
    instruments = data.index.get_level_values("instrument")
    payload = {
        "rows": int(len(data)),
        "instruments": int(instruments.nunique()),
        "start": str(dates.min().date()),
        "end": str(dates.max().date()),
        "columns": list(data.columns),
    }
    return json.dumps(payload, indent=2, ensure_ascii=False)


def _standard_backtest_composite(
    topk_metrics: dict[str, float],
    monte_carlo_metrics: dict[str, float | int],
    qlib_report: dict[str, object],
) -> dict[str, object]:
    sharpe = _clip01((_number(topk_metrics.get("sharpe")) + 1.0) / 3.0)
    annual = _clip01((_number(topk_metrics.get("annual_return")) + 0.2) / 0.6)
    drawdown = _clip01(1.0 + _number(topk_metrics.get("max_drawdown")) / 0.35)
    loss = _clip01(1.0 - _number(monte_carlo_metrics.get("loss_probability")))
    var = _clip01(1.0 - _number(monte_carlo_metrics.get("var_95")) / 0.25)
    qlib = 1.0 if qlib_report.get("status") in {"config_ready", "started", "completed"} else 0.0
    score = 100.0 * (0.25 * sharpe + 0.2 * annual + 0.2 * drawdown + 0.2 * loss + 0.1 * var + 0.05 * qlib)
    if score >= 75:
        decision = "pass"
    elif score >= 55:
        decision = "watch"
    else:
        decision = "reject"
    return {
        "score": round(score, 2),
        "decision": decision,
        "weights": {
            "sharpe": 0.25,
            "annual_return": 0.2,
            "drawdown_control": 0.2,
            "monte_carlo_loss_probability": 0.2,
            "monte_carlo_var": 0.1,
            "qlib_readiness": 0.05,
        },
    }


def _number(value: object) -> float:
    try:
        return float(value)
    except (TypeError, ValueError):
        return 0.0


def _clip01(value: float) -> float:
    return max(0.0, min(1.0, value))


def load_multibagger_bars(args: argparse.Namespace) -> pd.DataFrame:
    if args.input_csv:
        return pd.read_csv(args.input_csv)
    query = """
        select symbol, trade_date, open, high, low, close, volume, turnover
        from lb_daily_bars
        where trade_date >= %s
          and (%s = 'all'
            or (%s = 'us' and right(symbol, 3) = '.US')
            or (%s = 'hk' and right(symbol, 3) = '.HK')
            or (%s = 'cn' and right(symbol, 3) in ('.SH', '.SZ')))
        order by symbol, trade_date
    """
    import psycopg

    with psycopg.connect(args.dsn) as conn:
        return pd.read_sql_query(query, conn, params=(args.start_date, args.market, args.market, args.market, args.market))


def _format_multibagger_table(report: dict[str, object]) -> str:
    rows = report.get("trend_pool") if isinstance(report, dict) else []
    if not rows:
        return "trend_pool empty"
    lines = ["symbol score return_20d return_60d reasons"]
    for row in rows if isinstance(rows, list) else []:
        if not isinstance(row, dict):
            continue
        reasons = ",".join(row.get("reasons") or [])
        lines.append(f"{row.get('symbol')} {row.get('score')} {row.get('return_20d')} {row.get('return_60d')} {reasons}")
    return "\n".join(lines)


def _format_company_fundamental_summary(report: dict[str, object]) -> str:
    items = report.get("items") if isinstance(report, dict) else []
    if not isinstance(items, list) or not items:
        return "company fundamental tags empty"
    lines: list[str] = []
    for item in items:
        if not isinstance(item, dict):
            continue
        labels = item.get("labels") if isinstance(item.get("labels"), dict) else {}
        metrics = item.get("metrics") if isinstance(item.get("metrics"), dict) else {}
        lines.append(
            "{symbol} {name}：{composite} | 市值={size} | 估值={valuation} | 成长={growth} | 盈利={profitability} | PE={pe} PB={pb}".format(
                symbol=item.get("symbol", ""),
                name=item.get("name", ""),
                composite=labels.get("composite", "-"),
                size=labels.get("size", "-"),
                valuation=labels.get("valuation", "-"),
                growth=labels.get("growth", "-"),
                profitability=labels.get("profitability", "-"),
                pe=_format_optional_number(metrics.get("pe")),
                pb=_format_optional_number(metrics.get("pb")),
            )
        )
    return "\n".join(lines)


def _format_optional_number(value: object) -> str:
    try:
        return f"{float(value):.2f}"
    except (TypeError, ValueError):
        return "-"


def load_equity_holding_names(symbols: list[str]) -> dict[str, str]:
    wanted = {symbol.strip().upper() for symbol in symbols}
    try:
        rows = run_positions_json()
    except Exception:
        return {symbol: symbol for symbol in wanted}
    names: dict[str, str] = {}
    for row in rows if isinstance(rows, list) else []:
        symbol = str(row.get("symbol") or "").strip().upper()
        if symbol in wanted:
            names[symbol] = str(row.get("name") or symbol).strip() or symbol
    for symbol in wanted:
        names.setdefault(symbol, symbol)
    return names


if __name__ == "__main__":
    raise SystemExit(main())
