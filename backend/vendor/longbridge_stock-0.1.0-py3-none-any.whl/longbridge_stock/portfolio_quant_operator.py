from __future__ import annotations

import re
from datetime import datetime
from typing import Any, Iterable

from longbridge_stock.asset_allocation import build_allocation_budget
from longbridge_stock.push_output import render_key_value_table


DEFAULT_FX_TO_USD = {"USD": 1.0, "HKD": 0.128, "CNY": 0.139, "CNH": 0.139}


def build_quant_operator_report(
    *,
    account: dict[str, Any],
    positions: Iterable[dict[str, Any]],
    quotes: dict[str, dict[str, Any]],
    as_of: datetime,
    markets: Iterable[str] | None = None,
) -> dict[str, Any]:
    position_rows = list(positions)
    priced_positions = [_position_with_usd_price(row, quotes.get(_symbol(row), {})) for row in position_rows]
    allocation = build_allocation_budget(account=account, positions=priced_positions, markets=markets)
    holdings = [
        _holding_decision(row, quotes.get(_symbol(row), {}), allocation)
        for row in priced_positions
        if _is_equity_position(row, markets=markets)
    ]
    holdings.sort(key=lambda row: (row["priority"], row["market_value"]), reverse=True)
    return {
        "as_of": as_of.isoformat(timespec="minutes"),
        "account": {
            "net_assets": round(_num(account.get("net_assets") or account.get("total_asset")), 2),
            "buy_power": round(_num(account.get("buy_power")), 2),
            "init_margin": round(_num(account.get("init_margin")), 2),
        },
        "allocation": allocation,
        "holdings": holdings,
        "top_actions": [row for row in holdings if row["action"] != "持有"][:5],
    }


def build_quant_operator_message(report: dict[str, Any]) -> str:
    allocation = report.get("allocation") or {}
    account = report.get("account") or {}
    option_limit = ((allocation.get("strategy_limits") or {}).get("option_income") or {})
    rows: list[tuple[str, Any]] = [
        ("净资产/买力", f"${_num(account.get('net_assets')):,.0f} / ${_num(account.get('buy_power')):,.0f}"),
        ("配置状态", _allocation_status_text(allocation.get("status"))),
        ("现金保留", f"${_num(allocation.get('reserve_cash')):,.0f}"),
        (
            "期权收入预算",
            f"已用${_num(option_limit.get('current')):,.0f} / 目标${_num(option_limit.get('target')):,.0f}，剩余${_num(option_limit.get('remaining')):,.0f}",
        ),
    ]
    action_rows = report.get("top_actions") or []
    if action_rows:
        for index, row in enumerate(action_rows, start=1):
            rows.append((f"#{index} {row['action']}", _holding_line(row)))
    else:
        rows.append(("操作", "当前持仓在预算内，暂不新增动作"))
    return render_key_value_table(f"【量化操作手】{report.get('as_of', '')}", rows)


def _holding_decision(row: dict[str, Any], quote: dict[str, Any], allocation: dict[str, Any]) -> dict[str, Any]:
    symbol = _symbol(row)
    name = str(row.get("name") or symbol)
    quantity = _num(row.get("quantity"))
    last = _num(quote.get("last") or row.get("local_market_price") or row.get("market_price") or row.get("last_price") or row.get("cost_price"))
    fx_to_usd = _fx_to_usd(row)
    market_value = abs(quantity) * last * fx_to_usd
    single_limit = _num(allocation.get("single_symbol_limit"))
    current_exposure = _num((allocation.get("symbol_exposure") or {}).get(symbol, market_value))
    change_pct = _num(quote.get("change_pct") or quote.get("change_percentage"))
    pnl_pct = _pct_change(last, row.get("cost_price") or row.get("average_cost"))
    target_value = min(market_value, single_limit) if single_limit > 0 else market_value
    target_quantity = int(target_value // (last * fx_to_usd)) if last > 0 and fx_to_usd > 0 else 0
    budget_status = str(allocation.get("status") or "")

    action = "持有"
    reason = "配置在预算内"
    priority = 1
    if budget_status == "blocked":
        action = "暂停新增"
        reason = "账户保证金或买力触发风控线"
        priority = 80
    if single_limit > 0 and current_exposure > single_limit * 1.15 and market_value > single_limit * 1.05:
        action = "减仓降风险"
        reason = "单票暴露超过账户上限"
        priority = 100
    elif single_limit > 0 and current_exposure > single_limit * 1.15:
        action = "降衍生品风险"
        reason = "同标的期权/正股合计暴露超过账户上限"
        priority = 90
    elif change_pct <= -3.0:
        action = "观察止损/对冲"
        reason = "日内跌幅较大，优先保护回撤"
        priority = 70
    elif change_pct >= 2.5 and budget_status != "blocked":
        action = "强势持有"
        reason = "日内强势，先保留核心仓位"
        priority = 40

    return {
        "symbol": symbol,
        "name": name,
        "quantity": round(quantity, 2),
        "last": round(last, 4),
        "currency": str(row.get("currency") or _currency_from_market(symbol, row)),
        "fx_to_usd": fx_to_usd,
        "market_value": round(market_value, 2),
        "current_exposure": round(current_exposure, 2),
        "target_value": round(target_value, 2),
        "target_quantity": target_quantity,
        "change_pct": round(change_pct, 2),
        "pnl_pct": round(pnl_pct, 2) if pnl_pct is not None else None,
        "action": action,
        "reason": reason,
        "priority": priority,
    }


def _holding_line(row: dict[str, Any]) -> str:
    pnl = f"，盈亏{row['pnl_pct']:.1f}%" if row.get("pnl_pct") is not None else ""
    return (
        f"{row['symbol']} {row.get('name') or ''}，现价{row['last']:.2f}，"
        f"日内{row['change_pct']:.1f}%{pnl}，市值${row['market_value']:,.0f}，"
        f"目标约{row['target_quantity']}股，原因：{row['reason']}"
    )


def _is_equity_position(row: dict[str, Any], *, markets: Iterable[str] | None = None) -> bool:
    symbol = _symbol(row)
    quantity = _num(row.get("quantity"))
    if quantity <= 0 or _looks_like_us_option(symbol):
        return False
    allowed = {str(market).upper() for market in markets or []}
    return not allowed or _market_of(symbol, row) in allowed


def _allocation_status_text(status: Any) -> str:
    return {
        "normal": "正常",
        "caution": "谨慎",
        "blocked": "暂停新增",
    }.get(str(status or ""), str(status or "-"))


def _pct_change(value: float, base: Any) -> float | None:
    base_value = _num(base)
    if base_value <= 0:
        return None
    return (value / base_value - 1.0) * 100.0


def _position_with_usd_price(row: dict[str, Any], quote: dict[str, Any]) -> dict[str, Any]:
    copied = dict(row)
    last = _num(quote.get("last") or row.get("market_price") or row.get("last_price") or row.get("cost_price"))
    copied["local_market_price"] = last
    copied["market_price"] = last * _fx_to_usd(row)
    return copied


def _fx_to_usd(row: dict[str, Any]) -> float:
    currency = str(row.get("currency") or _currency_from_market(_symbol(row), row)).upper()
    return DEFAULT_FX_TO_USD.get(currency, 1.0)


def _currency_from_market(symbol: str, row: dict[str, Any]) -> str:
    market = _market_of(symbol, row)
    if market == "HK":
        return "HKD"
    if market in {"SH", "SZ", "CN"}:
        return "CNY"
    return "USD"


def _symbol(row: dict[str, Any]) -> str:
    return str(row.get("symbol") or "").strip().upper()


def _market_of(symbol: str, row: dict[str, Any]) -> str:
    market = str(row.get("market") or "").strip().upper()
    if market:
        return market
    return symbol.rsplit(".", 1)[-1] if "." in symbol else ""


def _looks_like_us_option(symbol: str) -> bool:
    core = symbol.removesuffix(".US")
    return bool(re.search(r"\d{6}[CP]\d+$", core))


def _num(value: Any) -> float:
    if value is None or value == "":
        return 0.0
    try:
        return float(value)
    except (TypeError, ValueError):
        return 0.0
