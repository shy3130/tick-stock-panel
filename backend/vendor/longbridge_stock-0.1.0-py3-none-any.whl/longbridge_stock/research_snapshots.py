from __future__ import annotations

import json
import time
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any, Callable, Protocol
from urllib.parse import quote_plus
from urllib.request import urlopen
from xml.etree import ElementTree as ET

from psycopg.types.json import Jsonb

from longbridge_stock.longbridge_sync import LongbridgeCliClient
from longbridge_stock.postgres_store import LongbridgePostgresStore


@dataclass(frozen=True)
class ResearchTarget:
    symbol: str
    market: str
    name: str
    score_date: str | None = None
    total_score: float | None = None
    strategy_score: float | None = None
    decision: str = ""
    model_reason: str = ""


@dataclass(frozen=True)
class FinancialFact:
    report_type: str
    report_period: str
    name: str
    value: Any
    yoy: str | None = None
    currency: str | None = None


@dataclass(frozen=True)
class NewsItem:
    title: str
    summary: str = ""
    url: str = ""
    source: str = ""
    published_at: str = ""


@dataclass(frozen=True)
class ResearchSnapshot:
    symbol: str
    market: str
    as_of: datetime
    financial_summary: str
    news_items: list[dict[str, str]]
    hotspots: list[str]
    llm_summary: str
    sources: list[dict[str, str]]
    payload: dict[str, Any]


class LLMTextClient(Protocol):
    def complete(self, prompt: str) -> str: ...


class NewsFetcher(Protocol):
    def fetch(self, target: ResearchTarget, limit: int = 5) -> list[NewsItem]: ...


class ResearchSnapshotRepository:
    def list_targets(self, market: str = "all", limit: int = 100, stale_hours: int = 24) -> list[ResearchTarget]:
        raise NotImplementedError

    def ensure_financial_report(self, target: ResearchTarget, refresh: bool = False) -> list[FinancialFact]:
        raise NotImplementedError

    def insert_snapshot(self, snapshot: ResearchSnapshot) -> None:
        raise NotImplementedError


class PostgresResearchSnapshotRepository(ResearchSnapshotRepository):
    def __init__(
        self,
        dsn: str,
        financial_fetcher: LongbridgeCliClient | None = None,
        rate_limit_per_second: float = 5.0,
    ) -> None:
        self.dsn = dsn
        self.financial_fetcher = financial_fetcher
        self.store = LongbridgePostgresStore(dsn)
        self.min_interval = 1.0 / rate_limit_per_second if rate_limit_per_second > 0 else 0.2
        self._last_financial_fetch = 0.0

    def list_targets(self, market: str = "all", limit: int = 100, stale_hours: int = 24) -> list[ResearchTarget]:
        import psycopg

        with psycopg.connect(self.dsn) as conn:
            columns = _table_columns(conn, "lb_stock_scores")
            model_reason_expr = score_column_expr(columns, "model_reason", "''")
            rows = conn.execute(
                f"""
                select s.symbol, s.market, coalesce(sym.name, s.symbol) as name,
                       s.score_date, s.total_score, s.decision, {model_reason_expr} as model_reason
                from lb_stock_scores s
                left join lb_symbols sym on sym.symbol = s.symbol
                where s.score_date = (select max(score_date) from lb_stock_scores)
                  and (%s = 'all' or s.market = %s)
                  and not exists (
                    select 1
                    from lb_stock_research_snapshots r
                    where r.symbol = s.symbol
                      and r.updated_at >= now() - (%s::text || ' hours')::interval
                  )
                order by s.total_score desc nulls last, s.symbol
                limit %s
                """,
                (market, market, stale_hours, limit),
            ).fetchall()
            scored_targets = [
                ResearchTarget(
                    symbol=str(row[0]),
                    market=str(row[1]),
                    name=str(row[2] or row[0]),
                    score_date=str(row[3]) if row[3] is not None else None,
                    total_score=_float_or_none(row[4]),
                    strategy_score=_float_or_none(row[4]),
                    decision=str(row[5] or ""),
                    model_reason=str(row[6] or ""),
                )
                for row in rows
            ]
            fast_targets = self._list_us_fast_targets(conn, market=market, limit=limit, stale_hours=stale_hours)
        return _dedupe_targets([*fast_targets, *scored_targets])[:limit]

    def _list_us_fast_targets(self, conn: Any, *, market: str, limit: int, stale_hours: int) -> list[ResearchTarget]:
        if market not in {"all", "us"}:
            return []
        try:
            rows = conn.execute(
                """
                with latest as (
                  select max(run_time) as run_time
                  from lb_us_fast_candidate_pool
                  where trade_date = (now() at time zone 'Asia/Shanghai')::date
                )
                select p.symbol,
                       coalesce(nullif(p.name, ''), sym.name, p.symbol) as name,
                       p.trade_date,
                       p.score,
                       p.decision,
                       p.output_stage
                from lb_us_fast_candidate_pool p
                join latest l on p.run_time = l.run_time
                left join lb_symbols sym on sym.symbol = p.symbol
                where not exists (
                  select 1
                  from lb_stock_research_snapshots r
                  where r.symbol = p.symbol
                    and r.updated_at >= now() - (%s::text || ' hours')::interval
                )
                order by p.rank asc
                limit %s
                """,
                (stale_hours, limit),
            ).fetchall()
        except Exception:
            return []
        return [
            ResearchTarget(
                symbol=str(row[0]),
                market="us",
                name=str(row[1] or row[0]),
                score_date=str(row[2]) if row[2] is not None else None,
                total_score=_float_or_none(row[3]),
                strategy_score=_float_or_none(row[3]),
                decision=str(row[4] or ""),
                model_reason=f"US Fast candidate pool: {row[5] or ''}".strip(),
            )
            for row in rows
        ]

    def ensure_financial_report(self, target: ResearchTarget, refresh: bool = False) -> list[FinancialFact]:
        facts = self._load_financial_facts(target.symbol)
        if facts and not refresh:
            return facts
        if self.financial_fetcher is not None:
            self._wait_for_financial_rate_limit()
            payload = self.financial_fetcher.financial_report(target.symbol)
            self.store.upsert_dataset(target.symbol, target.market, "financial_report", payload, datetime.now(timezone.utc))
            facts = self._load_financial_facts(target.symbol)
        return facts

    def insert_snapshot(self, snapshot: ResearchSnapshot) -> None:
        import psycopg

        with psycopg.connect(self.dsn) as conn:
            conn.execute(
                """
                insert into lb_stock_research_snapshots
                  (symbol, market, as_of, financial_summary, news_items, hotspots, llm_summary, sources, payload)
                values (%s, %s, %s, %s, %s, %s, %s, %s, %s)
                """,
                (
                    snapshot.symbol,
                    snapshot.market,
                    snapshot.as_of,
                    snapshot.financial_summary,
                    Jsonb(snapshot.news_items),
                    Jsonb(snapshot.hotspots),
                    snapshot.llm_summary,
                    Jsonb(snapshot.sources),
                    Jsonb(snapshot.payload),
                ),
            )

    def _load_financial_facts(self, symbol: str) -> list[FinancialFact]:
        import psycopg

        with psycopg.connect(self.dsn) as conn:
            rows = conn.execute(
                """
                select report_type, report_period, name, value, yoy, currency
                from lb_financial_report
                where symbol = %s
                order by fp_end desc nulls last, fiscal_year desc nulls last, report_type, field
                limit 18
                """,
                (symbol,),
            ).fetchall()
        return [
            FinancialFact(
                report_type=str(row[0] or ""),
                report_period=str(row[1] or ""),
                name=str(row[2] or ""),
                value=row[3],
                yoy=str(row[4]) if row[4] is not None else None,
                currency=str(row[5]) if row[5] is not None else None,
            )
            for row in rows
            if row[2]
        ]

    def _wait_for_financial_rate_limit(self) -> None:
        remaining = self.min_interval - (time.monotonic() - self._last_financial_fetch)
        if remaining > 0:
            time.sleep(remaining)
        self._last_financial_fetch = time.monotonic()


class GoogleNewsRssFetcher:
    def __init__(self, timeout: float = 10.0) -> None:
        self.timeout = timeout

    def fetch(self, target: ResearchTarget, limit: int = 5) -> list[NewsItem]:
        query = quote_plus(f"{target.name} {target.symbol} stock OR earnings OR revenue")
        url = f"https://news.google.com/rss/search?q={query}&hl=zh-CN&gl=CN&ceid=CN:zh-Hans"
        try:
            with urlopen(url, timeout=self.timeout) as response:
                xml = response.read()
            root = ET.fromstring(xml)
        except Exception:
            return []
        items: list[NewsItem] = []
        for item in root.findall(".//item")[:limit]:
            source_node = item.find("source")
            items.append(
                NewsItem(
                    title=_xml_text(item.find("title")),
                    summary=_clean_html(_xml_text(item.find("description"))),
                    url=_xml_text(item.find("link")),
                    source=_xml_text(source_node) or "Google News",
                    published_at=_xml_text(item.find("pubDate")),
                )
            )
        return [item for item in items if item.title]


class LongbridgeNewsFetcher:
    def __init__(self, client: LongbridgeCliClient | None = None) -> None:
        self.client = client or LongbridgeCliClient(rate_limit_per_second=5)

    def fetch(self, target: ResearchTarget, limit: int = 5) -> list[NewsItem]:
        try:
            payload = self.client.news(target.symbol, count=limit, lang="zh-CN")
        except Exception:
            return []
        rows = payload if isinstance(payload, list) else payload.get("list", []) if isinstance(payload, dict) else []
        items = []
        for row in rows[:limit]:
            if not isinstance(row, dict):
                continue
            title = _string(row.get("title"))
            if not title:
                continue
            items.append(
                NewsItem(
                    title=title,
                    summary=_string(row.get("summary") or row.get("desc") or row.get("content")),
                    url=_string(row.get("url") or row.get("link")),
                    source=_string(row.get("source") or row.get("provider") or "Longbridge"),
                    published_at=_string(row.get("published_at") or row.get("publishedAt") or row.get("time")),
                )
            )
        return items


class CombinedNewsFetcher:
    def __init__(self, primary: NewsFetcher, fallback: NewsFetcher) -> None:
        self.primary = primary
        self.fallback = fallback

    def fetch(self, target: ResearchTarget, limit: int = 5) -> list[NewsItem]:
        items = self.primary.fetch(target, limit=limit)
        if len(items) >= limit:
            return items[:limit]
        seen = {item.title for item in items}
        for item in self.fallback.fetch(target, limit=limit):
            if item.title not in seen:
                items.append(item)
                seen.add(item.title)
            if len(items) >= limit:
                break
        return items


def generate_research_snapshot_batch(
    repository: ResearchSnapshotRepository,
    news_fetcher: NewsFetcher,
    llm_client: LLMTextClient | None,
    market: str = "all",
    limit: int = 100,
    stale_hours: int = 24,
    news_limit: int = 5,
    refresh_financials: bool = False,
    dry_run: bool = False,
    now: Callable[[], datetime] | None = None,
) -> list[dict[str, Any]]:
    clock = now or (lambda: datetime.now(timezone.utc))
    results: list[dict[str, Any]] = []
    for target in repository.list_targets(market=market, limit=limit, stale_hours=stale_hours):
        try:
            financial_facts = repository.ensure_financial_report(target, refresh=refresh_financials)
            news_items = news_fetcher.fetch(target, limit=news_limit)
            snapshot = build_research_snapshot(target, financial_facts, news_items, llm_client, clock())
            if not dry_run:
                repository.insert_snapshot(snapshot)
            results.append({"symbol": target.symbol, "ok": True, "error": None})
        except Exception as exc:
            results.append({"symbol": target.symbol, "ok": False, "error": str(exc)})
    return results


def build_research_snapshot(
    target: ResearchTarget,
    financial_facts: list[FinancialFact],
    news_items: list[NewsItem],
    llm_client: LLMTextClient | None,
    as_of: datetime,
) -> ResearchSnapshot:
    financial_summary = summarize_financial_facts(financial_facts)
    news_payload = [_news_payload(item) for item in news_items]
    hotspots = detect_hotspots(target, news_items)
    prompt = build_llm_prompt(target, financial_summary, news_items, hotspots)
    llm_summary = ""
    llm_error = ""
    if llm_client is not None:
        try:
            llm_summary = llm_client.complete(prompt).strip()
        except Exception as exc:
            llm_error = str(exc)
    if not llm_summary:
        llm_summary = fallback_research_summary(target, financial_summary, news_items, hotspots)
    sources = [_news_source(item) for item in news_items]
    payload = {
        "scoreDate": target.score_date,
        "totalScore": target.total_score,
        "strategyScore": target.strategy_score,
        "decision": target.decision,
        "modelReason": target.model_reason,
        "llmPrompt": prompt,
    }
    if llm_error:
        payload["llmError"] = llm_error
    return ResearchSnapshot(
        symbol=target.symbol,
        market=target.market,
        as_of=as_of,
        financial_summary=financial_summary,
        news_items=news_payload,
        hotspots=hotspots,
        llm_summary=llm_summary,
        sources=sources,
        payload=payload,
    )


def summarize_financial_facts(facts: list[FinancialFact]) -> str:
    if not facts:
        return "暂无可用财报明细，需优先补抓长桥 financial-report 数据。"
    pieces = []
    for fact in facts[:8]:
        value = "" if fact.value is None else f" {_plain_number(fact.value)}"
        currency = f" {fact.currency}" if fact.currency else ""
        yoy = f"，同比 {fact.yoy}" if fact.yoy else ""
        period = f"（{fact.report_period}）" if fact.report_period else ""
        pieces.append(f"{fact.name}{value}{currency}{period}{yoy}")
    return "；".join(pieces) + "。"


def build_llm_prompt(target: ResearchTarget, financial_summary: str, news_items: list[NewsItem], hotspots: list[str]) -> str:
    news_text = "\n".join(f"- {item.title}: {item.summary}" for item in news_items[:5]) or "- 暂无新闻"
    hotspot_text = "、".join(hotspots) or "暂无热点"
    return (
        "你是股票研究助理。请用中文为单只股票生成一段研究快照，必须结合财报、最近新闻/热点、"
        "行业或公司特点、量化模型信号，并明确说明为什么值得观察以及主要风险。"
        "不要给出确定性收益承诺，不要编造不存在的数据。\n\n"
        f"股票：{target.symbol} / {target.name} / {target.market}\n"
        f"评分：total={target.total_score}, strategy={target.strategy_score}, decision={target.decision}\n"
        f"模型备注：{target.model_reason}\n"
        f"财报摘要：{financial_summary}\n"
        f"热点：{hotspot_text}\n"
        f"最近新闻：\n{news_text}\n\n"
        "输出 120-220 字，语气务实，适合展示在股票推荐解析页面。"
    )


def detect_hotspots(target: ResearchTarget, news_items: list[NewsItem]) -> list[str]:
    text = " ".join([target.name, target.symbol, *(item.title + " " + item.summary for item in news_items)]).lower()
    rules = [
        ("AI 云算力", ["ai", "gpu", "cloud", "算力", "人工智能", "云"]),
        ("半导体", ["semiconductor", "chip", "芯片", "半导体"]),
        ("创新药", ["drug", "biotech", "pharma", "药", "生物科技"]),
        ("新能源", ["ev", "battery", "solar", "新能源", "电池", "光伏"]),
        ("金融科技", ["fintech", "payment", "broker", "金融科技", "支付", "券商"]),
        ("消费复苏", ["retail", "consumer", "travel", "消费", "旅游", "零售"]),
        ("业绩催化", ["earnings", "revenue", "profit", "财报", "收入", "利润"]),
    ]
    hotspots = [label for label, keywords in rules if any(keyword in text for keyword in keywords)]
    return hotspots[:6] or ["业绩跟踪"]


def fallback_research_summary(
    target: ResearchTarget,
    financial_summary: str,
    news_items: list[NewsItem],
    hotspots: list[str],
) -> str:
    news_hint = news_items[0].title if news_items else "近期新闻待补充"
    hotspot_text = "、".join(hotspots[:3])
    score_text = f"综合分 {target.total_score:g}" if target.total_score is not None else "综合分待确认"
    return (
        f"{target.name} 当前进入研究池主要来自 {score_text}、{target.decision or '候选'} 分层和模型信号。"
        f"财报侧：{financial_summary} 新闻侧关注「{news_hint}」，关联热点为 {hotspot_text}。"
        "后续需要继续跟踪业绩兑现、板块热度持续性和高位波动风险。"
    )


def _news_payload(item: NewsItem) -> dict[str, str]:
    return {
        "title": item.title,
        "summary": item.summary,
        "url": item.url,
        "source": item.source,
        "publishedAt": item.published_at,
    }


def _news_source(item: NewsItem) -> dict[str, str]:
    return {**_news_payload(item), "type": "news"}


def _xml_text(node: ET.Element | None) -> str:
    return "" if node is None or node.text is None else node.text.strip()


def _clean_html(value: str) -> str:
    text = value.replace("<ol>", " ").replace("</ol>", " ").replace("<li>", " ").replace("</li>", " ")
    for token in ["&quot;", "&#39;", "&amp;", "&lt;", "&gt;"]:
        text = text.replace(token, {"&quot;": '"', "&#39;": "'", "&amp;": "&", "&lt;": "<", "&gt;": ">"}[token])
    return " ".join(text.split())


def _string(value: Any) -> str:
    return "" if value is None else str(value).strip()


def _float_or_none(value: Any) -> float | None:
    if value is None:
        return None
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def _dedupe_targets(targets: list[ResearchTarget]) -> list[ResearchTarget]:
    seen: set[str] = set()
    output: list[ResearchTarget] = []
    for target in targets:
        key = target.symbol.strip().upper()
        if not key or key in seen:
            continue
        seen.add(key)
        output.append(target)
    return output


def score_column_expr(columns: set[str], column: str, fallback_sql: str) -> str:
    return f"s.{column}" if column in columns else fallback_sql


def _table_columns(conn: Any, table_name: str) -> set[str]:
    rows = conn.execute(
        """
        select column_name
        from information_schema.columns
        where table_name = %s
        """,
        (table_name,),
    ).fetchall()
    return {str(row[0]) for row in rows}


def _plain_number(value: Any) -> str:
    try:
        number = float(value)
    except (TypeError, ValueError):
        return str(value)
    if number.is_integer():
        return str(int(number))
    return f"{number:.4f}".rstrip("0").rstrip(".")
