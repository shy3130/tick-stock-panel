from __future__ import annotations

import json
import subprocess
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any, Callable


Runner = Callable[[list[str]], subprocess.CompletedProcess[str]]


DEFAULT_INDEX_SYMBOLS: dict[str, tuple[str, ...]] = {
    "HK": ("HSI.HK", "HSCEI.HK", "HSTECH.HK"),
    "US": (".SPX.US", ".IXIC.US", ".DJI.US", ".VIX.US"),
    "CN": ("000001.SH", "399001.SZ", "399006.SZ"),
    "SG": ("STI.SG",),
}


@dataclass(frozen=True)
class MacroTrendConfig:
    market: str = "HK"
    index_symbols: tuple[str, ...] | None = None
    industry_count: int = 12
    top_mover_count: int = 8
    anomaly_count: int = 8
    constituent_limit: int = 50
    news_per_symbol: int = 3
    include_news: bool = True
    lang: str = "zh-CN"

    def normalized_market(self) -> str:
        return self.market.strip().upper()

    def resolved_index_symbols(self) -> tuple[str, ...]:
        return self.index_symbols or DEFAULT_INDEX_SYMBOLS.get(self.normalized_market(), ())


def collect_market_macro_snapshot(config: MacroTrendConfig, *, runner: Runner | None = None) -> dict[str, Any]:
    runner = runner or _default_runner
    market = config.normalized_market()
    index_symbols = config.resolved_index_symbols()
    primary_index = index_symbols[0] if index_symbols else ""
    snapshot: dict[str, Any] = {
        "market": market,
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "market_status": _run_json(["longbridge", "market-status", "--format", "json"], runner=runner),
        "market_temp": _run_json(["longbridge", "market-temp", market, "--format", "json"], runner=runner),
        "quotes": _run_json(["longbridge", "quote", *index_symbols, "--format", "json"], runner=runner) if index_symbols else [],
        "intraday": {},
        "industries": _run_json(
            [
                "longbridge",
                "industry-rank",
                "--market",
                market,
                "--indicator",
                "today-trend",
                "--count",
                str(config.industry_count),
                "--format",
                "json",
            ],
            runner=runner,
        ),
        "top_movers": _run_json(
            ["longbridge", "top-movers", "--market", market, "--count", str(config.top_mover_count), "--format", "json"],
            runner=runner,
        ),
        "anomalies": _run_json(
            ["longbridge", "anomaly", "--market", market, "--count", str(config.anomaly_count), "--format", "json"],
            runner=runner,
        ),
        "constituents": _run_json(
            ["longbridge", "constituent", primary_index, "--limit", str(config.constituent_limit), "--sort", "change", "--format", "json"],
            runner=runner,
        )
        if primary_index
        else {},
        "news": {},
        "errors": [],
    }
    intraday: dict[str, Any] = {}
    for symbol in index_symbols:
        intraday[symbol] = _run_json(["longbridge", "intraday", symbol, "--format", "json"], runner=runner)
    snapshot["intraday"] = intraday
    if config.include_news and config.news_per_symbol > 0:
        news: dict[str, Any] = {}
        for symbol in _top_mover_symbols(snapshot["top_movers"])[: config.top_mover_count]:
            news[symbol] = _run_json(
                ["longbridge", "news", symbol, "--count", str(config.news_per_symbol), "--format", "json"],
                runner=runner,
            )
        snapshot["news"] = news
    return snapshot


def analyze_market_macro_snapshot(snapshot: dict[str, Any]) -> dict[str, Any]:
    market = str(snapshot.get("market") or "").upper() or "UNKNOWN"
    index_rows = _list_payload(snapshot.get("quotes"))
    intraday_by_symbol = snapshot.get("intraday") if isinstance(snapshot.get("intraday"), dict) else {}
    industry_rows = _industry_rows(snapshot.get("industries"))
    constituent_rows = _list_payload(snapshot.get("constituents"))
    mover_rows = _top_mover_rows(snapshot.get("top_movers"))
    anomaly_rows = _list_payload(snapshot.get("anomalies"))

    index_score, index_detail = _index_trend_score(index_rows, intraday_by_symbol)
    breadth_score, breadth = _breadth_score(constituent_rows)
    sector_score, hot_sectors = _sector_score(industry_rows)
    appetite_score, temp_detail = _risk_appetite_score(snapshot.get("market_temp"))
    anomaly_score, anomaly_detail = _anomaly_score(mover_rows, anomaly_rows)

    score = round(
        100
        * (
            0.34 * index_score
            + 0.22 * breadth_score
            + 0.20 * sector_score
            + 0.16 * appetite_score
            + 0.08 * anomaly_score
        ),
        1,
    )
    trend_state = _trend_state(score)
    trend_quality = _trend_quality(index_score=index_score, breadth_score=breadth_score, sector_score=sector_score)
    risk_flags = _risk_flags(score=score, breadth=breadth, temp=temp_detail, anomaly=anomaly_detail, index_score=index_score)
    news_catalysts = _news_catalysts(mover_rows, snapshot.get("news"))
    market_status = _market_status(snapshot.get("market_status"), market)
    summary = _summary(
        market=market,
        market_status=market_status,
        trend_state=trend_state,
        trend_quality=trend_quality,
        score=score,
        hot_sectors=hot_sectors,
        news_catalysts=news_catalysts,
        risk_flags=risk_flags,
    )
    return {
        "market": market,
        "generated_at": snapshot.get("generated_at"),
        "market_status": market_status,
        "score": score,
        "trend_state": trend_state,
        "trend_state_label": _TREND_LABELS[trend_state],
        "trend_quality": trend_quality,
        "trend_quality_label": _QUALITY_LABELS[trend_quality],
        "summary": summary,
        "components": {
            "index_trend": round(index_score, 3),
            "breadth": round(breadth_score, 3),
            "sector_rotation": round(sector_score, 3),
            "risk_appetite": round(appetite_score, 3),
            "anomaly_confirmation": round(anomaly_score, 3),
        },
        "index_trend": index_detail,
        "breadth": breadth,
        "market_temperature": temp_detail,
        "hot_sectors": hot_sectors,
        "top_movers": _compact_top_movers(mover_rows),
        "news_catalysts": news_catalysts,
        "risk_flags": risk_flags,
        "evidence_counts": {
            "indices": len(index_rows),
            "constituents": len(constituent_rows),
            "industries": len(industry_rows),
            "top_movers": len(mover_rows),
            "news_symbols": len(snapshot.get("news") or {}),
        },
    }


def build_market_macro_report(config: MacroTrendConfig, *, runner: Runner | None = None) -> dict[str, Any]:
    snapshot = collect_market_macro_snapshot(config, runner=runner)
    return analyze_market_macro_snapshot(snapshot)


def _default_runner(command: list[str]) -> subprocess.CompletedProcess[str]:
    return subprocess.run(command, capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=120)


def _run_json(command: list[str], *, runner: Runner) -> Any:
    completed = runner(command)
    if completed.returncode != 0:
        return {"error": (completed.stderr or completed.stdout or "").strip(), "command": command}
    text = completed.stdout or ""
    if not text.strip():
        return []
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        return {"error": "invalid_json", "command": command, "stdout": text[:1000]}


def _list_payload(payload: Any) -> list[dict[str, Any]]:
    if isinstance(payload, list):
        return [row for row in payload if isinstance(row, dict)]
    if not isinstance(payload, dict):
        return []
    for key in ("items", "lists", "stocks", "constituents", "data", "securities", "rows"):
        value = payload.get(key)
        if isinstance(value, list):
            return [row for row in value if isinstance(row, dict)]
    return []


def _industry_rows(payload: Any) -> list[dict[str, Any]]:
    rows = _list_payload(payload)
    flattened: list[dict[str, Any]] = []
    for row in rows:
        children = row.get("lists")
        if isinstance(children, list):
            flattened.extend(child for child in children if isinstance(child, dict))
        elif row.get("name"):
            flattened.append(row)
    return flattened


def _top_mover_rows(payload: Any) -> list[dict[str, Any]]:
    if isinstance(payload, dict) and isinstance(payload.get("events"), list):
        return [row for row in payload["events"] if isinstance(row, dict)]
    return _list_payload(payload)


def _top_mover_symbols(payload: Any) -> list[str]:
    symbols: list[str] = []
    for row in _top_mover_rows(payload):
        stock = row.get("stock") if isinstance(row.get("stock"), dict) else row
        symbol = str(stock.get("symbol") or "").strip().upper()
        if symbol and symbol not in symbols:
            symbols.append(symbol)
    return symbols


def _index_trend_score(index_rows: list[dict[str, Any]], intraday_by_symbol: Any) -> tuple[float, list[dict[str, Any]]]:
    details: list[dict[str, Any]] = []
    scores: list[float] = []
    for row in index_rows:
        symbol = str(row.get("symbol") or row.get("code") or "").strip().upper()
        if not symbol:
            continue
        change = _quote_change_ratio(row)
        lines = _list_payload(intraday_by_symbol.get(symbol) if isinstance(intraday_by_symbol, dict) else None)
        slope = _intraday_slope(lines)
        combined = _clip01(0.5 + change * 18 + slope * 10)
        if symbol == ".VIX.US":
            combined = 1.0 - combined
        details.append(
            {
                "symbol": symbol,
                "name": row.get("name") or symbol,
                "change": round(change, 4),
                "intraday_slope": round(slope, 4),
                "score": round(combined, 3),
            }
        )
        scores.append(combined)
    return (_average(scores, default=0.5), details)


def _breadth_score(rows: list[dict[str, Any]]) -> tuple[float, dict[str, Any]]:
    changes = [_ratio(row.get("change", row.get("chg", row.get("change_percentage")))) for row in rows]
    changes = [value for value in changes if value != 0 or rows]
    if not changes:
        return 0.5, {"rising": 0, "falling": 0, "flat": 0, "rising_ratio": 0.0, "average_change": 0.0}
    rising = sum(1 for value in changes if value > 0.0001)
    falling = sum(1 for value in changes if value < -0.0001)
    flat = len(changes) - rising - falling
    rising_ratio = rising / len(changes)
    average_change = sum(changes) / len(changes)
    score = _clip01(0.25 + rising_ratio * 0.55 + average_change * 10)
    return score, {
        "rising": rising,
        "falling": falling,
        "flat": flat,
        "total": len(changes),
        "rising_ratio": round(rising_ratio, 3),
        "average_change": round(average_change, 4),
    }


def _sector_score(rows: list[dict[str, Any]]) -> tuple[float, list[dict[str, Any]]]:
    sectors = []
    for row in rows:
        change = _ratio(row.get("chg", row.get("change", row.get("value_data"))))
        sectors.append(
            {
                "name": str(row.get("name") or row.get("label") or "").strip(),
                "counter_id": str(row.get("counter_id") or "").strip(),
                "change": round(change, 4),
                "minutes_count": int(_number(row.get("minutes_count"))),
            }
        )
    sectors = [row for row in sectors if row["name"]]
    sectors.sort(key=lambda row: row["change"], reverse=True)
    top = sectors[:5]
    if not sectors:
        return 0.5, []
    top_avg = _average([row["change"] for row in top], default=0)
    positive_ratio = sum(1 for row in sectors if row["change"] > 0) / len(sectors)
    score = _clip01(0.35 + positive_ratio * 0.35 + top_avg * 8)
    return score, top


def _risk_appetite_score(payload: Any) -> tuple[float, dict[str, Any]]:
    rows = _list_payload(payload)
    values = {str(row.get("field") or "").strip().lower(): row.get("value") for row in rows}
    temperature = _number(values.get("temperature"))
    sentiment = _number(values.get("sentiment"))
    valuation = _number(values.get("valuation"))
    base = temperature if temperature else sentiment if sentiment else 50.0
    score = _clip01(base / 100.0)
    return score, {
        "temperature": temperature,
        "sentiment": sentiment,
        "valuation": valuation,
        "description": str(values.get("description") or ""),
    }


def _anomaly_score(movers: list[dict[str, Any]], anomalies: list[dict[str, Any]]) -> tuple[float, dict[str, Any]]:
    changes = []
    for row in movers:
        stock = row.get("stock") if isinstance(row.get("stock"), dict) else row
        changes.append(_ratio(stock.get("change", stock.get("chg"))))
    bullish_anomalies = 0
    bearish_anomalies = 0
    for row in anomalies:
        text = " ".join(str(row.get(key) or "") for key in ("alert", "emotion", "alert_reason", "type")).lower()
        if "bull" in text or "rise" in text or "buy" in text:
            bullish_anomalies += 1
        if "bear" in text or "sell" in text or "fall" in text:
            bearish_anomalies += 1
    avg_change = _average(changes, default=0)
    score = _clip01(0.5 + avg_change * 8 + (bullish_anomalies - bearish_anomalies) * 0.04)
    return score, {
        "top_mover_average_change": round(avg_change, 4),
        "bullish_anomalies": bullish_anomalies,
        "bearish_anomalies": bearish_anomalies,
    }


def _news_catalysts(movers: list[dict[str, Any]], news_payload: Any) -> list[dict[str, Any]]:
    news_by_symbol = news_payload if isinstance(news_payload, dict) else {}
    catalysts: list[dict[str, Any]] = []
    for row in movers:
        stock = row.get("stock") if isinstance(row.get("stock"), dict) else row
        symbol = str(stock.get("symbol") or "").strip().upper()
        if not symbol:
            continue
        news_rows = _list_payload(news_by_symbol.get(symbol))
        titles = [str(item.get("title") or item.get("headline") or "").strip() for item in news_rows]
        titles = [title for title in titles if title][:3]
        if titles:
            catalysts.append(
                {
                    "symbol": symbol,
                    "name": stock.get("name") or symbol,
                    "change": round(_ratio(stock.get("change", stock.get("chg"))), 4),
                    "labels": stock.get("labels") or [],
                    "news_titles": titles,
                }
            )
    return catalysts


def _compact_top_movers(rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    compact = []
    for row in rows[:10]:
        stock = row.get("stock") if isinstance(row.get("stock"), dict) else row
        compact.append(
            {
                "symbol": stock.get("symbol"),
                "name": stock.get("name"),
                "change": round(_ratio(stock.get("change", stock.get("chg"))), 4),
                "reason": row.get("alert_reason") or row.get("reason"),
                "labels": stock.get("labels") or [],
            }
        )
    return compact


def _trend_state(score: float) -> str:
    if score >= 75:
        return "strong_uptrend"
    if score >= 60:
        return "constructive_uptrend"
    if score >= 45:
        return "range_bound"
    if score >= 30:
        return "weakening"
    return "downtrend"


def _trend_quality(*, index_score: float, breadth_score: float, sector_score: float) -> str:
    if index_score >= 0.58 and breadth_score < 0.45:
        return "narrow_index_pull"
    if index_score >= 0.62 and breadth_score >= 0.58 and sector_score >= 0.58:
        return "broad_risk_on"
    if index_score < 0.45 and breadth_score < 0.45:
        return "risk_off"
    if sector_score >= 0.62 and breadth_score < 0.5:
        return "theme_driven"
    return "balanced"


def _risk_flags(*, score: float, breadth: dict[str, Any], temp: dict[str, Any], anomaly: dict[str, Any], index_score: float) -> list[str]:
    flags: list[str] = []
    if index_score > 0.58 and float(breadth.get("rising_ratio") or 0) < 0.5:
        flags.append("narrow_rally")
    if score >= 75 and float(temp.get("temperature") or 0) >= 80:
        flags.append("overheated")
    if anomaly.get("bearish_anomalies", 0) > anomaly.get("bullish_anomalies", 0):
        flags.append("bearish_anomaly_pressure")
    if score < 45:
        flags.append("trend_pressure")
    return flags


def _market_status(payload: Any, market: str) -> str:
    for row in _list_payload(payload):
        if str(row.get("market") or "").upper() == market:
            return str(row.get("status") or "")
    return ""


_TREND_LABELS = {
    "strong_uptrend": "强趋势上行",
    "constructive_uptrend": "震荡偏强",
    "range_bound": "震荡",
    "weakening": "震荡偏弱",
    "downtrend": "趋势下行",
}

_QUALITY_LABELS = {
    "broad_risk_on": "普涨扩散",
    "balanced": "均衡",
    "theme_driven": "热点驱动",
    "narrow_index_pull": "少数权重拉动",
    "risk_off": "风险收缩",
}


def _summary(
    *,
    market: str,
    market_status: str,
    trend_state: str,
    trend_quality: str,
    score: float,
    hot_sectors: list[dict[str, Any]],
    news_catalysts: list[dict[str, Any]],
    risk_flags: list[str],
) -> str:
    status_lower = market_status.lower()
    scope = "当前盘中" if status_lower in {"trading", "open", "regular trading"} else "最近快照"
    sector_names = "、".join(str(row["name"]) for row in hot_sectors[:3]) or "暂无清晰主线"
    catalyst = ""
    if news_catalysts:
        catalyst = f"；新闻催化集中在 {news_catalysts[0]['symbol']}"
    risk = ""
    if "narrow_rally" in risk_flags:
        risk = "，但上涨扩散不足，偏少数权重或局部热点拉动"
    elif risk_flags:
        risk = "，需留意 " + "、".join(risk_flags[:2])
    return f"{market} 大盘（{scope}）：{_TREND_LABELS[trend_state]}，评分 {score:.1f}，趋势质量为{_QUALITY_LABELS[trend_quality]}。主线板块：{sector_names}{catalyst}{risk}。"


def _intraday_slope(lines: list[dict[str, Any]]) -> float:
    prices = [_number(row.get("price", row.get("last_done"))) for row in lines]
    prices = [price for price in prices if price > 0]
    if len(prices) < 2 or prices[0] == 0:
        return 0.0
    return prices[-1] / prices[0] - 1.0


def _quote_change_ratio(row: dict[str, Any]) -> float:
    if row.get("change_percentage") is not None:
        return _number(row.get("change_percentage")) / 100.0
    return _ratio(row.get("change", row.get("chg")))


def _ratio(value: Any) -> float:
    if value is None:
        return 0.0
    if isinstance(value, (int, float)):
        return float(value) / 100.0 if abs(float(value)) > 2 else float(value)
    text = str(value).strip().replace(",", "")
    if not text:
        return 0.0
    if text.endswith("%"):
        return _number(text[:-1]) / 100.0
    number = _number(text)
    return number / 100.0 if abs(number) > 2 else number


def _number(value: Any) -> float:
    try:
        return float(value)
    except (TypeError, ValueError):
        return 0.0


def _average(values: list[float], *, default: float) -> float:
    return sum(values) / len(values) if values else default


def _clip01(value: float) -> float:
    return max(0.0, min(1.0, value))
