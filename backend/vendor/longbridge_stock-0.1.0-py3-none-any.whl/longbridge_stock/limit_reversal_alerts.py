from __future__ import annotations

import json
import time
from dataclasses import dataclass
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any, Iterable

from longbridge_stock import clickhouse_realtime
from longbridge_stock.limit_reversal_line import current_limit_reversal_watchlist
from longbridge_stock.market_sessions import SHANGHAI_TZ, is_trading_time
from longbridge_stock.realtime_alerts import (
    AlertState,
    OpenClawNotifier,
    RealtimeAlert,
)


DEFAULT_STATE_PATH = Path("/home/alwin/data/longbridge/limit_reversal_alert_state.json")


@dataclass(frozen=True)
class LimitReversalAlertConfig:
    markets: list[str]
    event_threshold: float = 0.10
    lookback_days: int = 45
    limit: int = 300
    min_red_pct: float = 0.0
    max_quote_age_minutes: int = 20
    max_alerts_per_run: int = 20


class LimitReversalAlertMonitor:
    def __init__(
        self,
        dsn: str,
        config: LimitReversalAlertConfig,
        notifier: OpenClawNotifier,
        state: AlertState,
    ) -> None:
        self.dsn = dsn
        self.config = config
        self.notifier = notifier
        self.state = state

    def run_once(self, now: datetime | None = None) -> dict[str, Any]:
        current = now or datetime.now(SHANGHAI_TZ)
        if not is_trading_time(current, self.config.markets):
            return {"status": "outside_trading_time", "checked": 0, "alerts": 0, "sent": 0}

        watchlist = current_limit_reversal_watchlist(
            dsn=self.dsn,
            markets=self.config.markets,
            lookback_days=self.config.lookback_days,
            event_threshold=self.config.event_threshold,
            limit=self.config.limit,
        )
        if watchlist.empty:
            return {"status": "ok", "checked": 0, "alerts": 0, "sent": 0}

        latest_quotes = _latest_quotes(self.dsn, watchlist["symbol"].astype(str).tolist())
        alerts: list[RealtimeAlert] = []
        for row in watchlist.to_dict("records"):
            quote = latest_quotes.get(str(row.get("symbol")))
            alert = _build_red_alert(row, quote, self.config, current)
            if alert:
                alerts.append(alert)

        trade_date = current.date().isoformat()
        sent = 0
        skipped = 0
        deferred = 0
        errors: list[str] = []
        for alert in alerts:
            if not self.state.should_send(alert, trade_date):
                skipped += 1
                continue
            if sent >= self.config.max_alerts_per_run:
                deferred += 1
                continue
            try:
                self.notifier.send(alert.message)
            except Exception as exc:
                errors.append(f"{alert.dedupe_key}: {exc}")
                continue
            self.state.mark_sent(alert, trade_date)
            sent += 1
        return {
            "status": "ok",
            "checked": int(len(watchlist)),
            "alerts": len(alerts),
            "sent": sent,
            "skipped": skipped,
            "deferred": deferred,
            "errors": errors,
        }

    def run_forever(self, interval_seconds: int) -> None:
        if interval_seconds <= 0:
            raise ValueError("interval_seconds must be positive")
        while True:
            started = time.monotonic()
            result = self.run_once()
            print(json.dumps(result, ensure_ascii=False), flush=True)
            time.sleep(max(0, interval_seconds - (time.monotonic() - started)))


def parse_markets(markets: str | Iterable[str]) -> list[str]:
    if isinstance(markets, str):
        values = markets.split(",")
    else:
        values = list(markets)
    resolved: list[str] = []
    for value in values:
        market = str(value).strip().lower()
        if market and market not in resolved:
            resolved.append(market)
    return resolved


def _latest_quotes(dsn: str, symbols: list[str]) -> dict[str, dict[str, Any]]:
    if not symbols:
        return {}
    rows = clickhouse_realtime.fetch_realtime_signal_rows(symbols, now=datetime.now(SHANGHAI_TZ), max_quote_age_minutes=24 * 60)
    return {
        symbol: {
            "symbol": symbol,
            "market": row.get("market"),
            "snapshot_minute": row.get("snapshot_minute"),
            "last_done": row.get("last"),
            "open": row.get("open"),
            "change_percentage": row.get("change_pct"),
            "volume": row.get("volume"),
            "turnover": row.get("turnover"),
            "trade_status": row.get("trade_status"),
        }
        for symbol, row in rows.items()
    }


def _build_red_alert(
    row: dict[str, Any],
    quote: dict[str, Any] | None,
    config: LimitReversalAlertConfig,
    now: datetime,
) -> RealtimeAlert | None:
    if not quote:
        return None
    last_done = _number(quote.get("last_done"))
    open_price = _number(quote.get("open"))
    quote_time = quote.get("snapshot_minute")
    if last_done is None or open_price is None or open_price <= 0:
        return None
    red_pct = last_done / open_price - 1
    if red_pct <= config.min_red_pct:
        return None
    if isinstance(quote_time, datetime):
        age = now.astimezone(SHANGHAI_TZ) - quote_time.astimezone(SHANGHAI_TZ)
        if age > timedelta(minutes=config.max_quote_age_minutes):
            return None

    symbol = str(row.get("symbol") or "-")
    market = str(row.get("market") or "").upper()
    name = str(row.get("name") or symbol)
    title = f"{market} {symbol} {name} 0/1/2/3线盘中翻红"
    message = "\n".join(
        [
            f"[长桥形态翻红提醒] {market} {symbol} {name}",
            f"形态：单日涨幅≥{config.event_threshold * 100:.0f}% 后，0/1/2/3线已成立，盘中翻红确认",
            f"起点日期：{row.get('event_date') or '-'}，涨幅：{_fmt(row.get('event_pct'))}%",
            f"0线：{row.get('zero_date') or '-'}，1/2/3线：{row.get('line1_date') or '-'}/{row.get('line2_date') or '-'}/{row.get('line3_date') or '-'}",
            f"现价：{_fmt(last_done)}，今开：{_fmt(open_price)}，相对开盘：{red_pct * 100:.2f}%",
            f"实时涨跌幅：{_fmt(quote.get('change_percentage'))}%",
            f"行情分钟：{quote_time.isoformat() if isinstance(quote_time, datetime) else quote_time or '-'}",
            "动作：进入观察买点，仍需结合盘口、资金流和大盘状态确认。",
        ]
    )
    return RealtimeAlert(
        alert_type="limit_reversal_red",
        symbol=symbol,
        market=market,
        name=name,
        title=title,
        message=message,
        score=red_pct * 100,
        signal="limit_reversal_intraday_red",
    )


def _number(value: Any) -> float | None:
    if value is None:
        return None
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def _fmt(value: Any) -> str:
    number = _number(value)
    if number is None:
        return "-"
    return f"{number:.2f}"
