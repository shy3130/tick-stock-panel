from __future__ import annotations

import os
import re
from datetime import date, timedelta
from typing import Any, Iterable

import psycopg

from longbridge_stock import clickhouse_realtime
from longbridge_stock.longbridge_sync import LongbridgeCliClient


def load_realtime_symbols(
    dsn: str,
    markets: Iterable[str],
    client: LongbridgeCliClient | None = None,
    limit: int | None = None,
    priority_only: bool = False,
) -> list[str]:
    normalized_markets = [_normalize_market(market) for market in markets]
    priority_symbols: list[str] = []
    account_client = _account_priority_client(client)
    if account_client is not None:
        priority_symbols.extend(_holding_symbols(account_client, normalized_markets))
        priority_symbols.extend(_traded_symbols(account_client, normalized_markets))
    priority_symbols.extend(_recommendation_pool_symbols(dsn, normalized_markets))
    if client is not None:
        priority_symbols.extend(_watchlist_symbols(client, normalized_markets))
    if priority_only:
        symbols = _unique_preserve_order(priority_symbols)
        return symbols[:limit] if limit else symbols
    all_symbols = _all_market_symbols(dsn, normalized_markets)
    symbols = _unique_preserve_order(priority_symbols + all_symbols)
    return symbols[:limit] if limit else symbols


def _account_priority_client(client: Any) -> Any | None:
    if client is not None and callable(getattr(client, "positions", None)) and callable(getattr(client, "order_history", None)):
        return client
    if client is None or type(client).__name__ != "LongbridgeSdkClient":
        return None
    if os.getenv("LONGBRIDGE_REALTIME_ACCOUNT_PRIORITY", "1").strip().lower() in {"0", "false", "no"}:
        return None
    try:
        rate_limit = float(os.getenv("LONGBRIDGE_REALTIME_ACCOUNT_RATE_LIMIT", "2"))
    except ValueError:
        rate_limit = 2.0
    try:
        return LongbridgeCliClient(rate_limit_per_second=rate_limit)
    except Exception:
        return None


def _holding_symbols(client: Any, markets: list[str]) -> list[str]:
    try:
        payload = client.positions()
    except Exception:
        return []
    symbols: list[str] = []
    for row in _payload_rows(payload, keys=("positions", "items", "list", "data")):
        symbol = _symbol_from_row(row)
        if not symbol or _market_from_symbol(symbol) not in markets or not _is_common_stock_symbol(symbol):
            continue
        quantity = _number(row.get("quantity") or row.get("qty") or row.get("available_quantity") or row.get("available"))
        if quantity <= 0:
            continue
        symbols.append(symbol)
    return _unique_preserve_order(symbols)


def _traded_symbols(client: Any, markets: list[str]) -> list[str]:
    try:
        payload = client.order_history(_order_history_start())
    except Exception:
        return []
    symbols: list[str] = []
    for row in _payload_rows(payload, keys=("orders", "items", "list", "data")):
        symbol = _symbol_from_row(row)
        if symbol and _market_from_symbol(symbol) in markets and _is_common_stock_symbol(symbol):
            symbols.append(symbol)
    return _unique_preserve_order(symbols)


def _recommendation_pool_symbols(dsn: str, markets: list[str]) -> list[str]:
    symbols: list[str] = []
    for loader in (_us_fast_candidate_pool_symbols, _model_pool_symbols):
        try:
            symbols.extend(loader(dsn, markets))
        except Exception:
            continue
    symbols.extend(_clickhouse_recommendation_pool_symbols(markets))
    return _unique_preserve_order(symbols)


def _us_fast_candidate_pool_symbols(dsn: str, markets: list[str]) -> list[str]:
    if "us" not in markets:
        return []
    with psycopg.connect(dsn) as conn:
        rows = conn.execute(
            """
            with latest as (
              select max(run_time) as run_time
              from lb_us_fast_candidate_pool
              where trade_date = (now() at time zone 'Asia/Shanghai')::date
            )
            select p.symbol
            from lb_us_fast_candidate_pool p
            join latest l on p.run_time = l.run_time
            where p.trade_date = (now() at time zone 'Asia/Shanghai')::date
              and coalesce(p.decision, '') <> 'avoid'
              and coalesce(p.status, '') <> 'blocked'
            order by p.rank asc, p.score desc nulls last, p.symbol
            limit 300
            """
        ).fetchall()
    return [str(row[0]).strip().upper() for row in rows if row and row[0]]


def _model_pool_symbols(dsn: str, markets: list[str]) -> list[str]:
    with psycopg.connect(dsn) as conn:
        rows = conn.execute(
            """
            with latest_score_date as (
              select max(score_date) as score_date from lb_stock_scores
            ),
            score_pool as (
              select s.symbol, s.market, 1 as priority, coalesce(s.total_score, 0)::numeric as score
              from lb_stock_scores s
              join latest_score_date d on d.score_date = s.score_date
              where coalesce(s.total_score, 0) >= 65
            ),
            volume_breakout_pool as (
              select s.symbol, s.market, 0 as priority,
                     coalesce(
                       (s.payload->>'breakout_observation_score')::numeric,
                       (s.payload->>'volume_breakout_score')::numeric,
                       0
                     ) as score
              from lb_stock_scores s
              join latest_score_date d on d.score_date = s.score_date
              where coalesce((s.payload->>'fresh_breakout_over_60')::boolean, false)
                and (
                  coalesce((s.payload->>'breakout_volume_ratio_20')::numeric, 0) >= 1.5
                  or coalesce((s.payload->>'breakout_turnover_ratio_20')::numeric, 0) >= 1.5
                )
                and coalesce(
                  (s.payload->>'breakout_observation_score')::numeric,
                  (s.payload->>'volume_breakout_score')::numeric,
                  0
                ) >= 50
            ),
            obs_pool as (
              select symbol, market, 0 as priority, coalesce(strategy_score, total_score, 0)::numeric as score
              from lb_observation_pool
            ),
            latest_limit_up_model as (
              select model_run_id
              from lb_limit_up_model_runs
              order by trained_at desc
              limit 1
            ),
            limit_pool as (
              select p.symbol, 'cn'::text as market, 0 as priority, coalesce(p.open_buy_score, 0)::numeric as score
              from lb_limit_up_predictions p
              join latest_limit_up_model m on m.model_run_id = p.model_run_id
              where p.event_date = ((now() at time zone 'Asia/Shanghai')::date - 1)
                and coalesce(open_buy_score, 0) >= 50
            ),
            ranked as (
              select symbol, market, priority, score,
                     row_number() over (partition by symbol order by priority, score desc) as rn
              from (
              select * from obs_pool
              union all select * from volume_breakout_pool
              union all select * from limit_pool
              union all select * from score_pool
              ) candidates
              where market = any(%s)
            )
            select symbol
            from ranked
            where rn = 1
            order by priority, score desc, symbol
            """,
            (markets,),
        ).fetchall()
    return [str(row[0]) for row in rows]


def _clickhouse_recommendation_pool_symbols(markets: list[str]) -> list[str]:
    if not markets:
        return []
    database = clickhouse_realtime._ident(clickhouse_realtime._database())
    market_sql = "(" + ",".join(clickhouse_realtime._sql_string(market) for market in markets) + ")"
    queries = [
        f"""
        select symbol
        from {database}.lb_intraday_candidate_pool final
        where trade_date >= today('Asia/Shanghai') - 3
          and market in {market_sql}
        group by symbol
        order by min(rank) asc, max(score) desc
        limit 500
        """,
        f"""
        select symbol
        from {database}.lb_52w_high_model_recommendations final
        where trade_date >= today('Asia/Shanghai') - 3
          and market in {market_sql}
        group by symbol
        order by max(confidence) desc
        limit 300
        """,
        f"""
        select symbol
        from {database}.lb_factor_candidate_snapshots final
        where trade_date >= today('Asia/Shanghai') - 3
          and market in {market_sql}
          and source in ('capital_ambush', 'daily_strong_mover_early_candidate')
        group by symbol
        order by max(score) desc
        limit 300
        """,
    ]
    symbols: list[str] = []
    for sql in queries:
        try:
            rows = clickhouse_realtime._query_json_each_row(sql)
        except Exception:
            continue
        symbols.extend(str(row.get("symbol") or "").strip().upper() for row in rows if row.get("symbol"))
    return [symbol for symbol in _unique_preserve_order(symbols) if _market_from_symbol(symbol) in markets and _is_common_stock_symbol(symbol)]


def _watchlist_symbols(client: LongbridgeCliClient, markets: list[str]) -> list[str]:
    try:
        payload = client.watchlist()
    except Exception:
        return []
    symbols: list[str] = []
    for group in payload if isinstance(payload, list) else []:
        securities = group.get("securities") if isinstance(group, dict) else None
        if not isinstance(securities, list):
            continue
        pinned = [item for item in securities if isinstance(item, dict) and item.get("is_pinned")]
        unpinned = [item for item in securities if isinstance(item, dict) and not item.get("is_pinned")]
        for item in pinned + unpinned:
            symbol = str(item.get("symbol") or "")
            if symbol and _market_from_symbol(symbol) in markets and _is_common_stock_symbol(symbol):
                symbols.append(symbol)
    return symbols


def _all_market_symbols(dsn: str, markets: list[str]) -> list[str]:
    with psycopg.connect(dsn) as conn:
        rows = conn.execute(
            """
            select symbol
            from lb_symbols
            where market = any(%s)
              and symbol !~ '^\\.'
            order by case market when 'cn' then 0 when 'hk' then 1 else 2 end, symbol
            """,
            (markets,),
        ).fetchall()
    return [str(row[0]) for row in rows]


def _unique_preserve_order(values: list[str]) -> list[str]:
    seen: set[str] = set()
    result: list[str] = []
    for value in values:
        if value not in seen:
            result.append(value)
            seen.add(value)
    return result


def _normalize_market(market: str) -> str:
    value = market.lower()
    if value in {"sh", "sz"}:
        return "cn"
    return value


def _market_from_symbol(symbol: str) -> str:
    suffix = symbol.rsplit(".", 1)[-1].lower() if "." in symbol else ""
    if suffix in {"sh", "sz"}:
        return "cn"
    return suffix


def _is_common_stock_symbol(symbol: str) -> bool:
    if "." not in symbol or symbol.startswith(".") or _looks_like_option_symbol(symbol):
        return False
    code = symbol.rsplit(".", 1)[0]
    market = _market_from_symbol(symbol)
    if market in {"cn", "hk"}:
        return code.isdigit()
    if market == "us":
        return code.replace("-", "").replace(".", "").isalnum()
    return bool(code)


def _symbol_from_row(row: Any) -> str:
    if not isinstance(row, dict):
        return ""
    for key in ("symbol", "ticker", "stock_symbol", "security_symbol", "underlying_symbol"):
        value = str(row.get(key) or "").strip().upper()
        if value:
            return value
    return ""


def _payload_rows(payload: Any, *, keys: tuple[str, ...]) -> list[dict[str, Any]]:
    if isinstance(payload, list):
        return [row for row in payload if isinstance(row, dict)]
    if not isinstance(payload, dict):
        return []
    for key in keys:
        value = payload.get(key)
        if isinstance(value, list):
            return [row for row in value if isinstance(row, dict)]
    return []


def _number(value: Any) -> float:
    try:
        return float(value)
    except (TypeError, ValueError):
        return 0.0


def _order_history_start() -> str:
    raw_days = os.getenv("LONGBRIDGE_REALTIME_ORDER_LOOKBACK_DAYS", "365")
    try:
        days = max(1, int(raw_days))
    except ValueError:
        days = 365
    return (date.today() - timedelta(days=days)).isoformat()


def _looks_like_option_symbol(symbol: str) -> bool:
    if not symbol.endswith(".US"):
        return False
    code = symbol.removesuffix(".US")
    return bool(re.search(r"\d{6}[CP]\d+$", code)) or (
        any(marker in code for marker in ("260", "261", "250", "270")) and ("P" in code[-8:] or "C" in code[-8:])
    )
