from __future__ import annotations

from decimal import Decimal, InvalidOperation
from typing import Any

from longbridge_stock import clickhouse_realtime


def fetch_realtime_model_pool(
    dsn: str,
    market: str = "cn",
    limit: int = 50,
    pool: str = "all",
) -> list[dict[str, Any]]:
    psycopg = _load_psycopg()
    query_limit = min(max(limit * 5, limit), 1500)
    market_filter = "" if market == "all" else "where market = %(market)s"
    pool_filter = "" if pool == "all" else "where pool = %(pool)s"
    query = f"""
        with latest_score_date as (
          select max(score_date) as score_date from lb_stock_scores
        ),
        score_pool as (
          select s.symbol, s.market, sym.name, 'score_pool'::text as pool, s.decision,
                 s.total_score::numeric as base_score, s.rank_in_market
          from lb_stock_scores s
          left join lb_symbols sym on sym.symbol = s.symbol
          join latest_score_date d on d.score_date = s.score_date
          where coalesce(s.total_score, 0) >= 65
        ),
        volume_breakout_pool as (
          select s.symbol, s.market, sym.name, 'volume_breakout'::text as pool, s.decision,
                 coalesce(
                   (s.payload->>'breakout_observation_score')::numeric,
                   (s.payload->>'volume_breakout_score')::numeric,
                   0
                 ) as base_score,
                 s.rank_in_market
          from lb_stock_scores s
          left join lb_symbols sym on sym.symbol = s.symbol
          join latest_score_date d on d.score_date = s.score_date
          where coalesce((s.payload->>'fresh_breakout_over_60')::boolean, false)
            and (
              coalesce((s.payload->>'breakout_volume_ratio_20')::numeric, 0) >= 1.5
              or coalesce((s.payload->>'breakout_turnover_ratio_20')::numeric, 0) >= 1.5
            )
            and coalesce(
              (s.payload->>'breakout_observation_score')::numeric,
              (s.payload->>'volume_breakout_score')::numeric,
              0
            ) >= 50
        ),
        obs_pool as (
          select o.symbol, o.market, o.name, o.strategy as pool, o.status as decision,
                 o.strategy_score::numeric as base_score, null::int as rank_in_market
          from lb_observation_pool o
        ),
        latest_limit_up_model as (
          select model_run_id
          from lb_limit_up_model_runs
          order by trained_at desc
          limit 1
        ),
        limit_pool as (
          select p.symbol, 'cn'::text as market, sym.name, 'limit_up'::text as pool, p.decision,
                 p.open_buy_score::numeric as base_score, null::int as rank_in_market
          from lb_limit_up_predictions p
          join latest_limit_up_model m on m.model_run_id = p.model_run_id
          left join lb_symbols sym on sym.symbol = p.symbol
          where p.event_date = ((now() at time zone 'Asia/Shanghai')::date - 1)
            and coalesce(p.open_buy_score, 0) >= 50
        ),
        pool_rows as (
          select * from (
            select * from score_pool
            union all select * from volume_breakout_pool
            union all select * from obs_pool
            union all select * from limit_pool
          ) combined
          {market_filter}
        ),
        filtered_pool as (
          select * from pool_rows
          {pool_filter}
        )
        select fp.pool, fp.symbol, fp.market, coalesce(fp.name, '-') as name, fp.decision,
               fp.base_score, fp.rank_in_market
        from filtered_pool fp
        order by fp.base_score desc nulls last, fp.rank_in_market nulls last, fp.symbol
        limit %(query_limit)s
    """
    params = {"market": market, "pool": pool, "query_limit": query_limit}
    with psycopg.connect(dsn) as conn:
        with conn.cursor() as cur:
            cur.execute(query, params)
            rows = cur.fetchall()
            columns = [desc.name for desc in cur.description]
    pool_rows = [dict(zip(columns, row)) for row in rows]
    rows_with_realtime = _attach_realtime_rows(pool_rows, dsn)
    analyzed = [_analyze_row(row) for row in rows_with_realtime]
    return sorted(analyzed, key=lambda item: item.get("realtimeScore") or 0, reverse=True)[:limit]


def _attach_realtime_rows(rows: list[dict[str, Any]], dsn: str) -> list[dict[str, Any]]:
    symbols = [str(row.get("symbol") or "") for row in rows]
    try:
        quote_rows = clickhouse_realtime.fetch_latest_quotes(symbols)
        capital_rows = clickhouse_realtime.fetch_latest_capital(symbols)
    except Exception:
        quote_rows = {}
        capital_rows = {}
    merged = []
    for row in rows:
        symbol = str(row.get("symbol") or "")
        merged.append({**row, **(quote_rows.get(symbol) or {}), **(capital_rows.get(symbol) or {})})
    return merged


def _analyze_row(row: dict[str, Any]) -> dict[str, Any]:
    base_score = _decimal(row.get("base_score")) or Decimal("50")
    change_pct = _decimal(row.get("change_percentage")) or Decimal("0")
    large_net = _decimal(row.get("large_net"))
    total_net = _decimal(row.get("total_net"))
    small_net = _decimal(row.get("small_net"))
    large_net_ratio = _decimal(row.get("large_net_ratio")) or Decimal("0")

    momentum_boost = _clamp(change_pct * Decimal("2"), Decimal("-20"), Decimal("20"))
    capital_boost = _clamp(large_net_ratio * Decimal("80"), Decimal("-25"), Decimal("25"))
    confirmation = Decimal("0")
    if large_net is not None and total_net is not None and large_net > 0 and total_net > 0:
        confirmation += Decimal("8")
    if large_net is not None and small_net is not None and large_net < 0 and small_net > 0:
        confirmation -= Decimal("8")

    realtime_score = _clamp(base_score + momentum_boost + capital_boost + confirmation, Decimal("0"), Decimal("120"))
    signal = _signal(change_pct, large_net, total_net, small_net)
    return {
        "pool": row.get("pool"),
        "symbol": row.get("symbol"),
        "market": str(row.get("market") or "").upper(),
        "name": row.get("name"),
        "decision": row.get("decision"),
        "baseScore": _float(row.get("base_score")),
        "rank": row.get("rank_in_market"),
        "lastDone": _float(row.get("last_done")),
        "prevClose": _float(row.get("prev_close")),
        "changePercentage": _float(row.get("change_percentage")),
        "volume": _float(row.get("volume")),
        "turnover": _float(row.get("turnover")),
        "tradeStatus": row.get("trade_status"),
        "largeIn": _float(row.get("large_in")),
        "largeOut": _float(row.get("large_out")),
        "largeNet": _float(row.get("large_net")),
        "mediumNet": _float(row.get("medium_net")),
        "smallNet": _float(row.get("small_net")),
        "totalNet": _float(row.get("total_net")),
        "dayLargeIn": _float(row.get("large_in")),
        "dayLargeOut": _float(row.get("large_out")),
        "dayLargeNet": _float(row.get("large_net")),
        "dayTotalIn": _float(row.get("total_in")),
        "dayTotalOut": _float(row.get("total_out")),
        "dayTotalNet": _float(row.get("total_net")),
        "largeNetRatio": _float(row.get("large_net_ratio")),
        "smallNetRatio": _float(row.get("small_net_ratio")),
        "realtimeScore": float(realtime_score.quantize(Decimal("0.01"))),
        "signal": signal,
        "signalLabel": _signal_label(signal),
        "quoteMinute": _iso(row.get("snapshot_minute")),
        "capitalMinute": _iso(row.get("capital_minute")),
        "capitalUpdatedAt": _iso(row.get("capital_updated_at")),
        "quoteFetchedAt": _iso(row.get("fetched_at")),
    }


def _signal(change_pct: Decimal, large_net: Decimal | None, total_net: Decimal | None, small_net: Decimal | None) -> str:
    if large_net is not None and total_net is not None and large_net > 0 and total_net > 0 and change_pct >= 0:
        return "capital_accumulation"
    if large_net is not None and total_net is not None and large_net < 0 and total_net < 0:
        return "main_fund_outflow"
    if change_pct >= Decimal("8"):
        return "high_momentum"
    if large_net is not None and small_net is not None and large_net < 0 and small_net > 0:
        return "retail_chase_risk"
    return "watch"


def _signal_label(signal: str) -> str:
    return {
        "capital_accumulation": "资金增强",
        "main_fund_outflow": "主力流出",
        "high_momentum": "高位强势",
        "retail_chase_risk": "散户追高风险",
        "watch": "观察",
    }.get(signal, "观察")


def _decimal(value: Any) -> Decimal | None:
    if value is None:
        return None
    try:
        return Decimal(str(value))
    except (InvalidOperation, ValueError):
        return None


def _float(value: Any) -> float | None:
    number = _decimal(value)
    return float(number) if number is not None else None


def _clamp(value: Decimal, low: Decimal, high: Decimal) -> Decimal:
    return max(low, min(high, value))


def _iso(value: Any) -> str | None:
    return value.isoformat() if hasattr(value, "isoformat") else None


def _load_psycopg():
    try:
        import psycopg
    except ImportError as exc:  # pragma: no cover
        raise RuntimeError("psycopg is required for realtime analysis") from exc
    return psycopg
