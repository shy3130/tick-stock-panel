from __future__ import annotations

import argparse
import json
import os
from dataclasses import dataclass
from datetime import date, datetime
from decimal import Decimal
from typing import Any, Iterable
from urllib import request
from urllib.parse import quote
from zoneinfo import ZoneInfo

import psycopg
from psycopg.rows import dict_row


SHANGHAI_TZ = ZoneInfo("Asia/Shanghai")
TASK_LOG_TABLES = {"lb_sync_runs", "lb_sync_errors"}
PG_SYSTEM_SCHEMAS = {"pg_catalog", "information_schema"}


@dataclass(frozen=True)
class ColumnMeta:
    name: str
    data_type: str
    nullable: bool


@dataclass(frozen=True)
class TableMeta:
    schema: str
    name: str
    columns: list[ColumnMeta]


def should_keep_in_postgres(schema: str, table: str) -> bool:
    return schema == "lb_monitor" or table in TASK_LOG_TABLES


def choose_order_key(columns: Iterable[str]) -> list[str]:
    names = set(columns)
    preferred = [
        ["market", "symbol", "trade_date"],
        ["market", "symbol", "score_date"],
        ["market", "symbol", "snapshot_minute"],
        ["market", "symbol", "line_time"],
        ["market", "symbol", "flow_time"],
        ["market", "symbol", "trade_time"],
        ["market", "symbol", "predicted_at"],
        ["symbol", "trade_date"],
        ["market", "symbol"],
        ["symbol", "fetched_at"],
        ["id"],
    ]
    for key in preferred:
        if all(column in names for column in key):
            return key
    return []


def choose_partition_key(columns: Iterable[str]) -> str | None:
    names = set(columns)
    for column in (
        "trade_date",
        "score_date",
        "snapshot_minute",
        "line_time",
        "flow_time",
        "trade_time",
        "predicted_at",
        "fetched_at",
        "updated_at",
        "created_at",
    ):
        if column in names:
            return column
    return None


def choose_version_key(columns: Iterable[str]) -> str | None:
    names = set(columns)
    for column in ("updated_at", "inserted_at", "fetched_at", "created_at"):
        if column in names:
            return column
    return None


def clickhouse_type(pg_type: str, *, nullable: bool, is_key: bool) -> str:
    normalized = pg_type.lower()
    if normalized in {"smallint", "integer", "bigint"}:
        base = "Int64"
    elif normalized in {"real", "double precision", "numeric", "decimal"}:
        base = "Float64"
    elif normalized == "boolean":
        base = "UInt8"
    elif normalized == "date":
        base = "Date"
    elif normalized in {"timestamp with time zone", "timestamp without time zone"}:
        base = "DateTime64(3, 'Asia/Shanghai')"
    elif normalized in {"json", "jsonb"}:
        base = "String"
    else:
        base = "String"
    if nullable and not is_key:
        return f"Nullable({base})"
    return base


def build_create_table_sql(meta: TableMeta, *, database: str, replace: bool = False) -> list[str]:
    columns = [column.name for column in meta.columns]
    order_key = choose_order_key(columns)
    partition_key = choose_partition_key(columns)
    version_key = choose_version_key(columns)
    key_columns = set(order_key)
    if partition_key:
        key_columns.add(partition_key)
    column_defs = []
    for column in meta.columns:
        ch_type = clickhouse_type(column.data_type, nullable=column.nullable, is_key=column.name in key_columns)
        column_defs.append(f"  {_ident(column.name)} {ch_type}")
    engine = f"ReplacingMergeTree({_ident(version_key)})" if version_key else "MergeTree"
    order_by = "tuple()" if not order_key else ", ".join(_ident(column) for column in order_key)
    statements: list[str] = []
    table = f"{_ident(database)}.{_ident(meta.name)}"
    if replace:
        statements.append(f"DROP TABLE IF EXISTS {table}")
    partition_clause = f"\nPARTITION BY toYYYYMM({_ident(partition_key)})" if partition_key else ""
    columns_sql = ",\n".join(column_defs)
    statements.append(
        f"""
CREATE TABLE IF NOT EXISTS {table} (
{columns_sql}
)
ENGINE = {engine}{partition_clause}
ORDER BY ({order_by})
""".strip()
    )
    return statements


def discover_business_tables(conn: psycopg.Connection[Any]) -> list[tuple[str, str]]:
    rows = conn.execute(
        """
        select table_schema, table_name
        from information_schema.tables
        where table_type = 'BASE TABLE'
          and table_schema not in ('pg_catalog', 'information_schema')
        order by table_schema, table_name
        """
    ).fetchall()
    tables = [(str(row["table_schema"]), str(row["table_name"])) for row in rows]
    return [(schema, table) for schema, table in tables if not should_keep_in_postgres(schema, table)]


def discover_columns(conn: psycopg.Connection[Any], schema: str, table: str) -> list[ColumnMeta]:
    rows = conn.execute(
        """
        select column_name, data_type, is_nullable
        from information_schema.columns
        where table_schema = %s and table_name = %s
        order by ordinal_position
        """,
        (schema, table),
    ).fetchall()
    return [
        ColumnMeta(
            name=str(row["column_name"]),
            data_type=str(row["data_type"]),
            nullable=str(row["is_nullable"]).upper() == "YES",
        )
        for row in rows
    ]


def existing_clickhouse_tables(*, database: str) -> set[str]:
    rows = _clickhouse_query_json(
        f"select name from system.tables where database = {_sql_string(database)}"
    )
    return {str(row["name"]) for row in rows}


def migrate_table(
    conn: psycopg.Connection[Any],
    *,
    schema: str,
    table: str,
    database: str,
    clickhouse_url: str,
    replace: bool,
    chunk_size: int,
    dry_run: bool = False,
) -> dict[str, Any]:
    columns = discover_columns(conn, schema, table)
    if not columns:
        raise ValueError(f"table has no columns: {schema}.{table}")
    meta = TableMeta(schema=schema, name=table, columns=columns)
    create_sql = build_create_table_sql(meta, database=database, replace=replace)
    if dry_run:
        return {"schema": schema, "table": table, "create_sql": create_sql, "rows": 0}
    for statement in create_sql:
        _clickhouse_execute(statement, clickhouse_url=clickhouse_url)
    column_names = [column.name for column in columns]
    select_sql = (
        "select "
        + ", ".join(_pg_ident(column) for column in column_names)
        + f" from {_pg_ident(schema)}.{_pg_ident(table)}"
    )
    inserted = 0
    cursor_name = f"migrate_{schema}_{table}".replace(".", "_")
    with conn.cursor(cursor_name, row_factory=dict_row) as cursor:
        cursor.itersize = chunk_size
        cursor.execute(select_sql)
        while True:
            rows = cursor.fetchmany(chunk_size)
            if not rows:
                break
            documents = [_normalize_row(dict(row), columns) for row in rows]
            _clickhouse_insert_json(database, table, documents, clickhouse_url=clickhouse_url)
            inserted += len(documents)
            print(json.dumps({"table": table, "inserted": inserted}, ensure_ascii=False), flush=True)
    return {"schema": schema, "table": table, "rows": inserted}


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Migrate non-task-log PostgreSQL tables into ClickHouse.")
    parser.add_argument("--dsn", default=os.getenv("LONGBRIDGE_PG_DSN", "dbname=longbridge_stock user=alwin host=/var/run/postgresql"))
    parser.add_argument("--clickhouse-url", default=os.getenv("CLICKHOUSE_URL", "http://127.0.0.1:8123"))
    parser.add_argument("--database", default=os.getenv("CLICKHOUSE_DATABASE", "longbridge"))
    parser.add_argument("--tables", default="", help="Comma-separated table names to migrate. Defaults to all missing business tables.")
    parser.add_argument("--replace", action="store_true", help="Drop and rebuild target ClickHouse tables before copying.")
    parser.add_argument("--include-existing", action="store_true", help="Also migrate tables that already exist in ClickHouse.")
    parser.add_argument("--chunk-size", type=int, default=5000)
    parser.add_argument("--dry-run", action="store_true")
    args = parser.parse_args(argv)

    if args.chunk_size <= 0:
        raise SystemExit("--chunk-size must be positive")
    requested = {table.strip() for table in args.tables.split(",") if table.strip()}
    with psycopg.connect(args.dsn, row_factory=dict_row) as conn:
        tables = discover_business_tables(conn)
        if requested:
            tables = [(schema, table) for schema, table in tables if table in requested or f"{schema}.{table}" in requested]
        existing = existing_clickhouse_tables(database=args.database)
        if not args.include_existing and not args.replace:
            tables = [(schema, table) for schema, table in tables if table not in existing]
        print(
            json.dumps(
                {
                    "selected_tables": [f"{schema}.{table}" for schema, table in tables],
                    "skip_existing": not args.include_existing and not args.replace,
                    "dry_run": args.dry_run,
                },
                ensure_ascii=False,
            ),
            flush=True,
        )
        for schema, table in tables:
            result = migrate_table(
                conn,
                schema=schema,
                table=table,
                database=args.database,
                clickhouse_url=args.clickhouse_url,
                replace=args.replace,
                chunk_size=args.chunk_size,
                dry_run=args.dry_run,
            )
            print(json.dumps({"status": "migrated", **result}, ensure_ascii=False), flush=True)
    return 0


def _normalize_row(row: dict[str, Any], columns: list[ColumnMeta]) -> dict[str, Any]:
    normalized: dict[str, Any] = {}
    for column in columns:
        value = row.get(column.name)
        if isinstance(value, datetime):
            if value.tzinfo:
                value = value.astimezone(SHANGHAI_TZ)
            normalized[column.name] = value.strftime("%Y-%m-%d %H:%M:%S.%f")[:-3]
        elif isinstance(value, date):
            normalized[column.name] = value.isoformat()
        elif isinstance(value, Decimal):
            normalized[column.name] = float(value)
        elif isinstance(value, (dict, list)):
            normalized[column.name] = json.dumps(value, ensure_ascii=False, default=str)
        else:
            normalized[column.name] = value
    return normalized


def _clickhouse_query_json(sql: str) -> list[dict[str, Any]]:
    body = _clickhouse_execute(sql + " format JSONEachRow")
    return [json.loads(line) for line in body.splitlines() if line.strip()]


def _clickhouse_insert_json(
    database: str,
    table: str,
    documents: list[dict[str, Any]],
    *,
    clickhouse_url: str,
) -> None:
    if not documents:
        return
    body = "\n".join(json.dumps(document, ensure_ascii=False, default=str) for document in documents).encode("utf-8")
    _clickhouse_execute(
        f"insert into {_ident(database)}.{_ident(table)} format JSONEachRow",
        clickhouse_url=clickhouse_url,
        payload=body,
    )


def _clickhouse_execute(sql: str, *, clickhouse_url: str | None = None, payload: bytes | None = None) -> str:
    url = clickhouse_url or os.getenv("CLICKHOUSE_URL", "http://127.0.0.1:8123")
    req = request.Request(f"{url}/?query={quote(sql)}", data=payload, method="POST")
    user = os.getenv("CLICKHOUSE_USER", "default")
    password = os.getenv("CLICKHOUSE_PASSWORD", "")
    if user:
        req.add_header("X-ClickHouse-User", user)
    if password:
        req.add_header("X-ClickHouse-Key", password)
    with request.urlopen(req, timeout=float(os.getenv("CLICKHOUSE_WRITE_TIMEOUT_SECONDS", "120"))) as response:
        return response.read().decode("utf-8")


def _ident(value: str) -> str:
    return "`" + value.replace("`", "``") + "`"


def _pg_ident(value: str) -> str:
    return '"' + value.replace('"', '""') + '"'


def _sql_string(value: str) -> str:
    return "'" + value.replace("'", "''") + "'"


if __name__ == "__main__":
    raise SystemExit(main())
