"""UI service helpers for the Longbridge Quant console."""

