from __future__ import annotations

from dataclasses import dataclass
from statistics import median
from typing import Literal, Mapping, Sequence


PivotKind = Literal["HIGH", "LOW"]


@dataclass(frozen=True)
class PivotDetectorConfig:
    atr_period: int = 14
    range_period: int = 20
    atr_multiplier: float = 1.5
    range_multiplier: float = 2.0
    min_reversal_ratio: float = 0.04
    max_reversal_ratio: float = 0.20
    min_separation: int = 2


@dataclass(frozen=True)
class DetectedPivot:
    kind: PivotKind
    bar_index: int
    price: float
    confirmed_index: int
    reversal_ratio: float


class CausalPivotDetector:
    def __init__(self, config: PivotDetectorConfig | None = None) -> None:
        self.config = config or PivotDetectorConfig()

    def detect(self, bars: Sequence[object]) -> tuple[DetectedPivot, ...]:
        if not bars:
            return ()

        highs = [self._number(bar, "high") for bar in bars]
        lows = [self._number(bar, "low") for bar in bars]
        closes = [self._number(bar, "close") for bar in bars]
        thresholds = self._thresholds(highs, lows, closes)

        pivots: list[DetectedPivot] = []
        state = "SEEK_DIRECTION"
        high_index = low_index = 0
        high_price = highs[0]
        low_price = lows[0]

        for index in range(1, len(bars)):
            if highs[index] >= high_price:
                high_index, high_price = index, highs[index]
            if lows[index] <= low_price:
                low_index, low_price = index, lows[index]

            threshold = thresholds[index]
            if state == "SEEK_DIRECTION":
                if (
                    index - low_index >= self.config.min_separation
                    and closes[index] >= low_price * (1 + threshold)
                ):
                    pivots.append(
                        DetectedPivot(
                            kind="LOW",
                            bar_index=low_index,
                            price=low_price,
                            confirmed_index=index,
                            reversal_ratio=threshold,
                        )
                    )
                    state = "RISING_LEG"
                    high_index, high_price = index, highs[index]
                elif (
                    index - high_index >= self.config.min_separation
                    and closes[index] <= high_price * (1 - threshold)
                ):
                    pivots.append(
                        DetectedPivot(
                            kind="HIGH",
                            bar_index=high_index,
                            price=high_price,
                            confirmed_index=index,
                            reversal_ratio=threshold,
                        )
                    )
                    state = "FALLING_LEG"
                    low_index, low_price = index, lows[index]
                continue

            if state == "RISING_LEG":
                if highs[index] >= high_price:
                    high_index, high_price = index, highs[index]
                if (
                    index - high_index >= self.config.min_separation
                    and closes[index] <= high_price * (1 - threshold)
                ):
                    pivots.append(
                        DetectedPivot(
                            kind="HIGH",
                            bar_index=high_index,
                            price=high_price,
                            confirmed_index=index,
                            reversal_ratio=threshold,
                        )
                    )
                    state = "FALLING_LEG"
                    low_index, low_price = index, lows[index]
                continue

            if lows[index] <= low_price:
                low_index, low_price = index, lows[index]
            if (
                index - low_index >= self.config.min_separation
                and closes[index] >= low_price * (1 + threshold)
            ):
                pivots.append(
                    DetectedPivot(
                        kind="LOW",
                        bar_index=low_index,
                        price=low_price,
                        confirmed_index=index,
                        reversal_ratio=threshold,
                    )
                )
                state = "RISING_LEG"
                high_index, high_price = index, highs[index]

        return tuple(pivots)

    def _thresholds(
        self,
        highs: list[float],
        lows: list[float],
        closes: list[float],
    ) -> list[float]:
        true_ranges: list[float] = []
        range_ratios: list[float] = []
        thresholds: list[float] = []
        previous_close = closes[0]
        for index, close in enumerate(closes):
            true_range = max(
                highs[index] - lows[index],
                abs(highs[index] - previous_close),
                abs(lows[index] - previous_close),
            )
            true_ranges.append(true_range)
            range_ratios.append((highs[index] - lows[index]) / max(abs(close), 1e-9))
            atr = sum(true_ranges[-self.config.atr_period :]) / min(
                len(true_ranges), self.config.atr_period
            )
            typical_range = median(range_ratios[-self.config.range_period :])
            raw = max(
                self.config.atr_multiplier * atr / max(abs(close), 1e-9),
                self.config.range_multiplier * typical_range,
                self.config.min_reversal_ratio,
            )
            thresholds.append(
                min(max(raw, self.config.min_reversal_ratio), self.config.max_reversal_ratio)
            )
            previous_close = close
        return thresholds

    @staticmethod
    def _number(bar: object, field: str) -> float:
        if isinstance(bar, Mapping):
            return float(bar[field])
        return float(getattr(bar, field))

