from __future__ import annotations


ETF_NAME_FLAGS = (
    "ETF",
    "ETN",
    "LOF",
    "基金",
    "指数基金",
    "货币",
    "债券",
    "国债",
    "可转债",
    "REIT",
    "REITS",
)

LEVERAGED_NAME_FLAGS = (
    "2X",
    "3X",
    "两倍",
    "三倍",
    "杠杆",
    "反向",
    "做空",
    "BULL",
    "BEAR",
)

CN_FUND_PREFIXES = (
    "159",
    "160",
    "161",
    "162",
    "163",
    "164",
    "165",
    "166",
    "167",
    "168",
    "169",
    "501",
    "502",
    "503",
    "505",
    "506",
    "508",
    "510",
    "511",
    "512",
    "513",
    "515",
    "516",
    "517",
    "518",
    "519",
    "520",
    "521",
    "522",
    "560",
    "561",
    "562",
    "563",
    "588",
    "589",
)

HK_ETF_PREFIXES = ("28", "30", "31", "32", "34", "72", "73", "75")


def is_etf_like_symbol(symbol: str, name: str = "") -> bool:
    normalized_symbol = str(symbol or "").strip().upper()
    normalized_name = str(name or "").strip().upper()
    text = f"{normalized_symbol} {normalized_name}"
    if any(flag in text for flag in ETF_NAME_FLAGS + LEVERAGED_NAME_FLAGS):
        return True

    code, _, market = normalized_symbol.partition(".")
    if market in {"SH", "SZ"} and code.startswith(CN_FUND_PREFIXES):
        return True
    if market == "HK" and code.lstrip("0").startswith(HK_ETF_PREFIXES):
        return True
    return False
