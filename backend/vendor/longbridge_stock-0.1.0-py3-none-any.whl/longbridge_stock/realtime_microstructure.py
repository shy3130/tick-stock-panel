from __future__ import annotations

import json
import time
from collections import Counter
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any, Iterable

from longbridge_stock import clickhouse_realtime
from longbridge_stock.collection_monitor import DatasetCoverage, heartbeat, write_dataset_coverage
from longbridge_stock.market_sessions import has_market_opened_today, is_trading_time, markets_from_symbols
from longbridge_stock.postgres_store import LongbridgePostgresStore
from longbridge_stock.realtime_symbols import load_realtime_symbols
from longbridge_stock.sdk_client import LongbridgeSdkClient


DATASET_KEYS = {
    "intraday": "intraday_line",
    "trades": "trade_tick",
    "depth": "order_book_depth",
}


@dataclass(frozen=True)
class RealtimeMicrostructureSummary:
    snapshot_minute: datetime
    input_symbols: int
    written_symbols: int
    written_rows: int
    failed: int
    elapsed_seconds: float
    datasets: list[str]
    input_by_market: dict[str, int] | None = None
    written_by_market: dict[str, int] | None = None

    def to_dict(self) -> dict[str, Any]:
        return {
            "snapshotMinute": self.snapshot_minute.isoformat(),
            "inputSymbols": self.input_symbols,
            "writtenSymbols": self.written_symbols,
            "writtenRows": self.written_rows,
            "failed": self.failed,
            "elapsedSeconds": round(self.elapsed_seconds, 3),
            "datasets": self.datasets,
            "inputByMarket": self.input_by_market or {},
            "writtenByMarket": self.written_by_market or {},
        }


class RealtimeMicrostructureSync:
    def __init__(
        self,
        dsn: str,
        client: LongbridgeSdkClient | None = None,
        store: LongbridgePostgresStore | None = None,
        trade_count: int = 100,
    ) -> None:
        self.dsn = dsn
        self.client = client or LongbridgeSdkClient(rate_limit_per_second=10)
        self.store = store or LongbridgePostgresStore(dsn)
        self.trade_count = trade_count

    def load_symbols(
        self,
        markets: Iterable[str],
        limit: int | None = None,
        priority_only: bool = True,
    ) -> list[str]:
        return load_realtime_symbols(self.dsn, markets, client=self.client, limit=limit, priority_only=priority_only)

    def sync_once(self, symbols: list[str], datasets: Iterable[str]) -> RealtimeMicrostructureSummary:
        selected = _normalize_datasets(datasets)
        started = time.monotonic()
        fetched_at = _now()
        snapshot_minute = fetched_at.replace(second=0, microsecond=0)
        input_by_market = Counter(_market_from_symbol(symbol) for symbol in symbols)
        latest_intraday_by_symbol = (
            self._latest_intraday_line_times(input_by_market.keys())
            if "intraday" in selected and not self.store.realtime_sinks.config.postgres_enabled
            else {}
        )
        written_by_market: Counter[str] = Counter()
        written_symbols: set[str] = set()
        written_rows = 0
        failed = 0

        self.store.ensure_realtime_microstructure_tables()
        for symbol in symbols:
            symbol_written = False
            try:
                if "intraday" in selected:
                    rows = self.client.intraday(symbol)
                    rows = _filter_new_intraday_rows(rows, latest_intraday_by_symbol.get(symbol))
                    written = self.store.upsert_intraday_lines(symbol, rows, _now())
                    written_rows += written
                    symbol_written = symbol_written or written > 0
                if "trades" in selected:
                    rows = self.client.trades(symbol, self.trade_count)
                    written = self.store.upsert_realtime_trades(symbol, rows, _now())
                    written_rows += written
                    symbol_written = symbol_written or written > 0
                if "depth" in selected:
                    payload = self.client.depth(symbol)
                    if isinstance(payload, dict):
                        self.store.upsert_realtime_depth(symbol, payload, snapshot_minute, _now())
                        written_rows += 1
                        symbol_written = True
            except Exception:
                failed += 1
                continue
            if symbol_written:
                written_symbols.add(symbol)
                written_by_market[_market_from_symbol(symbol)] += 1

        elapsed = time.monotonic() - started
        self._write_monitoring(
            snapshot_minute=snapshot_minute,
            input_by_market=dict(input_by_market),
            written_by_market=dict(written_by_market),
            written_symbols=len(written_symbols),
            written_rows=written_rows,
            failed=failed,
            elapsed_seconds=elapsed,
            datasets=selected,
        )
        return RealtimeMicrostructureSummary(
            snapshot_minute=snapshot_minute,
            input_symbols=len(symbols),
            written_symbols=len(written_symbols),
            written_rows=written_rows,
            failed=failed,
            elapsed_seconds=elapsed,
            datasets=selected,
            input_by_market=dict(input_by_market),
            written_by_market=dict(written_by_market),
        )

    def run_forever(self, symbols: list[str], datasets: Iterable[str], interval_seconds: int) -> None:
        if interval_seconds <= 0:
            raise ValueError("interval_seconds must be positive")
        selected = _normalize_datasets(datasets)
        markets = markets_from_symbols(symbols)
        input_by_market = Counter(_market_from_symbol(symbol) for symbol in symbols)
        task_key = _task_key(dict(input_by_market), selected)
        while True:
            now = _now()
            outside_trading_time = not is_trading_time(now, markets)
            should_idle_outside_session = outside_trading_time and (
                not has_market_opened_today(now, markets) or self._is_latest_coverage_complete(dict(input_by_market), selected)
            )
            if should_idle_outside_session:
                snapshot_minute = now.replace(second=0, microsecond=0)
                self._write_coverage_snapshot(
                    snapshot_minute=snapshot_minute,
                    input_by_market=dict(input_by_market),
                    datasets=selected,
                )
                heartbeat(
                    self.dsn,
                    task_key,
                    status="outside_trading_time",
                    rows_written=0,
                    rows_failed=0,
                    queue_depth=0,
                    runtime={"datasets": selected, "input_by_market": dict(input_by_market), "elapsed_seconds": 0},
                )
                print(json.dumps({"status": "outside_trading_time", "markets": markets, "datasets": selected}, ensure_ascii=False), flush=True)
                time.sleep(min(interval_seconds, 300))
                continue
            summary = self.sync_once(symbols, selected)
            print(json.dumps(summary.to_dict(), ensure_ascii=False), flush=True)
            if outside_trading_time and not self._is_latest_coverage_complete(dict(input_by_market), selected):
                time.sleep(min(interval_seconds, 60))
                continue
            time.sleep(max(0, interval_seconds - summary.elapsed_seconds))

    def _write_monitoring(
        self,
        *,
        snapshot_minute: datetime,
        input_by_market: dict[str, int],
        written_by_market: dict[str, int],
        written_symbols: int,
        written_rows: int,
        failed: int,
        elapsed_seconds: float,
        datasets: list[str],
    ) -> None:
        try:
            coverage: list[DatasetCoverage] = []
            for market, expected in input_by_market.items():
                collected = int(written_by_market.get(market, 0))
                for dataset in datasets:
                    coverage.append(
                        DatasetCoverage(
                            market=market,
                            dataset_key=DATASET_KEYS[dataset],
                            expected_count=expected,
                            collected_count=collected,
                            latest_data_at=snapshot_minute,
                            freshness_status="ok" if collected >= expected else "partial",
                        )
                    )
            write_dataset_coverage(self.dsn, coverage)
            heartbeat(
                self.dsn,
                _task_key(input_by_market, datasets),
                status="running",
                rows_written=written_rows,
                rows_failed=failed,
                last_write_at=snapshot_minute,
                last_success_at=snapshot_minute if written_symbols else None,
                runtime={
                    "datasets": datasets,
                    "input_by_market": input_by_market,
                    "written_by_market": written_by_market,
                    "written_symbols": written_symbols,
                    "elapsed_seconds": round(elapsed_seconds, 3),
                },
            )
        except Exception:
            return

    def _write_coverage_snapshot(
        self,
        *,
        snapshot_minute: datetime,
        input_by_market: dict[str, int],
        datasets: list[str],
    ) -> None:
        try:
            actual_counts = self._latest_coverage_counts(input_by_market.keys(), datasets)
            coverage: list[DatasetCoverage] = []
            for market, expected in input_by_market.items():
                for dataset in datasets:
                    dataset_key = DATASET_KEYS[dataset]
                    collected = int(actual_counts.get((market, dataset_key), 0) or 0)
                    coverage.append(
                        DatasetCoverage(
                            market=market,
                            dataset_key=dataset_key,
                            expected_count=expected,
                            collected_count=collected,
                            latest_data_at=snapshot_minute,
                            freshness_status="ok" if _coverage_is_complete(collected, expected) else "partial",
                        )
                    )
            write_dataset_coverage(self.dsn, coverage)
        except Exception:
            return

    def _is_latest_coverage_complete(self, input_by_market: dict[str, int], datasets: list[str]) -> bool:
        counts = self._latest_coverage_counts(input_by_market.keys(), datasets)
        for market, expected in input_by_market.items():
            for dataset in datasets:
                dataset_key = DATASET_KEYS[dataset]
                if not _coverage_is_complete(int(counts.get((market, dataset_key), 0) or 0), expected):
                    return False
        return True

    def _latest_coverage_counts(self, markets: Iterable[str], datasets: list[str]) -> dict[tuple[str, str], int]:
        selected_markets = list(markets)
        if not selected_markets:
            return {}
        counts: dict[tuple[str, str], int] = {}
        try:
            database = clickhouse_realtime._database()
            table_map = {
                "intraday": ("lb_intraday_lines", "line_time", "intraday_line"),
                "trades": ("lb_realtime_trades", "trade_time", "trade_tick"),
                "depth": ("lb_realtime_depth", "snapshot_minute", "order_book_depth"),
            }
            market_sql = "(" + ",".join("'" + market.replace("'", "") + "'" for market in selected_markets) + ")"
            for dataset in datasets:
                if dataset not in table_map:
                    continue
                table, time_col, key = table_map[dataset]
                rows = clickhouse_realtime._query_json_each_row(
                    f"""
                    select market, countDistinct(symbol) as count
                    from {database}.{table}
                    where market in {market_sql}
                      and {time_col} >= toStartOfDay(now('Asia/Shanghai'))
                    group by market
                    """
                )
                for row in rows:
                    counts[(str(row.get("market")), key)] = int(row.get("count") or 0)
        except Exception:
            return {}
        return counts

    def _latest_intraday_line_times(self, markets: Iterable[str]) -> dict[str, datetime]:
        selected_markets = list(markets)
        if not selected_markets:
            return {}
        try:
            database = clickhouse_realtime._database()
            market_sql = "(" + ",".join("'" + market.replace("'", "") + "'" for market in selected_markets) + ")"
            rows = clickhouse_realtime._query_json_each_row(
                f"""
                select symbol, max(line_time) as latest_line_time
                from {database}.lb_intraday_lines
                where market in {market_sql}
                  and line_time >= toStartOfDay(now('Asia/Shanghai'))
                group by symbol
                """
            )
        except Exception:
            return {}
        latest: dict[str, datetime] = {}
        for row in rows:
            symbol = str(row.get("symbol") or "")
            line_time = _parse_line_datetime(row.get("latest_line_time"))
            if symbol and line_time is not None:
                latest[symbol] = line_time
        return latest


@dataclass(frozen=True)
class MarketTemperatureSummary:
    markets: list[str]
    written: int
    failed: int
    elapsed_seconds: float

    def to_dict(self) -> dict[str, Any]:
        return {
            "markets": self.markets,
            "written": self.written,
            "failed": self.failed,
            "elapsedSeconds": round(self.elapsed_seconds, 3),
        }


class MarketTemperatureSync:
    def __init__(
        self,
        dsn: str,
        client: LongbridgeSdkClient | None = None,
        store: LongbridgePostgresStore | None = None,
    ) -> None:
        self.dsn = dsn
        self.client = client or LongbridgeSdkClient(rate_limit_per_second=10)
        self.store = store or LongbridgePostgresStore(dsn)

    def sync_once(self, markets: Iterable[str]) -> MarketTemperatureSummary:
        started = time.monotonic()
        selected = [_normalize_market(market) for market in markets]
        written = 0
        written_markets: set[str] = set()
        failed = 0
        fetched_at = _now()
        self.store.ensure_realtime_microstructure_tables()
        for market in selected:
            try:
                payload = self.client.market_temperature("CN" if market == "cn" else market.upper())
                if isinstance(payload, dict) and self.store.upsert_market_temperature(market, payload, fetched_at):
                    written += 1
                    written_markets.add(market)
            except Exception:
                failed += 1
        elapsed = time.monotonic() - started
        try:
            write_dataset_coverage(
                self.dsn,
                [
                    DatasetCoverage(
                        market=market,
                        dataset_key="market_temperature",
                        expected_count=1,
                        collected_count=1 if market in written_markets else 0,
                        latest_data_at=fetched_at if written else None,
                        freshness_status="ok" if written else "partial",
                    )
                    for market in selected
                ],
            )
            heartbeat(
                self.dsn,
                "market_temperature_sync",
                status="running",
                rows_written=written,
                rows_failed=failed,
                last_write_at=fetched_at if written else None,
                last_success_at=fetched_at if written else None,
                runtime={"markets": selected, "elapsed_seconds": round(elapsed, 3)},
            )
        except Exception:
            pass
        return MarketTemperatureSummary(markets=selected, written=written, failed=failed, elapsed_seconds=elapsed)


def _normalize_datasets(datasets: Iterable[str]) -> list[str]:
    selected: list[str] = []
    for item in datasets:
        key = item.strip().lower()
        if not key:
            continue
        if key not in DATASET_KEYS:
            raise ValueError(f"unsupported microstructure dataset: {key}")
        if key not in selected:
            selected.append(key)
    return selected or ["intraday", "trades", "depth"]


def _normalize_market(market: str) -> str:
    value = market.strip().lower()
    if value in {"sh", "sz"}:
        return "cn"
    return value


def _market_from_symbol(symbol: str) -> str:
    suffix = symbol.rsplit(".", 1)[-1].lower() if "." in symbol else ""
    if suffix in {"sh", "sz"}:
        return "cn"
    return suffix


def _task_key(input_by_market: dict[str, int], datasets: list[str]) -> str:
    markets = set(input_by_market)
    if datasets == ["intraday"]:
        if markets == {"cn"}:
            return "realtime_intraday_cn_full"
        if markets == {"hk"}:
            return "realtime_intraday_hk_full"
        if markets == {"us"}:
            return "realtime_intraday_us_full"
    return "realtime_microstructure_priority"


def _coverage_is_complete(collected: int, expected: int) -> bool:
    if expected <= 0:
        return True
    missing = max(expected - collected, 0)
    tolerance = max(5, int(expected * 0.002))
    return missing <= tolerance


def _filter_new_intraday_rows(rows: Any, latest_line_time: datetime | None) -> Any:
    if latest_line_time is None or not isinstance(rows, list):
        return rows
    filtered: list[Any] = []
    for row in rows:
        if not isinstance(row, dict):
            filtered.append(row)
            continue
        line_time = _parse_line_datetime(row.get("timestamp") or row.get("time"))
        if line_time is None or line_time > latest_line_time:
            filtered.append(row)
    return filtered


def _parse_line_datetime(value: Any) -> datetime | None:
    if isinstance(value, datetime):
        parsed = value
    elif value is None:
        return None
    else:
        text = str(value).strip()
        if not text:
            return None
        if text.endswith("Z"):
            text = text[:-1] + "+00:00"
        try:
            parsed = datetime.fromisoformat(text)
        except ValueError:
            try:
                parsed = datetime.fromtimestamp(float(text), tz=timezone.utc)
            except (TypeError, ValueError, OSError):
                return None
    if parsed.tzinfo is None:
        return parsed.astimezone()
    return parsed.astimezone()


def _now() -> datetime:
    return datetime.now(timezone.utc).astimezone()
