from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import yaml


@dataclass(frozen=True)
class DataConfig:
    provider_uri: Path
    local_csv_dir: Path
    region: str = "cn"
    market: str = "csi300"
    benchmark: str = "SH000300"
    fields: list[str] = field(default_factory=lambda: ["close", "open", "high", "low", "volume", "factor"])


@dataclass(frozen=True)
class BacktestConfig:
    top_k: int = 30
    cost_rate: float = 0.0015
    rebalance_frequency: str = "daily"


@dataclass(frozen=True)
class ExperimentConfig:
    name: str
    start_time: str
    end_time: str
    factor_set: list[str]
    score_weights: dict[str, float]
    backtest: BacktestConfig
    train_start_time: str | None = None
    train_end_time: str | None = None
    valid_start_time: str | None = None
    valid_end_time: str | None = None
    test_start_time: str | None = None
    test_end_time: str | None = None


def load_yaml(path: str | Path) -> dict[str, Any]:
    with Path(path).open("r", encoding="utf-8") as fh:
        data = yaml.safe_load(fh) or {}
    if not isinstance(data, dict):
        raise ValueError(f"Expected YAML object in {path}")
    return data


def load_data_config(path: str | Path) -> DataConfig:
    raw = load_yaml(path)
    return DataConfig(
        provider_uri=Path(raw["provider_uri"]),
        local_csv_dir=Path(raw.get("local_csv_dir", "")),
        region=str(raw.get("region", "cn")),
        market=str(raw.get("market", "csi300")),
        benchmark=str(raw.get("benchmark", "SH000300")),
        fields=list(raw.get("fields", [])),
    )


def load_experiment_config(path: str | Path) -> ExperimentConfig:
    raw = load_yaml(path)
    backtest = BacktestConfig(**raw.get("backtest", {}))
    return ExperimentConfig(
        name=str(raw["name"]),
        start_time=str(raw["start_time"]),
        end_time=str(raw["end_time"]),
        train_start_time=raw.get("train_start_time"),
        train_end_time=raw.get("train_end_time"),
        valid_start_time=raw.get("valid_start_time"),
        valid_end_time=raw.get("valid_end_time"),
        test_start_time=raw.get("test_start_time"),
        test_end_time=raw.get("test_end_time"),
        factor_set=list(raw.get("factor_set", [])),
        score_weights={str(k): float(v) for k, v in raw.get("score_weights", {}).items()},
        backtest=backtest,
    )
