from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import pandas as pd


@dataclass(frozen=True)
class SwingRegimeConfig:
    zigzag_threshold: float = 0.15
    pullback_threshold: float = 0.15
    rebound_target: float = 0.15
    peak_risk_threshold: float = 0.15
    trend_break_drawdown: float = 0.20
    trend_break_days: int = 14
    trend_break_rebound: float = 0.10
    forward_window_days: int = 10


@dataclass(frozen=True)
class SwingPivot:
    index: int
    kind: str
    trade_date: str
    price: float


def detect_zigzag_pivots(frame: pd.DataFrame, threshold: float = 0.15) -> list[SwingPivot]:
    data = _prepare_frame(frame)
    if data.empty:
        return []

    pivots: list[tuple[int, str]] = []
    trend: str | None = None
    extreme_index = 0
    extreme_price = float(data.iloc[0]["close"])
    initial_low_index = 0
    initial_low_price = extreme_price
    initial_high_index = 0
    initial_high_price = extreme_price

    for index in range(1, len(data)):
        price = float(data.iloc[index]["close"])
        if trend is None:
            if price < initial_low_price:
                initial_low_index = index
                initial_low_price = price
            if price > initial_high_price:
                initial_high_index = index
                initial_high_price = price
            if price >= initial_low_price * (1.0 + threshold):
                pivots.append((initial_low_index, "low"))
                trend = "up"
                extreme_index = index
                extreme_price = price
            elif price <= initial_high_price * (1.0 - threshold):
                pivots.append((initial_high_index, "high"))
                trend = "down"
                extreme_index = index
                extreme_price = price
            continue

        if trend == "up":
            if price > extreme_price:
                extreme_index = index
                extreme_price = price
            elif price <= extreme_price * (1.0 - threshold):
                pivots.append((extreme_index, "high"))
                trend = "down"
                extreme_index = index
                extreme_price = price
        else:
            if price < extreme_price:
                extreme_index = index
                extreme_price = price
            elif price >= extreme_price * (1.0 + threshold):
                pivots.append((extreme_index, "low"))
                trend = "up"
                extreme_index = index
                extreme_price = price

    if trend is not None:
        pivots.append((extreme_index, "high" if trend == "up" else "low"))

    return [_pivot_from_row(data, index, kind) for index, kind in _dedupe_pivots(pivots)]


def build_swing_rows(frame: pd.DataFrame, config: SwingRegimeConfig | None = None) -> list[dict[str, Any]]:
    cfg = config or SwingRegimeConfig()
    pivots = detect_zigzag_pivots(frame, threshold=cfg.zigzag_threshold)
    rows: list[dict[str, Any]] = []
    for pivot_index, pivot in enumerate(pivots):
        if pivot.kind != "low":
            continue
        high = _next_pivot(pivots, pivot_index + 1, "high")
        if high is None:
            continue
        next_low = _next_low_or_latest(pivots, pivot_index + 2)
        if next_low is None:
            continue
        rows.append(
            {
                "start_date": pivot.trade_date,
                "high_date": high.trade_date,
                "pullback_date": next_low.trade_date,
                "start_price": _round(pivot.price),
                "high_price": _round(high.price),
                "pullback_price": _round(next_low.price),
                "up_return": _round(high.price / pivot.price - 1.0),
                "drawdown": _round(next_low.price / high.price - 1.0),
                "up_days": int(high.index - pivot.index),
                "pullback_days": int(next_low.index - high.index),
                "duration_ratio": _round((next_low.index - high.index) / max(high.index - pivot.index, 1)),
                "status": "current" if next_low.kind == "latest" else "done",
            }
        )
    return rows


def build_current_swing_status(frame: pd.DataFrame, config: SwingRegimeConfig | None = None) -> dict[str, Any]:
    cfg = config or SwingRegimeConfig()
    data = _prepare_frame(frame)
    if data.empty:
        return _unknown_swing_status()

    latest_index = len(data) - 1
    latest = data.iloc[-1]
    latest_close = float(latest["close"])
    pivots = detect_zigzag_pivots(data, threshold=cfg.zigzag_threshold)
    if not pivots:
        return {
            **_unknown_swing_status(),
            "as_of": str(latest["trade_date"]),
            "latest_close": _round(latest_close),
        }

    last = pivots[-1]
    if last.kind == "high":
        anchor = last
        start = _previous_pivot(pivots, len(pivots) - 2, "low")
        if latest_index > last.index and latest_close < last.price:
            phase = "down"
            elapsed_days = latest_index - anchor.index
            drawdown = latest_close / anchor.price - 1.0 if anchor.price else None
            leg_return = drawdown
        else:
            phase = "up"
            anchor = start or last
            elapsed_days = latest_index - anchor.index
            drawdown = 0.0
            leg_return = latest_close / anchor.price - 1.0 if anchor.price else None
    elif last.kind == "low":
        anchor = last
        previous_high = _previous_pivot(pivots, len(pivots) - 2, "high")
        if latest_index > last.index and latest_close > last.price:
            phase = "up"
            elapsed_days = latest_index - anchor.index
            drawdown = 0.0
            leg_return = latest_close / anchor.price - 1.0 if anchor.price else None
        else:
            phase = "down"
            anchor = previous_high or last
            elapsed_days = latest_index - anchor.index
            drawdown = latest_close / anchor.price - 1.0 if anchor.price else None
            leg_return = drawdown
    else:
        return {
            **_unknown_swing_status(),
            "as_of": str(latest["trade_date"]),
            "latest_close": _round(latest_close),
        }

    swings = [row for row in build_swing_rows(data, cfg) if row.get("status") == "done"]
    typical_days = _median_int(
        row.get("up_days") if phase == "up" else row.get("pullback_days")
        for row in swings
    )
    remaining_days = max(int(typical_days) - int(elapsed_days), 0) if typical_days is not None else None
    bias = _swing_bias(phase, drawdown, elapsed_days, typical_days, cfg)
    return {
        "symbol": str(latest.get("symbol") or ""),
        "as_of": str(latest["trade_date"]),
        "latest_close": _round(latest_close),
        "phase": phase,
        "phase_label": "Up leg" if phase == "up" else "Down leg",
        "anchor_date": anchor.trade_date,
        "anchor_price": _round(anchor.price),
        "elapsed_days": int(elapsed_days),
        "typical_days": int(typical_days) if typical_days is not None else None,
        "remaining_days": int(remaining_days) if remaining_days is not None else None,
        "bias": bias,
        "bias_label": _bias_label(bias),
        "drawdown": _round(drawdown),
        "leg_return": _round(leg_return),
    }


def build_regime_feature_frame(frame: pd.DataFrame, config: SwingRegimeConfig | None = None) -> pd.DataFrame:
    cfg = config or SwingRegimeConfig()
    data = _prepare_frame(frame)
    if data.empty:
        return data

    for window in (5, 10, 20):
        data[f"return_{window}d"] = data["close"].pct_change(window)
        data[f"ma{window}"] = data["close"].rolling(window, min_periods=window).mean()
        data[f"distance_ma{window}"] = data["close"] / data[f"ma{window}"] - 1.0

    data["high_20d"] = data["high"].rolling(20, min_periods=1).max()
    data["drawdown_from_20d_high"] = data["close"] / data["high_20d"] - 1.0
    data["volume_ratio_20d"] = data["volume"] / data["volume"].shift(1).rolling(20, min_periods=3).mean()
    day_range = (data["high"] - data["low"]).replace(0, pd.NA)
    data["close_range_position"] = (data["close"] - data["low"]) / day_range

    _add_swing_context(data, cfg)
    _add_forward_labels(data, cfg)

    numeric_columns = [
        "return_5d",
        "return_10d",
        "return_20d",
        "distance_ma5",
        "distance_ma10",
        "distance_ma20",
        "drawdown_from_20d_high",
        "drawdown_from_swing_high",
        "volume_ratio_20d",
        "close_range_position",
        "future_max_rebound",
        "future_max_drawdown",
    ]
    for column in numeric_columns:
        if column in data.columns:
            data[column] = data[column].map(_round_or_none)
    return data


def build_swing_regime_report(frame: pd.DataFrame, config: SwingRegimeConfig | None = None) -> dict[str, Any]:
    cfg = config or SwingRegimeConfig()
    features = build_regime_feature_frame(frame, cfg)
    if features.empty:
        return {"summary": {"rows": 0}, "latest": {}, "swings": []}
    latest = features.iloc[-1].to_dict()
    swings = build_swing_rows(frame, cfg)
    symbol = str(latest.get("symbol") or "")
    summary = {
        "symbol": symbol,
        "as_of": str(latest.get("trade_date") or ""),
        "rows": int(len(features)),
        "latest_close": _round(latest.get("close")),
        "pullback_reversal_count": int(features["pullback_reversal"].sum()),
        "peak_risk_count": int(features["peak_risk"].sum()),
        "trend_break_risk_count": int(features["trend_break_risk"].sum()),
    }
    latest_keys = [
        "trade_date",
        "symbol",
        "close",
        "return_10d",
        "return_20d",
        "distance_ma20",
        "drawdown_from_20d_high",
        "drawdown_from_swing_high",
        "days_since_swing_high",
        "future_max_rebound",
        "future_max_drawdown",
        "pullback_setup",
        "trend_break_setup",
        "pullback_reversal",
        "peak_risk",
        "trend_break_risk",
    ]
    return {
        "summary": summary,
        "latest": {key: _json_value(latest.get(key)) for key in latest_keys if key in latest},
        "swings": swings,
    }


def format_swing_regime_table(report: dict[str, Any]) -> str:
    summary = report.get("summary") or {}
    latest = report.get("latest") or {}
    swings = list(report.get("swings") or [])
    symbol = summary.get("symbol") or "-"
    as_of = summary.get("as_of") or "-"
    lines = [f"{symbol} swing regime as of {as_of}"]
    lines.append(
        "latest close={close} drawdown20={drawdown20} swing_dd={swing_dd} days_since_high={days}".format(
            close=_display(latest.get("close")),
            drawdown20=_pct(latest.get("drawdown_from_20d_high")),
            swing_dd=_pct(latest.get("drawdown_from_swing_high")),
            days=_display(latest.get("days_since_swing_high")),
        )
    )
    lines.append(
        "pullback_reversal_count={pullback} peak_risk_count={peak} trend_break_risk_count={breaks}".format(
            pullback=summary.get("pullback_reversal_count", 0),
            peak=summary.get("peak_risk_count", 0),
            breaks=summary.get("trend_break_risk_count", 0),
        )
    )
    lines.append(
        "latest flags: pullback_setup={pullback} trend_break_setup={trend_break} pullback_reversal_label={label}".format(
            pullback=_display(latest.get("pullback_setup")),
            trend_break=_display(latest.get("trend_break_setup")),
            label=_display(latest.get("pullback_reversal")),
        )
    )
    lines.append("")
    lines.append("| dates | up | drawdown | days | status |")
    lines.append("|---|---:|---:|---:|---|")
    for row in swings:
        dates = f"{row.get('start_date')} -> {row.get('high_date')} -> {row.get('pullback_date')}"
        days = f"{row.get('up_days')}/{row.get('pullback_days')}"
        lines.append(
            f"| {dates} | {_pct(row.get('up_return'))} | {_pct(row.get('drawdown'))} | {days} | {row.get('status')} |"
        )
    return "\n".join(lines)


def format_holding_swing_status(status: dict[str, Any] | None, *, include_bias: bool = True) -> str:
    if not status:
        return "-"
    phase = str(status.get("phase_label") or status.get("phase") or "").strip()
    if not phase or phase.lower() == "unknown":
        return "-"
    elapsed = status.get("elapsed_days")
    typical = status.get("typical_days")
    remaining = status.get("remaining_days")
    parts: list[str] = []
    if elapsed is not None and typical is not None:
        parts.append(f"{phase} {int(elapsed)}/{int(typical)}d")
    elif elapsed is not None:
        parts.append(f"{phase} {int(elapsed)}d")
    else:
        parts.append(phase)
    if remaining is not None:
        parts.append(f"rem ~{int(remaining)}d")
    if include_bias:
        bias_label = str(status.get("bias_label") or "").strip()
        if bias_label:
            parts.append(bias_label)
    drawdown = _num_or_none(status.get("drawdown"))
    if drawdown is not None and drawdown < 0:
        parts.append(f"dd {drawdown * 100:.1f}%")
    return ", ".join(parts)


def _prepare_frame(frame: pd.DataFrame) -> pd.DataFrame:
    data = frame.copy()
    if data.empty:
        return data
    data["trade_date"] = pd.to_datetime(data["trade_date"], errors="coerce")
    if "symbol" not in data.columns:
        data["symbol"] = ""
    for column in ("open", "high", "low", "close", "volume", "turnover"):
        if column not in data.columns:
            data[column] = 0.0
        data[column] = pd.to_numeric(data[column], errors="coerce")
    data = data.dropna(subset=["trade_date", "close"]).sort_values("trade_date").reset_index(drop=True)
    data["trade_date"] = data["trade_date"].dt.date.astype(str)
    return data


def _add_swing_context(data: pd.DataFrame, config: SwingRegimeConfig) -> None:
    pivots = detect_zigzag_pivots(data, threshold=config.zigzag_threshold)
    high_pivots = [pivot for pivot in pivots if pivot.kind == "high"]
    latest_high_price: float | None = None
    latest_high_index: int | None = None
    high_iter = iter(high_pivots)
    next_high = next(high_iter, None)
    drawdowns: list[float | None] = []
    days_since_high: list[int | None] = []
    for row_index, row in data.iterrows():
        while next_high is not None and next_high.index <= row_index:
            latest_high_price = next_high.price
            latest_high_index = next_high.index
            next_high = next(high_iter, None)
        if latest_high_price is None or latest_high_index is None:
            drawdowns.append(None)
            days_since_high.append(None)
        else:
            drawdowns.append(float(row["close"]) / latest_high_price - 1.0)
            days_since_high.append(int(row_index - latest_high_index))
    data["drawdown_from_swing_high"] = drawdowns
    data["days_since_swing_high"] = days_since_high


def _add_forward_labels(data: pd.DataFrame, config: SwingRegimeConfig) -> None:
    max_rebounds: list[float | None] = []
    max_drawdowns: list[float | None] = []
    closes = list(data["close"].astype(float))
    for index, close in enumerate(closes):
        future = closes[index + 1 : index + 1 + config.forward_window_days]
        if not future or close == 0:
            max_rebounds.append(None)
            max_drawdowns.append(None)
            continue
        returns = [price / close - 1.0 for price in future]
        max_rebounds.append(max(returns))
        max_drawdowns.append(min(returns))
    data["future_max_rebound"] = max_rebounds
    data["future_max_drawdown"] = max_drawdowns

    pullback = data["drawdown_from_swing_high"].fillna(0) <= -config.pullback_threshold
    rebound = data["future_max_rebound"].fillna(float("-inf")) >= config.rebound_target
    peak_risk = data["future_max_drawdown"].fillna(0) <= -config.peak_risk_threshold
    trend_break_setup = (
        (data["drawdown_from_swing_high"].fillna(0) <= -config.trend_break_drawdown)
        & (data["days_since_swing_high"].fillna(0) >= config.trend_break_days)
    )
    trend_break = (
        trend_break_setup
        & (data["future_max_rebound"].fillna(float("-inf")) < config.trend_break_rebound)
    )
    data["pullback_setup"] = pullback.astype(int)
    data["trend_break_setup"] = trend_break_setup.astype(int)
    data["pullback_reversal"] = (pullback & rebound).astype(int)
    data["peak_risk"] = peak_risk.astype(int)
    data["trend_break_risk"] = trend_break.astype(int)


def _next_pivot(pivots: list[SwingPivot], start: int, kind: str) -> SwingPivot | None:
    for pivot in pivots[start:]:
        if pivot.kind == kind:
            return pivot
    return None


def _previous_pivot(pivots: list[SwingPivot], start: int, kind: str) -> SwingPivot | None:
    for pivot in reversed(pivots[: start + 1]):
        if pivot.kind == kind:
            return pivot
    return None


def _next_low_or_latest(pivots: list[SwingPivot], start: int) -> SwingPivot | None:
    for pivot in pivots[start:]:
        if pivot.kind in {"low", "latest"}:
            return pivot
    return None


def _dedupe_pivots(pivots: list[tuple[int, str]]) -> list[tuple[int, str]]:
    deduped: list[tuple[int, str]] = []
    for pivot in pivots:
        if deduped and deduped[-1] == pivot:
            continue
        deduped.append(pivot)
    return deduped


def _pivot_from_row(data: pd.DataFrame, index: int, kind: str) -> SwingPivot:
    row = data.iloc[index]
    return SwingPivot(index=index, kind=kind, trade_date=str(row["trade_date"]), price=float(row["close"]))


def _median_int(values: Any) -> int | None:
    cleaned = sorted(int(value) for value in values if value is not None)
    if not cleaned:
        return None
    midpoint = len(cleaned) // 2
    if len(cleaned) % 2:
        return cleaned[midpoint]
    return int(round((cleaned[midpoint - 1] + cleaned[midpoint]) / 2))


def _unknown_swing_status() -> dict[str, Any]:
    return {
        "phase": "unknown",
        "phase_label": "Unknown",
        "elapsed_days": None,
        "typical_days": None,
        "remaining_days": None,
        "bias": "wait",
        "bias_label": "Wait",
        "drawdown": None,
        "leg_return": None,
    }


def _swing_bias(
    phase: str,
    drawdown: float | None,
    elapsed_days: int,
    typical_days: int | None,
    config: SwingRegimeConfig,
) -> str:
    if phase == "up":
        return "long_watch"
    if phase != "down":
        return "wait"
    if drawdown is not None and drawdown <= -config.pullback_threshold:
        if typical_days is None or elapsed_days >= max(1, int(round(typical_days * 0.7))):
            return "reversal_watch"
    return "short_watch"


def _bias_label(bias: str) -> str:
    return {
        "long_watch": "Long watch",
        "short_watch": "Short watch",
        "reversal_watch": "Reversal watch",
        "wait": "Wait",
    }.get(bias, bias)


def _round(value: Any, digits: int = 4) -> float | None:
    numeric = _num_or_none(value)
    return round(numeric, digits) if numeric is not None else None


def _round_or_none(value: Any) -> float | None:
    return _round(value)


def _num_or_none(value: Any) -> float | None:
    if value is None or pd.isna(value):
        return None
    return float(value)


def _json_value(value: Any) -> Any:
    if value is None or pd.isna(value):
        return None
    if isinstance(value, float):
        return _round(value)
    if hasattr(value, "item"):
        return value.item()
    return value


def _pct(value: Any) -> str:
    numeric = _num_or_none(value)
    return "-" if numeric is None else f"{numeric * 100:.1f}%"


def _display(value: Any) -> str:
    numeric = _num_or_none(value)
    if numeric is None:
        return "-"
    if float(numeric).is_integer():
        return str(int(numeric))
    return f"{numeric:.4f}".rstrip("0").rstrip(".")
