from __future__ import annotations

import json
import os
from datetime import date, datetime, timedelta
from typing import Any, Iterable
from urllib import request
from urllib.parse import quote


def enabled() -> bool:
    source = os.getenv("LONGBRIDGE_REALTIME_READ_SOURCE", "clickhouse").strip().lower()
    return source in {"clickhouse", "ch", "auto"}


def fetch_latest_quotes(symbols: Iterable[str]) -> dict[str, dict[str, Any]]:
    symbol_list = _symbols(symbols)
    if not symbol_list or not enabled():
        return {}
    database = _ident(_database())
    sql = f"""
        select symbol, market, snapshot_minute, last_done, prev_close,
               change_percentage, volume, turnover, trade_status, fetched_at
        from {database}.lb_realtime_quotes
        where symbol in {_symbol_tuple(symbol_list)}
        order by symbol, snapshot_minute desc, inserted_at desc
        limit 1 by symbol
    """
    return {str(row.get("symbol")): row for row in _query_json_each_row(sql)}


def fetch_eastmoney_company_names(symbols: Iterable[str]) -> dict[str, str]:
    symbol_list = _symbols(symbols)
    if not symbol_list or not enabled():
        return {}
    database = _ident(_database())
    names: dict[str, str] = {}
    sql = f"""
        select symbol, company_name
        from {database}.lb_eastmoney_f10_profiles
        where symbol in {_symbol_tuple(symbol_list)}
          and company_name is not null
          and company_name != ''
        order by symbol, updated_at desc
        limit 1 by symbol
    """
    try:
        rows = _query_json_each_row(sql)
    except Exception:
        rows = []
    for row in rows:
        symbol = str(row.get("symbol") or "").strip().upper()
        name = str(row.get("company_name") or "").strip()
        if symbol and name and name != symbol:
            names[symbol] = name
    missing = [symbol for symbol in symbol_list if symbol not in names]
    if not missing:
        return names
    try:
        rows = _query_json_each_row(
            f"""
            select symbol, name
            from {database}.lb_eastmoney_stock_boards final
            where symbol in {_symbol_tuple(missing)}
              and name is not null
              and name != ''
            order by symbol
            """
        )
    except Exception:
        rows = []
    for row in rows:
        symbol = str(row.get("symbol") or "").strip().upper()
        name = str(row.get("name") or "").strip()
        if symbol and name and name != symbol:
            names[symbol] = name
    return names


def fetch_latest_capital(symbols: Iterable[str]) -> dict[str, dict[str, Any]]:
    symbol_list = _symbols(symbols)
    if not symbol_list or not enabled():
        return {}
    database = _ident(_database())
    sql = f"""
        select symbol, market, snapshot_minute as capital_minute,
               large_in, large_out, large_net,
               medium_in, medium_out, medium_net,
               small_in, small_out, small_net,
               total_in, total_out, total_net, large_net_ratio, small_net_ratio,
               provider_timestamp, inserted_at as capital_updated_at
        from {database}.lb_realtime_capital
        where symbol in {_symbol_tuple(symbol_list)}
          and snapshot_minute >= now() - interval 7 day
        order by symbol, snapshot_minute desc, inserted_at desc
        limit 1 by symbol
    """
    return {str(row.get("symbol")): row for row in _query_json_each_row(sql)}


def fetch_latest_capital_flow(symbols: Iterable[str]) -> dict[str, dict[str, Any]]:
    symbol_list = _symbols(symbols)
    if not symbol_list or not enabled():
        return {}
    database = _ident(_database())
    sql = f"""
        select symbol, flow_time, inflow
        from {database}.lb_realtime_capital_flow
        where symbol in {_symbol_tuple(symbol_list)}
        order by symbol, flow_time desc, inserted_at desc
        limit 1 by symbol
    """
    return {str(row.get("symbol")): row for row in _query_json_each_row(sql)}


def fetch_latest_capital_snapshot(symbol: str) -> dict[str, Any] | None:
    normalized = symbol.strip().upper()
    capital = fetch_latest_capital([normalized]).get(normalized)
    if not capital:
        return None
    flow = fetch_latest_capital_flow([normalized]).get(normalized) or {}
    return {**capital, **flow}


def fetch_daily_capital_features(
    symbols: Iterable[str],
    *,
    end_date: date | str | None = None,
    lookback_days: int = 20,
) -> dict[str, dict[str, Any]]:
    symbol_list = _symbols(symbols)
    if not symbol_list or not enabled():
        return {}
    database = _ident(_database())
    if end_date is None:
        anchor_expr = "today()"
    else:
        anchor = end_date.isoformat() if hasattr(end_date, "isoformat") else str(end_date)
        anchor_expr = f"toDate('{anchor}')"
    days = max(20, int(lookback_days))
    rows = _query_json_each_row(
        f"""
        with {anchor_expr} as anchor_date
        select symbol,
               sumIf(total_net, snapshot_date >= anchor_date - interval 4 day) as capital_net_5d,
               sumIf(total_net, snapshot_date >= anchor_date - interval 9 day) as capital_net_10d,
               sumIf(total_net, snapshot_date >= anchor_date - interval 19 day) as capital_net_20d,
               sumIf(total_net, snapshot_date >= anchor_date - interval 59 day) as capital_net_60d,
               sumIf(large_net, snapshot_date >= anchor_date - interval 4 day) as large_capital_net_5d,
               sumIf(large_net, snapshot_date >= anchor_date - interval 9 day) as large_capital_net_10d,
               sumIf(large_net, snapshot_date >= anchor_date - interval 19 day) as large_capital_net_20d,
               sumIf(large_net, snapshot_date >= anchor_date - interval 59 day) as large_capital_net_60d,
               countIf(snapshot_date >= anchor_date - interval 4 day) as capital_days_5d,
               countIf(snapshot_date >= anchor_date - interval 9 day) as capital_days_10d,
               countIf(snapshot_date >= anchor_date - interval 19 day) as capital_days_20d,
               countIf(snapshot_date >= anchor_date - interval 59 day) as capital_days_60d,
               max(snapshot_date) as capital_latest_date
        from (
          select symbol,
                 toDate(snapshot_minute) as snapshot_date,
                 argMax(total_net, tuple(snapshot_minute, inserted_at)) as total_net,
                 argMax(large_net, tuple(snapshot_minute, inserted_at)) as large_net
          from {database}.lb_realtime_capital
          where symbol in {_symbol_tuple(symbol_list)}
            and snapshot_minute >= toDateTime(anchor_date - interval {days + 5} day)
            and snapshot_minute < toDateTime(anchor_date + interval 1 day)
          group by symbol, snapshot_date
        )
        group by symbol
        """
    )
    return {
        str(row.get("symbol") or "").strip().upper(): {
            "capital_net_5d": _num_or_none(row.get("capital_net_5d")),
            "capital_net_10d": _num_or_none(row.get("capital_net_10d")),
            "capital_net_20d": _num_or_none(row.get("capital_net_20d")),
            "capital_net_60d": _num_or_none(row.get("capital_net_60d")),
            "large_capital_net_5d": _num_or_none(row.get("large_capital_net_5d")),
            "large_capital_net_10d": _num_or_none(row.get("large_capital_net_10d")),
            "large_capital_net_20d": _num_or_none(row.get("large_capital_net_20d")),
            "large_capital_net_60d": _num_or_none(row.get("large_capital_net_60d")),
            "capital_days_5d": int(row.get("capital_days_5d") or 0),
            "capital_days_10d": int(row.get("capital_days_10d") or 0),
            "capital_days_20d": int(row.get("capital_days_20d") or 0),
            "capital_days_60d": int(row.get("capital_days_60d") or 0),
            "capital_latest_date": row.get("capital_latest_date"),
        }
        for row in rows
        if row.get("symbol")
    }


def fetch_realtime_signal_rows(
    symbols: Iterable[str],
    *,
    now: datetime,
    max_quote_age_minutes: int,
) -> dict[str, dict[str, Any]]:
    symbol_list = _symbols(symbols)
    if not symbol_list or not enabled():
        return {}
    database = _ident(_database())
    min_quote_time = _dt(now - timedelta(minutes=max_quote_age_minutes))
    now_text = _dt(now)
    quote_rows = _query_json_each_row(
        f"""
        select symbol, market, snapshot_minute, last_done, prev_close, open, high, low,
               change_percentage, volume, turnover, trade_status
        from {database}.lb_realtime_quotes
        where symbol in {_symbol_tuple(symbol_list)}
          and snapshot_minute >= parseDateTime64BestEffort('{min_quote_time}', 3, 'Asia/Shanghai')
        order by symbol, snapshot_minute desc, inserted_at desc
        limit 1 by symbol
        """
    )
    capital_rows = _query_json_each_row(
        f"""
        select symbol, snapshot_minute as capital_minute,
               large_in, large_out, large_net, medium_net, small_net,
               total_in, total_out, total_net, large_net_ratio, small_net_ratio
        from {database}.lb_realtime_capital
        where symbol in {_symbol_tuple(symbol_list)}
        order by symbol, snapshot_minute desc, inserted_at desc
        limit 1 by symbol
        """
    )
    flow_rows = _query_json_each_row(
        f"""
        select symbol,
               sumIf(inflow, flow_time >= parseDateTime64BestEffort('{now_text}', 3, 'Asia/Shanghai') - interval 15 minute) as flow_15m,
               sumIf(inflow, flow_time >= parseDateTime64BestEffort('{now_text}', 3, 'Asia/Shanghai') - interval 30 minute) as flow_30m,
               sum(inflow) as flow_today,
               count() as flow_points,
               max(flow_time) as last_flow_time
        from {database}.lb_realtime_capital_flow
        where symbol in {_symbol_tuple(symbol_list)}
          and flow_time >= parseDateTime64BestEffort('{now_text}', 3, 'Asia/Shanghai') - interval 1 day
        group by symbol
        """
    )
    capital_by_symbol = {str(row.get("symbol")): row for row in capital_rows}
    flow_by_symbol = {str(row.get("symbol")): row for row in flow_rows}
    out: dict[str, dict[str, Any]] = {}
    for quote in quote_rows:
        symbol = str(quote.get("symbol") or "")
        if not symbol:
            continue
        out[symbol] = {
            "quote_minute": quote.get("snapshot_minute"),
            "snapshot_minute": quote.get("snapshot_minute"),
            "symbol": symbol,
            "market": quote.get("market"),
            "last": _num(quote.get("last_done")),
            "prev_close": _num(quote.get("prev_close")),
            "open": _num(quote.get("open")),
            "high": _num(quote.get("high")),
            "low": _num(quote.get("low")),
            "change_pct": _change_pct(
                quote.get("change_percentage"),
                quote.get("last_done"),
                quote.get("prev_close"),
            ),
            "volume": _num(quote.get("volume")),
            "turnover": _num(quote.get("turnover")),
            "trade_status": quote.get("trade_status"),
            **_capital_signal_fields(capital_by_symbol.get(symbol) or {}),
            **_flow_signal_fields(flow_by_symbol.get(symbol) or {}),
        }
    return out


def fetch_holding_capital_rows(
    symbols: Iterable[str],
    *,
    now: datetime,
    max_quote_age_minutes: int = 25,
) -> list[dict[str, Any]]:
    realtime_rows = fetch_realtime_signal_rows(symbols, now=now, max_quote_age_minutes=max_quote_age_minutes)
    output: list[dict[str, Any]] = []
    for symbol in _symbols(symbols):
        row = realtime_rows.get(symbol)
        if not row:
            continue
        last = _num(row.get("last"))
        prev_close = _num(row.get("prev_close"))
        open_price = _num(row.get("open"))
        output.append(
            {
                "symbol": symbol,
                "market": str(row.get("market") or symbol.rsplit(".", 1)[-1]).lower(),
                "name": symbol,
                "quoteMinute": row.get("snapshot_minute"),
                "lastDone": last,
                "prevClose": prev_close,
                "open": open_price,
                "high": _num(row.get("high")),
                "low": _num(row.get("low")),
                "volume": _num(row.get("volume")),
                "turnover": _num(row.get("turnover")),
                "tradeStatus": row.get("trade_status"),
                "changePct": round((last - prev_close) / prev_close * 100, 2) if prev_close else 0.0,
                "fromOpenPct": round((last - open_price) / open_price * 100, 2) if open_price else 0.0,
                "capitalMinute": row.get("capital_minute"),
                "largeNet": _num(row.get("large_net")),
                "mediumNet": _num(row.get("medium_net")),
                "smallNet": _num(row.get("small_net")),
                "totalNet": _num(row.get("total_net")),
                "totalIn": _num(row.get("total_in")),
                "totalOut": _num(row.get("total_out")),
                "largeNetRatio": _num(row.get("large_net_ratio")),
                "smallNetRatio": _num(row.get("small_net_ratio")),
                "lastFlowTime": row.get("last_flow_time"),
                "flow15m": _num(row.get("flow_15m")),
                "flow30m": _num(row.get("flow_30m")),
                "flowToday": _num(row.get("flow_today")),
                "flowPoints": row.get("flow_points"),
                "stale": False,
            }
        )
    return output


def fetch_top_capital_symbols(market: str, *, limit: int) -> list[str]:
    database = _ident(_database())
    normalized_market = market.strip().lower().replace("'", "")
    rows = _query_json_each_row(
        f"""
        select symbol
        from (
          select symbol, market, total_net
          from {database}.lb_realtime_capital
          where market = '{normalized_market}'
          order by symbol, snapshot_minute desc, inserted_at desc
          limit 1 by symbol
        )
        order by total_net desc
        limit {int(limit)}
        """
    )
    return [str(row.get("symbol") or "").strip().upper() for row in rows if row.get("symbol")]


def fetch_latest_profit_predictions(symbols: Iterable[str], *, model_run_id: str, market: str) -> dict[str, dict[str, Any]]:
    symbol_list = _symbols(symbols)
    if not symbol_list or not model_run_id or not enabled():
        return {}
    database = _ident(_database())
    model = _sql_string(model_run_id)
    market_key = _sql_string(market.lower())
    rows = _query_json_each_row(
        f"""
        select symbol,
               market,
               name,
               profit_probability,
               expected_return,
               horizon_minutes,
               target_return,
               entry_price,
               risk_score,
               decision,
               feature_snapshot,
               predicted_at
        from {database}.lb_realtime_profit_predictions
        where model_run_id = {model}
          and market = {market_key}
          and symbol in {_symbol_tuple(symbol_list)}
        order by symbol, predicted_at desc, profit_probability desc, inserted_at desc
        limit 1 by symbol
        """
    )
    return {
        str(row.get("symbol") or "").strip().upper(): {
            "symbol": str(row.get("symbol") or "").strip().upper(),
            "market": row.get("market"),
            "name": row.get("name"),
            "profit_probability": _num_or_none(row.get("profit_probability")),
            "expected_return": _num_or_none(row.get("expected_return")),
            "horizon_minutes": row.get("horizon_minutes"),
            "target_return": _num_or_none(row.get("target_return")),
            "entry_price": _num_or_none(row.get("entry_price")),
            "risk_score": _num_or_none(row.get("risk_score")),
            "decision": row.get("decision"),
            "feature_snapshot": _json_dict(row.get("feature_snapshot")),
            "predicted_at": row.get("predicted_at"),
        }
        for row in rows
        if row.get("symbol")
    }


def ensure_realtime_profit_training_samples() -> None:
    database = _ident(_database())
    _execute(
        f"""
        create table if not exists {database}.lb_realtime_profit_training_samples (
          sample_date Date,
          market LowCardinality(String),
          profile LowCardinality(String),
          target_direction LowCardinality(String),
          symbol String,
          name String,
          sample_time DateTime64(3, 'Asia/Shanghai'),
          last_done Float64,
          target_return Float64,
          horizon_minutes UInt16,
          change_percentage Float64,
          return_1m Float64,
          return_5m Float64,
          return_15m Float64,
          volatility_5m Float64,
          volatility_15m Float64,
          volume_ratio_5m Float64,
          turnover_ratio_5m Float64,
          large_net_ratio Float64,
          small_net_ratio Float64,
          total_net_ratio Float64,
          capital_flow_5m Float64,
          capital_flow_slope_15m Float64,
          depth_imbalance Float64,
          bid_ask_volume_ratio Float64,
          trade_buy_ratio_5m Float64,
          trade_volume_5m Float64,
          intraday_position Float64,
          price_to_avg_15m Float64,
          down_momentum_5m Float64,
          down_momentum_15m Float64,
          near_day_low Float64,
          short_selling_ratio Float64,
          short_rate Float64,
          short_balance_ratio Float64,
          days_to_cover Float64,
          negative_sentiment_score Float64,
          bearish_event_strength Float64,
          future_high Float64,
          future_low Float64,
          future_price Float64,
          future_max_return Float64,
          future_max_drawdown Float64,
          future_return Float64,
          target_profit UInt8,
          source LowCardinality(String),
          generated_at DateTime64(3, 'Asia/Shanghai'),
          inserted_at DateTime64(3, 'Asia/Shanghai') default now64(3)
        )
        engine = ReplacingMergeTree(inserted_at)
        partition by toYYYYMM(sample_date)
        order by (market, profile, target_direction, sample_date, symbol, sample_time)
        ttl toDateTime(sample_date) + interval 365 day
        """
    )


def fetch_realtime_profit_training_samples(
    *,
    market: str,
    profile: str,
    target_direction: str,
    lookback_days: int,
    max_rows: int,
) -> list[dict[str, Any]]:
    if not enabled():
        return []
    ensure_realtime_profit_training_samples()
    database = _ident(_database())
    rows = _query_json_each_row(
        f"""
        select symbol, market, name, sample_time as snapshot_minute, last_done,
               change_percentage, return_1m, return_5m, return_15m,
               volatility_5m, volatility_15m, volume_ratio_5m, turnover_ratio_5m,
               large_net_ratio, small_net_ratio, total_net_ratio,
               capital_flow_5m, capital_flow_slope_15m, depth_imbalance,
               bid_ask_volume_ratio, trade_buy_ratio_5m, trade_volume_5m,
               intraday_position, price_to_avg_15m, down_momentum_5m,
               down_momentum_15m, near_day_low, short_selling_ratio, short_rate,
               short_balance_ratio, days_to_cover, negative_sentiment_score,
               bearish_event_strength, future_high, future_low, future_price,
               future_max_return, future_max_drawdown, future_return, target_profit
        from {database}.lb_realtime_profit_training_samples final
        where market = {_sql_string(market.lower())}
          and profile = {_sql_string((profile or "realtime").lower())}
          and target_direction = {_sql_string((target_direction or "long").lower())}
          and sample_date >= today() - interval {max(1, int(lookback_days))} day
        order by sample_time desc, symbol
        limit {max(1, int(max_rows))}
        """
    )
    return rows


def materialize_realtime_profit_training_samples(
    *,
    market: str,
    profile: str,
    target_direction: str,
    sample_date: str,
    horizon_minutes: int,
    target_return: float,
    sample_interval_minutes: int = 5,
    min_turnover: float = 0.0,
    rank_limit: int = 0,
    horizon_calendar_hours: int = 120,
    source: str = "full_market_5m",
) -> None:
    ensure_realtime_profit_training_samples()
    database = _ident(_database())
    interval = max(1, int(sample_interval_minutes))
    rank_filter = f"and turnover_rank <= {int(rank_limit)}" if int(rank_limit) > 0 else ""
    target_expr = (
        f"if(future_max_drawdown <= -{float(target_return)}, 1, 0)"
        if (target_direction or "long").lower() == "short"
        else f"if(future_max_return >= {float(target_return)}, 1, 0)"
    )
    _execute(
        f"""
        insert into {database}.lb_realtime_profit_training_samples
        with quote_dedup as (
          select symbol, market, snapshot_minute,
                 argMax(last_done, inserted_at) as last_done,
                 argMax(prev_close, inserted_at) as prev_close,
                 argMax(open, inserted_at) as open,
                 argMax(high, inserted_at) as high,
                 argMax(low, inserted_at) as low,
                 argMax(change_percentage, inserted_at) as change_percentage,
                 argMax(volume, inserted_at) as volume,
                 argMax(turnover, inserted_at) as turnover
          from {database}.lb_realtime_quotes
          where market = {_sql_string(market.lower())}
            and snapshot_minute >= toDateTime64({_sql_string(sample_date)}, 3, 'Asia/Shanghai')
            and snapshot_minute < toDateTime64({_sql_string(sample_date)}, 3, 'Asia/Shanghai') + interval 1 day
            and last_done > 0
          group by symbol, market, snapshot_minute
        ),
        quote_window as (
          select q.*,
                 coalesce(q.last_done / nullIf(lagInFrame(q.last_done, 1) over w, 0) - 1, 0) as return_1m,
                 coalesce(q.last_done / nullIf(lagInFrame(q.last_done, 5) over w, 0) - 1, 0) as return_5m,
                 coalesce(q.last_done / nullIf(lagInFrame(q.last_done, 15) over w, 0) - 1, 0) as return_15m,
                 coalesce(stddevPop(q.last_done / nullIf(q.prev_close, 0) - 1)
                   over (partition by q.symbol order by q.snapshot_minute rows between 5 preceding and current row), 0) as volatility_5m,
                 coalesce(stddevPop(q.last_done / nullIf(q.prev_close, 0) - 1)
                   over (partition by q.symbol order by q.snapshot_minute rows between 15 preceding and current row), 0) as volatility_15m,
                 greatest(q.volume - coalesce(lagInFrame(q.volume, 1) over w, q.volume), 0) as minute_volume,
                 greatest(q.turnover - coalesce(lagInFrame(q.turnover, 1) over w, q.turnover), 0) as minute_turnover,
                 coalesce(q.last_done / nullIf(avg(q.last_done)
                   over (partition by q.symbol order by q.snapshot_minute rows between 15 preceding and current row), 0) - 1, 0) as price_to_avg_15m
          from quote_dedup q
          window w as (partition by q.symbol order by q.snapshot_minute rows between 15 preceding and current row)
        ),
        quote_features as (
          select qw.*,
                 coalesce(minute_volume / nullIf(avg(minute_volume)
                   over (partition by symbol order by snapshot_minute rows between 5 preceding and current row), 0), 1) as volume_ratio_5m,
                 coalesce(minute_turnover / nullIf(avg(minute_turnover)
                   over (partition by symbol order by snapshot_minute rows between 5 preceding and current row), 0), 1) as turnover_ratio_5m,
                 row_number() over (partition by snapshot_minute order by turnover desc) as turnover_rank
          from quote_window qw
        ),
        sample_rows as (
          select *
          from quote_features
          where toMinute(snapshot_minute) % {interval} = 0
            and coalesce(turnover, 0) >= {max(0.0, float(min_turnover))}
            {rank_filter}
        ),
        capital as (
          select symbol,
                 toStartOfInterval(snapshot_minute, interval {interval} minute) as capital_bucket,
                 argMax(large_net, inserted_at) as large_net,
                 argMax(small_net, inserted_at) as small_net,
                 argMax(total_net, inserted_at) as total_net,
                 argMax(total_in, inserted_at) as total_in,
                 argMax(total_out, inserted_at) as total_out,
                 argMax(large_net_ratio, inserted_at) as large_net_ratio,
                 argMax(small_net_ratio, inserted_at) as small_net_ratio
          from {database}.lb_realtime_capital
          where market = {_sql_string(market.lower())}
            and snapshot_minute >= toDateTime64({_sql_string(sample_date)}, 3, 'Asia/Shanghai')
            and snapshot_minute < toDateTime64({_sql_string(sample_date)}, 3, 'Asia/Shanghai') + interval 1 day
          group by symbol, capital_bucket
        ),
        future_quotes as (
          select symbol, snapshot_minute, argMax(last_done, inserted_at) as last_done
          from {database}.lb_realtime_quotes
          where market = {_sql_string(market.lower())}
            and snapshot_minute > toDateTime64({_sql_string(sample_date)}, 3, 'Asia/Shanghai')
            and snapshot_minute <= toDateTime64({_sql_string(sample_date)}, 3, 'Asia/Shanghai') + interval {max(1, int(horizon_calendar_hours))} hour
            and last_done > 0
          group by symbol, snapshot_minute
        ),
        labeled as (
          select s.*,
                 max(f.last_done) as future_high,
                 min(f.last_done) as future_low,
                 argMax(f.last_done, f.snapshot_minute) as future_price
          from sample_rows s
          inner join future_quotes f on f.symbol = s.symbol
            and f.snapshot_minute > s.snapshot_minute
            and f.snapshot_minute <= s.snapshot_minute + interval {max(1, int(horizon_calendar_hours))} hour
          group by s.symbol, s.market, s.snapshot_minute, s.last_done, s.prev_close, s.open, s.high, s.low,
                   s.change_percentage, s.volume, s.turnover, s.return_1m, s.return_5m, s.return_15m,
                   s.volatility_5m, s.volatility_15m, s.minute_volume, s.minute_turnover,
                   s.price_to_avg_15m, s.volume_ratio_5m, s.turnover_ratio_5m, s.turnover_rank
        ),
        final_rows as (
          select toDate({_sql_string(sample_date)}) as sample_date,
                 {_sql_string(market.lower())} as market,
                 {_sql_string((profile or "realtime").lower())} as profile,
                 {_sql_string((target_direction or "long").lower())} as target_direction,
                 l.symbol as symbol,
                 l.symbol as name,
                 l.snapshot_minute as sample_time,
                 l.last_done as last_done,
                 {float(target_return)} as target_return,
                 {int(horizon_minutes)} as horizon_minutes,
                 coalesce(l.change_percentage, if(l.prev_close > 0, (l.last_done / l.prev_close - 1) * 100, 0)) as change_percentage,
                 l.return_1m, l.return_5m, l.return_15m, l.volatility_5m, l.volatility_15m,
                 l.volume_ratio_5m, l.turnover_ratio_5m,
                 coalesce(c.large_net_ratio, c.large_net / nullIf(abs(l.turnover), 0), 0) as large_net_ratio,
                 coalesce(c.small_net_ratio, c.small_net / nullIf(abs(l.turnover), 0), 0) as small_net_ratio,
                 coalesce(c.total_net / nullIf(c.total_in + c.total_out, 0), c.total_net / nullIf(abs(l.turnover), 0), 0) as total_net_ratio,
                 0.0 as capital_flow_5m, 0.0 as capital_flow_slope_15m, 0.0 as depth_imbalance,
                 1.0 as bid_ask_volume_ratio, 0.5 as trade_buy_ratio_5m, 0.0 as trade_volume_5m,
                 coalesce((l.last_done - l.low) / nullIf(l.high - l.low, 0), 0.5) as intraday_position,
                 l.price_to_avg_15m,
                 greatest(-l.return_5m, 0) as down_momentum_5m,
                 greatest(-l.return_15m, 0) as down_momentum_15m,
                 coalesce(1 - (l.last_done - l.low) / nullIf(l.high - l.low, 0), 0.5) as near_day_low,
                 0.0 as short_selling_ratio, 0.0 as short_rate, 0.0 as short_balance_ratio,
                 0.0 as days_to_cover, 0.0 as negative_sentiment_score, 0.0 as bearish_event_strength,
                 l.future_high, l.future_low, l.future_price,
                 l.future_high / nullIf(l.last_done, 0) - 1 as future_max_return,
                 l.future_low / nullIf(l.last_done, 0) - 1 as future_max_drawdown,
                 l.future_price / nullIf(l.last_done, 0) - 1 as future_return,
                 {target_expr} as target_profit,
                 {_sql_string(source)} as source,
                 now64(3, 'Asia/Shanghai') as generated_at
          from labeled l
          left join capital c on c.symbol = l.symbol
            and c.capital_bucket = toStartOfInterval(l.snapshot_minute, interval {interval} minute)
        )
        select *
        from final_rows
        where isFinite(future_max_return)
          and isFinite(future_max_drawdown)
          and isFinite(future_return)
        """
    )


def ensure_realtime_profit_model_runs() -> None:
    database = _ident(_database())
    _execute(
        f"""
        create table if not exists {database}.lb_realtime_profit_model_runs (
          model_run_id String,
          market LowCardinality(String),
          profile LowCardinality(String),
          model_type String,
          horizon_minutes UInt16,
          target_return Float64,
          model_path String,
          train_count UInt32,
          validation_count UInt32,
          metrics String,
          feature_names Array(String),
          trained_at DateTime64(6, 'Asia/Shanghai'),
          inserted_at DateTime64(3, 'Asia/Shanghai') default now64(3)
        )
        engine = ReplacingMergeTree(inserted_at)
        partition by toYYYYMM(trained_at)
        order by (market, profile, model_run_id)
        """
    )


def insert_realtime_profit_model_run(row: dict[str, Any]) -> None:
    ensure_realtime_profit_model_runs()
    database = _ident(_database())
    metrics = row.get("metrics")
    normalized = {
        "model_run_id": str(row.get("model_run_id") or ""),
        "market": str(row.get("market") or "").lower(),
        "profile": str(row.get("profile") or _profile_from_metrics(metrics)),
        "model_type": str(row.get("model_type") or ""),
        "horizon_minutes": int(_num(row.get("horizon_minutes"))),
        "target_return": float(_num(row.get("target_return"))),
        "model_path": str(row.get("model_path") or ""),
        "train_count": int(_num(row.get("train_count"))),
        "validation_count": int(_num(row.get("validation_count"))),
        "metrics": _payload_text(metrics),
        "feature_names": [str(item) for item in (row.get("feature_names") or [])],
        "trained_at": _date_time_text(row.get("trained_at") or datetime.now().astimezone()),
    }
    _insert_json_each_row(f"{database}.lb_realtime_profit_model_runs", [normalized])


def fetch_latest_realtime_profit_model_run(*, market: str, profile: str = "realtime") -> dict[str, Any] | None:
    ensure_realtime_profit_model_runs()
    database = _ident(_database())
    rows = _query_json_each_row(
        f"""
        select model_run_id, model_path, market, profile, model_type, horizon_minutes,
               target_return, train_count, validation_count, metrics, feature_names, trained_at
        from {database}.lb_realtime_profit_model_runs final
        where market = {_sql_string(market.lower())}
          and profile = {_sql_string((profile or "realtime").lower())}
        order by trained_at desc, inserted_at desc
        limit 1
        """
    )
    if not rows:
        return None
    row = dict(rows[0])
    row["metrics"] = _json_dict(row.get("metrics"))
    return row


def fetch_latest_realtime_profit_model_runs(*, market: str = "all", profile: str | None = None, limit: int = 20) -> list[dict[str, Any]]:
    ensure_realtime_profit_model_runs()
    database = _ident(_database())
    filters = []
    if market.lower() != "all":
        filters.append(f"market = {_sql_string(market.lower())}")
    if profile:
        filters.append(f"profile = {_sql_string(profile.lower())}")
    where = "where " + " and ".join(filters) if filters else ""
    rows = _query_json_each_row(
        f"""
        select *
        from (
          select *, row_number() over (partition by market, profile order by trained_at desc, inserted_at desc) as rn
          from {database}.lb_realtime_profit_model_runs final
          {where}
        )
        where rn = 1
        order by trained_at desc
        limit {int(limit)}
        """
    )
    for row in rows:
        row["metrics"] = _json_dict(row.get("metrics"))
    return rows


def fetch_latest_profit_prediction_rows(*, model_run_id: str, market: str, limit: int) -> list[dict[str, Any]]:
    if not model_run_id or not enabled():
        return []
    database = _ident(_database())
    model = _sql_string(model_run_id)
    market_key = _sql_string(market.lower())
    rows = _query_json_each_row(
        f"""
        with (
          select max(predicted_at)
          from {database}.lb_realtime_profit_predictions
          where model_run_id = {model}
            and market = {market_key}
        ) as latest_predicted_at
        select symbol,
               market,
               name,
               predicted_at,
               entry_price,
               profit_probability,
               expected_return,
               risk_score,
               decision,
               horizon_minutes,
               target_return,
               validation_due_at,
               feature_snapshot
        from {database}.lb_realtime_profit_predictions
        where model_run_id = {model}
          and market = {market_key}
          and predicted_at = latest_predicted_at
        order by coalesce(profit_probability, 0) desc, coalesce(risk_score, 999) asc, symbol
        limit {int(limit)}
        """
    )
    return [_profit_prediction_row(row) for row in rows]


def ensure_realtime_profit_validation() -> None:
    database = _ident(_database())
    _execute(
        f"""
        create table if not exists {database}.lb_realtime_profit_validation (
          model_run_id String,
          predicted_at DateTime64(3, 'Asia/Shanghai'),
          symbol LowCardinality(String),
          market LowCardinality(String),
          name String,
          horizon_minutes UInt16,
          target_return Nullable(Float64),
          entry_price Nullable(Float64),
          profit_probability Nullable(Float64),
          expected_return Nullable(Float64),
          risk_score Nullable(Float64),
          decision LowCardinality(String),
          feature_snapshot String,
          validation_due_at Nullable(DateTime64(3, 'Asia/Shanghai')),
          actual_high Nullable(Float64),
          actual_low Nullable(Float64),
          actual_return Nullable(Float64),
          actual_max_drawdown Nullable(Float64),
          actual_hit Nullable(UInt8),
          actual_observed_until Nullable(DateTime64(3, 'Asia/Shanghai')),
          actual_filled_at Nullable(DateTime64(3, 'Asia/Shanghai')),
          inserted_at DateTime64(3, 'Asia/Shanghai') default now64(3)
        )
        engine = ReplacingMergeTree(inserted_at)
        partition by toYYYYMM(predicted_at)
        order by (market, model_run_id, symbol, predicted_at, horizon_minutes)
        ttl toDateTime(predicted_at) + interval 180 day
        """
    )


def insert_realtime_profit_validation_rows(rows: list[dict[str, Any]]) -> None:
    if not rows:
        return
    ensure_realtime_profit_validation()
    database = _ident(_database())
    documents = []
    for row in rows:
        documents.append(
            {
                "model_run_id": str(row.get("model_run_id") or ""),
                "predicted_at": _date_time_text(row.get("predicted_at")),
                "symbol": str(row.get("symbol") or "").strip().upper(),
                "market": str(row.get("market") or "").lower(),
                "name": str(row.get("name") or ""),
                "horizon_minutes": int(_num(row.get("horizon_minutes"))),
                "target_return": _num_or_none(row.get("target_return")),
                "entry_price": _num_or_none(row.get("entry_price")),
                "profit_probability": _num_or_none(row.get("profit_probability")),
                "expected_return": _num_or_none(row.get("expected_return")),
                "risk_score": _num_or_none(row.get("risk_score")),
                "decision": str(row.get("decision") or ""),
                "feature_snapshot": _payload_text(row.get("feature_snapshot")),
                "validation_due_at": _date_time_text(row.get("validation_due_at")) if row.get("validation_due_at") else None,
            }
        )
    _insert_json_each_row(f"{database}.lb_realtime_profit_validation", documents)


def fetch_realtime_profit_validation_series(
    symbols: Iterable[str],
    *,
    model_run_id: str,
    market: str,
    limit: int = 360,
    lookback_days: int = 3,
) -> list[dict[str, Any]]:
    symbol_list = _symbols(symbols)
    if not symbol_list or not model_run_id or not enabled():
        return []
    ensure_realtime_profit_validation()
    database = _ident(_database())
    rows = _query_json_each_row(
        f"""
        select model_run_id,
               predicted_at,
               symbol,
               market,
               name,
               horizon_minutes,
               target_return,
               entry_price,
               profit_probability,
               expected_return,
               risk_score,
               decision,
               validation_due_at,
               actual_return,
               actual_hit,
               actual_high,
               actual_low,
               actual_observed_until,
               cast(null, 'Nullable(Float64)') as actual_price
        from {database}.lb_realtime_profit_validation final
        where model_run_id = {_sql_string(model_run_id)}
          and market = {_sql_string(market.lower())}
          and symbol in {_symbol_tuple(symbol_list)}
          and predicted_at >= now64(3, 'Asia/Shanghai') - interval {max(1, int(lookback_days))} day
        order by predicted_at desc, inserted_at desc
        limit {max(1, int(limit))}
        """
    )
    return [_profit_validation_row(row) for row in rows]


def fetch_latest_us_fast_profit_prediction_rows(*, model_run_id: str, limit: int) -> list[dict[str, Any]]:
    if not model_run_id or not enabled():
        return []
    database = _ident(_database())
    model = _sql_string(model_run_id)
    rows = _query_json_each_row(
        f"""
        with (
          select max(predicted_at)
          from {database}.lb_us_fast_profit_predictions
          where model_run_id = {model}
        ) as latest_predicted_at
        select symbol,
               market,
               name,
               predicted_at,
               entry_price,
               profit_probability,
               expected_return,
               risk_score,
               decision,
               horizon_minutes,
               target_return,
               validation_due_at,
               feature_snapshot
        from {database}.lb_us_fast_profit_predictions
        where model_run_id = {model}
          and predicted_at = latest_predicted_at
        order by coalesce(profit_probability, 0) desc, coalesce(risk_score, 999) asc, symbol
        limit {int(limit)}
        """
    )
    return [_profit_prediction_row(row) for row in rows]


def fetch_realtime_profit_outcome_review(
    *,
    market: str = "all",
    profile: str = "all",
    lookback_days: int = 30,
    min_probability: float = 0.70,
    target_return: float = 0.02,
    limit: int = 100,
) -> list[dict[str, Any]]:
    if not enabled():
        return []
    database = _ident(_database())
    market_filter = "" if market.lower() == "all" else f"and p.market = {_sql_string(market.lower())}"
    profile_filter = "" if profile.lower() == "all" else f"and m.profile = {_sql_string(profile.lower())}"
    target = float(target_return)
    rows = _query_json_each_row(
        f"""
        with predictions as (
          select p.model_run_id,
                 m.profile,
                 p.predicted_at,
                 p.symbol,
                 p.market,
                 p.name,
                 p.horizon_minutes,
                 p.target_return,
                 p.entry_price,
                 p.profit_probability,
                 p.expected_return,
                 p.risk_score,
                 p.decision,
                 p.validation_due_at
          from {database}.lb_realtime_profit_predictions p
          inner join {database}.lb_realtime_profit_model_runs m on m.model_run_id = p.model_run_id
          where p.predicted_at >= now64(3, 'Asia/Shanghai') - interval {max(1, int(lookback_days))} day
            and p.validation_due_at <= now64(3, 'Asia/Shanghai')
            and p.target_return >= {target}
            and p.entry_price > 0
            and p.profit_probability >= {float(min_probability)}
            and p.decision not in ('avoid', 'avoid_short')
            {market_filter}
            {profile_filter}
          union all
          select p.model_run_id,
                 m.profile,
                 p.predicted_at,
                 p.symbol,
                 p.market,
                 p.name,
                 p.horizon_minutes,
                 p.target_return,
                 p.entry_price,
                 p.profit_probability,
                 p.expected_return,
                 p.risk_score,
                 p.decision,
                 p.validation_due_at
          from {database}.lb_us_fast_profit_predictions p
          inner join {database}.lb_realtime_profit_model_runs m on m.model_run_id = p.model_run_id
          where p.predicted_at >= now64(3, 'Asia/Shanghai') - interval {max(1, int(lookback_days))} day
            and p.validation_due_at <= now64(3, 'Asia/Shanghai')
            and p.target_return >= {target}
            and p.entry_price > 0
            and p.profit_probability >= {float(min_probability)}
            and p.decision not in ('avoid', 'avoid_short')
            {market_filter}
            {profile_filter}
        ),
        latest_per_symbol_day as (
          select *,
                 row_number() over (
                   partition by symbol, toDate(predicted_at), model_run_id
                   order by profit_probability desc, predicted_at desc
                 ) as rn
          from predictions
        ),
        selected as (
          select *
          from latest_per_symbol_day
          where rn = 1
          order by predicted_at desc, profit_probability desc
          limit {max(1, int(limit))}
        ),
        quote_dedup as (
          select symbol, snapshot_minute, argMax(last_done, inserted_at) as last_done
          from {database}.lb_realtime_quotes q
          where symbol in (select symbol from selected)
            and snapshot_minute >= (select min(predicted_at) from selected)
            and snapshot_minute <= (select max(validation_due_at) from selected) + interval 1 hour
            and q.last_done > 0
          group by symbol, snapshot_minute
        )
        select s.model_run_id,
               s.profile,
               s.predicted_at,
               s.symbol,
               s.market,
               s.name,
               s.horizon_minutes,
               s.target_return,
               s.entry_price,
               s.profit_probability,
               s.expected_return,
               s.risk_score,
               s.decision,
               s.validation_due_at,
               max(q.last_done) as actual_high,
               min(q.last_done) as actual_low,
               argMax(q.last_done, q.snapshot_minute) as actual_price,
               max(q.snapshot_minute) as actual_observed_until,
               max(q.last_done) / nullIf(s.entry_price, 0) - 1 as max_return,
               min(q.last_done) / nullIf(s.entry_price, 0) - 1 as max_drawdown,
               argMax(q.last_done, q.snapshot_minute) / nullIf(s.entry_price, 0) - 1 as actual_return,
               if(max(q.last_done) / nullIf(s.entry_price, 0) - 1 >= {target}, 1, 0) as hit_target
        from selected s
        inner join quote_dedup q on q.symbol = s.symbol
          and q.snapshot_minute > s.predicted_at
          and q.snapshot_minute <= s.validation_due_at
        group by s.model_run_id, s.profile, s.predicted_at, s.symbol, s.market, s.name,
                 s.horizon_minutes, s.target_return, s.entry_price, s.profit_probability,
                 s.expected_return, s.risk_score, s.decision, s.validation_due_at
        order by s.predicted_at desc, s.profit_probability desc
        """
    )
    return [_profit_outcome_review_row(row) for row in rows]


def ensure_eastmoney_stock_boards() -> None:
    database = _ident(_database())
    _execute(
        f"""
        create table if not exists {database}.lb_eastmoney_stock_boards (
          symbol LowCardinality(String),
          market LowCardinality(String),
          name String,
          eastmoney_code String,
          exchange_board LowCardinality(String),
          industry String,
          industry_board_code String,
          region_board String,
          concepts Array(String),
          source LowCardinality(String),
          source_url String,
          payload String,
          fetched_at DateTime64(3, 'Asia/Shanghai'),
          inserted_at DateTime64(3, 'Asia/Shanghai') default now64(3)
        )
        engine = ReplacingMergeTree(inserted_at)
        order by (symbol)
        """
    )


def insert_eastmoney_stock_boards(rows: list[dict[str, Any]]) -> None:
    if not rows:
        return
    ensure_eastmoney_stock_boards()
    database = _ident(_database())
    table = f"{database}.lb_eastmoney_stock_boards"
    now_text = _dt(datetime.now().astimezone())
    normalized = []
    for row in rows:
        symbol = str(row.get("symbol") or "").strip().upper()
        if not symbol:
            continue
        payload = row.get("payload")
        concepts = row.get("concepts") or []
        if isinstance(concepts, str):
            concepts = [item.strip() for item in concepts.split(",") if item.strip()]
        item = {
            "symbol": symbol,
            "market": str(row.get("market") or symbol.rsplit(".", 1)[-1]).strip().lower(),
            "name": str(row.get("name") or ""),
            "eastmoney_code": str(row.get("eastmoney_code") or ""),
            "exchange_board": str(row.get("exchange_board") or ""),
            "industry": str(row.get("industry") or ""),
            "industry_board_code": str(row.get("industry_board_code") or ""),
            "region_board": str(row.get("region_board") or ""),
            "concepts": [str(item).strip() for item in concepts if str(item).strip()],
            "source": str(row.get("source") or ""),
            "source_url": str(row.get("source_url") or ""),
            "payload": _payload_text(payload),
            "fetched_at": _date_time_text(row.get("fetched_at") or now_text),
            "inserted_at": _date_time_text(row.get("inserted_at") or now_text),
        }
        normalized.append(item)
    _insert_json_each_row(table, normalized)


def fetch_eastmoney_stock_board_info(symbols: Iterable[str]) -> dict[str, dict[str, Any]]:
    symbol_list = _symbols(symbols)
    if not symbol_list or not enabled():
        return {}
    ensure_eastmoney_stock_boards()
    database = _ident(_database())
    rows = _query_json_each_row(
        f"""
        select
          symbol,
          market,
          name,
          eastmoney_code,
          exchange_board,
          industry,
          industry_board_code,
          region_board,
          concepts,
          source,
          source_url,
          fetched_at
        from {database}.lb_eastmoney_stock_boards final
        where symbol in {_symbol_tuple(symbol_list)}
        order by symbol
        """
    )
    output: dict[str, dict[str, Any]] = {}
    for row in rows:
        symbol = str(row.get("symbol") or "").strip().upper()
        if not symbol:
            continue
        output[symbol] = {
            "symbol": symbol,
            "market": row.get("market"),
            "name": row.get("name"),
            "eastmoney_code": row.get("eastmoney_code"),
            "exchange_board": row.get("exchange_board"),
            "industry": row.get("industry"),
            "industry_board_code": row.get("industry_board_code"),
            "region_board": row.get("region_board"),
            "concepts": row.get("concepts") or [],
            "source": row.get("source"),
            "source_url": row.get("source_url"),
            "fetched_at": row.get("fetched_at"),
        }
    return output


def fetch_eastmoney_profile_industries(symbols: Iterable[str]) -> dict[str, str]:
    symbol_list = _symbols(symbols)
    if not symbol_list or not enabled():
        return {}
    database = _ident(_database())
    rows = _query_json_each_row(
        f"""
        select symbol, industry
        from {database}.lb_eastmoney_f10_profiles final
        where symbol in {_symbol_tuple(symbol_list)}
          and industry != ''
        order by symbol, updated_at desc
        limit 1 by symbol
        """
    )
    return {
        str(row.get("symbol") or "").strip().upper(): str(row.get("industry") or "")
        for row in rows
        if row.get("symbol") and row.get("industry")
    }


def fetch_eastmoney_profile_industry_symbols(industry: str, *, market: str, limit: int) -> list[str]:
    value = str(industry or "").strip()
    market_key = str(market or "").strip().lower()
    if not value or not market_key or not enabled():
        return []
    database = _ident(_database())
    rows = _query_json_each_row(
        f"""
        select symbol
        from {database}.lb_eastmoney_f10_profiles final
        where market = {_sql_string(market_key)}
          and industry = {_sql_string(value)}
        order by symbol
        limit {max(1, int(limit))}
        """
    )
    return [str(row.get("symbol") or "").strip().upper() for row in rows if row.get("symbol")]


def ensure_hk_short_selling_turnover() -> None:
    database = _ident(_database())
    _execute(
        f"""
        create table if not exists {database}.lb_hk_short_selling_turnover (
          trade_date Date,
          session LowCardinality(String),
          board LowCardinality(String),
          code UInt32,
          symbol LowCardinality(String),
          name String,
          price Nullable(Float64),
          change Nullable(Float64),
          change_pct Nullable(Float64),
          short_volume UInt64,
          short_turnover Float64,
          turnover Nullable(Float64),
          market_short_value_pct Nullable(Float64),
          short_selling_ratio Nullable(Float64),
          ssr_3d_sma Nullable(Float64),
          ssr_5d_sma Nullable(Float64),
          currency LowCardinality(String),
          source LowCardinality(String),
          source_url String,
          fetched_at DateTime64(3, 'Asia/Shanghai'),
          inserted_at DateTime64(3, 'Asia/Shanghai') default now64(3)
        )
        engine = ReplacingMergeTree(inserted_at)
        partition by toYYYYMM(trade_date)
        order by (trade_date, session, board, symbol)
        ttl toDateTime(trade_date) + interval 730 day
        """
    )
    _execute(f"alter table {database}.lb_hk_short_selling_turnover add column if not exists price Nullable(Float64) after name")
    _execute(f"alter table {database}.lb_hk_short_selling_turnover add column if not exists change Nullable(Float64) after price")
    _execute(f"alter table {database}.lb_hk_short_selling_turnover add column if not exists change_pct Nullable(Float64) after change")
    _execute(f"alter table {database}.lb_hk_short_selling_turnover add column if not exists turnover Nullable(Float64) after short_turnover")
    _execute(
        f"alter table {database}.lb_hk_short_selling_turnover "
        "add column if not exists market_short_value_pct Nullable(Float64) after turnover"
    )
    _execute(
        f"alter table {database}.lb_hk_short_selling_turnover "
        "add column if not exists short_selling_ratio Nullable(Float64) after market_short_value_pct"
    )
    _execute(f"alter table {database}.lb_hk_short_selling_turnover add column if not exists ssr_3d_sma Nullable(Float64) after short_selling_ratio")
    _execute(f"alter table {database}.lb_hk_short_selling_turnover add column if not exists ssr_5d_sma Nullable(Float64) after ssr_3d_sma")


def insert_hk_short_selling_turnover_rows(rows: list[dict[str, Any]]) -> None:
    if not rows:
        return
    ensure_hk_short_selling_turnover()
    database = _ident(_database())
    table = f"{database}.lb_hk_short_selling_turnover"
    normalized = []
    for row in rows:
        symbol = str(row.get("symbol") or "").strip().upper()
        if not symbol:
            continue
        normalized.append(
            {
                "trade_date": _date_text(row.get("trade_date")),
                "session": str(row.get("session") or ""),
                "board": str(row.get("board") or ""),
                "code": int(_num(row.get("code"))),
                "symbol": symbol,
                "name": str(row.get("name") or ""),
                "price": _num_or_none(row.get("price")),
                "change": _num_or_none(row.get("change")),
                "change_pct": _num_or_none(row.get("change_pct")),
                "short_volume": int(_num(row.get("short_volume"))),
                "short_turnover": float(_num(row.get("short_turnover"))),
                "turnover": _num_or_none(row.get("turnover")),
                "market_short_value_pct": _num_or_none(row.get("market_short_value_pct")),
                "short_selling_ratio": _num_or_none(row.get("short_selling_ratio")),
                "ssr_3d_sma": _num_or_none(row.get("ssr_3d_sma")),
                "ssr_5d_sma": _num_or_none(row.get("ssr_5d_sma")),
                "currency": str(row.get("currency") or "HKD"),
                "source": str(row.get("source") or "hkex_short_selling_turnover"),
                "source_url": str(row.get("source_url") or ""),
                "fetched_at": _date_time_text(row.get("fetched_at") or datetime.now().astimezone()),
            }
        )
    _insert_json_each_row(table, normalized)


def fetch_latest_hk_short_selling_turnover(symbols: Iterable[str], *, session: str = "day_close") -> dict[str, dict[str, Any]]:
    symbol_list = _symbols(symbols)
    if not symbol_list or not enabled():
        return {}
    ensure_hk_short_selling_turnover()
    database = _ident(_database())
    rows = _query_json_each_row(
        f"""
        select trade_date, session, board, code, symbol, name,
               price, change, change_pct, short_volume, short_turnover, turnover,
               market_short_value_pct, short_selling_ratio, ssr_3d_sma, ssr_5d_sma,
               currency, source, source_url, fetched_at
        from {database}.lb_hk_short_selling_turnover final
        where symbol in {_symbol_tuple(symbol_list)}
          and session = {_sql_string(session)}
        order by symbol, trade_date desc, fetched_at desc
        limit 1 by symbol
        """
    )
    output: dict[str, dict[str, Any]] = {}
    for row in rows:
        symbol = str(row.get("symbol") or "").strip().upper()
        if not symbol:
            continue
        item = dict(row)
        item["scan_date"] = item.get("scan_date") or item.get("scan_date_text")
        output[symbol] = item
    return output


def ensure_us_short_positions() -> None:
    database = _ident(_database())
    _execute(
        f"""
        create table if not exists {database}.lb_us_short_positions (
          report_date Date,
          symbol LowCardinality(String),
          market LowCardinality(String),
          counter_id String,
          provider_timestamp UInt64,
          current_shares_short UInt64,
          short_interest_ratio Nullable(Float64),
          days_to_cover Nullable(Float64),
          avg_daily_share_volume UInt64,
          close Nullable(Float64),
          source LowCardinality(String),
          fetched_at DateTime64(6, 'Asia/Shanghai'),
          inserted_at DateTime64(6, 'Asia/Shanghai') default now64(6, 'Asia/Shanghai')
        )
        engine = ReplacingMergeTree(inserted_at)
        partition by toYYYYMM(report_date)
        order by (symbol, report_date)
        """
    )


def insert_us_short_positions(rows: list[dict[str, Any]]) -> None:
    if not rows:
        return
    ensure_us_short_positions()
    database = _ident(_database())
    now_text = _dt(datetime.now().astimezone())
    normalized = []
    for row in rows:
        symbol = str(row.get("symbol") or "").strip().upper()
        if not symbol:
            continue
        if "." not in symbol:
            symbol = f"{symbol}.US"
        normalized.append(
            {
                "report_date": _date_text(row.get("report_date")),
                "symbol": symbol,
                "market": str(row.get("market") or "us").strip().lower() or "us",
                "counter_id": str(row.get("counter_id") or ""),
                "provider_timestamp": int(_num(row.get("timestamp") or row.get("provider_timestamp"))),
                "current_shares_short": int(_num(row.get("current_shares_short"))),
                "short_interest_ratio": _num_or_none(row.get("short_interest_ratio") or row.get("rate")),
                "days_to_cover": _num_or_none(row.get("days_to_cover")),
                "avg_daily_share_volume": int(_num(row.get("avg_daily_share_volume"))),
                "close": _num_or_none(row.get("close")),
                "source": str(row.get("source") or "longbridge_short_positions"),
                "fetched_at": _date_time_text(row.get("fetched_at") or now_text),
            }
        )
    if normalized:
        _insert_json_each_row(f"{database}.lb_us_short_positions", normalized)


def fetch_latest_us_short_positions(symbols: Iterable[str]) -> dict[str, dict[str, Any]]:
    symbol_list = _symbols(symbols)
    if not symbol_list or not enabled():
        return {}
    ensure_us_short_positions()
    database = _ident(_database())
    rows = _query_json_each_row(
        f"""
        select report_date, symbol, market, counter_id, provider_timestamp,
               current_shares_short, short_interest_ratio, days_to_cover,
               avg_daily_share_volume, close, source, fetched_at
        from {database}.lb_us_short_positions final
        where symbol in {_symbol_tuple(symbol_list)}
        order by symbol, report_date desc, inserted_at desc
        limit 1 by symbol
        """
    )
    return {str(row.get("symbol") or "").strip().upper(): row for row in rows if row.get("symbol")}


def ensure_stock_short_trades() -> None:
    database = _ident(_database())
    _execute(
        f"""
        create table if not exists {database}.lb_stock_short_trades (
          trade_date Date,
          symbol LowCardinality(String),
          market LowCardinality(String),
          provider_timestamp UInt64,
          amount Nullable(UInt64),
          balance Nullable(Float64),
          nus_amount Nullable(UInt64),
          ny_amount Nullable(UInt64),
          total_amount Nullable(UInt64),
          rate Nullable(Float64),
          close Nullable(Float64),
          source LowCardinality(String),
          fetched_at DateTime64(6, 'Asia/Shanghai'),
          inserted_at DateTime64(6, 'Asia/Shanghai') default now64(6, 'Asia/Shanghai')
        )
        engine = ReplacingMergeTree(inserted_at)
        partition by toYYYYMM(trade_date)
        order by (symbol, trade_date)
        ttl toDateTime(trade_date) + interval 1095 day
        """
    )


def insert_stock_short_trades(rows: list[dict[str, Any]]) -> None:
    if not rows:
        return
    ensure_stock_short_trades()
    database = _ident(_database())
    now_text = _dt(datetime.now().astimezone())
    normalized = []
    for row in rows:
        symbol = str(row.get("symbol") or "").strip().upper()
        if not symbol:
            continue
        market = str(row.get("market") or "").strip().lower()
        if not market and "." in symbol:
            market = symbol.rsplit(".", 1)[-1].lower()
        normalized.append(
            {
                "trade_date": _date_text(row.get("trade_date")),
                "symbol": symbol,
                "market": market,
                "provider_timestamp": int(_num(row.get("timestamp") or row.get("provider_timestamp"))),
                "amount": _int_or_none(row.get("amount")),
                "balance": _num_or_none(row.get("balance")),
                "nus_amount": _int_or_none(row.get("nus_amount")),
                "ny_amount": _int_or_none(row.get("ny_amount")),
                "total_amount": _int_or_none(row.get("total_amount")),
                "rate": _num_or_none(row.get("rate")),
                "close": _num_or_none(row.get("close")),
                "source": str(row.get("source") or "longbridge_short_trades"),
                "fetched_at": _date_time_text(row.get("fetched_at") or now_text),
            }
        )
    if normalized:
        _insert_json_each_row(f"{database}.lb_stock_short_trades", normalized)


def ensure_longbridge_daily_capability_snapshots() -> None:
    database = _ident(_database())
    _execute(
        f"""
        create table if not exists {database}.lb_longbridge_daily_capability_snapshots (
          as_of Date,
          capability LowCardinality(String),
          scope LowCardinality(String),
          market LowCardinality(String),
          symbol String,
          command String,
          status LowCardinality(String),
          payload String,
          error String,
          fetched_at DateTime64(6, 'Asia/Shanghai'),
          inserted_at DateTime64(6, 'Asia/Shanghai') default now64(6, 'Asia/Shanghai')
        )
        engine = ReplacingMergeTree(inserted_at)
        partition by toYYYYMM(as_of)
        order by (as_of, capability, scope, market, symbol, command)
        ttl toDateTime(as_of) + interval 1095 day
        """
    )


def insert_longbridge_daily_capability_snapshots(rows: list[dict[str, Any]]) -> None:
    if not rows:
        return
    ensure_longbridge_daily_capability_snapshots()
    database = _ident(_database())
    normalized: list[dict[str, Any]] = []
    for row in rows:
        normalized.append(
            {
                "as_of": _date_text(row.get("as_of")),
                "capability": str(row.get("capability") or ""),
                "scope": str(row.get("scope") or ""),
                "market": str(row.get("market") or ""),
                "symbol": str(row.get("symbol") or ""),
                "command": str(row.get("command") or ""),
                "status": str(row.get("status") or ""),
                "payload": json.dumps(row.get("payload"), ensure_ascii=False, default=str) if not isinstance(row.get("payload"), str) else str(row.get("payload") or ""),
                "error": str(row.get("error") or ""),
                "fetched_at": _date_time_text(row.get("fetched_at")),
            }
        )
    _insert_json_each_row(f"{database}.lb_longbridge_daily_capability_snapshots", normalized)


def ensure_sentiment_impact_events() -> None:
    database = _ident(_database())
    _execute(
        f"""
        create table if not exists {database}.lb_sentiment_impact_events (
          analysis_date Date,
          source_symbol String,
          source_market LowCardinality(String),
          source_name String,
          event_title String,
          sentiment LowCardinality(String),
          impact_direction LowCardinality(String),
          impact_strength UInt8,
          impact_strength_pct Float64,
          confidence Float64,
          nlp_sentiment_score Float64,
          nlp_sentiment_label LowCardinality(String),
          nlp_signal_hits String,
          nlp_model_name String,
          nlp_model_status LowCardinality(String),
          time_horizon LowCardinality(String),
          affected_symbols Array(String),
          affected_sectors Array(String),
          trading_implication String,
          evidence_summary String,
          evidence_sources String,
          llm_model String,
          llm_status LowCardinality(String),
          payload String,
          analyzed_at DateTime64(6, 'Asia/Shanghai'),
          inserted_at DateTime64(6, 'Asia/Shanghai') default now64(6, 'Asia/Shanghai')
        )
        engine = ReplacingMergeTree(inserted_at)
        partition by toYYYYMM(analysis_date)
        order by (analysis_date, source_market, source_symbol, event_title)
        ttl toDateTime(analysis_date) + interval 730 day
        """
    )
    _execute(
        f"alter table {database}.lb_sentiment_impact_events "
        "add column if not exists impact_strength_pct Float64 after impact_strength"
    )
    _execute(
        f"alter table {database}.lb_sentiment_impact_events "
        "add column if not exists nlp_sentiment_score Float64 after confidence"
    )
    _execute(
        f"alter table {database}.lb_sentiment_impact_events "
        "add column if not exists nlp_sentiment_label LowCardinality(String) after nlp_sentiment_score"
    )
    _execute(
        f"alter table {database}.lb_sentiment_impact_events "
        "add column if not exists nlp_signal_hits String after nlp_sentiment_label"
    )
    _execute(
        f"alter table {database}.lb_sentiment_impact_events "
        "add column if not exists nlp_model_name String after nlp_signal_hits"
    )
    _execute(
        f"alter table {database}.lb_sentiment_impact_events "
        "add column if not exists nlp_model_status LowCardinality(String) after nlp_model_name"
    )


def insert_sentiment_impact_events(rows: list[dict[str, Any]]) -> None:
    if not rows:
        return
    ensure_sentiment_impact_events()
    database = _ident(_database())
    normalized: list[dict[str, Any]] = []
    for row in rows:
        symbol = str(row.get("source_symbol") or row.get("symbol") or "").strip().upper()
        if not symbol:
            continue
        impact_strength = int(max(0, min(5, _num(row.get("impact_strength")))))
        impact_strength_pct = row.get("impact_strength_pct")
        if impact_strength_pct is None:
            impact_strength_pct = impact_strength / 5 * 100 if impact_strength else 0
        nlp_sentiment_score = float(max(-100.0, min(100.0, _num(row.get("nlp_sentiment_score")))))
        nlp_sentiment_label = str(row.get("nlp_sentiment_label") or "")
        if not nlp_sentiment_label:
            if nlp_sentiment_score >= 30:
                nlp_sentiment_label = "positive"
            elif nlp_sentiment_score >= 10:
                nlp_sentiment_label = "slightly_positive"
            elif nlp_sentiment_score <= -30:
                nlp_sentiment_label = "negative"
            elif nlp_sentiment_score <= -10:
                nlp_sentiment_label = "slightly_negative"
            else:
                nlp_sentiment_label = "mixed_neutral"
        normalized.append(
            {
                "analysis_date": _date_text(row.get("analysis_date")),
                "source_symbol": symbol,
                "source_market": str(row.get("source_market") or row.get("market") or "").strip().lower(),
                "source_name": str(row.get("source_name") or row.get("name") or symbol),
                "event_title": str(row.get("event_title") or ""),
                "sentiment": str(row.get("sentiment") or "unknown"),
                "impact_direction": str(row.get("impact_direction") or "uncertain"),
                "impact_strength": impact_strength,
                "impact_strength_pct": float(max(0.0, min(100.0, _num(impact_strength_pct)))),
                "confidence": float(max(0.0, min(1.0, _num(row.get("confidence"))))),
                "nlp_sentiment_score": nlp_sentiment_score,
                "nlp_sentiment_label": nlp_sentiment_label,
                "nlp_signal_hits": _payload_text(row.get("nlp_signal_hits") or []),
                "nlp_model_name": str(row.get("nlp_model_name") or ""),
                "nlp_model_status": str(row.get("nlp_model_status") or ""),
                "time_horizon": str(row.get("time_horizon") or "unknown"),
                "affected_symbols": [str(item).strip().upper() for item in (row.get("affected_symbols") or []) if str(item).strip()],
                "affected_sectors": [str(item).strip() for item in (row.get("affected_sectors") or []) if str(item).strip()],
                "trading_implication": str(row.get("trading_implication") or ""),
                "evidence_summary": str(row.get("evidence_summary") or ""),
                "evidence_sources": _payload_text(row.get("evidence_sources") or []),
                "llm_model": str(row.get("llm_model") or ""),
                "llm_status": str(row.get("llm_status") or ""),
                "payload": _payload_text(row.get("payload") or {}),
                "analyzed_at": _date_time_text(row.get("analyzed_at")),
            }
        )
    if normalized:
        _insert_json_each_row(f"{database}.lb_sentiment_impact_events", normalized)


def fetch_daily_capability_snapshots(
    symbols: Iterable[str],
    *,
    capabilities: Iterable[str],
    lookback_days: int = 3,
) -> list[dict[str, Any]]:
    symbol_list = _symbols(symbols)
    capability_list = [str(item).strip() for item in capabilities if str(item).strip()]
    if not symbol_list or not capability_list or not enabled():
        return []
    ensure_longbridge_daily_capability_snapshots()
    database = _ident(_database())
    return _query_json_each_row(
        f"""
        select as_of, capability, scope, market, symbol, command, status, payload, error, fetched_at
        from {database}.lb_longbridge_daily_capability_snapshots final
        where symbol in {_symbol_tuple(symbol_list)}
          and capability in {_symbol_tuple(capability_list)}
          and as_of >= today() - interval {max(1, int(lookback_days))} day
        order by symbol, capability, as_of desc, fetched_at desc
        """
    )


def fetch_latest_stock_short_trades(symbols: Iterable[str]) -> dict[str, dict[str, Any]]:
    symbol_list = _symbols(symbols)
    if not symbol_list or not enabled():
        return {}
    ensure_stock_short_trades()
    database = _ident(_database())
    rows = _query_json_each_row(
        f"""
        select trade_date, symbol, market, provider_timestamp, amount, balance,
               nus_amount, ny_amount, total_amount, rate, close, source, fetched_at
        from {database}.lb_stock_short_trades final
        where symbol in {_symbol_tuple(symbol_list)}
        order by symbol, trade_date desc, inserted_at desc
        limit 1 by symbol
        """
    )
    return {str(row.get("symbol") or "").strip().upper(): row for row in rows if row.get("symbol")}


def fetch_stock_short_trade_rate_features(symbols: Iterable[str], *, lookback_days: int = 10) -> dict[str, dict[str, Any]]:
    symbol_list = _symbols(symbols)
    if not symbol_list or not enabled():
        return {}
    ensure_stock_short_trades()
    database = _ident(_database())
    rows = _query_json_each_row(
        f"""
        select symbol, trade_date, argMax(rate, inserted_at) as latest_rate
        from {database}.lb_stock_short_trades final
        where symbol in {_symbol_tuple(symbol_list)}
          and trade_date >= today() - interval {max(5, int(lookback_days))} day
          and rate is not null
        group by symbol, trade_date
        order by symbol, trade_date desc
        """
    )
    grouped: dict[str, list[dict[str, Any]]] = {}
    for row in rows:
        symbol = str(row.get("symbol") or "").strip().upper()
        if symbol:
            grouped.setdefault(symbol, []).append(row)
    output: dict[str, dict[str, Any]] = {}
    for symbol, symbol_rows in grouped.items():
        if not symbol_rows:
            continue
        latest = symbol_rows[0]
        recent_rates = [_num_or_none(row.get("latest_rate")) for row in symbol_rows[:5]]
        recent_rates = [value for value in recent_rates if value is not None]
        rate_5d = sum(recent_rates) / len(recent_rates) if recent_rates else None
        rate = _num_or_none(latest.get("latest_rate"))
        output[symbol] = {
            "short_rate_trade_date": latest.get("trade_date"),
            "short_rate": rate,
            "short_selling_ratio": _ratio_to_pct(rate),
            "ssr_5d_sma": _ratio_to_pct(rate_5d),
            "short_selling_source": "longbridge_short_trades",
        }
    return output


def fetch_latest_short_selling_features(symbols: Iterable[str]) -> dict[str, dict[str, Any]]:
    symbol_list = _symbols(symbols)
    if not symbol_list or not enabled():
        return {}
    output: dict[str, dict[str, Any]] = {symbol: {} for symbol in symbol_list}
    hk_symbols = [symbol for symbol in symbol_list if symbol.endswith(".HK")]
    if hk_symbols:
        try:
            for symbol, row in fetch_latest_hk_short_selling_turnover(hk_symbols).items():
                output.setdefault(symbol, {}).update(
                    {
                        "short_trade_date": row.get("trade_date"),
                        "short_session": row.get("session"),
                        "short_turnover": _num_or_none(row.get("short_turnover")),
                        "short_selling_ratio": _num_or_none(row.get("short_selling_ratio")),
                        "ssr_3d_sma": _num_or_none(row.get("ssr_3d_sma")),
                        "ssr_5d_sma": _num_or_none(row.get("ssr_5d_sma")),
                        "market_short_value_pct": _num_or_none(row.get("market_short_value_pct")),
                        "short_selling_source": "hkex_short_selling_turnover",
                    }
                )
        except Exception:
            pass
    try:
        for symbol, row in fetch_stock_short_trade_rate_features(symbol_list).items():
            output.setdefault(symbol, {}).update(row)
            if row.get("short_rate_trade_date"):
                output[symbol]["short_trade_date"] = row.get("short_rate_trade_date")
    except Exception:
        pass
    try:
        for symbol, row in fetch_latest_stock_short_trades(symbol_list).items():
            output.setdefault(symbol, {}).update(
                {
                    "short_trade_date": row.get("trade_date") or output.get(symbol, {}).get("short_trade_date"),
                    "short_rate": _num_or_none(row.get("rate")),
                    "short_amount": _num_or_none(row.get("amount")),
                    "short_balance": _num_or_none(row.get("balance")),
                    "short_total_amount": _num_or_none(row.get("total_amount")),
                    "short_close": _num_or_none(row.get("close")),
                }
            )
    except Exception:
        pass
    return {symbol: features for symbol, features in output.items() if features}


def _ratio_to_pct(value: Any) -> float | None:
    parsed = _num_or_none(value)
    if parsed is None:
        return None
    if abs(parsed) <= 1:
        return parsed * 100
    return parsed


def ensure_us_option_chains_daily() -> None:
    database = _ident(_database())
    _execute(
        f"""
        create table if not exists {database}.lb_us_option_chains_daily (
          fetch_date Date,
          underlying_symbol LowCardinality(String),
          contract_symbol String,
          expiry_date Date,
          strike_price Float64,
          direction LowCardinality(String),
          standard UInt8,
          source LowCardinality(String),
          fetched_at DateTime64(6, 'Asia/Shanghai'),
          inserted_at DateTime64(6, 'Asia/Shanghai') default now64(6, 'Asia/Shanghai')
        )
        engine = ReplacingMergeTree(inserted_at)
        partition by toYYYYMM(fetch_date)
        order by (fetch_date, underlying_symbol, expiry_date, strike_price, direction, contract_symbol)
        """
    )


def insert_us_option_chain_daily(rows: list[dict[str, Any]]) -> None:
    if not rows:
        return
    ensure_us_option_chains_daily()
    database = _ident(_database())
    now_text = _dt(datetime.now().astimezone())
    normalized = []
    for row in rows:
        contract_symbol = str(row.get("contract_symbol") or "").strip().upper()
        if not contract_symbol:
            continue
        fetched_at = row.get("fetched_at") or now_text
        normalized.append(
            {
                "fetch_date": _date_from_any(fetched_at),
                "underlying_symbol": _us_symbol(row.get("underlying_symbol")),
                "contract_symbol": contract_symbol,
                "expiry_date": _date_text(row.get("expiry_date")),
                "strike_price": _num(row.get("strike_price")),
                "direction": str(row.get("direction") or ""),
                "standard": 1 if _truthy(row.get("standard")) else 0,
                "source": str(row.get("source") or "longbridge_option_chain"),
                "fetched_at": _date_time_text(fetched_at),
            }
        )
    if normalized:
        _insert_json_each_row(f"{database}.lb_us_option_chains_daily", normalized)


def ensure_us_option_quote_snapshots() -> None:
    database = _ident(_database())
    _execute(
        f"""
        create table if not exists {database}.lb_us_option_quote_snapshots (
          snapshot_date Date,
          contract_symbol String,
          underlying_symbol LowCardinality(String),
          direction LowCardinality(String),
          expiry_date Date,
          strike_price Float64,
          last Nullable(Float64),
          open Nullable(Float64),
          high Nullable(Float64),
          low Nullable(Float64),
          prev_close Nullable(Float64),
          volume UInt64,
          turnover Nullable(Float64),
          open_interest UInt64,
          implied_volatility Nullable(Float64),
          historical_volatility Nullable(Float64),
          quote_timestamp String,
          trade_status LowCardinality(String),
          contract_type LowCardinality(String),
          contract_size String,
          contract_multiplier String,
          source LowCardinality(String),
          fetched_at DateTime64(6, 'Asia/Shanghai'),
          inserted_at DateTime64(6, 'Asia/Shanghai') default now64(6, 'Asia/Shanghai')
        )
        engine = ReplacingMergeTree(inserted_at)
        partition by toYYYYMM(snapshot_date)
        order by (snapshot_date, contract_symbol, quote_timestamp)
        """
    )


def insert_us_option_quote_snapshots(rows: list[dict[str, Any]]) -> None:
    if not rows:
        return
    ensure_us_option_quote_snapshots()
    database = _ident(_database())
    now_text = _dt(datetime.now().astimezone())
    normalized = []
    for row in rows:
        contract_symbol = str(row.get("contract_symbol") or row.get("symbol") or "").strip().upper()
        if not contract_symbol:
            continue
        fetched_at = row.get("fetched_at") or now_text
        normalized.append(
            {
                "snapshot_date": _date_from_any(fetched_at),
                "contract_symbol": contract_symbol,
                "underlying_symbol": _us_symbol(row.get("underlying_symbol")),
                "direction": str(row.get("direction") or ""),
                "expiry_date": _date_text(row.get("expiry_date")),
                "strike_price": _num(row.get("strike_price")),
                "last": _num_or_none(row.get("last")),
                "open": _num_or_none(row.get("open")),
                "high": _num_or_none(row.get("high")),
                "low": _num_or_none(row.get("low")),
                "prev_close": _num_or_none(row.get("prev_close")),
                "volume": int(_num(row.get("volume"))),
                "turnover": _num_or_none(row.get("turnover")),
                "open_interest": int(_num(row.get("open_interest"))),
                "implied_volatility": _num_or_none(row.get("implied_volatility")),
                "historical_volatility": _num_or_none(row.get("historical_volatility")),
                "quote_timestamp": str(row.get("quote_timestamp") or row.get("timestamp") or ""),
                "trade_status": str(row.get("trade_status") or ""),
                "contract_type": str(row.get("contract_type") or ""),
                "contract_size": str(row.get("contract_size") or ""),
                "contract_multiplier": str(row.get("contract_multiplier") or ""),
                "source": str(row.get("source") or "longbridge_option_quote"),
                "fetched_at": _date_time_text(fetched_at),
            }
        )
    if normalized:
        _insert_json_each_row(f"{database}.lb_us_option_quote_snapshots", normalized)


def ensure_us_option_volume_daily() -> None:
    database = _ident(_database())
    _execute(
        f"""
        create table if not exists {database}.lb_us_option_volume_daily (
          trade_date Date,
          underlying_symbol LowCardinality(String),
          underlying_counter_id String,
          provider_timestamp UInt64,
          total_call_volume UInt64,
          total_put_volume UInt64,
          total_volume UInt64,
          total_call_open_interest UInt64,
          total_put_open_interest UInt64,
          total_open_interest UInt64,
          put_call_volume_ratio Nullable(Float64),
          put_call_open_interest_ratio Nullable(Float64),
          source LowCardinality(String),
          fetched_at DateTime64(6, 'Asia/Shanghai'),
          inserted_at DateTime64(6, 'Asia/Shanghai') default now64(6, 'Asia/Shanghai')
        )
        engine = ReplacingMergeTree(inserted_at)
        partition by toYYYYMM(trade_date)
        order by (underlying_symbol, trade_date)
        """
    )


def insert_us_option_volume_daily(rows: list[dict[str, Any]]) -> None:
    if not rows:
        return
    ensure_us_option_volume_daily()
    database = _ident(_database())
    now_text = _dt(datetime.now().astimezone())
    normalized = []
    for row in rows:
        symbol = _us_symbol(row.get("underlying_symbol"))
        if not symbol:
            continue
        normalized.append(
            {
                "trade_date": _date_text(row.get("trade_date")),
                "underlying_symbol": symbol,
                "underlying_counter_id": str(row.get("underlying_counter_id") or ""),
                "provider_timestamp": int(_num(row.get("provider_timestamp"))),
                "total_call_volume": int(_num(row.get("total_call_volume"))),
                "total_put_volume": int(_num(row.get("total_put_volume"))),
                "total_volume": int(_num(row.get("total_volume"))),
                "total_call_open_interest": int(_num(row.get("total_call_open_interest"))),
                "total_put_open_interest": int(_num(row.get("total_put_open_interest"))),
                "total_open_interest": int(_num(row.get("total_open_interest"))),
                "put_call_volume_ratio": _num_or_none(row.get("put_call_volume_ratio")),
                "put_call_open_interest_ratio": _num_or_none(row.get("put_call_open_interest_ratio")),
                "source": str(row.get("source") or "longbridge_option_volume_daily"),
                "fetched_at": _date_time_text(row.get("fetched_at") or now_text),
            }
        )
    if normalized:
        _insert_json_each_row(f"{database}.lb_us_option_volume_daily", normalized)


def fetch_intraday_bars(symbols: Iterable[str], *, period: str, limit: int) -> list[dict[str, Any]]:
    symbol_list = _symbols(symbols)
    if not symbol_list or not enabled():
        return []
    minutes = int(period.removesuffix("m"))
    database = _ident(_database())
    symbol_filter = _symbol_tuple(symbol_list)
    rows = _query_json_each_row(
        f"""
        with (
          select toStartOfDay(max(line_time))
          from {database}.lb_intraday_lines
          where symbol in {symbol_filter}
        ) as trade_start
        select
          toString(toStartOfInterval(line_time, interval {minutes} minute)) as bucket,
          argMin(price, line_time) as open,
          max(price) as high,
          min(price) as low,
          argMax(price, line_time) as close,
          sum(volume) as volume,
          sum(turnover) as turnover
        from {database}.lb_intraday_lines
        where symbol in {symbol_filter}
          and line_time >= trade_start
          and line_time < trade_start + interval 1 day
        group by bucket
        order by bucket desc
        limit {int(limit)}
        """
    )
    prev_close = _latest_prev_close(symbol_list)
    bars = [
        {
            "time": str(row.get("bucket") or ""),
            "date": str(row.get("bucket") or ""),
            "open": _num(row.get("open")),
            "high": _num(row.get("high")),
            "low": _num(row.get("low")),
            "close": _num(row.get("close")),
            "volume": _num(row.get("volume")),
            "turnover": _num(row.get("turnover")),
            "prevClose": prev_close,
        }
        for row in rows
        if row.get("open") is not None and row.get("close") is not None
    ]
    bars.reverse()
    return bars


def ensure_intraday_candidate_pool() -> None:
    database = _ident(_database())
    _execute(
        f"""
        create table if not exists {database}.lb_intraday_candidate_pool (
          market LowCardinality(String),
          trade_date Date,
          run_time DateTime64(3, 'Asia/Shanghai'),
          rank UInt16,
          symbol String,
          name String,
          score Float64,
          reason String,
          last Float64,
          change_pct Float64,
          high Float64,
          low Float64,
          total_net Nullable(Float64),
          large_net Nullable(Float64),
          zone_low Float64,
          zone_high Float64,
          confirm_price Float64,
          risk_line Float64,
          status LowCardinality(String),
          payload String,
          created_at DateTime64(3, 'Asia/Shanghai') default now64(3),
          updated_at DateTime64(3, 'Asia/Shanghai') default now64(3)
        )
        engine = ReplacingMergeTree(updated_at)
        partition by toYYYYMM(trade_date)
        order by (market, trade_date, run_time, rank)
        """
    )


def insert_intraday_candidate_pool(rows: list[dict[str, Any]]) -> None:
    if not rows:
        return
    ensure_intraday_candidate_pool()
    database = _ident(_database())
    table = f"{database}.lb_intraday_candidate_pool"
    now_text = _dt(datetime.now().astimezone())
    normalized = []
    for row in rows:
        item = dict(row)
        item.setdefault("status", "watching")
        item.setdefault("created_at", now_text)
        item["updated_at"] = now_text
        item["trade_date"] = _date_text(item.get("trade_date"))
        item["run_time"] = _date_time_text(item.get("run_time"))
        item["created_at"] = _date_time_text(item.get("created_at"))
        item["updated_at"] = _date_time_text(item.get("updated_at"))
        item["payload"] = _payload_text(item.get("payload"))
        normalized.append(item)
    _insert_json_each_row(table, normalized)


def fetch_intraday_candidate_pool_entries(*, trade_date: date, market: str, max_rank: int = 3) -> list[dict[str, Any]]:
    ensure_intraday_candidate_pool()
    database = _ident(_database())
    market_key = _sql_string(market.lower())
    trade_date_key = _sql_string(_date_text(trade_date))
    rows = _query_json_each_row(
        f"""
        select *
        from (
          select
            market, trade_date, run_time, rank, symbol, name, score, reason,
            last, change_pct, high, low, total_net, large_net,
            zone_low, zone_high, confirm_price, risk_line, status, payload,
            created_at, updated_at
          from {database}.lb_intraday_candidate_pool final
          where trade_date = toDate({trade_date_key})
            and market = {market_key}
            and run_time = (
              select max(run_time)
              from {database}.lb_intraday_candidate_pool final
              where trade_date = toDate({trade_date_key})
                and market = {market_key}
            )
            and rank <= {max(1, int(max_rank))}
            and status in ('watching', 'buy_zone', 'breakout', 'weak')
          order by symbol, run_time desc, rank asc
          limit 1 by symbol
        )
        order by rank asc, symbol
        """
    )
    return rows


def update_intraday_candidate_pool_status(entry: dict[str, Any], status: str) -> None:
    replacement = dict(entry)
    replacement["status"] = status
    replacement["payload"] = _payload_text(replacement.get("payload"))
    insert_intraday_candidate_pool([replacement])


def ensure_daily_strong_mover_early_candidates() -> None:
    database = _ident(_database())
    _execute(
        f"""
        create table if not exists {database}.lb_daily_strong_mover_early_candidates (
          trade_date Date,
          market LowCardinality(String),
          run_time DateTime64(3, 'Asia/Shanghai'),
          rank UInt16,
          symbol String,
          score Float64,
          rules String,
          feature_snapshot String,
          source LowCardinality(String),
          created_at DateTime64(3, 'Asia/Shanghai') default now64(3),
          updated_at DateTime64(3, 'Asia/Shanghai') default now64(3)
        )
        engine = ReplacingMergeTree(updated_at)
        partition by toYYYYMM(trade_date)
        order by (trade_date, market, rank, symbol)
        """
    )
    _execute(f"alter table {database}.lb_daily_strong_mover_early_candidates add column if not exists run_time DateTime64(3, 'Asia/Shanghai') after market")


def insert_daily_strong_mover_early_candidates(rows: list[dict[str, Any]]) -> None:
    if not rows:
        return
    ensure_daily_strong_mover_early_candidates()
    database = _ident(_database())
    table = f"{database}.lb_daily_strong_mover_early_candidates"
    now_text = _dt(datetime.now().astimezone())
    normalized = []
    for row in rows:
        item = dict(row)
        item.setdefault("source", "daily_strong_mover_early_screen")
        item.setdefault("run_time", now_text)
        item.setdefault("created_at", now_text)
        item["updated_at"] = now_text
        item["trade_date"] = _date_text(item.get("trade_date"))
        item["run_time"] = _date_time_text(item.get("run_time"))
        item["created_at"] = _date_time_text(item.get("created_at"))
        item["updated_at"] = _date_time_text(item.get("updated_at"))
        item["rules"] = _payload_text(item.get("rules"))
        item["feature_snapshot"] = _payload_text(item.get("feature_snapshot"))
        normalized.append(item)
    _insert_json_each_row(table, normalized)


def fetch_latest_daily_strong_mover_early_candidates(*, market: str, limit: int = 30) -> list[dict[str, Any]]:
    ensure_daily_strong_mover_early_candidates()
    database = _ident(_database())
    market_key = _sql_string(market.lower())
    rows = _query_json_each_row(
        f"""
        select trade_date, market, run_time, rank, symbol, score, rules, feature_snapshot, source, created_at, updated_at
        from {database}.lb_daily_strong_mover_early_candidates final
        where market = {market_key}
          and trade_date = (
            select max(trade_date)
            from {database}.lb_daily_strong_mover_early_candidates final
            where market = {market_key}
          )
          and run_time = (
            select max(run_time)
            from {database}.lb_daily_strong_mover_early_candidates final
            where market = {market_key}
          )
        order by rank asc, symbol
        limit {max(1, int(limit))}
        """
    )
    return rows


def ensure_factor_candidate_snapshots() -> None:
    database = _ident(_database())
    _execute(
        f"""
        create table if not exists {database}.lb_factor_candidate_snapshots (
          source LowCardinality(String),
          market LowCardinality(String),
          trade_date Date,
          signal_time DateTime64(3, 'Asia/Shanghai'),
          symbol String,
          name String,
          score Nullable(Float64),
          entry_price Nullable(Float64),
          features String,
          created_at DateTime64(3, 'Asia/Shanghai') default now64(3),
          updated_at DateTime64(3, 'Asia/Shanghai') default now64(3)
        )
        engine = ReplacingMergeTree(updated_at)
        partition by toYYYYMM(trade_date)
        order by (source, market, trade_date, signal_time, symbol)
        ttl toDateTime(trade_date) + interval 365 day
        """
    )


def insert_factor_candidate_snapshots(rows: list[dict[str, Any]]) -> None:
    if not rows:
        return
    ensure_factor_candidate_snapshots()
    database = _ident(_database())
    now_text = _dt(datetime.now().astimezone())
    normalized = []
    for row in rows:
        symbol = str(row.get("symbol") or "").strip().upper()
        market = str(row.get("market") or "").strip().lower()
        source = str(row.get("source") or "").strip()
        signal_time = row.get("signal_time")
        if not symbol or not market or not source or not signal_time:
            continue
        item = {
            "source": source,
            "market": market,
            "trade_date": _date_text(row.get("trade_date") or signal_time),
            "signal_time": _date_time_text(signal_time),
            "symbol": symbol,
            "name": str(row.get("name") or symbol),
            "score": _num_or_none(row.get("score")),
            "entry_price": _num_or_none(row.get("entry_price")),
            "features": _payload_text(row.get("features")),
            "created_at": _date_time_text(row.get("created_at") or now_text),
            "updated_at": _date_time_text(row.get("updated_at") or now_text),
        }
        normalized.append(item)
    if normalized:
        _insert_json_each_row(f"{database}.lb_factor_candidate_snapshots", normalized)


def ensure_factor_signal_outcomes() -> None:
    database = _ident(_database())
    _execute(
        f"""
        create table if not exists {database}.lb_factor_signal_outcomes (
          source LowCardinality(String),
          market LowCardinality(String),
          signal_time DateTime64(3, 'Asia/Shanghai'),
          symbol String,
          horizon_days UInt16,
          entry_price Nullable(Float64),
          future_price Nullable(Float64),
          future_return Nullable(Float64),
          max_favorable_return Nullable(Float64),
          max_drawdown Nullable(Float64),
          hit_2pct Nullable(UInt8),
          observed_until Nullable(DateTime64(3, 'Asia/Shanghai')),
          created_at DateTime64(3, 'Asia/Shanghai') default now64(3),
          updated_at DateTime64(3, 'Asia/Shanghai') default now64(3)
        )
        engine = ReplacingMergeTree(updated_at)
        partition by toYYYYMM(signal_time)
        order by (source, market, symbol, signal_time, horizon_days)
        ttl toDateTime(signal_time) + interval 365 day
        """
    )


def insert_factor_signal_outcomes(rows: list[dict[str, Any]]) -> None:
    if not rows:
        return
    ensure_factor_signal_outcomes()
    database = _ident(_database())
    now_text = _dt(datetime.now().astimezone())
    normalized = []
    for row in rows:
        symbol = str(row.get("symbol") or "").strip().upper()
        market = str(row.get("market") or "").strip().lower()
        source = str(row.get("source") or "").strip()
        signal_time = row.get("signal_time")
        if not symbol or not market or not source or not signal_time:
            continue
        hit_value = row.get("hit_2pct")
        normalized.append(
            {
                "source": source,
                "market": market,
                "signal_time": _date_time_text(signal_time),
                "symbol": symbol,
                "horizon_days": int(_num(row.get("horizon_days"))),
                "entry_price": _num_or_none(row.get("entry_price")),
                "future_price": _num_or_none(row.get("future_price")),
                "future_return": _num_or_none(row.get("future_return")),
                "max_favorable_return": _num_or_none(row.get("max_favorable_return")),
                "max_drawdown": _num_or_none(row.get("max_drawdown")),
                "hit_2pct": None if hit_value is None else int(_num(hit_value)),
                "observed_until": _date_time_text(row.get("observed_until")) if row.get("observed_until") else None,
                "created_at": _date_time_text(row.get("created_at") or now_text),
                "updated_at": _date_time_text(row.get("updated_at") or now_text),
            }
        )
    if normalized:
        _insert_json_each_row(f"{database}.lb_factor_signal_outcomes", normalized)


def fetch_factor_evaluation_rows(
    *,
    source: str,
    horizon_days: int,
    market: str = "all",
    start_date: str | None = None,
    limit: int = 100000,
) -> list[dict[str, Any]]:
    ensure_factor_candidate_snapshots()
    ensure_factor_signal_outcomes()
    database = _ident(_database())
    filters = [f"s.source = {_sql_string(source)}", f"o.horizon_days = {int(horizon_days)}"]
    if market.lower() != "all":
        filters.append(f"s.market = {_sql_string(market.lower())}")
    if start_date:
        filters.append(f"s.trade_date >= toDate({_sql_string(start_date)})")
    where = " and ".join(filters)
    return _query_json_each_row(
        f"""
        select
          s.source,
          s.market,
          toString(s.trade_date) as signal_date,
          s.signal_time,
          s.symbol,
          s.name,
          s.score,
          s.entry_price,
          s.features,
          o.horizon_days,
          o.future_price,
          o.future_return,
          o.max_favorable_return,
          o.max_drawdown,
          o.hit_2pct,
          o.observed_until
        from (select * from {database}.lb_factor_candidate_snapshots final) as s
        inner join (select * from {database}.lb_factor_signal_outcomes final) as o
          on s.source = o.source
         and s.market = o.market
         and s.symbol = o.symbol
         and s.signal_time = o.signal_time
        where {where}
        order by s.signal_time desc, s.symbol
        limit {max(1, int(limit))}
        """
    )


def fetch_stock_pattern_candidate_contexts(symbols: Iterable[str], *, market: str) -> dict[str, dict[str, Any]]:
    symbol_list = _symbols(symbols)
    market_key = str(market or "").strip().lower()
    if not symbol_list or not market_key or not enabled():
        return {}
    database = _ident(_database())
    try:
        rows = _query_json_each_row(
            f"""
            select
              symbol,
              market,
              toString(scan_date) as scan_date_text,
              pool,
              score,
              pattern_type,
              up_probability,
              down_probability,
              median_max_return,
              median_max_drawdown,
              median_final_return,
              match_count,
              reasons,
              risk_flags
            from {database}.lb_stock_pattern_candidates final
            where market = {_sql_string(market_key)}
              and symbol in {_symbol_tuple(symbol_list)}
              and scan_date = (
                select max(scan_date)
                from {database}.lb_stock_pattern_candidates final
                where market = {_sql_string(market_key)}
              )
            order by symbol, score desc
            limit 1 by symbol
            """
        )
    except Exception:
        return {}
    return {str(row.get("symbol") or "").strip().upper(): row for row in rows if row.get("symbol")}


def _execute(sql: str) -> None:
    req = _request(sql)
    with request.urlopen(req, timeout=float(os.getenv("CLICKHOUSE_READ_TIMEOUT_SECONDS", "5"))) as response:
        response.read()


def _insert_json_each_row(table: str, rows: list[dict[str, Any]]) -> None:
    if not rows:
        return
    body = "\n".join(json.dumps(row, ensure_ascii=False, default=str) for row in rows).encode("utf-8")
    req = _request(f"insert into {table} format JSONEachRow", data=body)
    with request.urlopen(req, timeout=float(os.getenv("CLICKHOUSE_WRITE_TIMEOUT_SECONDS", os.getenv("CLICKHOUSE_READ_TIMEOUT_SECONDS", "10")))) as response:
        response.read()


def _query_json_each_row(sql: str) -> list[dict[str, Any]]:
    req = _request(sql + " format JSONEachRow")
    with request.urlopen(req, timeout=float(os.getenv("CLICKHOUSE_READ_TIMEOUT_SECONDS", "5"))) as response:
        body = response.read().decode("utf-8")
    return [json.loads(line) for line in body.splitlines() if line.strip()]


def _request(sql: str, *, data: bytes | None = None) -> request.Request:
    req = request.Request(f"{_url()}/?query={quote(sql)}", data=data, method="POST")
    user = os.getenv("CLICKHOUSE_USER", "default")
    password = os.getenv("CLICKHOUSE_PASSWORD", "")
    if user:
        req.add_header("X-ClickHouse-User", user)
    if password:
        req.add_header("X-ClickHouse-Key", password)
    return req


def _capital_signal_fields(row: dict[str, Any]) -> dict[str, Any]:
    return {
        "capital_minute": row.get("capital_minute"),
        "large_in": _num(row.get("large_in")),
        "large_out": _num(row.get("large_out")),
        "large_net": _num(row.get("large_net")),
        "medium_net": _num(row.get("medium_net")),
        "small_net": _num(row.get("small_net")),
        "total_in": _num(row.get("total_in")),
        "total_out": _num(row.get("total_out")),
        "total_net": _num(row.get("total_net")),
        "large_net_ratio": _num(row.get("large_net_ratio")),
        "small_net_ratio": _num(row.get("small_net_ratio")),
    }


def _flow_signal_fields(row: dict[str, Any]) -> dict[str, Any]:
    return {
        "flow_15m": _num(row.get("flow_15m")),
        "flow_30m": _num(row.get("flow_30m")),
        "flow_today": _num(row.get("flow_today")),
        "flow_points": int(_num(row.get("flow_points"))),
        "last_flow_time": row.get("last_flow_time"),
    }


def _latest_prev_close(symbols: list[str]) -> float:
    database = _ident(_database())
    rows = _query_json_each_row(
        f"""
        select prev_close
        from {database}.lb_realtime_quotes
        where symbol in {_symbol_tuple(symbols)}
          and prev_close is not null
        order by snapshot_minute desc, inserted_at desc
        limit 1
        """
    )
    if not rows:
        return 0.0
    return _num(rows[0].get("prev_close"))


def _symbols(symbols: Iterable[str]) -> list[str]:
    return sorted({str(symbol).strip().upper() for symbol in symbols if str(symbol).strip()})


def _symbol_tuple(symbols: list[str]) -> str:
    return "(" + ",".join(_sql_string(symbol) for symbol in symbols) + ")"


def _sql_string(value: str) -> str:
    return "'" + value.replace("\\", "\\\\").replace("'", "\\'") + "'"


def _url() -> str:
    return os.getenv("CLICKHOUSE_URL", "http://127.0.0.1:8123").rstrip("/")


def _database() -> str:
    return os.getenv("CLICKHOUSE_DATABASE", "longbridge")


def _dt(value: datetime) -> str:
    return value.isoformat()


def _date_text(value: Any) -> str:
    if isinstance(value, datetime):
        return value.date().isoformat()
    if isinstance(value, date):
        return value.isoformat()
    return str(value)


def _date_time_text(value: Any) -> str:
    if isinstance(value, datetime):
        return value.isoformat()
    return str(value)


def _payload_text(value: Any) -> str:
    if isinstance(value, str):
        return value
    return json.dumps(value or {}, ensure_ascii=False, default=str)


def _profile_from_metrics(value: Any) -> str:
    if isinstance(value, dict):
        return str(value.get("profile") or "realtime").lower()
    if value:
        try:
            loaded = json.loads(str(value))
        except json.JSONDecodeError:
            return "realtime"
        if isinstance(loaded, dict):
            return str(loaded.get("profile") or "realtime").lower()
    return "realtime"


def _num(value: Any) -> float:
    if value is None or value == "":
        return 0.0
    try:
        return float(value)
    except (TypeError, ValueError):
        return 0.0


def _change_pct(value: Any, last: Any, prev_close: Any) -> float:
    parsed = _num_or_none(value)
    if parsed is not None:
        return parsed
    last_num = _num_or_none(last)
    prev_num = _num_or_none(prev_close)
    if last_num is None or prev_num in (None, 0):
        return 0.0
    return round((last_num - prev_num) / prev_num * 100, 4)


def _num_or_none(value: Any) -> float | None:
    if value is None or value == "":
        return None
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def _int_or_none(value: Any) -> int | None:
    parsed = _num_or_none(value)
    return None if parsed is None else int(parsed)


def _us_symbol(value: Any) -> str:
    symbol = str(value or "").strip().upper()
    if symbol and "." not in symbol:
        symbol = f"{symbol}.US"
    return symbol


def _date_from_any(value: Any) -> str:
    if isinstance(value, datetime):
        return value.date().isoformat()
    if isinstance(value, date):
        return value.isoformat()
    text = str(value or "")
    return text[:10]


def _truthy(value: Any) -> bool:
    if isinstance(value, bool):
        return value
    return str(value).strip().lower() in {"1", "true", "yes", "y"}


def _json_dict(value: Any) -> dict[str, Any]:
    if isinstance(value, dict):
        return value
    if not value:
        return {}
    try:
        loaded = json.loads(str(value))
    except json.JSONDecodeError:
        return {}
    return loaded if isinstance(loaded, dict) else {}


def _profit_prediction_row(row: dict[str, Any]) -> dict[str, Any]:
    return {
        "symbol": str(row.get("symbol") or "").strip().upper(),
        "market": row.get("market"),
        "name": row.get("name"),
        "predicted_at": row.get("predicted_at"),
        "entry_price": _num_or_none(row.get("entry_price")),
        "profit_probability": _num_or_none(row.get("profit_probability")),
        "expected_return": _num_or_none(row.get("expected_return")),
        "risk_score": _num_or_none(row.get("risk_score")),
        "decision": row.get("decision"),
        "horizon_minutes": row.get("horizon_minutes"),
        "target_return": _num_or_none(row.get("target_return")),
        "validation_due_at": row.get("validation_due_at"),
        "feature_snapshot": _json_dict(row.get("feature_snapshot")),
    }


def _profit_validation_row(row: dict[str, Any]) -> dict[str, Any]:
    return {
        "model_run_id": row.get("model_run_id"),
        "predicted_at": row.get("predicted_at"),
        "symbol": str(row.get("symbol") or "").strip().upper(),
        "market": str(row.get("market") or "").lower(),
        "name": row.get("name"),
        "horizon_minutes": row.get("horizon_minutes"),
        "target_return": _num_or_none(row.get("target_return")),
        "entry_price": _num_or_none(row.get("entry_price")),
        "profit_probability": _num_or_none(row.get("profit_probability")),
        "expected_return": _num_or_none(row.get("expected_return")),
        "risk_score": _num_or_none(row.get("risk_score")),
        "decision": row.get("decision"),
        "validation_due_at": row.get("validation_due_at"),
        "actual_return": _num_or_none(row.get("actual_return")),
        "actual_hit": row.get("actual_hit"),
        "actual_high": _num_or_none(row.get("actual_high")),
        "actual_low": _num_or_none(row.get("actual_low")),
        "actual_observed_until": row.get("actual_observed_until"),
        "actual_price": _num_or_none(row.get("actual_price")),
    }


def _profit_outcome_review_row(row: dict[str, Any]) -> dict[str, Any]:
    return {
        "model_run_id": row.get("model_run_id"),
        "profile": str(row.get("profile") or ""),
        "predicted_at": row.get("predicted_at"),
        "symbol": str(row.get("symbol") or "").strip().upper(),
        "market": str(row.get("market") or "").lower(),
        "name": row.get("name"),
        "horizon_minutes": row.get("horizon_minutes"),
        "target_return": _num_or_none(row.get("target_return")),
        "entry_price": _num_or_none(row.get("entry_price")),
        "profit_probability": _num_or_none(row.get("profit_probability")),
        "expected_return": _num_or_none(row.get("expected_return")),
        "risk_score": _num_or_none(row.get("risk_score")),
        "decision": row.get("decision"),
        "validation_due_at": row.get("validation_due_at"),
        "actual_high": _num_or_none(row.get("actual_high")),
        "actual_low": _num_or_none(row.get("actual_low")),
        "actual_price": _num_or_none(row.get("actual_price")),
        "actual_observed_until": row.get("actual_observed_until"),
        "max_return": _num_or_none(row.get("max_return")),
        "max_drawdown": _num_or_none(row.get("max_drawdown")),
        "actual_return": _num_or_none(row.get("actual_return")),
        "hit_target": bool(int(_num(row.get("hit_target")))),
    }


def _ident(value: str) -> str:
    if not value.replace("_", "").isalnum():
        raise ValueError(f"unsafe ClickHouse identifier: {value!r}")
    return value
