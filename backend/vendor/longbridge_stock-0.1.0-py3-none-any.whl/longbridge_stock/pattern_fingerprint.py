from __future__ import annotations

from dataclasses import dataclass
from statistics import median
from typing import Any, Iterable

import pandas as pd


@dataclass(frozen=True)
class PatternFingerprintConfig:
    window_days: int = 40
    forward_days: tuple[int, ...] = (5, 10, 20)
    path_samples: int = 8
    min_history_days: int = 20


def build_pattern_windows(frame: pd.DataFrame, config: PatternFingerprintConfig | None = None) -> pd.DataFrame:
    cfg = config or PatternFingerprintConfig()
    data = _prepare_frame(frame)
    if data.empty:
        return pd.DataFrame()
    rows: list[dict[str, Any]] = []
    for symbol, part in data.groupby("symbol", sort=False):
        part = part.sort_values("trade_date").reset_index(drop=True)
        if len(part) < cfg.window_days:
            continue
        for end_index in range(cfg.window_days - 1, len(part)):
            window = part.iloc[end_index - cfg.window_days + 1 : end_index + 1].reset_index(drop=True)
            row = _window_row(str(symbol), window, part, end_index, cfg)
            rows.append(row)
    return pd.DataFrame(rows)


def find_similar_patterns(
    target_row: pd.Series | dict[str, Any],
    windows: pd.DataFrame,
    *,
    top_n: int = 20,
    exclude_same_symbol: bool = True,
) -> list[dict[str, Any]]:
    if windows.empty:
        return []
    target = dict(target_row)
    target_fp = list(target.get("fingerprint") or [])
    if not target_fp:
        return []
    candidates = windows.copy()
    if exclude_same_symbol:
        candidates = candidates[candidates["symbol"].astype(str) != str(target.get("symbol"))]

    matches: list[dict[str, Any]] = []
    for row in candidates.to_dict("records"):
        fp = list(row.get("fingerprint") or [])
        if len(fp) != len(target_fp):
            continue
        distance = _weighted_distance(target_fp, fp)
        matches.append(_match_row(row, distance))
    matches.sort(key=lambda item: item["distance"])
    return matches[:top_n]


def summarize_match_outcomes(
    matches: Iterable[dict[str, Any]],
    *,
    forward_days: tuple[int, ...] = (5, 10, 20),
    up_threshold: float = 0.08,
    down_threshold: float = -0.08,
) -> dict[str, Any]:
    rows = list(matches)
    horizons: dict[str, dict[str, Any]] = {}
    for horizon in forward_days:
        max_key = f"future_max_return_{horizon}d"
        dd_key = f"future_max_drawdown_{horizon}d"
        final_key = f"future_final_return_{horizon}d"
        max_returns = [_num_or_none(row.get(max_key)) for row in rows]
        drawdowns = [_num_or_none(row.get(dd_key)) for row in rows]
        finals = [_num_or_none(row.get(final_key)) for row in rows]
        max_returns = [value for value in max_returns if value is not None]
        drawdowns = [value for value in drawdowns if value is not None]
        finals = [value for value in finals if value is not None]
        count = max(len(max_returns), len(drawdowns), len(finals))
        horizons[f"{horizon}d"] = {
            "sample_count": count,
            "up_probability": _round(_ratio([value >= up_threshold for value in max_returns])),
            "down_probability": _round(_ratio([value <= down_threshold for value in drawdowns])),
            "median_max_return": _round(median(max_returns)) if max_returns else None,
            "median_max_drawdown": _round(median(drawdowns)) if drawdowns else None,
            "median_final_return": _round(median(finals)) if finals else None,
        }
    return {"match_count": len(rows), "horizons": horizons}


def build_pattern_match_report(
    frame: pd.DataFrame,
    *,
    target_symbol: str,
    as_of: str | None = None,
    config: PatternFingerprintConfig | None = None,
    top_n: int = 20,
) -> dict[str, Any]:
    cfg = config or PatternFingerprintConfig()
    windows = build_pattern_windows(frame, cfg)
    if windows.empty:
        return {"target": {}, "matches": [], "outcome_summary": {"match_count": 0, "horizons": {}}}
    target_windows = windows[windows["symbol"].astype(str).str.upper() == target_symbol.strip().upper()]
    if as_of:
        target_windows = target_windows[target_windows["end_date"].astype(str) <= as_of]
    if target_windows.empty:
        return {"target": {}, "matches": [], "outcome_summary": {"match_count": 0, "horizons": {}}}
    target = target_windows.sort_values("end_date").iloc[-1]
    matches = find_similar_patterns(target, windows, top_n=top_n, exclude_same_symbol=True)
    summary = summarize_match_outcomes(matches, forward_days=cfg.forward_days)
    return {
        "target": _target_row(target.to_dict()),
        "matches": matches,
        "outcome_summary": summary,
    }


def _prepare_frame(frame: pd.DataFrame) -> pd.DataFrame:
    data = frame.copy()
    if data.empty:
        return data
    if "symbol" not in data.columns:
        data["symbol"] = ""
    data["trade_date"] = pd.to_datetime(data["trade_date"], errors="coerce")
    for column in ("open", "high", "low", "close", "volume", "turnover"):
        if column not in data.columns:
            data[column] = 0.0
        data[column] = pd.to_numeric(data[column], errors="coerce")
    data = data.dropna(subset=["symbol", "trade_date", "close"])
    data = data[data["close"] > 0]
    return data.sort_values(["symbol", "trade_date"]).reset_index(drop=True)


def _window_row(
    symbol: str,
    window: pd.DataFrame,
    full: pd.DataFrame,
    end_index: int,
    config: PatternFingerprintConfig,
) -> dict[str, Any]:
    close = list(window["close"].astype(float))
    volume = list(window["volume"].astype(float))
    first = close[0]
    last = close[-1]
    path = _sample_path([price / first - 1.0 for price in close], config.path_samples)
    volume_ratio = _safe_div(volume[-1], _mean(volume[:-1]))
    return_total = _safe_div(last, first)
    if return_total is not None:
        return_total -= 1.0
    max_drawdown = _max_drawdown(close)
    range_position = _range_position(window)
    ma5 = _mean(close[-5:])
    ma10 = _mean(close[-10:])
    ma20 = _mean(close[-20:])
    ma_slope = _safe_div(ma5, ma20)
    if ma_slope is not None:
        ma_slope -= 1.0
    ret5 = _trailing_return(close, 5)
    ret10 = _trailing_return(close, 10)
    ret20 = _trailing_return(close, 20)
    volatility = _volatility(close)
    base = {
        "symbol": symbol,
        "start_date": str(window.iloc[0]["trade_date"].date()),
        "end_date": str(window.iloc[-1]["trade_date"].date()),
        "latest_close": _round(last),
        "return_total": _round(return_total),
        "return_5d": _round(ret5),
        "return_10d": _round(ret10),
        "return_20d": _round(ret20),
        "max_drawdown": _round(max_drawdown),
        "volatility": _round(volatility),
        "range_position": _round(range_position),
        "volume_ratio": _round(volume_ratio),
        "ma_slope": _round(ma_slope),
        "pattern_type": _classify_pattern(return_total, ret5, ret10, ret20, max_drawdown, volume_ratio, ma_slope, range_position),
    }
    base["fingerprint"] = _fingerprint(base, path)
    base.update(_forward_outcomes(full, end_index, config.forward_days))
    return base


def _classify_pattern(
    return_total: float | None,
    ret5: float | None,
    ret10: float | None,
    ret20: float | None,
    max_drawdown: float | None,
    volume_ratio: float | None,
    ma_slope: float | None,
    range_position: float | None,
) -> str:
    total = return_total or 0.0
    r5 = ret5 or 0.0
    r10 = ret10 or 0.0
    dd = max_drawdown or 0.0
    vol = volume_ratio or 0.0
    slope = ma_slope or 0.0
    pos = range_position or 0.5
    if total >= 0.15 and (slope >= 0 or r5 >= 0):
        return "trend_run"
    if total >= 0.10 and dd <= -0.12 and r5 < 0:
        return "washout"
    if total <= -0.12 and slope < 0 and r10 < 0:
        return "breakdown"
    if dd <= -0.15 and r5 > 0.03:
        return "rebound"
    if total > 0.05 and vol >= 1.5 and pos < 0.45:
        return "distribution"
    return "range_build"


def _fingerprint(base: dict[str, Any], path: list[float]) -> list[float]:
    scalars = [
        base.get("return_total"),
        base.get("return_5d"),
        base.get("return_10d"),
        base.get("return_20d"),
        base.get("max_drawdown"),
        base.get("volatility"),
        base.get("range_position"),
        _logish(base.get("volume_ratio")),
        base.get("ma_slope"),
    ]
    return [_round(value) or 0.0 for value in scalars + path]


def _forward_outcomes(full: pd.DataFrame, end_index: int, forward_days: tuple[int, ...]) -> dict[str, Any]:
    close = float(full.iloc[end_index]["close"])
    output: dict[str, Any] = {}
    for horizon in forward_days:
        future = list(full.iloc[end_index + 1 : end_index + 1 + horizon]["close"].astype(float))
        if not future or close == 0:
            output[f"future_max_return_{horizon}d"] = None
            output[f"future_max_drawdown_{horizon}d"] = None
            output[f"future_final_return_{horizon}d"] = None
            continue
        returns = [price / close - 1.0 for price in future]
        output[f"future_max_return_{horizon}d"] = _round(max(returns))
        output[f"future_max_drawdown_{horizon}d"] = _round(min(returns))
        output[f"future_final_return_{horizon}d"] = _round(returns[-1])
    return output


def _match_row(row: dict[str, Any], distance: float) -> dict[str, Any]:
    keys = [
        "symbol",
        "start_date",
        "end_date",
        "pattern_type",
        "latest_close",
        "return_total",
        "max_drawdown",
        "volume_ratio",
        "future_max_return_3d",
        "future_max_drawdown_3d",
        "future_final_return_3d",
        "future_max_return_5d",
        "future_max_drawdown_5d",
        "future_final_return_5d",
        "future_max_return_10d",
        "future_max_drawdown_10d",
        "future_final_return_10d",
        "future_max_return_20d",
        "future_max_drawdown_20d",
        "future_final_return_20d",
    ]
    result = {key: _json_value(row.get(key)) for key in keys if key in row}
    result["distance"] = _round(distance)
    return result


def _target_row(row: dict[str, Any]) -> dict[str, Any]:
    keys = [
        "symbol",
        "start_date",
        "end_date",
        "pattern_type",
        "latest_close",
        "return_total",
        "return_5d",
        "return_10d",
        "return_20d",
        "max_drawdown",
        "volume_ratio",
        "ma_slope",
    ]
    return {key: _json_value(row.get(key)) for key in keys}


def _weighted_distance(left: list[float], right: list[float]) -> float:
    weights = [1.4, 1.0, 1.0, 1.0, 1.4, 0.8, 0.7, 0.8, 1.0] + [1.2] * max(0, len(left) - 9)
    total = 0.0
    weight_total = 0.0
    for index, (a, b) in enumerate(zip(left, right)):
        weight = weights[index] if index < len(weights) else 1.0
        total += weight * (float(a) - float(b)) ** 2
        weight_total += weight
    return (total / max(weight_total, 1.0)) ** 0.5


def _sample_path(values: list[float], samples: int) -> list[float]:
    if not values:
        return [0.0] * samples
    if samples <= 1:
        return [_round(values[-1]) or 0.0]
    output: list[float] = []
    last_index = len(values) - 1
    for sample_index in range(samples):
        index = round(sample_index * last_index / (samples - 1))
        output.append(_round(values[index]) or 0.0)
    return output


def _max_drawdown(values: list[float]) -> float | None:
    peak: float | None = None
    drawdown = 0.0
    for value in values:
        peak = value if peak is None else max(peak, value)
        if peak:
            drawdown = min(drawdown, value / peak - 1.0)
    return drawdown


def _range_position(window: pd.DataFrame) -> float | None:
    high = _max(window["high"])
    low = _min(window["low"])
    close = _num_or_none(window.iloc[-1]["close"])
    if high is None or low is None or close is None or high == low:
        return None
    return (close - low) / (high - low)


def _trailing_return(values: list[float], days: int) -> float | None:
    if len(values) <= days or values[-days - 1] == 0:
        return None
    return values[-1] / values[-days - 1] - 1.0


def _volatility(values: list[float]) -> float | None:
    returns: list[float] = []
    for index in range(1, len(values)):
        prev = values[index - 1]
        if prev:
            returns.append(values[index] / prev - 1.0)
    if not returns:
        return None
    mean = sum(returns) / len(returns)
    return (sum((value - mean) ** 2 for value in returns) / len(returns)) ** 0.5


def _mean(values: Iterable[Any]) -> float | None:
    cleaned = [_num_or_none(value) for value in values]
    cleaned = [value for value in cleaned if value is not None]
    return sum(cleaned) / len(cleaned) if cleaned else None


def _max(values: Iterable[Any]) -> float | None:
    cleaned = [_num_or_none(value) for value in values]
    cleaned = [value for value in cleaned if value is not None]
    return max(cleaned) if cleaned else None


def _min(values: Iterable[Any]) -> float | None:
    cleaned = [_num_or_none(value) for value in values]
    cleaned = [value for value in cleaned if value is not None]
    return min(cleaned) if cleaned else None


def _safe_div(left: float | None, right: float | None) -> float | None:
    if left is None or right is None or right == 0:
        return None
    return left / right


def _logish(value: Any) -> float | None:
    numeric = _num_or_none(value)
    if numeric is None:
        return None
    if numeric >= 1:
        return numeric - 1.0
    return 1.0 - (1.0 / numeric) if numeric > 0 else -1.0


def _ratio(values: list[bool]) -> float | None:
    if not values:
        return None
    return sum(1 for value in values if value) / len(values)


def _num_or_none(value: Any) -> float | None:
    if value is None or pd.isna(value):
        return None
    return float(value)


def _round(value: Any, digits: int = 4) -> float | None:
    numeric = _num_or_none(value)
    return round(numeric, digits) if numeric is not None else None


def _json_value(value: Any) -> Any:
    if value is None or pd.isna(value):
        return None
    if isinstance(value, float):
        return _round(value)
    if hasattr(value, "item"):
        return value.item()
    return value
