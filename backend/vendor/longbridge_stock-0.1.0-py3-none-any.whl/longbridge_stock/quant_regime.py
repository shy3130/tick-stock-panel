from __future__ import annotations

import math
from typing import Any

import numpy as np

try:  # pragma: no cover - exercised when sklearn is installed in the runtime.
    from sklearn.ensemble import IsolationForest
    from sklearn.mixture import GaussianMixture
    from sklearn.preprocessing import StandardScaler
except Exception:  # pragma: no cover - lightweight fallback for minimal installs.
    IsolationForest = None
    GaussianMixture = None
    StandardScaler = None


SUPPORTIVE_PRICE_REGIMES = {"strong_trend", "steady_uptrend"}
WEAK_PRICE_REGIMES = {"downtrend", "distribution", "high_volatility_weak"}
SUPPORTIVE_CAPITAL_REGIMES = {"strong_inflow", "moderate_inflow", "accumulation"}
WEAK_CAPITAL_REGIMES = {"strong_outflow", "moderate_outflow", "distribution"}


PRICE_FEATURES = (
    "return_5d",
    "return_10d",
    "return_20d",
    "return_60d",
    "close_to_ma5",
    "close_to_ma10",
    "close_to_ma20",
    "close_to_ma60",
    "ma5_slope_3d",
    "ma20_slope_3d",
    "trend_alignment_5_10_20_60",
    "close_position",
    "volatility_5d",
    "volatility_20d",
)
CAPITAL_FEATURES = (
    "total_net",
    "large_net",
    "capital_net_5d",
    "capital_net_10d",
    "capital_net_20d",
    "capital_net_60d",
    "large_capital_net_5d",
    "large_capital_net_10d",
    "large_capital_net_20d",
    "large_capital_net_60d",
)
VOLATILITY_FEATURES = ("volatility_5d", "volatility_10d", "volatility_20d", "volatility_60d", "amplitude", "turnover_ratio_5d", "turnover_ratio_20d")
ANOMALY_FEATURES = (
    "return_5d",
    "return_10d",
    "return_20d",
    "return_60d",
    "close_position",
    "short_mid_return_spread",
    "ma5_ma20_spread",
    "volatility_20d",
    "short_term_volatility_acceleration",
    "turnover_ratio_5d",
    "turnover_ratio_20d",
    "short_term_turnover_acceleration",
    "total_net",
    "large_net",
)


def summarize_daily_quant_regime(row: dict[str, Any]) -> dict[str, Any]:
    """Summarize one row with the algorithmic regime pipeline.

    Candidate-pool production should call ``summarize_daily_quant_regimes`` so
    GMM/IsolationForest can use the whole cross-section. This wrapper keeps the
    original single-row interface for tests and small tools.
    """

    return summarize_daily_quant_regimes({"__single__": row}).get("__SINGLE__", _missing_regime(row))


def summarize_daily_quant_regimes(rows_by_symbol: dict[str, dict[str, Any]]) -> dict[str, dict[str, Any]]:
    normalized_input = {
        str(symbol).upper(): row
        for symbol, row in rows_by_symbol.items()
        if symbol and isinstance(row, dict)
    }
    symbols = list(normalized_input)
    if not symbols:
        return {}

    normalized_rows = {symbol: _normalize_row(normalized_input[symbol]) for symbol in symbols}
    fit_rows = {**normalized_rows, **_prototype_rows()}

    price_model = _fit_gmm_context(
        fit_rows,
        PRICE_FEATURES,
        component_count=3,
        score_fn=lambda center: (
            center[0] * 0.22
            + center[1] * 0.18
            + center[2] * 0.18
            + center[3] * 0.10
            + (center[4] - 1.0) * 0.32
            + (center[5] - 1.0) * 0.28
            + (center[6] - 1.0) * 0.24
            + (center[7] - 1.0) * 0.14
            + center[8] * 0.16
            + center[9] * 0.10
            + center[10] * 0.18
            + center[11] * 0.10
            - center[12] * 0.20
            - center[13] * 0.30
        ),
    )
    capital_model = _fit_gmm_context(
        fit_rows,
        CAPITAL_FEATURES,
        component_count=3,
        transform=_signed_log_matrix,
        score_fn=lambda center: float(np.nanmean(center)),
    )
    volatility_model = _fit_gmm_context(
        fit_rows,
        VOLATILITY_FEATURES,
        component_count=3,
        score_fn=lambda center: center[0] * 0.24 + center[1] * 0.18 + center[2] * 0.18 + center[3] * 0.10 + center[4] * 0.18 + center[5] * 0.06 + center[6] * 0.06,
    )
    anomaly_model = _fit_isolation_context(fit_rows, ANOMALY_FEATURES)

    output: dict[str, dict[str, Any]] = {}
    for symbol in symbols:
        row = normalized_rows[symbol]
        price_rank, price_prob = _predict_gmm_rank(price_model, symbol)
        capital_rank, capital_prob = _predict_gmm_rank(capital_model, symbol)
        volatility_rank, volatility_prob = _predict_gmm_rank(volatility_model, symbol)
        anomaly_score, is_anomaly = _predict_anomaly(anomaly_model, symbol)
        trend_score = kalman_trend_score(row)
        price_regime = _price_regime_from_algorithm(price_rank, trend_score)
        capital_regime = _capital_regime_from_algorithm(capital_rank, row)
        volatility_regime = _volatility_regime_from_algorithm(volatility_rank)
        anomaly = _anomaly_from_algorithm(
            row,
            anomaly_score,
            is_anomaly,
            price_rank=price_rank,
            capital_rank=capital_rank,
            volatility_rank=volatility_rank,
        )
        output[symbol] = {
            "algorithm": "kalman_gmm_isolation_forest",
            "price_regime": price_regime,
            "capital_regime": capital_regime,
            "volatility_regime": volatility_regime,
            "anomaly": anomaly,
            "kalman_trend_score": round(trend_score, 6),
            "price_cluster_rank": price_rank,
            "price_cluster_probability": round(price_prob, 6),
            "capital_cluster_rank": capital_rank,
            "capital_cluster_probability": round(capital_prob, 6),
            "volatility_cluster_rank": volatility_rank,
            "volatility_cluster_probability": round(volatility_prob, 6),
            "isolation_score": round(anomaly_score, 6),
            **row,
        }
    return output


def kalman_trend_score(row: dict[str, Any]) -> float:
    """Estimate trend slope from synthetic multi-horizon observations."""

    return_5d = _num(row.get("return_5d"), 0.0)
    return_10d = _num(row.get("return_10d"), return_5d)
    return_20d = _num(row.get("return_20d"), 0.0)
    return_60d = _num(row.get("return_60d"), return_20d)
    close_to_ma5 = _num(row.get("close_to_ma5"), 1.0) - 1.0
    close_to_ma10 = _num(row.get("close_to_ma10"), 1.0) - 1.0
    close_to_ma20 = _num(row.get("close_to_ma20"), 1.0) - 1.0
    close_to_ma60 = _num(row.get("close_to_ma60"), 1.0) - 1.0
    ma5_slope = _num(row.get("ma5_slope_3d"), 0.0)
    ma20_slope = _num(row.get("ma20_slope_3d"), 0.0)
    observations = np.array(
        [
            return_60d * 0.35,
            return_20d,
            return_10d + close_to_ma20,
            return_5d + close_to_ma10,
            return_5d + close_to_ma5 + ma5_slope,
            return_10d + close_to_ma5 + close_to_ma60 + ma20_slope,
        ],
        dtype=float,
    )
    x = np.array([observations[0], 0.0], dtype=float)
    covariance = np.eye(2) * 0.10
    transition = np.array([[1.0, 1.0], [0.0, 1.0]], dtype=float)
    observation = np.array([[1.0, 0.0]], dtype=float)
    process_noise = np.eye(2) * 0.0025
    observation_noise = np.array([[0.010]], dtype=float)
    for value in observations[1:]:
        x = transition @ x
        covariance = transition @ covariance @ transition.T + process_noise
        residual = np.array([value], dtype=float) - observation @ x
        residual_covariance = observation @ covariance @ observation.T + observation_noise
        gain = covariance @ observation.T @ np.linalg.inv(residual_covariance)
        x = x + (gain @ residual).reshape(2)
        covariance = (np.eye(2) - gain @ observation) @ covariance
    short_mid_spread = _num(row.get("short_mid_return_spread"), return_5d - return_20d)
    ma5_ma20_spread = _num(row.get("ma5_ma20_spread"), _num(row.get("close_to_ma5"), 1.0) - _num(row.get("close_to_ma20"), 1.0))
    short_rollover = min(0.0, return_5d) * 0.12 + min(0.0, short_mid_spread) * 0.08 + min(0.0, ma5_ma20_spread) * 0.08 + ma5_slope * 0.20
    return float(x[1] + short_rollover)


def quant_regime_score_adjustment(regime: dict[str, Any], *, base_score: float = 0.0) -> dict[str, Any]:
    if not isinstance(regime, dict) or not regime:
        return {"penalty": 0.0, "bonus": 0.0, "action": "normal", "label": "missing_regime"}

    price_regime = str(regime.get("price_regime") or "neutral")
    capital_regime = str(regime.get("capital_regime") or "missing")
    volatility_regime = str(regime.get("volatility_regime") or "normal")
    anomaly = str(regime.get("anomaly") or "none")
    trend_score = _num(regime.get("kalman_trend_score"), 0.0)
    isolation_score = _num(regime.get("isolation_score"), 0.0)

    penalty = 0.0
    bonus = 0.0
    if price_regime in SUPPORTIVE_PRICE_REGIMES:
        bonus += 2.0 if price_regime == "strong_trend" else 1.0
    elif price_regime in WEAK_PRICE_REGIMES:
        penalty += 5.0 if price_regime == "high_volatility_weak" else 4.0

    if capital_regime in SUPPORTIVE_CAPITAL_REGIMES:
        bonus += 2.0 if capital_regime == "strong_inflow" else 1.0
    elif capital_regime in WEAK_CAPITAL_REGIMES:
        penalty += 5.0 if capital_regime == "strong_outflow" else 3.0

    if volatility_regime == "extreme":
        penalty += 5.0
    elif volatility_regime == "high":
        penalty += 2.0
    elif volatility_regime == "low" and price_regime in SUPPORTIVE_PRICE_REGIMES:
        bonus += 0.5

    if anomaly == "spike_fade":
        penalty += 7.0
    elif anomaly == "overextended":
        penalty += 5.0
    elif anomaly == "price_capital_divergence":
        penalty += 4.0

    if trend_score > 0:
        bonus += min(1.0, abs(trend_score) * 8.0)
    else:
        penalty += min(2.0, abs(trend_score) * 16.0)
    if isolation_score < -0.04:
        penalty += min(2.0, abs(isolation_score) * 10.0)

    penalty = round(max(0.0, min(18.0, penalty)), 3)
    bonus = round(max(0.0, min(5.0, bonus)), 3)
    action = "normal"
    if penalty >= 9.5 and base_score < 86.0:
        action = "observe_only"
    elif penalty >= 6.0:
        action = "downgrade"
    elif bonus >= 3.0 and penalty == 0:
        action = "upgrade"

    return {
        "label": quant_regime_label(regime),
        "penalty": penalty,
        "bonus": bonus,
        "action": action,
        "price_regime": price_regime,
        "capital_regime": capital_regime,
        "volatility_regime": volatility_regime,
        "anomaly": anomaly,
        "algorithm": str(regime.get("algorithm") or "unknown"),
    }


def quant_regime_label(regime: dict[str, Any]) -> str:
    price = str(regime.get("price_regime") or "neutral")
    capital = str(regime.get("capital_regime") or "missing")
    anomaly = str(regime.get("anomaly") or "none")
    if anomaly != "none":
        return {
            "spike_fade": "放量冲高回落",
            "overextended": "短期过热",
            "price_capital_divergence": "价涨资金背离",
        }.get(anomaly, "异常波动")
    if price in SUPPORTIVE_PRICE_REGIMES and capital in SUPPORTIVE_CAPITAL_REGIMES:
        return "趋势资金共振"
    if price in WEAK_PRICE_REGIMES and capital in WEAK_CAPITAL_REGIMES:
        return "趋势资金转弱"
    if price in SUPPORTIVE_PRICE_REGIMES:
        return "趋势偏强"
    if capital in SUPPORTIVE_CAPITAL_REGIMES:
        return "资金偏强"
    if price in WEAK_PRICE_REGIMES:
        return "趋势转弱"
    if capital in WEAK_CAPITAL_REGIMES:
        return "资金转弱"
    return "中性观察"


def quant_regime_text(regime: dict[str, Any]) -> str:
    if not isinstance(regime, dict) or not regime:
        return "-"
    label = quant_regime_label(regime)
    price = _cn_price(str(regime.get("price_regime") or "neutral"))
    capital = _cn_capital(str(regime.get("capital_regime") or "missing"))
    volatility = _cn_volatility(str(regime.get("volatility_regime") or "normal"))
    anomaly = str(regime.get("anomaly") or "none")
    trend = _num(regime.get("kalman_trend_score"), None)
    parts = [label, f"价格{price}", f"资金{capital}", f"波动{volatility}"]
    if trend is not None:
        parts.append(f"Kalman趋势 {trend * 100:+.1f}%")
    if anomaly != "none":
        parts.append(_cn_anomaly(anomaly))
    return "；".join(parts)


def _fit_gmm_context(
    rows: dict[str, dict[str, Any]],
    features: tuple[str, ...],
    *,
    component_count: int,
    score_fn: Any,
    transform: Any | None = None,
) -> dict[str, Any]:
    symbols = list(rows)
    matrix = np.array([[rows[symbol].get(feature) for feature in features] for symbol in symbols], dtype=float)
    if transform:
        matrix = transform(matrix)
    matrix = np.nan_to_num(matrix, nan=0.0, posinf=0.0, neginf=0.0)
    components = max(1, min(component_count, len(symbols)))
    if GaussianMixture is not None and StandardScaler is not None and components >= 2:
        scaler = StandardScaler()
        scaled = scaler.fit_transform(matrix)
        model = GaussianMixture(n_components=components, random_state=42, covariance_type="full", reg_covar=1e-5)
        labels = model.fit_predict(scaled)
        probabilities = model.predict_proba(scaled)
        centers = scaler.inverse_transform(model.means_)
    else:
        labels, centers = _kmeans(matrix, components)
        probabilities = _distance_probabilities(matrix, centers)
    center_scores = np.array([score_fn(center) for center in centers], dtype=float)
    order = np.argsort(center_scores)
    cluster_rank = {int(cluster): int(rank) for rank, cluster in enumerate(order)}
    return {
        "symbols": symbols,
        "labels": labels,
        "probabilities": probabilities,
        "cluster_rank": cluster_rank,
    }


def _fit_isolation_context(rows: dict[str, dict[str, Any]], features: tuple[str, ...]) -> dict[str, Any]:
    filtered_rows = {symbol: row for symbol, row in rows.items() if symbol != "__proto_spike_fade__"}
    symbols = list(filtered_rows)
    matrix = np.array([[filtered_rows[symbol].get(feature) for feature in features] for symbol in symbols], dtype=float)
    matrix[:, -2:] = _signed_log_matrix(matrix[:, -2:])
    matrix = np.nan_to_num(matrix, nan=0.0, posinf=0.0, neginf=0.0)
    if IsolationForest is not None and StandardScaler is not None and len(symbols) >= 4:
        scaled = StandardScaler().fit_transform(matrix)
        model = IsolationForest(n_estimators=80, contamination=0.20, random_state=42)
        model.fit(scaled)
        scores = model.decision_function(scaled)
        labels = model.predict(scaled)
    else:
        scores = _robust_anomaly_scores(matrix)
        labels = np.where(scores < -0.20, -1, 1)
    return {"symbols": symbols, "scores": scores, "labels": labels}


def _predict_gmm_rank(context: dict[str, Any], symbol: str) -> tuple[int, float]:
    index = context["symbols"].index(symbol)
    label = int(context["labels"][index])
    rank = int(context["cluster_rank"].get(label, 0))
    probability = float(np.max(context["probabilities"][index]))
    return rank, probability


def _predict_anomaly(context: dict[str, Any], symbol: str) -> tuple[float, bool]:
    index = context["symbols"].index(symbol)
    score = float(context["scores"][index])
    return score, int(context["labels"][index]) == -1


def _price_regime_from_algorithm(rank: int, trend_score: float) -> str:
    if rank >= 2 or trend_score >= 0.012:
        return "strong_trend" if trend_score >= 0 else "steady_uptrend"
    if rank == 1:
        if trend_score <= -0.004:
            return "downtrend"
        return "neutral" if trend_score >= 0 else "distribution"
    return "downtrend" if trend_score < 0 else "high_volatility_weak"


def _capital_regime_from_algorithm(rank: int, row: dict[str, Any]) -> str:
    values = [row.get(key) for key in CAPITAL_FEATURES if row.get(key) is not None]
    if not values:
        return "missing"
    direction = float(np.nanmean(_signed_log_matrix(np.array(values, dtype=float))))
    if rank >= 2:
        return "strong_inflow" if direction >= 0 else "accumulation"
    if rank == 1:
        return "moderate_inflow" if direction >= 0 else "moderate_outflow"
    return "distribution" if direction >= 0 else "strong_outflow"


def _volatility_regime_from_algorithm(rank: int) -> str:
    return ["low", "normal", "high"][max(0, min(2, int(rank)))]


def _anomaly_from_algorithm(
    row: dict[str, Any],
    anomaly_score: float,
    is_anomaly: bool,
    *,
    price_rank: int,
    capital_rank: int,
    volatility_rank: int,
) -> str:
    features = {
        "spike_fade": max(_num(row.get("turnover_ratio_5d"), 1.0), _num(row.get("turnover_ratio_20d"), 1.0)) * max(0.0, _num(row.get("return_5d"), 0.0)) * max(0.0, 1.0 - _num(row.get("close_position"), 0.5)),
        "overextended": max(0.0, _num(row.get("return_20d"), 0.0)) * max(0.0, _num(row.get("volatility_20d"), 0.0)),
        "short_term_rollover": max(0.0, -_num(row.get("short_mid_return_spread"), 0.0)) * max(0.0, -_num(row.get("ma5_ma20_spread"), 0.0)),
        "price_capital_divergence": max(0.0, _num(row.get("return_5d"), 0.0)) * max(0.0, -_num(row.get("total_net"), 0.0) - _num(row.get("large_net"), 0.0)) / 10_000_000.0,
    }
    strongest = max(features, key=features.get)
    threshold = 0.012 if strongest == "short_term_rollover" else 0.08
    cluster_conflict = price_rank >= 2 and capital_rank <= 0 and volatility_rank >= 2
    if features[strongest] >= threshold:
        return strongest
    if not is_anomaly and not cluster_conflict and anomaly_score >= -0.03:
        return "none"
    return max(features, key=features.get)


def _normalize_row(row: dict[str, Any]) -> dict[str, Any]:
    return_5d = _num(row.get("return_5d"), _num(row.get("ret_5d"), 0.0))
    return_20d = _num(row.get("return_20d"), _num(row.get("ret_20d"), 0.0))
    close_to_ma20 = _ma_ratio(row.get("close_to_ma20"), 1.0)
    return_10d = _num(row.get("return_10d"), _num(row.get("ret_10d"), (return_5d + return_20d) / 2.0))
    return_60d = _num(row.get("return_60d"), _num(row.get("ret_60d"), return_20d))
    close_to_ma5 = _ma_ratio(row.get("close_to_ma5"), close_to_ma20)
    close_to_ma10 = _ma_ratio(row.get("close_to_ma10"), close_to_ma20)
    close_to_ma60 = _ma_ratio(row.get("close_to_ma60"), close_to_ma20)
    volatility_20d = _num(row.get("volatility_20d"), _num(row.get("volatility_20"), 0.0))
    turnover_ratio_20d = _num(row.get("turnover_ratio_20d"), _num(row.get("turnover_ratio_20"), 1.0))
    return {
        "return_5d": return_5d,
        "return_10d": return_10d,
        "return_20d": return_20d,
        "return_60d": return_60d,
        "close_to_ma5": close_to_ma5,
        "close_to_ma10": close_to_ma10,
        "close_to_ma20": close_to_ma20,
        "close_to_ma60": close_to_ma60,
        "ma5_slope_3d": _num(row.get("ma5_slope_3d"), 0.0),
        "ma10_slope_3d": _num(row.get("ma10_slope_3d"), 0.0),
        "ma20_slope_3d": _num(row.get("ma20_slope_3d"), 0.0),
        "ma60_slope_3d": _num(row.get("ma60_slope_3d"), 0.0),
        "short_mid_return_spread": _num(row.get("short_mid_return_spread"), return_5d - return_20d),
        "short_long_return_spread": _num(row.get("short_long_return_spread"), return_5d - return_60d),
        "ma5_ma20_spread": _num(row.get("ma5_ma20_spread"), close_to_ma5 - close_to_ma20),
        "ma10_ma60_spread": _num(row.get("ma10_ma60_spread"), close_to_ma10 - close_to_ma60),
        "trend_alignment_5_10_20_60": _num(row.get("trend_alignment_5_10_20_60"), float(np.mean([close_to_ma5 > 1.0, close_to_ma10 > 1.0, close_to_ma20 > 1.0, close_to_ma60 > 1.0]))),
        "close_position": _num(row.get("close_position"), _num(row.get("close_pos"), 0.5)),
        "volatility_5d": _num(row.get("volatility_5d"), _num(row.get("volatility_5"), volatility_20d)),
        "volatility_10d": _num(row.get("volatility_10d"), _num(row.get("volatility_10"), volatility_20d)),
        "volatility_20d": volatility_20d,
        "volatility_60d": _num(row.get("volatility_60d"), _num(row.get("volatility_60"), volatility_20d)),
        "turnover_ratio_5d": _num(row.get("turnover_ratio_5d"), _num(row.get("turnover_ratio_5"), turnover_ratio_20d)),
        "turnover_ratio_10d": _num(row.get("turnover_ratio_10d"), _num(row.get("turnover_ratio_10"), turnover_ratio_20d)),
        "turnover_ratio_20d": turnover_ratio_20d,
        "turnover_ratio_60d": _num(row.get("turnover_ratio_60d"), _num(row.get("turnover_ratio_60"), turnover_ratio_20d)),
        "short_term_turnover_acceleration": _num(row.get("short_term_turnover_acceleration"), _num(row.get("turnover_ratio_5d"), _num(row.get("turnover_ratio_5"), turnover_ratio_20d)) - turnover_ratio_20d),
        "short_term_volatility_acceleration": _num(row.get("short_term_volatility_acceleration"), _num(row.get("volatility_5d"), _num(row.get("volatility_5"), volatility_20d)) - volatility_20d),
        "amplitude": _num(row.get("amplitude"), volatility_20d * 2.0),
        "total_net": _optional_num(row.get("total_net")),
        "large_net": _optional_num(row.get("large_net")),
        "capital_net_5d": _optional_num(row.get("capital_net_5d")),
        "capital_net_10d": _optional_num(row.get("capital_net_10d")),
        "capital_net_20d": _optional_num(row.get("capital_net_20d")),
        "capital_net_60d": _optional_num(row.get("capital_net_60d")),
        "large_capital_net_5d": _optional_num(row.get("large_capital_net_5d")),
        "large_capital_net_10d": _optional_num(row.get("large_capital_net_10d")),
        "large_capital_net_20d": _optional_num(row.get("large_capital_net_20d")),
        "large_capital_net_60d": _optional_num(row.get("large_capital_net_60d")),
    }


def _missing_regime(row: dict[str, Any]) -> dict[str, Any]:
    normalized = _normalize_row(row)
    return {"algorithm": "missing", "price_regime": "neutral", "capital_regime": "missing", "volatility_regime": "normal", "anomaly": "none", **normalized}


def _prototype_rows() -> dict[str, dict[str, Any]]:
    return {
        "__proto_strong__": _normalize_row({"return_5d": 0.05, "return_10d": 0.09, "return_20d": 0.18, "return_60d": 0.32, "close_to_ma5": 1.03, "close_to_ma10": 1.05, "close_to_ma20": 1.08, "close_to_ma60": 1.15, "ma5_slope_3d": 0.02, "ma20_slope_3d": 0.012, "trend_alignment_5_10_20_60": 1.0, "close_position": 0.78, "volatility_5d": 0.022, "volatility_20d": 0.025, "turnover_ratio_5d": 1.5, "turnover_ratio_20d": 1.4, "total_net": 40_000_000, "large_net": 20_000_000, "capital_net_5d": 25_000_000, "capital_net_10d": 36_000_000, "capital_net_20d": 60_000_000, "capital_net_60d": 120_000_000, "large_capital_net_5d": 15_000_000, "large_capital_net_10d": 24_000_000, "large_capital_net_20d": 42_000_000, "large_capital_net_60d": 80_000_000}),
        "__proto_neutral__": _normalize_row({"return_5d": 0.0, "return_10d": 0.0, "return_20d": 0.0, "return_60d": 0.0, "close_to_ma5": 1.0, "close_to_ma10": 1.0, "close_to_ma20": 1.0, "close_to_ma60": 1.0, "trend_alignment_5_10_20_60": 0.5, "close_position": 0.50, "volatility_5d": 0.030, "volatility_20d": 0.030, "turnover_ratio_5d": 1.0, "turnover_ratio_20d": 1.0, "total_net": 0, "large_net": 0, "capital_net_5d": 0, "capital_net_10d": 0, "capital_net_20d": 0, "capital_net_60d": 0, "large_capital_net_5d": 0, "large_capital_net_10d": 0, "large_capital_net_20d": 0, "large_capital_net_60d": 0}),
        "__proto_weak__": _normalize_row({"return_5d": -0.06, "return_10d": -0.10, "return_20d": -0.16, "return_60d": -0.24, "close_to_ma5": 0.96, "close_to_ma10": 0.94, "close_to_ma20": 0.92, "close_to_ma60": 0.88, "ma5_slope_3d": -0.02, "ma20_slope_3d": -0.012, "trend_alignment_5_10_20_60": 0.0, "close_position": 0.20, "volatility_5d": 0.070, "volatility_20d": 0.060, "turnover_ratio_5d": 2.3, "turnover_ratio_20d": 2.0, "total_net": -40_000_000, "large_net": -20_000_000, "capital_net_5d": -25_000_000, "capital_net_10d": -36_000_000, "capital_net_20d": -60_000_000, "capital_net_60d": -120_000_000, "large_capital_net_5d": -15_000_000, "large_capital_net_10d": -24_000_000, "large_capital_net_20d": -42_000_000, "large_capital_net_60d": -80_000_000}),
        "__proto_spike_fade__": _normalize_row({"return_5d": 0.16, "return_10d": 0.20, "return_20d": 0.24, "return_60d": 0.30, "close_to_ma5": 1.04, "close_to_ma10": 1.06, "close_to_ma20": 1.08, "close_to_ma60": 1.12, "ma5_slope_3d": -0.01, "trend_alignment_5_10_20_60": 1.0, "close_position": 0.35, "volatility_5d": 0.075, "volatility_20d": 0.055, "turnover_ratio_5d": 5.0, "turnover_ratio_20d": 4.5, "total_net": -8_000_000, "large_net": -4_000_000}),
    }


def _signed_log_matrix(matrix: np.ndarray) -> np.ndarray:
    values = np.asarray(matrix, dtype=float)
    return np.sign(values) * np.log1p(np.abs(values))


def _kmeans(matrix: np.ndarray, components: int) -> tuple[np.ndarray, np.ndarray]:
    if components <= 1:
        return np.zeros(len(matrix), dtype=int), np.array([np.nanmean(matrix, axis=0)])
    centers = matrix[np.linspace(0, len(matrix) - 1, components).astype(int)].copy()
    labels = np.zeros(len(matrix), dtype=int)
    for _ in range(20):
        distances = np.linalg.norm(matrix[:, None, :] - centers[None, :, :], axis=2)
        labels = np.argmin(distances, axis=1)
        for cluster in range(components):
            if np.any(labels == cluster):
                centers[cluster] = np.nanmean(matrix[labels == cluster], axis=0)
    return labels, centers


def _distance_probabilities(matrix: np.ndarray, centers: np.ndarray) -> np.ndarray:
    distances = np.linalg.norm(matrix[:, None, :] - centers[None, :, :], axis=2)
    inv = 1.0 / (distances + 1e-6)
    return inv / inv.sum(axis=1, keepdims=True)


def _robust_anomaly_scores(matrix: np.ndarray) -> np.ndarray:
    median = np.nanmedian(matrix, axis=0)
    mad = np.nanmedian(np.abs(matrix - median), axis=0) + 1e-6
    z = np.abs((matrix - median) / mad)
    return -np.nanmean(z, axis=1) / 10.0


def _cn_price(value: str) -> str:
    return {
        "strong_trend": "强趋势",
        "steady_uptrend": "稳步上行",
        "downtrend": "下行",
        "distribution": "派发",
        "high_volatility_weak": "高波动转弱",
        "neutral": "中性",
    }.get(value, value)


def _cn_capital(value: str) -> str:
    return {
        "strong_inflow": "强流入",
        "moderate_inflow": "温和流入",
        "accumulation": "承接",
        "strong_outflow": "强流出",
        "moderate_outflow": "温和流出",
        "distribution": "派发",
        "mixed": "分歧",
        "missing": "缺失",
    }.get(value, value)


def _cn_volatility(value: str) -> str:
    return {"extreme": "极高", "high": "偏高", "low": "低", "normal": "正常"}.get(value, value)


def _cn_anomaly(value: str) -> str:
    return {
        "spike_fade": "放量冲高回落",
        "overextended": "短期过热",
        "price_capital_divergence": "价涨资金背离",
    }.get(value, value)


def _ma_ratio(value: Any, default: float = 1.0) -> float:
    number = _num(value, default)
    if number is None:
        return default
    if -0.8 < number < 0.8:
        return 1.0 + number
    return number


def _num(value: Any, default: float | None = 0.0) -> float | None:
    try:
        if value is None:
            return default
        number = float(value)
    except (TypeError, ValueError):
        return default
    if math.isnan(number):
        return default
    return number


def _optional_num(value: Any) -> float | None:
    return _num(value, None)
