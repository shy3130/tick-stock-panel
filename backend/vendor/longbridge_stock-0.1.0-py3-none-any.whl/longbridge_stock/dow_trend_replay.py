from __future__ import annotations

from dataclasses import dataclass, replace
from datetime import date, datetime
from math import log
from typing import Iterable, Literal, Mapping, Sequence

from longbridge_stock.dow_pivot_detector import (
    CausalPivotDetector,
    PivotDetectorConfig,
)


PivotKind = Literal["HIGH", "LOW"]
LineSide = Literal["SUPPORT", "RESISTANCE"]
LineRole = Literal["MAIN", "ACCELERATION"]
ChannelRegime = Literal[
    "UNKNOWN",
    "UP_CHANNEL",
    "DOWN_CHANNEL",
    "UP_TRANSITION",
    "DOWN_TRANSITION",
    "BOX",
]


@dataclass(frozen=True)
class Bar:
    index: int
    timestamp: date | datetime
    open: float
    high: float
    low: float
    close: float
    volume: float

    @classmethod
    def from_mapping(cls, index: int, value: Mapping[str, object]) -> "Bar":
        timestamp = value.get("date", value.get("timestamp"))
        if not isinstance(timestamp, (date, datetime)):
            raise ValueError("bar date/timestamp must be a date or datetime")
        return cls(
            index=index,
            timestamp=timestamp,
            open=float(value["open"]),
            high=float(value["high"]),
            low=float(value["low"]),
            close=float(value["close"]),
            volume=float(value.get("volume", 0.0)),
        )


@dataclass(frozen=True)
class AnchorOverride:
    index: int
    kind: PivotKind
    price: float
    confirmed_index: int | None = None

    def confirmation_index(self) -> int:
        return self.index if self.confirmed_index is None else self.confirmed_index


@dataclass(frozen=True)
class Pivot:
    id: str
    kind: PivotKind
    bar_index: int
    price: float
    confirmed_index: int


@dataclass(frozen=True)
class TrendLine:
    id: str
    side: LineSide
    role: LineRole
    generation: int
    first_pivot_id: str
    second_pivot_id: str
    anchor_indexes: tuple[int, int]
    anchor_prices: tuple[float, float]
    created_index: int
    touch_count: int = 2
    invalidated_index: int | None = None
    controls_signals: bool = True

    def value_at(self, bar_index: int) -> float:
        first_index, second_index = self.anchor_indexes
        first_price, second_price = self.anchor_prices
        distance = second_index - first_index
        if distance <= 0:
            raise ValueError("trendline anchors must be in chronological order")
        slope = (second_price - first_price) / distance
        return first_price + slope * (bar_index - first_index)


@dataclass(frozen=True)
class LineEvent:
    event_type: str
    bar_index: int
    line_id: str
    reason: str


@dataclass(frozen=True)
class TradeSignal:
    side: Literal["BUY", "SELL"]
    bar_index: int
    price: float
    reason: str
    confidence: str
    line_id: str | None = None
    first_cross_index: int | None = None
    volume_ratio: float | None = None
    pattern: str | None = None


@dataclass(frozen=True)
class BoxStructure:
    id: str
    start_index: int
    created_index: int
    top: float
    bottom: float
    broken_index: int | None = None
    break_side: Literal["UP", "DOWN"] | None = None


@dataclass(frozen=True)
class PullbackReview:
    id: str
    line_id: str
    side: LineSide
    break_index: int
    outcome: Literal[
        "OBSERVING",
        "STRONG_RECLAIM",
        "WEAK_FAILURE",
        "SIDEWAYS_BOX",
        "NO_RECLAIM",
    ] = "OBSERVING"
    resolved_index: int | None = None


@dataclass(frozen=True)
class RegimeEvent:
    bar_index: int
    previous: ChannelRegime
    current: ChannelRegime
    reason: str


@dataclass(frozen=True)
class ReplayFrame:
    bar_index: int
    active_support_line_id: str | None
    active_resistance_line_id: str | None
    active_box_id: str | None = None
    active_pullback_id: str | None = None
    regime: ChannelRegime = "UNKNOWN"


@dataclass(frozen=True)
class ReplayResult:
    bars: tuple[Bar, ...]
    pivots: tuple[Pivot, ...]
    lines: tuple[TrendLine, ...]
    boxes: tuple[BoxStructure, ...]
    pullbacks: tuple[PullbackReview, ...]
    regime_events: tuple[RegimeEvent, ...]
    frames: tuple[ReplayFrame, ...]
    events: tuple[LineEvent, ...]
    signals: tuple[TradeSignal, ...]


class DowTrendReplayEngine:
    def __init__(
        self,
        *,
        pivot_detector: CausalPivotDetector | None = None,
        minor_pivot_detector: CausalPivotDetector | None = None,
        line_tolerance_ratio: float = 0.003,
    ) -> None:
        self.pivot_detector = pivot_detector or CausalPivotDetector()
        self.minor_pivot_detector = minor_pivot_detector or CausalPivotDetector(
            PivotDetectorConfig(
                atr_multiplier=0.8,
                range_multiplier=1.0,
                min_reversal_ratio=0.02,
                max_reversal_ratio=0.10,
                min_separation=2,
            )
        )
        self.line_tolerance_ratio = line_tolerance_ratio

    def replay(
        self,
        bars: Sequence[Bar | Mapping[str, object]],
        anchor_overrides: Iterable[AnchorOverride] | None = None,
    ) -> ReplayResult:
        normalized_bars = tuple(
            value if isinstance(value, Bar) else Bar.from_mapping(index, value)
            for index, value in enumerate(bars)
        )
        automatic_mode = anchor_overrides is None
        if anchor_overrides is None:
            overrides = tuple(
                AnchorOverride(
                    index=pivot.bar_index,
                    kind=pivot.kind,
                    price=pivot.price,
                    confirmed_index=pivot.confirmed_index,
                )
                for pivot in self.pivot_detector.detect(normalized_bars)
            )
        else:
            overrides = tuple(anchor_overrides)
        self._validate_overrides(normalized_bars, overrides)

        by_confirmation: dict[int, list[AnchorOverride]] = {}
        for anchor in overrides:
            by_confirmation.setdefault(anchor.confirmation_index(), []).append(anchor)

        minor_by_confirmation: dict[int, list[Pivot]] = {}
        if automatic_mode:
            for detected in self.minor_pivot_detector.detect(normalized_bars):
                minor_by_confirmation.setdefault(detected.confirmed_index, []).append(
                    Pivot(
                        id=(
                            f"MINOR-{detected.kind}-{detected.bar_index}-"
                            f"{detected.confirmed_index}"
                        ),
                        kind=detected.kind,
                        bar_index=detected.bar_index,
                        price=detected.price,
                        confirmed_index=detected.confirmed_index,
                    )
                )

        pivots: list[Pivot] = []
        lines: list[TrendLine] = []
        lows: list[Pivot] = []
        highs: list[Pivot] = []
        active_support: TrendLine | None = None
        active_resistance: TrendLine | None = None
        active_support_acceleration: TrendLine | None = None
        support_acceleration_candidates: list[Pivot] = []
        support_acceleration_generation = 0
        support_acceleration_base: Pivot | None = None
        support_peak_high: float | None = None
        support_pullback_low: float | None = None
        pending_support_candidate: TrendLine | None = None
        resistance_acceleration_base: Pivot | None = None
        resistance_trough_low: float | None = None
        resistance_rebound_high: float | None = None
        pending_resistance_candidate: TrendLine | None = None
        resistance_acceleration_generation = 0
        active_resistance_acceleration: TrendLine | None = None
        support_break_closes = 0
        resistance_break_closes = 0
        support_first_cross_index: int | None = None
        resistance_first_cross_index: int | None = None
        entry_emitted_line_ids: set[str] = set()
        defensive_exit_emitted_line_ids: set[str] = set()
        boxes: list[BoxStructure] = []
        active_box: BoxStructure | None = None
        box_watch_start: int | None = None
        box_up_closes = 0
        box_down_closes = 0
        pullbacks: list[PullbackReview] = []
        active_pullback: PullbackReview | None = None
        pullback_reclaim_count = 0
        weak_pullback_count = 0
        regime: ChannelRegime = "UNKNOWN"
        regime_events: list[RegimeEvent] = []
        transition_start_index: int | None = None
        transition_base_low: Pivot | None = None
        transition_rebound_high: Pivot | None = None
        transition_higher_low: Pivot | None = None
        transition_base_high: Pivot | None = None
        transition_break_low: Pivot | None = None
        transition_lower_high: Pivot | None = None
        frames: list[ReplayFrame] = []
        events: list[LineEvent] = []
        signals: list[TradeSignal] = []

        def change_regime(
            current: ChannelRegime, bar_index: int, reason: str
        ) -> None:
            nonlocal regime
            if regime == current:
                return
            regime_events.append(
                RegimeEvent(
                    bar_index=bar_index,
                    previous=regime,
                    current=current,
                    reason=reason,
                )
            )
            regime = current

        for bar_index in range(len(normalized_bars)):
            for pivot in minor_by_confirmation.get(bar_index, ()):
                if (
                    pivot.kind == "LOW"
                    and active_support is not None
                    and support_acceleration_base is not None
                    and pivot.bar_index > support_acceleration_base.bar_index
                    and self._pivot_is_above_line(pivot, active_support)
                    and self._log_slope(support_acceleration_base, pivot)
                    > max(self._line_log_slope(active_support), 0.0)
                ):
                    candidate_slope = self._log_slope(
                        support_acceleration_base, pivot
                    )
                    if (
                        active_support_acceleration is not None
                        and candidate_slope
                        <= self._line_log_slope(active_support_acceleration)
                    ):
                        continue
                    if (
                        pending_support_candidate is not None
                        and pending_support_candidate.invalidated_index is None
                        and pending_support_candidate.anchor_indexes[1]
                        == pivot.bar_index
                    ):
                        pending_support_candidate = replace(
                            pending_support_candidate,
                            invalidated_index=bar_index,
                        )
                        self._replace_line(lines, pending_support_candidate)
                    if active_support_acceleration is not None:
                        active_support_acceleration = replace(
                            active_support_acceleration,
                            invalidated_index=bar_index,
                        )
                        self._replace_line(lines, active_support_acceleration)
                    support_acceleration_generation += 1
                    active_support_acceleration = self._make_acceleration_line(
                        support_acceleration_base,
                        pivot,
                        "SUPPORT",
                        support_acceleration_generation,
                        len(lines) + 1,
                    )
                    lines.append(active_support_acceleration)
                    events.append(
                        LineEvent(
                            event_type="ACCELERATION_CREATED",
                            bar_index=bar_index,
                            line_id=active_support_acceleration.id,
                            reason="confirmed_minor_retracement_low",
                        )
                    )
                    support_break_closes = 0
                elif (
                    pivot.kind == "HIGH"
                    and active_resistance is not None
                    and resistance_acceleration_base is not None
                    and pivot.bar_index > resistance_acceleration_base.bar_index
                    and self._pivot_is_below_line(pivot, active_resistance)
                    and self._log_slope(resistance_acceleration_base, pivot)
                    < min(self._line_log_slope(active_resistance), 0.0)
                ):
                    candidate_slope = self._log_slope(
                        resistance_acceleration_base, pivot
                    )
                    if (
                        active_resistance_acceleration is not None
                        and candidate_slope
                        >= self._line_log_slope(active_resistance_acceleration)
                    ):
                        continue
                    if (
                        pending_resistance_candidate is not None
                        and pending_resistance_candidate.invalidated_index is None
                        and pending_resistance_candidate.anchor_indexes[1]
                        == pivot.bar_index
                    ):
                        pending_resistance_candidate = replace(
                            pending_resistance_candidate,
                            invalidated_index=bar_index,
                        )
                        self._replace_line(lines, pending_resistance_candidate)
                    if active_resistance_acceleration is not None:
                        active_resistance_acceleration = replace(
                            active_resistance_acceleration,
                            invalidated_index=bar_index,
                        )
                        self._replace_line(lines, active_resistance_acceleration)
                    resistance_acceleration_generation += 1
                    active_resistance_acceleration = self._make_acceleration_line(
                        resistance_acceleration_base,
                        pivot,
                        "RESISTANCE",
                        resistance_acceleration_generation,
                        len(lines) + 1,
                    )
                    lines.append(active_resistance_acceleration)
                    resistance_break_closes = 0

            for anchor in sorted(
                by_confirmation.get(bar_index, ()), key=lambda item: item.index
            ):
                pivot = Pivot(
                    id=f"{anchor.kind}-{anchor.index}-{bar_index}",
                    kind=anchor.kind,
                    bar_index=anchor.index,
                    price=float(anchor.price),
                    confirmed_index=bar_index,
                )
                pivots.append(pivot)
                if pivot.kind == "LOW":
                    lows.append(pivot)
                    if active_support is None and len(lows) >= 2:
                        first, second = lows[-2:]
                        if second.price > first.price:
                            active_support = self._make_line(
                                first, second, "SUPPORT", len(lines) + 1
                            )
                            lines.append(active_support)
                            if automatic_mode:
                                support_acceleration_base = second
                                support_peak_high = None
                                support_pullback_low = None
                    elif active_support is not None:
                        if self._pivot_touches_line(pivot, active_support):
                            active_support = replace(
                                active_support,
                                touch_count=active_support.touch_count + 1,
                            )
                            self._replace_line(lines, active_support)
                            events.append(
                                LineEvent(
                                    event_type="THIRD_TOUCH",
                                    bar_index=bar_index,
                                    line_id=active_support.id,
                                    reason="confirmed_low_retested_existing_support",
                                )
                            )
                        elif self._pivot_is_above_line(pivot, active_support):
                            if automatic_mode:
                                support_acceleration_base = pivot
                                support_peak_high = None
                                support_pullback_low = None
                            elif active_support_acceleration is not None and self._pivot_touches_line(
                                pivot, active_support_acceleration
                            ):
                                active_support_acceleration = replace(
                                    active_support_acceleration,
                                    touch_count=active_support_acceleration.touch_count + 1,
                                )
                                self._replace_line(lines, active_support_acceleration)
                            elif (
                                active_support_acceleration is None
                                or self._pivot_is_above_line(
                                    pivot, active_support_acceleration
                                )
                            ):
                                support_acceleration_candidates.append(pivot)
                                if len(support_acceleration_candidates) >= 2:
                                    first, second = support_acceleration_candidates[-2:]
                                    if active_support_acceleration is not None:
                                        active_support_acceleration = replace(
                                            active_support_acceleration,
                                            invalidated_index=bar_index,
                                        )
                                        self._replace_line(
                                            lines, active_support_acceleration
                                        )
                                        events.append(
                                            LineEvent(
                                                event_type="ACCELERATION_REPLACED",
                                                bar_index=bar_index,
                                                line_id=active_support_acceleration.id,
                                                reason="new_steeper_retracement_pair",
                                            )
                                        )
                                    support_acceleration_generation += 1
                                    active_support_acceleration = (
                                        self._make_acceleration_line(
                                            first,
                                            second,
                                            "SUPPORT",
                                            support_acceleration_generation,
                                            len(lines) + 1,
                                        )
                                    )
                                    lines.append(active_support_acceleration)
                                    events.append(
                                        LineEvent(
                                            event_type="ACCELERATION_CREATED",
                                            bar_index=bar_index,
                                            line_id=active_support_acceleration.id,
                                            reason="two_accelerated_retracement_lows",
                                        )
                                    )
                                    support_acceleration_candidates = []
                else:
                    highs.append(pivot)
                    if active_resistance is None and len(highs) >= 2:
                        first, second = highs[-2:]
                        if second.price < first.price:
                            active_resistance = self._make_line(
                                first, second, "RESISTANCE", len(lines) + 1
                            )
                            lines.append(active_resistance)
                            if automatic_mode:
                                resistance_acceleration_base = second
                                resistance_trough_low = None
                                resistance_rebound_high = None
                    elif active_resistance is not None and self._pivot_touches_line(
                        pivot, active_resistance
                    ):
                        active_resistance = replace(
                            active_resistance,
                            touch_count=active_resistance.touch_count + 1,
                        )
                        self._replace_line(lines, active_resistance)
                        events.append(
                            LineEvent(
                                event_type="THIRD_TOUCH",
                                bar_index=bar_index,
                                line_id=active_resistance.id,
                                reason="confirmed_high_retested_existing_resistance",
                            )
                        )
                    elif (
                        automatic_mode
                        and active_resistance is not None
                        and self._pivot_is_below_line(pivot, active_resistance)
                    ):
                        resistance_acceleration_base = pivot
                        resistance_trough_low = None
                        resistance_rebound_high = None

            confirmed_major_pivots = [
                pivot for pivot in pivots if pivot.confirmed_index == bar_index
            ]
            if regime == "UNKNOWN" and len(lows) >= 2 and len(highs) >= 2:
                rising_structure = (
                    lows[-1].price > lows[-2].price
                    and highs[-1].price > highs[-2].price
                )
                falling_structure = (
                    lows[-1].price < lows[-2].price
                    and highs[-1].price < highs[-2].price
                )
                if rising_structure:
                    change_regime(
                        "UP_CHANNEL", bar_index, "rising_highs_and_rising_lows"
                    )
                elif falling_structure:
                    change_regime(
                        "DOWN_CHANNEL", bar_index, "falling_highs_and_falling_lows"
                    )

            if regime == "DOWN_TRANSITION":
                for confirmed in confirmed_major_pivots:
                    if (
                        confirmed.kind == "HIGH"
                        and transition_start_index is not None
                        and confirmed.bar_index > transition_start_index
                    ):
                        transition_rebound_high = confirmed
                        transition_higher_low = None
                    elif (
                        confirmed.kind == "LOW"
                        and transition_rebound_high is not None
                        and transition_base_low is not None
                        and confirmed.bar_index > transition_rebound_high.bar_index
                    ):
                        if confirmed.price > transition_base_low.price:
                            transition_higher_low = confirmed
                        else:
                            change_regime(
                                "DOWN_CHANNEL",
                                bar_index,
                                "transition_failed_with_lower_low",
                            )
                            transition_start_index = None
                            transition_base_low = confirmed
                            transition_rebound_high = None
                            transition_higher_low = None

            if regime == "UP_TRANSITION":
                for confirmed in confirmed_major_pivots:
                    if (
                        confirmed.kind == "LOW"
                        and transition_start_index is not None
                        and confirmed.bar_index > transition_start_index
                    ):
                        transition_break_low = confirmed
                        transition_lower_high = None
                    elif (
                        confirmed.kind == "HIGH"
                        and transition_break_low is not None
                        and transition_base_high is not None
                        and confirmed.bar_index > transition_break_low.bar_index
                    ):
                        if confirmed.price < transition_base_high.price:
                            transition_lower_high = confirmed
                        else:
                            change_regime(
                                "UP_CHANNEL",
                                bar_index,
                                "transition_failed_with_higher_high",
                            )
                            transition_start_index = None
                            transition_base_high = confirmed
                            transition_break_low = None
                            transition_lower_high = None

            bar = normalized_bars[bar_index]
            if (
                regime == "DOWN_TRANSITION"
                and transition_base_low is not None
                and transition_rebound_high is not None
                and transition_higher_low is not None
                and bar.close
                > transition_rebound_high.price * (1 + self.line_tolerance_ratio)
                and self._candle_pattern(normalized_bars, bar_index) == "BIG_BULL"
                and (self._volume_ratio(normalized_bars, bar_index) or 0.0) >= 1.2
            ):
                active_support = self._make_line(
                    transition_base_low,
                    transition_higher_low,
                    "SUPPORT",
                    len(lines) + 1,
                )
                lines.append(active_support)
                change_regime(
                    "UP_CHANNEL",
                    bar_index,
                    "higher_low_and_volume_breakout_confirmed_up_channel",
                )
                signals.append(
                    TradeSignal(
                        side="BUY",
                        bar_index=bar_index,
                        price=bar.close,
                        reason="up_channel_confirmed",
                        confidence="STRONG",
                        line_id=active_support.id,
                        volume_ratio=self._volume_ratio(
                            normalized_bars, bar_index
                        ),
                        pattern="BIG_BULL",
                    )
                )
                transition_start_index = None
                transition_base_low = None
                transition_rebound_high = None
                transition_higher_low = None

            if (
                regime == "UP_TRANSITION"
                and transition_base_high is not None
                and transition_break_low is not None
                and transition_lower_high is not None
                and bar.close
                < transition_break_low.price * (1 - self.line_tolerance_ratio)
                and self._candle_pattern(normalized_bars, bar_index) == "BIG_BEAR"
                and (self._volume_ratio(normalized_bars, bar_index) or 0.0) >= 1.2
            ):
                active_resistance = self._make_line(
                    transition_base_high,
                    transition_lower_high,
                    "RESISTANCE",
                    len(lines) + 1,
                )
                lines.append(active_resistance)
                change_regime(
                    "DOWN_CHANNEL",
                    bar_index,
                    "lower_high_and_volume_breakdown_confirmed_down_channel",
                )
                if not any(
                    signal.side == "SELL" and signal.bar_index == bar_index
                    for signal in signals
                ):
                    signals.append(
                        TradeSignal(
                            side="SELL",
                            bar_index=bar_index,
                            price=bar.close,
                            reason="down_channel_confirmed",
                            confidence="STRONG",
                            line_id=active_resistance.id,
                            volume_ratio=self._volume_ratio(
                                normalized_bars, bar_index
                            ),
                            pattern="BIG_BEAR",
                        )
                    )
                transition_start_index = None
                transition_base_high = None
                transition_break_low = None
                transition_lower_high = None

            if automatic_mode and active_support is not None:
                base = support_acceleration_base
                if base is not None and bar_index > base.confirmed_index:
                    if support_peak_high is None or bar.high >= support_peak_high:
                        support_peak_high = bar.high
                        support_pullback_low = None
                    elif (
                        bar.low < normalized_bars[bar_index - 1].low
                        and (
                            support_pullback_low is None
                            or bar.low < support_pullback_low
                        )
                    ):
                        candidate = Pivot(
                            id=f"AUTO-LOW-{bar_index}",
                            kind="LOW",
                            bar_index=bar_index,
                            price=bar.low,
                            confirmed_index=bar_index,
                        )
                        candidate_slope = self._log_slope(base, candidate)
                        main_slope = self._line_log_slope(active_support)
                        if candidate_slope > max(main_slope, 0.0):
                            if (
                                pending_support_candidate is not None
                                and pending_support_candidate.invalidated_index is None
                            ):
                                pending_support_candidate = replace(
                                    pending_support_candidate,
                                    invalidated_index=bar_index,
                                )
                                self._replace_line(lines, pending_support_candidate)
                                events.append(
                                    LineEvent(
                                        event_type="ACCELERATION_CANDIDATE_REPLACED",
                                        bar_index=bar_index,
                                        line_id=pending_support_candidate.id,
                                        reason="new_intraleg_retracement_low",
                                    )
                                )
                            pending_support_candidate = self._make_acceleration_line(
                                base,
                                candidate,
                                "SUPPORT",
                                support_acceleration_generation + 1,
                                len(lines) + 1,
                                controls_signals=False,
                            )
                            lines.append(pending_support_candidate)
                            events.append(
                                LineEvent(
                                    event_type="ACCELERATION_CANDIDATE_CREATED",
                                    bar_index=bar_index,
                                    line_id=pending_support_candidate.id,
                                    reason="intraleg_retracement_low_above_main_support",
                                )
                            )
                        support_pullback_low = bar.low

            if automatic_mode and active_resistance is not None:
                base = resistance_acceleration_base
                if base is not None and bar_index > base.confirmed_index:
                    if resistance_trough_low is None or bar.low <= resistance_trough_low:
                        resistance_trough_low = bar.low
                        resistance_rebound_high = None
                    elif (
                        bar.high > normalized_bars[bar_index - 1].high
                        and (
                            resistance_rebound_high is None
                            or bar.high > resistance_rebound_high
                        )
                    ):
                        candidate = Pivot(
                            id=f"AUTO-HIGH-{bar_index}",
                            kind="HIGH",
                            bar_index=bar_index,
                            price=bar.high,
                            confirmed_index=bar_index,
                        )
                        candidate_slope = self._log_slope(base, candidate)
                        main_slope = self._line_log_slope(active_resistance)
                        if candidate_slope < min(main_slope, 0.0):
                            if (
                                pending_resistance_candidate is not None
                                and pending_resistance_candidate.invalidated_index is None
                            ):
                                pending_resistance_candidate = replace(
                                    pending_resistance_candidate,
                                    invalidated_index=bar_index,
                                )
                                self._replace_line(lines, pending_resistance_candidate)
                            pending_resistance_candidate = self._make_acceleration_line(
                                base,
                                candidate,
                                "RESISTANCE",
                                resistance_acceleration_generation + 1,
                                len(lines) + 1,
                                controls_signals=False,
                            )
                            lines.append(pending_resistance_candidate)
                        resistance_rebound_high = bar.high

            support_control = active_support_acceleration or active_support
            if (
                active_box is None
                and support_control is not None
                and bar_index > support_control.created_index
            ):
                support_value = support_control.value_at(bar_index)
                boundary = support_value * (1 - self.line_tolerance_ratio)
                if bar.close < boundary:
                    support_break_closes += 1
                    if support_break_closes == 1:
                        support_first_cross_index = bar_index
                        events.append(
                            LineEvent(
                                event_type="BREAK_PENDING",
                                bar_index=bar_index,
                                line_id=support_control.id,
                                reason="first_close_below_support",
                            )
                        )
                    if support_break_closes >= 2:
                        support_control = replace(
                            support_control, invalidated_index=bar_index
                        )
                        self._replace_line(lines, support_control)
                        events.append(
                            LineEvent(
                                event_type="BREAK_CONFIRMED",
                                bar_index=bar_index,
                                line_id=support_control.id,
                                reason="two_persistent_closes_below_support",
                            )
                        )
                        signals.append(
                            TradeSignal(
                                side="SELL",
                                bar_index=bar_index,
                                price=bar.close,
                                reason=(
                                    "support_break_confirmed_by_persistent_closes"
                                ),
                                confidence="STRUCTURAL",
                                line_id=support_control.id,
                                first_cross_index=support_first_cross_index,
                                volume_ratio=self._volume_ratio(
                                    normalized_bars, bar_index
                                ),
                                pattern=self._candle_pattern(
                                    normalized_bars, bar_index
                                ),
                            )
                        )
                        active_pullback = PullbackReview(
                            id=f"PULLBACK-{len(pullbacks) + 1}",
                            line_id=support_control.id,
                            side="SUPPORT",
                            break_index=bar_index,
                        )
                        pullbacks.append(active_pullback)
                        pullback_reclaim_count = 0
                        weak_pullback_count = 0
                        if regime == "UP_CHANNEL":
                            transition_start_index = bar_index
                            transition_base_high = highs[-1] if highs else None
                            transition_break_low = None
                            transition_lower_high = None
                            change_regime(
                                "UP_TRANSITION",
                                bar_index,
                                "up_support_break_started_transition",
                            )
                        if support_control.role == "ACCELERATION":
                            active_support_acceleration = None
                            support_acceleration_candidates = []
                        else:
                            active_support = None
                            if active_resistance is not None:
                                active_resistance = replace(
                                    active_resistance,
                                    invalidated_index=bar_index,
                                )
                                self._replace_line(lines, active_resistance)
                                active_resistance = None
                            active_resistance_acceleration = None
                            highs = highs[-1:]
                        box_watch_start = bar_index + 1
                        support_break_closes = 0
                        support_first_cross_index = None
                else:
                    if bar.low < boundary:
                        events.append(
                            LineEvent(
                                event_type="WICK_PENETRATION",
                                bar_index=bar_index,
                                line_id=support_control.id,
                                reason="wick_crossed_support_but_close_recovered",
                            )
                        )
                    support_break_closes = 0
                    support_first_cross_index = None

            if (
                active_box is None
                and (active_resistance_acceleration or active_resistance) is not None
            ):
                resistance_control = active_resistance_acceleration or active_resistance
                assert resistance_control is not None
                if bar_index <= resistance_control.created_index:
                    frames.append(
                        ReplayFrame(
                            bar_index=bar_index,
                            active_support_line_id=(
                                active_support_acceleration.id
                                if active_support_acceleration is not None
                                else (active_support.id if active_support is not None else None)
                            ),
                            active_resistance_line_id=resistance_control.id,
                            regime=regime,
                        )
                    )
                    continue
                resistance_value = resistance_control.value_at(bar_index)
                boundary = resistance_value * (1 + self.line_tolerance_ratio)
                if bar.close > boundary:
                    resistance_break_closes += 1
                    if resistance_break_closes == 1:
                        resistance_first_cross_index = bar_index
                        events.append(
                            LineEvent(
                                event_type="BREAK_PENDING",
                                bar_index=bar_index,
                                line_id=resistance_control.id,
                                reason="first_close_above_resistance",
                            )
                        )
                    if resistance_break_closes >= 2:
                        resistance_control = replace(
                            resistance_control, invalidated_index=bar_index
                        )
                        self._replace_line(lines, resistance_control)
                        events.append(
                            LineEvent(
                                event_type="BREAK_CONFIRMED",
                                bar_index=bar_index,
                                line_id=resistance_control.id,
                                reason="two_persistent_closes_above_resistance",
                            )
                        )
                        if regime in ("DOWN_CHANNEL", "DOWN_TRANSITION"):
                            if regime == "DOWN_CHANNEL":
                                change_regime(
                                    "DOWN_TRANSITION",
                                    bar_index,
                                    "down_resistance_break_started_transition",
                                )
                                transition_start_index = bar_index
                                transition_base_low = lows[-1] if lows else None
                                transition_rebound_high = None
                                transition_higher_low = None
                        else:
                            signals.append(
                                TradeSignal(
                                    side="BUY",
                                    bar_index=bar_index,
                                    price=bar.close,
                                    reason=(
                                        "resistance_break_confirmed_by_persistent_closes"
                                    ),
                                    confidence="STRUCTURAL",
                                    line_id=resistance_control.id,
                                    first_cross_index=resistance_first_cross_index,
                                    volume_ratio=self._volume_ratio(
                                        normalized_bars, bar_index
                                    ),
                                    pattern=self._candle_pattern(
                                        normalized_bars, bar_index
                                    ),
                                )
                            )
                            active_pullback = PullbackReview(
                                id=f"PULLBACK-{len(pullbacks) + 1}",
                                line_id=resistance_control.id,
                                side="RESISTANCE",
                                break_index=bar_index,
                            )
                            pullbacks.append(active_pullback)
                            pullback_reclaim_count = 0
                            weak_pullback_count = 0
                        if resistance_control.role == "ACCELERATION":
                            active_resistance_acceleration = None
                        else:
                            active_resistance = None
                            if active_support is not None:
                                active_support = replace(
                                    active_support,
                                    invalidated_index=bar_index,
                                )
                                self._replace_line(lines, active_support)
                                active_support = None
                            active_support_acceleration = None
                            support_acceleration_base = None
                            lows = lows[-1:]
                        box_watch_start = bar_index + 1
                        resistance_break_closes = 0
                        resistance_first_cross_index = None
                else:
                    resistance_break_closes = 0
                    resistance_first_cross_index = None

            if active_pullback is not None and bar_index > active_pullback.break_index:
                broken_line = next(
                    line for line in lines if line.id == active_pullback.line_id
                )
                line_value = broken_line.value_at(bar_index)
                volume_ratio = self._volume_ratio(normalized_bars, bar_index) or 0.0
                previous_volume_ratio = (
                    self._volume_ratio(normalized_bars, bar_index - 1) or 0.0
                )
                pattern = self._candle_pattern(normalized_bars, bar_index)
                tolerance = self.line_tolerance_ratio
                strong_reclaim = False
                weak_failure = False

                if active_pullback.side == "SUPPORT":
                    reclaimed = (
                        pattern == "BIG_BULL"
                        and bar.close > line_value * (1 - tolerance)
                    )
                    pullback_reclaim_count = (
                        pullback_reclaim_count + 1 if reclaimed else 0
                    )
                    if (
                        weak_pullback_count >= 2
                        and pattern == "BIG_BEAR"
                        and volume_ratio >= 1.2
                        and bar.close
                        < min(item.low for item in normalized_bars[bar_index - 2 : bar_index])
                    ):
                        weak_failure = True
                    strong_reclaim = (
                        pullback_reclaim_count >= 2
                        and max(volume_ratio, previous_volume_ratio) >= 1.2
                    )
                    near_unreclaimed_line = (
                        bar.close <= line_value * (1 + tolerance)
                        and abs(bar.close - line_value) / max(abs(line_value), 1e-9)
                        <= 0.04
                    )
                else:
                    reclaimed = (
                        pattern == "BIG_BEAR"
                        and bar.close < line_value * (1 + tolerance)
                    )
                    pullback_reclaim_count = (
                        pullback_reclaim_count + 1 if reclaimed else 0
                    )
                    if (
                        weak_pullback_count >= 2
                        and pattern == "BIG_BULL"
                        and volume_ratio >= 1.2
                        and bar.close
                        > max(item.high for item in normalized_bars[bar_index - 2 : bar_index])
                    ):
                        weak_failure = True
                    strong_reclaim = (
                        pullback_reclaim_count >= 2
                        and max(volume_ratio, previous_volume_ratio) >= 1.2
                    )
                    near_unreclaimed_line = (
                        bar.close >= line_value * (1 - tolerance)
                        and abs(bar.close - line_value) / max(abs(line_value), 1e-9)
                        <= 0.04
                    )

                if strong_reclaim:
                    active_pullback = replace(
                        active_pullback,
                        outcome="STRONG_RECLAIM",
                        resolved_index=bar_index,
                    )
                    self._replace_pullback(pullbacks, active_pullback)
                    reentry_side: Literal["BUY", "SELL"] = (
                        "BUY" if active_pullback.side == "SUPPORT" else "SELL"
                    )
                    if not any(
                        signal.side == reentry_side and signal.bar_index == bar_index
                        for signal in signals
                    ):
                        signals.append(
                            TradeSignal(
                                side=reentry_side,
                                bar_index=bar_index,
                                price=bar.close,
                                reason="strong_pullback_reclaim",
                                confidence="STRONG",
                                line_id=broken_line.id,
                                volume_ratio=volume_ratio,
                                pattern=pattern,
                            )
                        )
                    restored_line = replace(
                        broken_line,
                        id=f"{broken_line.id}-RESTORED-{bar_index}",
                        created_index=bar_index,
                        invalidated_index=None,
                    )
                    lines.append(restored_line)
                    if active_pullback.side == "SUPPORT":
                        if restored_line.role == "ACCELERATION":
                            active_support_acceleration = restored_line
                        else:
                            active_support = restored_line
                    elif restored_line.role == "ACCELERATION":
                        active_resistance_acceleration = restored_line
                    else:
                        active_resistance = restored_line
                    change_regime(
                        (
                            "UP_CHANNEL"
                            if active_pullback.side == "SUPPORT"
                            else "DOWN_CHANNEL"
                        ),
                        bar_index,
                        "strong_pullback_restored_original_channel",
                    )
                    box_watch_start = None
                    active_pullback = None
                    pullback_reclaim_count = 0
                    weak_pullback_count = 0
                elif weak_failure:
                    active_pullback = replace(
                        active_pullback,
                        outcome="WEAK_FAILURE",
                        resolved_index=bar_index,
                    )
                    self._replace_pullback(pullbacks, active_pullback)
                    active_pullback = None
                    pullback_reclaim_count = 0
                    weak_pullback_count = 0
                elif bar_index - active_pullback.break_index >= 10:
                    active_pullback = replace(
                        active_pullback,
                        outcome="NO_RECLAIM",
                        resolved_index=bar_index,
                    )
                    self._replace_pullback(pullbacks, active_pullback)
                    active_pullback = None
                    pullback_reclaim_count = 0
                    weak_pullback_count = 0
                else:
                    small_body = self._body_ratio(bar) <= 0.35
                    weak_pullback_count = (
                        weak_pullback_count + 1
                        if small_body
                        and volume_ratio <= 0.9
                        and near_unreclaimed_line
                        else 0
                    )

            if active_box is not None:
                upper = active_box.top * (1 + self.line_tolerance_ratio)
                lower = active_box.bottom * (1 - self.line_tolerance_ratio)
                box_up_closes = box_up_closes + 1 if bar.close > upper else 0
                box_down_closes = box_down_closes + 1 if bar.close < lower else 0
                if box_up_closes >= 2 or box_down_closes >= 2:
                    break_side: Literal["UP", "DOWN"] = (
                        "UP" if box_up_closes >= 2 else "DOWN"
                    )
                    active_box = replace(
                        active_box,
                        broken_index=bar_index,
                        break_side=break_side,
                    )
                    for index, item in enumerate(boxes):
                        if item.id == active_box.id:
                            boxes[index] = active_box
                            break
                    signal_side: Literal["BUY", "SELL"] = (
                        "BUY" if break_side == "UP" else "SELL"
                    )
                    if not any(
                        signal.side == signal_side and signal.bar_index == bar_index
                        for signal in signals
                    ):
                        signals.append(
                            TradeSignal(
                            side=signal_side,
                            bar_index=bar_index,
                            price=bar.close,
                            reason=(
                                "box_breakout_confirmed"
                                if break_side == "UP"
                                else "box_breakdown_confirmed"
                            ),
                            confidence="STRUCTURAL",
                            volume_ratio=self._volume_ratio(
                                normalized_bars, bar_index
                            ),
                            pattern=self._candle_pattern(
                                normalized_bars, bar_index
                            ),
                            )
                        )
                    change_regime(
                        "UP_CHANNEL" if break_side == "UP" else "DOWN_CHANNEL",
                        bar_index,
                        "box_boundary_break_confirmed",
                    )
                    active_box = None
                    box_watch_start = None
                    box_up_closes = 0
                    box_down_closes = 0
            elif (
                box_watch_start is not None
                and bar_index - box_watch_start + 1 >= 6
            ):
                window = normalized_bars[box_watch_start : bar_index + 1]
                top = max(item.high for item in window)
                bottom = min(item.low for item in window)
                width = top - bottom
                average_range = sum(item.high - item.low for item in window) / len(window)
                midpoint = max((top + bottom) / 2, 1e-9)
                close_slope = abs(window[-1].close - window[0].close) / midpoint
                upper_touches = sum(item.high >= top - width * 0.2 for item in window)
                lower_touches = sum(item.low <= bottom + width * 0.2 for item in window)
                if (
                    width <= average_range * 4
                    and width / midpoint <= 0.30
                    and close_slope <= max(average_range / midpoint, 0.01)
                    and upper_touches >= 2
                    and lower_touches >= 2
                ):
                    active_box = BoxStructure(
                        id=f"BOX-{len(boxes) + 1}",
                        start_index=box_watch_start,
                        created_index=bar_index,
                        top=top,
                        bottom=bottom,
                    )
                    boxes.append(active_box)
                    change_regime(
                        "BOX", bar_index, "sideways_structure_confirmed"
                    )
                    if active_pullback is not None:
                        active_pullback = replace(
                            active_pullback,
                            outcome="SIDEWAYS_BOX",
                            resolved_index=bar_index,
                        )
                        self._replace_pullback(pullbacks, active_pullback)
                        active_pullback = None
                        pullback_reclaim_count = 0
                        weak_pullback_count = 0

            entry_line = active_support_acceleration or active_support
            if (
                regime == "UP_CHANNEL"
                and active_box is None
                and entry_line is not None
                and entry_line.id not in defensive_exit_emitted_line_ids
                and self._is_bearish_volume_breakdown(
                    normalized_bars, bar_index
                )
            ):
                signals.append(
                    TradeSignal(
                        side="SELL",
                        bar_index=bar_index,
                        price=bar.close,
                        reason="bearish_volume_breakdown_defensive_exit",
                        confidence="DEFENSIVE",
                        line_id=entry_line.id,
                        volume_ratio=self._volume_ratio(
                            normalized_bars, bar_index
                        ),
                        pattern="BIG_BEAR",
                    )
                )
                defensive_exit_emitted_line_ids.add(entry_line.id)

            if (
                regime == "UP_CHANNEL"
                and active_box is None
                and entry_line is not None
                and active_resistance is None
                and active_resistance_acceleration is None
                and entry_line.id not in entry_emitted_line_ids
                and self._allows_momentum_entry(entry_line)
                and bar_index > entry_line.created_index
                and not any(
                    signal.side == "BUY" and signal.bar_index == bar_index
                    for signal in signals
                )
                and self._is_strong_volume_breakout(normalized_bars, bar_index)
            ):
                volume_ratio = self._volume_ratio(normalized_bars, bar_index)
                signals.append(
                    TradeSignal(
                        side="BUY",
                        bar_index=bar_index,
                        price=bar.close,
                        reason="uptrend_volume_breakout",
                        confidence="STRONG",
                        line_id=entry_line.id,
                        volume_ratio=volume_ratio,
                        pattern=self._candle_pattern(normalized_bars, bar_index),
                    )
                )
                entry_emitted_line_ids.add(entry_line.id)

            frames.append(
                ReplayFrame(
                    bar_index=bar_index,
                    active_support_line_id=(
                        active_support_acceleration.id
                        if active_support_acceleration is not None
                        else (active_support.id if active_support is not None else None)
                    ),
                    active_resistance_line_id=(
                        active_resistance_acceleration.id
                        if active_resistance_acceleration is not None
                        else (active_resistance.id if active_resistance is not None else None)
                    ),
                    active_box_id=(active_box.id if active_box else None),
                    active_pullback_id=(
                        active_pullback.id if active_pullback else None
                    ),
                    regime=regime,
                )
            )

        return ReplayResult(
            bars=normalized_bars,
            pivots=tuple(pivots),
            lines=tuple(lines),
            boxes=tuple(boxes),
            pullbacks=tuple(pullbacks),
            regime_events=tuple(regime_events),
            frames=tuple(frames),
            events=tuple(events),
            signals=tuple(signals),
        )

    def _pivot_touches_line(self, pivot: Pivot, line: TrendLine) -> bool:
        expected = line.value_at(pivot.bar_index)
        tolerance = max(abs(expected) * self.line_tolerance_ratio, 1e-9)
        return abs(pivot.price - expected) <= tolerance

    def _pivot_is_above_line(self, pivot: Pivot, line: TrendLine) -> bool:
        expected = line.value_at(pivot.bar_index)
        tolerance = max(abs(expected) * self.line_tolerance_ratio, 1e-9)
        return pivot.price > expected + tolerance

    def _pivot_is_below_line(self, pivot: Pivot, line: TrendLine) -> bool:
        expected = line.value_at(pivot.bar_index)
        tolerance = max(abs(expected) * self.line_tolerance_ratio, 1e-9)
        return pivot.price < expected - tolerance

    @staticmethod
    def _log_slope(first: Pivot, second: Pivot) -> float:
        distance = second.bar_index - first.bar_index
        if distance <= 0 or first.price <= 0 or second.price <= 0:
            return 0.0
        return (log(second.price) - log(first.price)) / distance

    @staticmethod
    def _line_log_slope(line: TrendLine) -> float:
        first_index, second_index = line.anchor_indexes
        first_price, second_price = line.anchor_prices
        distance = second_index - first_index
        if distance <= 0 or first_price <= 0 or second_price <= 0:
            return 0.0
        return (log(second_price) - log(first_price)) / distance

    @staticmethod
    def _volume_ratio(bars: Sequence[Bar], bar_index: int) -> float | None:
        history = [bar.volume for bar in bars[max(0, bar_index - 20) : bar_index]]
        if not history:
            return None
        average = sum(history) / len(history)
        if average <= 0:
            return None
        return bars[bar_index].volume / average

    @staticmethod
    def _candle_pattern(bars: Sequence[Bar], bar_index: int) -> str | None:
        bar = bars[bar_index]
        body_ratio = DowTrendReplayEngine._body_ratio(bar)
        if body_ratio >= 0.55:
            return "BIG_BULL" if bar.close > bar.open else "BIG_BEAR"
        return None

    @staticmethod
    def _body_ratio(bar: Bar) -> float:
        candle_range = max(bar.high - bar.low, 1e-9)
        return abs(bar.close - bar.open) / candle_range

    def _is_strong_volume_breakout(
        self, bars: Sequence[Bar], bar_index: int
    ) -> bool:
        if bar_index <= 0:
            return False
        history = bars[max(0, bar_index - 20) : bar_index]
        prior_high = max(bar.high for bar in history)
        volume_ratio = self._volume_ratio(bars, bar_index)
        return (
            bars[bar_index].close > prior_high
            and self._candle_pattern(bars, bar_index) == "BIG_BULL"
            and volume_ratio is not None
            and volume_ratio >= 1.2
        )

    @staticmethod
    def _is_bearish_volume_breakdown(
        bars: Sequence[Bar], bar_index: int
    ) -> bool:
        if bar_index < 3:
            return False
        bar = bars[bar_index]
        recent_lows = [item.low for item in bars[bar_index - 3 : bar_index]]
        return (
            DowTrendReplayEngine._candle_pattern(bars, bar_index) == "BIG_BEAR"
            and bar.close < min(recent_lows)
            and bar.volume >= bars[bar_index - 1].volume * 1.15
        )

    @staticmethod
    def _allows_momentum_entry(line: TrendLine) -> bool:
        return line.role == "MAIN" or line.generation < 2

    @staticmethod
    def _make_acceleration_line(
        first: Pivot,
        second: Pivot,
        side: LineSide,
        generation: int,
        sequence: int,
        controls_signals: bool = True,
    ) -> TrendLine:
        return TrendLine(
            id=f"{side}-ACCELERATION-{generation}-{sequence}",
            side=side,
            role="ACCELERATION",
            generation=generation,
            first_pivot_id=first.id,
            second_pivot_id=second.id,
            anchor_indexes=(first.bar_index, second.bar_index),
            anchor_prices=(first.price, second.price),
            created_index=second.confirmed_index,
            controls_signals=controls_signals,
        )

    @staticmethod
    def _replace_line(lines: list[TrendLine], updated: TrendLine) -> None:
        for index, line in enumerate(lines):
            if line.id == updated.id:
                lines[index] = updated
                return
        raise ValueError(f"line not found: {updated.id}")

    @staticmethod
    def _replace_pullback(
        pullbacks: list[PullbackReview], updated: PullbackReview
    ) -> None:
        for index, pullback in enumerate(pullbacks):
            if pullback.id == updated.id:
                pullbacks[index] = updated
                return
        raise ValueError(f"pullback not found: {updated.id}")

    @staticmethod
    def _make_line(
        first: Pivot, second: Pivot, side: LineSide, sequence: int
    ) -> TrendLine:
        return TrendLine(
            id=f"{side}-MAIN-{sequence}",
            side=side,
            role="MAIN",
            generation=0,
            first_pivot_id=first.id,
            second_pivot_id=second.id,
            anchor_indexes=(first.bar_index, second.bar_index),
            anchor_prices=(first.price, second.price),
            created_index=second.confirmed_index,
        )

    @staticmethod
    def _validate_overrides(
        bars: Sequence[Bar], overrides: Sequence[AnchorOverride]
    ) -> None:
        for anchor in overrides:
            confirmation_index = anchor.confirmation_index()
            if anchor.kind not in ("HIGH", "LOW"):
                raise ValueError(f"unsupported pivot kind: {anchor.kind}")
            if not 0 <= anchor.index < len(bars):
                raise ValueError("anchor index is outside the bar range")
            if not anchor.index <= confirmation_index < len(bars):
                raise ValueError("anchor confirmation must not precede its market bar")
