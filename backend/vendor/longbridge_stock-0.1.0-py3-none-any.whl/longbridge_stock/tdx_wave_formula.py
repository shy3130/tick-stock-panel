from __future__ import annotations

from math import isfinite
from statistics import pstdev
from typing import Any


def evaluate_intraday_wave_formula(
    bars: list[dict[str, Any]],
    *,
    current: float | None,
    high: float | None,
    low: float | None,
    prev_close: float | None,
) -> dict[str, Any]:
    """Realtime-safe subset of the saved TDX top/bottom formulas.

    The Obsidian formulas include ZIG based turning points. Those are deliberately
    excluded here because they can repaint before a swing is confirmed.
    """
    closes = [_num_or_none(row.get("close") or row.get("price")) for row in bars]
    closes = [value for value in closes if value is not None]
    if current is not None:
        if closes:
            closes[-1] = current
        else:
            closes.append(current)
    if len(closes) < 5 or current is None:
        return _empty("数据不足")

    highs = [_num_or_none(row.get("high") or row.get("close") or row.get("price")) for row in bars]
    lows = [_num_or_none(row.get("low") or row.get("close") or row.get("price")) for row in bars]
    highs = [value for value in highs if value is not None]
    lows = [value for value in lows if value is not None]
    day_high = high if high is not None else (max(highs) if highs else current)
    day_low = low if low is not None else (min(lows) if lows else current)
    previous_close = prev_close if prev_close is not None else closes[0]
    support, resistance, middle = _support_resistance(previous_close, day_high, day_low)

    trend_values = _trend_line(closes)
    trend = trend_values[-1] if trend_values else None
    previous_trend = trend_values[-2] if len(trend_values) >= 2 else None
    buy_cross = _cross_up(previous_trend, trend, 11) or _cross_up(previous_trend, trend, 6) or _cross_up(previous_trend, trend, 3)
    oversold_prepare = trend is not None and trend < 11
    low_rebound = previous_trend is not None and trend is not None and previous_trend < 11 and trend > previous_trend
    sell_prepare = trend is not None and trend > 89 and current > middle

    buy_signal = bool(buy_cross or low_rebound or oversold_prepare)
    sell_signal = bool(sell_prepare)
    if buy_cross:
        buy_state = "低位上穿"
    elif low_rebound or oversold_prepare:
        buy_state = "准备买入"
    else:
        buy_state = "无"
    sell_state = "准备卖出" if sell_prepare else "无"

    evidence: list[str] = []
    if trend is not None:
        evidence.append(f"趋势线{trend:.1f}")
    if buy_state != "无":
        evidence.append(buy_state)
    if sell_state != "无":
        evidence.append(sell_state)
    return {
        "buySignal": buy_signal,
        "sellSignal": sell_signal,
        "buyState": buy_state,
        "sellState": sell_state,
        "trendLine": round(trend, 4) if trend is not None else None,
        "previousTrendLine": round(previous_trend, 4) if previous_trend is not None else None,
        "support": round(support, 4),
        "resistance": round(resistance, 4),
        "middle": round(middle, 4),
        "repaintSignalsExcluded": ["ZIG波段顶底"],
        "evidence": evidence,
    }


def evaluate_daily_wave_formula(bars: list[dict[str, Any]], *, current: float | None = None) -> dict[str, Any]:
    closes = [_num_or_none(row.get("close")) for row in bars]
    highs = [_num_or_none(row.get("high")) for row in bars]
    lows = [_num_or_none(row.get("low")) for row in bars]
    opens = [_num_or_none(row.get("open")) for row in bars]
    volumes = [_num_or_none(row.get("volume")) for row in bars]
    closes = [value for value in closes if value is not None]
    highs = [value for value in highs if value is not None]
    lows = [value for value in lows if value is not None]
    opens = [value for value in opens if value is not None]
    volumes = [value for value in volumes if value is not None]
    if current is not None and closes:
        closes[-1] = current
    if len(closes) < 21 or len(highs) < 2 or len(lows) < 2 or len(opens) < 2:
        return {"reversalBuy": False, "danger": False, "state": "数据不足", "evidence": []}

    ma5 = _mean(closes[-5:])
    ma13 = _mean(closes[-13:]) if len(closes) >= 13 else None
    ma21 = _mean(closes[-21:])
    ma60 = _mean(closes[-60:]) if len(closes) >= 60 else None
    ma360 = _mean(closes[-360:]) if len(closes) >= 360 else None
    bullish = bool(
        ma13 is not None
        and ma60 is not None
        and ma360 is not None
        and ma5 > ma13 > ma21 > ma60 > ma360
    )
    jx = (highs[-1] + lows[-1] + closes[-1]) / 3
    previous_jx = (highs[-2] + lows[-2] + closes[-2]) / 3
    jx_up = jx + 1.65 * pstdev(closes[-20:])
    previous_jx_up = previous_jx + 1.65 * pstdev(closes[-21:-1])
    volume_up = len(volumes) >= 10 and volumes[-1] > _mean(volumes[-5:]) and _mean(volumes[-5:]) > _mean(volumes[-10:])
    reversal_buy = bullish and closes[-1] > jx and jx_up > previous_jx_up and closes[-2] <= previous_jx and volume_up
    danger = closes[-1] < ma5 and closes[-1] < opens[-1] and closes[-2] > opens[-2] and closes[-1] < lows[-2]
    state = "反转买点" if reversal_buy else ("危险" if danger else "无")
    return {
        "reversalBuy": reversal_buy,
        "danger": danger,
        "state": state,
        "ma5": round(ma5, 4),
        "ma21": round(ma21, 4),
        "evidence": [state] if state != "无" else [],
    }


def _trend_line(closes: list[float]) -> list[float]:
    stochastic: list[float] = []
    for index, close in enumerate(closes):
        start = max(0, index - 54)
        window = closes[start : index + 1]
        low = min(window)
        high = max(window)
        value = 50.0 if high <= low else (close - low) / (high - low) * 100
        stochastic.append(value)
    sma1 = _tdx_sma(stochastic, 5, 1)
    sma2 = _tdx_sma(sma1, 3, 1)
    v11 = [3 * first - 2 * second for first, second in zip(sma1, sma2, strict=True)]
    return _ema(v11, 3)


def _support_resistance(prev_close: float, high: float, low: float) -> tuple[float, float, float]:
    upper = max(prev_close, high)
    lower = min(prev_close, low)
    spread = max(0.0, upper - lower)
    support = lower + spread * 0.5 / 8
    resistance = lower + spread * 7 / 8
    return support, resistance, (support + resistance) / 2


def _cross_up(previous: float | None, current: float | None, level: float) -> bool:
    return previous is not None and current is not None and previous < level <= current


def _tdx_sma(values: list[float], period: int, weight: int) -> list[float]:
    output: list[float] = []
    previous: float | None = None
    for value in values:
        previous = value if previous is None else (weight * value + (period - weight) * previous) / period
        output.append(previous)
    return output


def _ema(values: list[float], period: int) -> list[float]:
    if not values:
        return []
    alpha = 2 / (period + 1)
    previous = values[0]
    output = [previous]
    for value in values[1:]:
        previous = value * alpha + previous * (1 - alpha)
        output.append(previous)
    return output


def _mean(values: list[float]) -> float:
    return sum(values) / len(values) if values else 0.0


def _num_or_none(value: Any) -> float | None:
    if value is None or value == "":
        return None
    try:
        number = float(value)
    except (TypeError, ValueError):
        return None
    return number if isfinite(number) else None


def _empty(state: str) -> dict[str, Any]:
    return {
        "buySignal": False,
        "sellSignal": False,
        "buyState": state,
        "sellState": state,
        "trendLine": None,
        "previousTrendLine": None,
        "support": None,
        "resistance": None,
        "middle": None,
        "repaintSignalsExcluded": ["ZIG波段顶底"],
        "evidence": [state],
    }
