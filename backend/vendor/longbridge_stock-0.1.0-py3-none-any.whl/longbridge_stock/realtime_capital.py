from __future__ import annotations

import json
import time
from collections import Counter
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any, Iterable

import psycopg

from longbridge_stock import clickhouse_realtime
from longbridge_stock.collection_monitor import DatasetCoverage, heartbeat, write_dataset_coverage
from longbridge_stock.longbridge_sync import LongbridgeCliClient
from longbridge_stock.market_sessions import is_trading_time, markets_from_symbols
from longbridge_stock.postgres_store import LongbridgePostgresStore
from longbridge_stock.realtime_symbols import load_realtime_symbols


@dataclass(frozen=True)
class RealtimeCapitalSummary:
    snapshot_minute: datetime
    input_symbols: int
    written: int
    failed: int
    elapsed_seconds: float
    input_by_market: dict[str, int] | None = None
    written_by_market: dict[str, int] | None = None

    def to_dict(self) -> dict[str, Any]:
        return {
            "snapshotMinute": self.snapshot_minute.isoformat(),
            "inputSymbols": self.input_symbols,
            "written": self.written,
            "failed": self.failed,
            "elapsedSeconds": round(self.elapsed_seconds, 3),
            "inputByMarket": self.input_by_market or {},
            "writtenByMarket": self.written_by_market or {},
        }


class RealtimeCapitalSync:
    def __init__(
        self,
        dsn: str,
        client: LongbridgeCliClient | None = None,
        store: LongbridgePostgresStore | None = None,
        include_flow: bool = False,
    ) -> None:
        self.dsn = dsn
        self.client = client or LongbridgeCliClient(rate_limit_per_second=5)
        self.store = store or LongbridgePostgresStore(dsn)
        self.include_flow = include_flow

    def load_symbols(
        self,
        markets: Iterable[str],
        limit: int | None = None,
        priority_only: bool = False,
    ) -> list[str]:
        return load_realtime_symbols(
            self.dsn,
            markets,
            client=self.client,
            limit=limit,
            priority_only=priority_only,
        )

    def sync_once(self, symbols: list[str]) -> RealtimeCapitalSummary:
        started = time.monotonic()
        fetched_at = _now()
        snapshot_minute = fetched_at.replace(second=0, microsecond=0)
        written = 0
        failed = 0
        input_by_market = Counter(_market_from_symbol(symbol) for symbol in symbols)
        written_by_market: Counter[str] = Counter()
        task_key = _task_key(dict(input_by_market), self.include_flow)
        self._write_heartbeat(
            task_key=task_key,
            snapshot_minute=snapshot_minute,
            input_by_market=dict(input_by_market),
            written_by_market={},
            written=0,
            failed=0,
            elapsed_seconds=0,
            last_started_at=fetched_at,
        )
        self.store.ensure_realtime_capital_table()
        last_heartbeat_elapsed = 0.0
        for index, symbol in enumerate(symbols, start=1):
            try:
                payload = self.client.capital(symbol)
                flow_payload = self.client.capital_flow(symbol) if self.include_flow else None
            except Exception:
                failed += 1
                continue
            if isinstance(payload, dict) and self.store.upsert_realtime_capital(
                symbol=symbol,
                payload=payload,
                flow_payload=flow_payload,
                snapshot_minute=snapshot_minute,
                fetched_at=_now(),
            ):
                written += 1
                written_by_market[_market_from_symbol(symbol)] += 1
            current_elapsed = time.monotonic() - started
            if index % 100 == 0 or current_elapsed - last_heartbeat_elapsed >= 60:
                self._write_heartbeat(
                    task_key=task_key,
                    snapshot_minute=snapshot_minute,
                    input_by_market=dict(input_by_market),
                    written_by_market=dict(written_by_market),
                    written=written,
                    failed=failed,
                    elapsed_seconds=current_elapsed,
                    queue_depth=max(len(symbols) - index, 0),
                    last_started_at=fetched_at,
                )
                last_heartbeat_elapsed = current_elapsed
        elapsed = time.monotonic() - started
        self._write_monitoring(
            snapshot_minute=snapshot_minute,
            input_by_market=dict(input_by_market),
            written_by_market=dict(written_by_market),
            written=written,
            failed=failed,
            elapsed_seconds=elapsed,
        )
        return RealtimeCapitalSummary(
            snapshot_minute=snapshot_minute,
            input_symbols=len(symbols),
            written=written,
            failed=failed,
            elapsed_seconds=elapsed,
            input_by_market=dict(input_by_market),
            written_by_market=dict(written_by_market),
        )

    def run_forever(self, symbols: list[str], interval_seconds: int) -> None:
        if interval_seconds <= 0:
            raise ValueError("interval_seconds must be positive")
        markets = markets_from_symbols(symbols)
        input_by_market = Counter(_market_from_symbol(symbol) for symbol in symbols)
        task_key = _task_key(dict(input_by_market), self.include_flow)
        while True:
            outside_trading_time = not is_trading_time(_now(), markets)
            if outside_trading_time and not self.store.realtime_sinks.config.postgres_enabled:
                heartbeat(
                    self.dsn,
                    task_key,
                    status="outside_trading_time",
                    rows_written=0,
                    rows_failed=0,
                    queue_depth=0,
                    runtime={
                        "input_by_market": dict(input_by_market),
                        "written_by_market": {},
                        "elapsed_seconds": 0,
                        "realtime_sinks": list(self.store.realtime_sinks.config.sinks),
                    },
                )
                print(json.dumps({"status": "outside_trading_time", "markets": markets}, ensure_ascii=False), flush=True)
                time.sleep(min(interval_seconds, 300))
                continue
            if outside_trading_time and self._is_latest_coverage_complete(dict(input_by_market)):
                snapshot_minute = _now().replace(second=0, microsecond=0)
                self._write_coverage_snapshot(
                    snapshot_minute=snapshot_minute,
                    input_by_market=dict(input_by_market),
                )
                self._write_heartbeat(
                    task_key=task_key,
                    snapshot_minute=snapshot_minute,
                    input_by_market=dict(input_by_market),
                    written_by_market={},
                    written=0,
                    failed=0,
                    elapsed_seconds=0,
                    status="outside_trading_time",
                )
                print(json.dumps({"status": "outside_trading_time", "markets": markets}, ensure_ascii=False), flush=True)
                time.sleep(min(interval_seconds, 300))
                continue
            summary = self.sync_once(symbols)
            print(json.dumps(summary.to_dict(), ensure_ascii=False), flush=True)
            if outside_trading_time and not self._is_latest_coverage_complete(dict(input_by_market)):
                time.sleep(min(interval_seconds, 60))
                continue
            sleep_seconds = max(0, interval_seconds - summary.elapsed_seconds)
            time.sleep(sleep_seconds)

    def _write_monitoring(
        self,
        *,
        snapshot_minute: datetime,
        input_by_market: dict[str, int],
        written_by_market: dict[str, int],
        written: int,
        failed: int,
        elapsed_seconds: float,
    ) -> None:
        task_key = _task_key(input_by_market, self.include_flow)
        try:
            actual_counts = {}
            if self.store.realtime_sinks.config.postgres_enabled:
                actual_counts = self._latest_coverage_counts(input_by_market.keys())
            coverage: list[DatasetCoverage] = []
            for market, expected in input_by_market.items():
                collected = int(actual_counts.get((market, "capital_distribution"), written_by_market.get(market, 0)) or 0)
                coverage.append(
                    DatasetCoverage(
                        market=market,
                        dataset_key="capital_distribution",
                        expected_count=expected,
                        collected_count=collected,
                        latest_data_at=snapshot_minute,
                        freshness_status="ok" if collected >= expected else "partial",
                    )
                )
                if self.include_flow:
                    flow_collected = int(actual_counts.get((market, "capital_flow"), 0) or 0)
                    coverage.append(
                        DatasetCoverage(
                            market=market,
                            dataset_key="capital_flow",
                            expected_count=expected,
                            collected_count=flow_collected,
                            latest_data_at=snapshot_minute,
                            freshness_status="ok" if flow_collected >= expected else "partial",
                        )
                    )
            write_dataset_coverage(self.dsn, coverage)
            heartbeat(
                self.dsn,
                task_key,
                status="running",
                rows_written=written,
                rows_failed=failed,
                last_write_at=snapshot_minute,
                last_success_at=snapshot_minute if written else None,
                runtime={
                    "include_flow": self.include_flow,
                    "input_by_market": input_by_market,
                    "written_by_market": written_by_market,
                    "elapsed_seconds": round(elapsed_seconds, 3),
                },
            )
        except Exception:
            return

    def _write_coverage_snapshot(self, *, snapshot_minute: datetime, input_by_market: dict[str, int]) -> None:
        try:
            actual_counts = self._latest_coverage_counts(input_by_market.keys())
            coverage: list[DatasetCoverage] = []
            for market, expected in input_by_market.items():
                collected = int(actual_counts.get((market, "capital_distribution"), 0) or 0)
                coverage.append(
                    DatasetCoverage(
                        market=market,
                        dataset_key="capital_distribution",
                        expected_count=expected,
                        collected_count=collected,
                        latest_data_at=snapshot_minute,
                        freshness_status="ok" if _coverage_is_complete(collected, expected) else "partial",
                    )
                )
                if self.include_flow:
                    flow_collected = int(actual_counts.get((market, "capital_flow"), 0) or 0)
                    coverage.append(
                        DatasetCoverage(
                            market=market,
                            dataset_key="capital_flow",
                            expected_count=expected,
                            collected_count=flow_collected,
                            latest_data_at=snapshot_minute,
                            freshness_status="ok" if _coverage_is_complete(flow_collected, expected) else "partial",
                        )
                    )
            write_dataset_coverage(self.dsn, coverage)
        except Exception:
            return

    def _is_latest_coverage_complete(self, expected_by_market: dict[str, int]) -> bool:
        if not expected_by_market:
            return True
        counts = self._latest_coverage_counts(expected_by_market.keys())
        for market, expected in expected_by_market.items():
            if not _coverage_is_complete(int(counts.get((market, "capital_distribution"), 0) or 0), expected):
                return False
            if self.include_flow and not _coverage_is_complete(int(counts.get((market, "capital_flow"), 0) or 0), expected):
                return False
        return True

    def _latest_coverage_counts(self, markets: Iterable[str]) -> dict[tuple[str, str], int]:
        safe_markets = [market.lower() for market in markets if market and market.isalpha()]
        if not safe_markets:
            return {}
        result: dict[tuple[str, str], int] = {}
        database = clickhouse_realtime._database()
        market_sql = "(" + ",".join("'" + market.replace("'", "") + "'" for market in safe_markets) + ")"
        for dataset_key, table in (
            ("capital_distribution", "lb_realtime_capital"),
            ("capital_flow", "lb_realtime_capital_flow"),
        ):
            rows = clickhouse_realtime._query_json_each_row(
                f"""
                select market, countDistinct(symbol) as count
                from {database}.{table}
                where market in {market_sql}
                group by market
                """
            )
            for row in rows:
                result[(str(row.get("market")).lower(), dataset_key)] = int(row.get("count") or 0)
        return result

    def _write_heartbeat(
        self,
        *,
        task_key: str,
        snapshot_minute: datetime,
        input_by_market: dict[str, int],
        written_by_market: dict[str, int],
        written: int,
        failed: int,
        elapsed_seconds: float,
        queue_depth: int = 0,
        last_started_at: datetime | None = None,
        status: str = "running",
    ) -> None:
        try:
            heartbeat(
                self.dsn,
                task_key,
                status=status,
                rows_written=written,
                rows_failed=failed,
                queue_depth=queue_depth,
                last_started_at=last_started_at,
                last_write_at=snapshot_minute if written else None,
                last_success_at=snapshot_minute if written else None,
                runtime={
                    "include_flow": self.include_flow,
                    "input_by_market": input_by_market,
                    "written_by_market": written_by_market,
                    "elapsed_seconds": round(elapsed_seconds, 3),
                },
            )
        except Exception:
            return


def _now() -> datetime:
    return datetime.now(timezone.utc).astimezone()


def _market_from_symbol(symbol: str) -> str:
    suffix = symbol.rsplit(".", 1)[-1].lower() if "." in symbol else ""
    if suffix in {"sh", "sz"}:
        return "cn"
    return suffix


def _coverage_is_complete(collected: int, expected: int) -> bool:
    if expected <= 0:
        return True
    missing = max(expected - collected, 0)
    tolerance = max(5, int(expected * 0.002))
    return missing <= tolerance


def _task_key(input_by_market: dict[str, int], include_flow: bool) -> str:
    markets = set(input_by_market)
    if include_flow and markets == {"hk"}:
        return "realtime_capital_hk_full"
    if include_flow and markets == {"us"}:
        return "realtime_capital_us_full"
    if include_flow:
        return "capital_flow_delayed"
    if markets == {"us"}:
        return "realtime_capital_us"
    return "realtime_capital_priority"
