from __future__ import annotations

import re
from datetime import date, datetime
from typing import Any
from urllib import request


HKEX_SHORT_SELLING_URLS = {
    ("morning", "main"): "https://www.hkex.com.hk/eng/stat/smstat/ssturnover/ncms/MSHTMAIN.HTM",
    ("morning", "gem"): "https://www.hkex.com.hk/eng/stat/smstat/ssturnover/ncms/MSHTGEM.HTM",
    ("morning", "nasdaq"): "https://www.hkex.com.hk/eng/stat/smstat/ssturnover/ncms/MSHTNASD.HTM",
    ("day_close", "main"): "https://www.hkex.com.hk/eng/stat/smstat/ssturnover/ncms/ASHTMAIN.HTM",
    ("day_close", "gem"): "https://www.hkex.com.hk/eng/stat/smstat/ssturnover/ncms/ASHTGEM.HTM",
    ("day_close", "nasdaq"): "https://www.hkex.com.hk/eng/stat/smstat/ssturnover/ncms/ASHTNASD.HTM",
}

_HEADER_RE = re.compile(r"TRADING DATE\s*:\s*(\d{1,2}\s+[A-Z]{3}\s+\d{4})", re.IGNORECASE)
_ROW_RE = re.compile(r"^\s*(\d{1,5})\s{2,}(.+?)\s{2,}([\d,]+)\s+([\d,]+)\s*$")


def fetch_hkex_short_selling_report(*, session: str, board: str, timeout: float = 30.0) -> str:
    url = report_url(session=session, board=board)
    req = request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
    with request.urlopen(req, timeout=timeout) as response:
        body = response.read()
    return body.decode("utf-8", errors="replace")


def report_url(*, session: str, board: str) -> str:
    key = (normalize_session(session), normalize_board(board))
    try:
        return HKEX_SHORT_SELLING_URLS[key]
    except KeyError as exc:
        raise ValueError(f"unsupported HKEX short selling report: session={session!r} board={board!r}") from exc


def parse_hkex_short_selling_report(
    text: str,
    *,
    session: str,
    board: str,
    source_url: str,
    fetched_at: datetime | None = None,
) -> list[dict[str, Any]]:
    trade_date = parse_trade_date(text)
    if trade_date is None:
        return []
    fetched_at = fetched_at or datetime.now().astimezone()
    normalized_session = normalize_session(session)
    normalized_board = normalize_board(board)
    rows: list[dict[str, Any]] = []
    for line in text.splitlines():
        match = _ROW_RE.match(line)
        if not match:
            continue
        code_text, name, volume_text, turnover_text = match.groups()
        code = int(code_text)
        rows.append(
            {
                "trade_date": trade_date,
                "session": normalized_session,
                "board": normalized_board,
                "code": code,
                "symbol": f"{code}.HK",
                "name": " ".join(name.split()),
                "short_volume": int(volume_text.replace(",", "")),
                "short_turnover": float(turnover_text.replace(",", "")),
                "currency": "HKD",
                "source": "hkex_short_selling_turnover",
                "source_url": source_url,
                "fetched_at": fetched_at,
            }
        )
    return rows


def parse_trade_date(text: str) -> date | None:
    match = _HEADER_RE.search(text)
    if not match:
        if "will be available after" in text.lower():
            return None
        raise ValueError("HKEX short selling report has no trading date header")
    return datetime.strptime(match.group(1).upper(), "%d %b %Y").date()


def normalize_session(value: str) -> str:
    normalized = value.strip().lower().replace("-", "_")
    aliases = {
        "am": "morning",
        "morning_close": "morning",
        "day": "day_close",
        "close": "day_close",
        "full_day": "day_close",
    }
    normalized = aliases.get(normalized, normalized)
    if normalized not in {"morning", "day_close"}:
        raise ValueError(f"unsupported short selling session: {value!r}")
    return normalized


def normalize_board(value: str) -> str:
    normalized = value.strip().lower().replace("-", "_")
    if normalized not in {"main", "gem", "nasdaq"}:
        raise ValueError(f"unsupported short selling board: {value!r}")
    return normalized
