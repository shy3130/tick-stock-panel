from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Iterable

from longbridge_stock import clickhouse_realtime


@dataclass(frozen=True)
class IntradayShape:
    label: str
    confidence: float
    transition_risk: float
    action: str
    minute_return: float
    return_5m: float
    return_15m: float
    intraday_return: float
    vwap_deviation: float
    close_position_30m: float
    drawdown_from_high: float
    rebound_from_low: float
    turnover_ratio_15m: float
    sample_count: int

    def to_dict(self) -> dict[str, Any]:
        return {
            "label": self.label,
            "confidence": self.confidence,
            "transition_risk": self.transition_risk,
            "action": self.action,
            "minute_return": self.minute_return,
            "return_5m": self.return_5m,
            "return_15m": self.return_15m,
            "intraday_return": self.intraday_return,
            "vwap_deviation": self.vwap_deviation,
            "close_position_30m": self.close_position_30m,
            "drawdown_from_high": self.drawdown_from_high,
            "rebound_from_low": self.rebound_from_low,
            "turnover_ratio_15m": self.turnover_ratio_15m,
            "sample_count": self.sample_count,
        }


def load_intraday_shape_contexts(
    symbols: Iterable[str],
    *,
    period: str = "5m",
    limit: int = 60,
    min_bars: int = 6,
) -> dict[str, dict[str, Any]]:
    bars_by_symbol = fetch_intraday_bars_by_symbol(symbols, period=period, limit=limit)
    return {
        symbol: shape.to_dict()
        for symbol, bars in bars_by_symbol.items()
        if (shape := classify_intraday_shape(bars, min_bars=min_bars)) is not None
    }


def fetch_intraday_bars_by_symbol(symbols: Iterable[str], *, period: str, limit: int) -> dict[str, list[dict[str, Any]]]:
    symbol_list = sorted({str(symbol or "").strip().upper() for symbol in symbols if str(symbol or "").strip()})
    if not symbol_list or not clickhouse_realtime.enabled():
        return {}
    minutes = max(1, int(str(period).removesuffix("m")))
    database = clickhouse_realtime._ident(clickhouse_realtime._database())
    symbol_filter = clickhouse_realtime._symbol_tuple(symbol_list)
    rows = clickhouse_realtime._query_json_each_row(
        f"""
        with latest_day as (
          select symbol, toStartOfDay(max(line_time)) as trade_start
          from {database}.lb_intraday_lines
          where symbol in {symbol_filter}
          group by symbol
        )
        select
          l.symbol as symbol,
          toString(toStartOfInterval(l.line_time, interval {minutes} minute)) as bucket,
          argMin(l.price, l.line_time) as open,
          max(l.price) as high,
          min(l.price) as low,
          argMax(l.price, l.line_time) as close,
          sum(l.volume) as volume,
          sum(l.turnover) as turnover
        from {database}.lb_intraday_lines l
        inner join latest_day d on d.symbol = l.symbol
        where l.symbol in {symbol_filter}
          and l.line_time >= d.trade_start
          and l.line_time < d.trade_start + interval 1 day
        group by l.symbol, bucket
        order by l.symbol, bucket desc
        limit {max(1, int(limit))} by l.symbol
        """
    )
    output: dict[str, list[dict[str, Any]]] = {}
    for row in rows:
        symbol = str(row.get("symbol") or "").strip().upper()
        if not symbol:
            continue
        output.setdefault(symbol, []).append(
            {
                "time": str(row.get("bucket") or ""),
                "open": _num(row.get("open")),
                "high": _num(row.get("high")),
                "low": _num(row.get("low")),
                "close": _num(row.get("close")),
                "volume": _num(row.get("volume")),
                "turnover": _num(row.get("turnover")),
            }
        )
    for bars in output.values():
        bars.sort(key=lambda item: str(item.get("time") or ""))
    return output


def classify_intraday_shape(bars: list[dict[str, Any]], *, min_bars: int = 6) -> IntradayShape | None:
    clean = [bar for bar in bars if _num(bar.get("close")) > 0 and _num(bar.get("open")) > 0]
    if len(clean) < min_bars:
        return None
    closes = [_num(bar.get("close")) for bar in clean]
    highs = [_num(bar.get("high")) for bar in clean]
    lows = [_num(bar.get("low")) for bar in clean]
    turnovers = [_num(bar.get("turnover")) for bar in clean]
    volumes = [_num(bar.get("volume")) for bar in clean]
    last = closes[-1]
    first_open = _num(clean[0].get("open"), last)
    minute_return = _return(closes[-2], last) if len(closes) >= 2 else 0.0
    return_5m = _window_return(closes, 2)
    return_15m = _window_return(closes, 4)
    return_30m = _window_return(closes, 7)
    intraday_return = _return(first_open, last)
    high_30 = max(highs[-7:] or highs)
    low_30 = min(lows[-7:] or lows)
    high_day = max(highs)
    low_day = min(lows)
    close_position_30m = _safe_div(last - low_30, high_30 - low_30, 0.5)
    drawdown_from_high = _return(high_day, last)
    rebound_from_low = _return(low_day, last)
    vwap = _safe_div(sum(turnovers), sum(volumes), last)
    vwap_deviation = _return(vwap, last)
    recent_turnover = sum(turnovers[-4:])
    baseline = sum(turnovers[:-4]) / max(1, len(turnovers[:-4])) * min(4, len(turnovers))
    turnover_ratio_15m = _safe_div(recent_turnover, baseline, 1.0)

    weak_pressure = 0.0
    weak_pressure += max(0.0, -return_15m) * 18
    weak_pressure += max(0.0, -return_30m) * 10
    weak_pressure += max(0.0, -vwap_deviation) * 12
    weak_pressure += max(0.0, -drawdown_from_high) * 8
    weak_pressure += max(0.0, 0.45 - close_position_30m) * 0.7
    if turnover_ratio_15m > 1.4 and return_15m < 0:
        weak_pressure += min(0.18, (turnover_ratio_15m - 1.4) * 0.05)
    transition_risk = max(0.05, min(0.95, 0.35 + weak_pressure))

    label = "震荡观察"
    action = "observe"
    if intraday_return >= 0.008 and drawdown_from_high <= -0.012 and return_15m <= -0.004 and close_position_30m < 0.45:
        label = "冲高衰竭"
        action = "block_buy"
        transition_risk = max(transition_risk, 0.72)
    elif return_15m <= -0.006 and vwap_deviation < -0.003 and close_position_30m < 0.40:
        label = "趋势转弱"
        action = "block_buy"
        transition_risk = max(transition_risk, 0.68)
    elif intraday_return <= -0.018 and return_5m > 0.002 and rebound_from_low > 0.006:
        label = "急跌止稳观察"
        action = "observe"
        transition_risk = max(transition_risk, 0.55)
    elif return_15m >= 0.004 and close_position_30m >= 0.72 and vwap_deviation >= 0:
        label = "突破确认"
        action = "allow_buy"
        transition_risk = min(transition_risk, 0.32)
    elif intraday_return >= 0.008 and return_15m >= -0.001 and close_position_30m >= 0.62 and vwap_deviation >= -0.002:
        label = "强趋势延续"
        action = "allow_buy"
        transition_risk = min(transition_risk, 0.38)
    elif drawdown_from_high < -0.006 and return_5m >= 0 and close_position_30m >= 0.45:
        label = "回踩承接"
        action = "allow_buy"
        transition_risk = min(transition_risk, 0.45)

    confidence = max(
        0.45,
        min(
            0.95,
            0.55
            + abs(return_15m) * 14
            + abs(vwap_deviation) * 8
            + abs(close_position_30m - 0.5) * 0.35
            + min(0.12, max(0.0, turnover_ratio_15m - 1.0) * 0.04),
        ),
    )
    return IntradayShape(
        label=label,
        confidence=round(confidence, 4),
        transition_risk=round(transition_risk, 4),
        action=action,
        minute_return=round(minute_return, 6),
        return_5m=round(return_5m, 6),
        return_15m=round(return_15m, 6),
        intraday_return=round(intraday_return, 6),
        vwap_deviation=round(vwap_deviation, 6),
        close_position_30m=round(close_position_30m, 6),
        drawdown_from_high=round(drawdown_from_high, 6),
        rebound_from_low=round(rebound_from_low, 6),
        turnover_ratio_15m=round(turnover_ratio_15m, 4),
        sample_count=len(clean),
    )


def merge_daily_and_intraday_shape(daily_shape: dict[str, Any] | None, intraday_shape: dict[str, Any] | None) -> dict[str, Any] | None:
    if not daily_shape and not intraday_shape:
        return None
    if not intraday_shape:
        return daily_shape
    merged = dict(daily_shape or {})
    if daily_shape and daily_shape.get("label"):
        merged["daily_label"] = daily_shape.get("label")
    merged.update(
        {
            "label": intraday_shape.get("label"),
            "hmm_transition_risk": intraday_shape.get("transition_risk"),
            "hmm_state_prob": intraday_shape.get("confidence"),
            "hmm_state_momentum": intraday_shape.get("return_15m"),
            "intraday": intraday_shape,
        }
    )
    return merged


def _window_return(values: list[float], periods: int) -> float:
    if len(values) <= periods:
        return _return(values[0], values[-1])
    return _return(values[-periods - 1], values[-1])


def _return(base: float, value: float) -> float:
    return _safe_div(value, base, 1.0) - 1.0 if base else 0.0


def _safe_div(numerator: float, denominator: float, default: float) -> float:
    return numerator / denominator if denominator else default


def _num(value: Any, default: float = 0.0) -> float:
    try:
        return float(value)
    except (TypeError, ValueError):
        return default
