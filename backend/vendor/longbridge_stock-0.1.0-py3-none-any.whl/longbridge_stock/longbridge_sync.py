from __future__ import annotations

import json
import subprocess
import threading
import time
import urllib.request
import zipfile
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass, field
from datetime import datetime, timezone
from io import BytesIO
from pathlib import Path
from typing import Any
from xml.etree import ElementTree as ET

import psycopg

from longbridge_stock.config import load_yaml


DEFAULT_CALC_INDEX_FIELDS = [
    "last_done",
    "turnover",
    "turnover_rate",
    "mktcap",
    "amplitude",
    "volume_ratio",
    "pe",
    "pb",
    "dps_rate",
    "five_day_change_rate",
    "ten_day_change_rate",
    "half_year_change_rate",
]

DEFAULT_HKEX_LIST_URL = "https://www.hkex.com.hk/eng/services/trading/securities/securitieslists/ListOfSecurities.xlsx"
HKEX_ALLOWED_CATEGORIES = {"Equity", "Real Estate Investment Trusts"}
XLSX_NS = {"m": "http://schemas.openxmlformats.org/spreadsheetml/2006/main"}


@dataclass(frozen=True)
class MarketSyncConfig:
    enabled: bool = True
    indexes: list[str] = field(default_factory=list)
    symbols: list[str] = field(default_factory=list)
    limit: int = 100
    security_list: bool = False
    hkex_full_market: bool = False
    hkex_list_url: str = DEFAULT_HKEX_LIST_URL
    symbol_universe: bool = False


@dataclass(frozen=True)
class LongbridgeSyncConfig:
    data_root: Path = Path("/home/alwin/data/longbridge")
    postgres_dsn: str | None = None
    rate_limit_per_second: float = 5
    max_workers: int = 1
    kline_count: int = 260
    skip_existing_daily: bool = False
    include_watchlist: bool = True
    exclude_options: bool = True
    markets: dict[str, MarketSyncConfig] = field(default_factory=dict)
    datasets: dict[str, bool] = field(default_factory=dict)
    calc_index_fields: list[str] = field(default_factory=lambda: list(DEFAULT_CALC_INDEX_FIELDS))


@dataclass(frozen=True)
class SymbolSyncResult:
    symbol: str
    market: str
    ok: bool
    datasets: list[str]
    error: str | None = None


class RateLimiter:
    def __init__(self, calls_per_second: float) -> None:
        if calls_per_second <= 0:
            raise ValueError("calls_per_second must be positive")
        self.min_interval = 1.0 / calls_per_second
        self._last_call = 0.0
        self._lock = threading.Lock()

    def wait(self) -> None:
        with self._lock:
            now = time.monotonic()
            remaining = self.min_interval - (now - self._last_call)
            if remaining > 0:
                time.sleep(remaining)
            self._last_call = time.monotonic()


class LongbridgeCliClient:
    def __init__(self, executable: str = "longbridge", rate_limit_per_second: float = 5) -> None:
        self.executable = executable
        self.rate_limiter = RateLimiter(rate_limit_per_second)

    def run(self, args: list[str]) -> Any:
        self.rate_limiter.wait()
        completed = subprocess.run(
            [self.executable, *args, "--format", "json"],
            check=False,
            capture_output=True,
            text=True,
            encoding="utf-8",
            timeout=120,
        )
        if completed.returncode != 0:
            message = completed.stderr.strip() or completed.stdout.strip()
            raise RuntimeError(message or f"longbridge command failed: {' '.join(args)}")
        stdout = completed.stdout.strip()
        return json.loads(stdout) if stdout else None

    def quote(self, symbol: str) -> Any:
        return self.run(["quote", symbol])

    def quote_many(self, symbols: list[str]) -> Any:
        if not symbols:
            return []
        return self.run(["quote", *symbols])

    def kline(self, symbol: str, count: int) -> Any:
        return self.run(["kline", symbol, "--period", "day", "--count", str(count), "--adjust", "forward"])

    def static(self, symbol: str) -> Any:
        return self.run(["static", symbol])

    def calc_index(self, symbol: str, fields: list[str]) -> Any:
        return self.run(["calc-index", symbol, "--fields", ",".join(fields)])

    def capital(self, symbol: str) -> Any:
        return self.run(["capital", symbol])

    def capital_flow(self, symbol: str) -> Any:
        return self.run(["capital", symbol, "--flow"])

    def valuation(self, symbol: str) -> Any:
        return self.run(["valuation", symbol])

    def financial_report(self, symbol: str) -> Any:
        return self.run(["financial-report", symbol, "--kind", "ALL", "--report", "qf"])

    def company(self, symbol: str) -> Any:
        return self.run(["company", symbol, "--lang", "zh-CN"])

    def executive(self, symbol: str) -> Any:
        return self.run(["executive", symbol, "--lang", "zh-CN"])

    def invest_relation(self, symbol: str) -> Any:
        return self.run(["invest-relation", symbol, "--lang", "zh-CN"])

    def operating(self, symbol: str) -> Any:
        return self.run(["operating", symbol, "--lang", "zh-CN"])

    def dividend(self, symbol: str) -> Any:
        return self.run(["dividend", symbol, "--lang", "zh-CN"])

    def institution_rating(self, symbol: str) -> Any:
        return self.run(["institution-rating", symbol, "--lang", "zh-CN"])

    def consensus(self, symbol: str) -> Any:
        return self.run(["consensus", symbol, "--lang", "zh-CN"])

    def news(self, symbol: str, count: int = 5, lang: str = "zh-CN") -> Any:
        return self.run(["news", symbol, "--count", str(count), "--lang", lang])

    def constituent(self, index_symbol: str, limit: int) -> Any:
        return self.run(["constituent", index_symbol, "--limit", str(limit), "--sort", "market-cap"])

    def watchlist(self) -> Any:
        return self.run(["watchlist"])

    def positions(self) -> Any:
        return self.run(["positions"])

    def order_history(self, start: str) -> Any:
        return self.run(["order", "--history", "--start", str(start)])

    def security_list(self, market: str = "US") -> Any:
        return self.run(["security-list", market])


class LongbridgeDataSync:
    def __init__(
        self,
        config: LongbridgeSyncConfig,
        client: LongbridgeCliClient | None = None,
        store: Any | None = None,
        client_factory: Any | None = None,
    ) -> None:
        self.config = config
        self.client = client or LongbridgeCliClient(rate_limit_per_second=config.rate_limit_per_second)
        self.client_factory = client_factory
        self._thread_local = threading.local()
        self._shared_rate_limiter = RateLimiter(config.rate_limit_per_second)
        self.store = store
        if self.store is None and config.postgres_dsn:
            from longbridge_stock.postgres_store import LongbridgePostgresStore

            self.store = LongbridgePostgresStore(config.postgres_dsn)

    def sync_once(self) -> list[SymbolSyncResult]:
        self._ensure_dirs()
        status = {
            "started_at": _now_iso(),
            "data_root": str(self.config.data_root),
            "rate_limit_per_second": self.config.rate_limit_per_second,
            "markets": {},
        }
        results: list[SymbolSyncResult] = []
        for market, market_config in self.config.markets.items():
            if not market_config.enabled:
                continue
            symbols = self.discover_symbols(market, market_config)
            symbols = self._filter_symbols_for_enabled_datasets(market, symbols)
            market_results = self._sync_market(market, symbols, status, results)
            status["markets"][market] = {
                "symbols": len(symbols),
                "ok": sum(1 for item in market_results if item.ok),
                "failed": sum(1 for item in market_results if not item.ok),
            }
        status["finished_at"] = _now_iso()
        status["latest_results"] = _results_payload(results[-50:])
        self._write_status(status)
        return results

    def run_forever(self, interval_seconds: int) -> None:
        while True:
            self.sync_once()
            time.sleep(interval_seconds)

    def discover_symbols(self, market: str, market_config: MarketSyncConfig) -> list[str]:
        priority_symbols: list[str] = []
        symbols = list(market_config.symbols)
        if self.config.include_watchlist:
            for item in _extract_watchlist_symbols(self.client.watchlist(), exclude_options=self.config.exclude_options):
                if _market_key(item) == market:
                    priority_symbols.append(item)
        for index_symbol in market_config.indexes:
            payload = self.client.constituent(index_symbol, market_config.limit)
            for item in _extract_constituents(payload):
                symbols.append(item)
        if market_config.symbol_universe and self.config.postgres_dsn:
            symbols.extend(_load_market_symbols_from_postgres(self.config.postgres_dsn, market, market_config.limit))
        if market == "hk" and market_config.hkex_full_market:
            symbols.extend(fetch_hkex_full_market_symbols(market_config.hkex_list_url, limit=market_config.limit))
        if market_config.security_list:
            symbols.extend(_extract_security_list_symbols(self.client.security_list("US"), limit=market_config.limit))
        return _unique_preserve_order(priority_symbols + sorted(set(symbols)))

    def _filter_symbols_for_enabled_datasets(self, market: str, symbols: list[str]) -> list[str]:
        if not self.config.skip_existing_daily or not self.config.postgres_dsn:
            return symbols
        enabled = {name for name, enabled in self.config.datasets.items() if enabled}
        if enabled != {"kline"}:
            return symbols
        return _filter_symbols_missing_daily_bar(self.config.postgres_dsn, market, symbols)

    def _sync_market(
        self,
        market: str,
        symbols: list[str],
        status: dict[str, Any],
        results: list[SymbolSyncResult],
    ) -> list[SymbolSyncResult]:
        workers = max(1, int(self.config.max_workers or 1))
        if workers <= 1 or len(symbols) <= 1:
            market_results = []
            for symbol in symbols:
                result = self.sync_symbol(market, symbol)
                results.append(result)
                market_results.append(result)
                self._write_status(status | {"updated_at": _now_iso(), "latest_results": _results_payload(results[-50:])})
            return market_results

        market_results = []
        with ThreadPoolExecutor(max_workers=workers) as executor:
            future_map = {executor.submit(self.sync_symbol, market, symbol): symbol for symbol in symbols}
            for future in as_completed(future_map):
                symbol = future_map[future]
                try:
                    result = future.result()
                except Exception as exc:  # pragma: no cover - defensive guard for unexpected worker failures
                    result = SymbolSyncResult(symbol=symbol, market=market, ok=False, datasets=[], error=str(exc))
                results.append(result)
                market_results.append(result)
                self._write_status(status | {"updated_at": _now_iso(), "latest_results": _results_payload(results[-50:])})
        return market_results

    def _client_for_worker(self) -> Any:
        if self.client_factory is None:
            return self.client
        client = getattr(self._thread_local, "client", None)
        if client is None:
            client = self.client_factory()
            if hasattr(client, "rate_limiter"):
                client.rate_limiter = self._shared_rate_limiter
            self._thread_local.client = client
        return client

    def sync_symbol(self, market: str, symbol: str) -> SymbolSyncResult:
        client = self._client_for_worker()
        written: list[str] = []
        errors: list[str] = []
        datasets = self.config.datasets
        jobs: list[tuple[str, bool, Any]] = [
            ("quote", datasets.get("quote", True), lambda: client.quote(symbol)),
            ("kline", datasets.get("kline", True), lambda: client.kline(symbol, self.config.kline_count)),
            ("static", datasets.get("static", True), lambda: client.static(symbol)),
            ("calc_index", datasets.get("calc_index", True), lambda: client.calc_index(symbol, self.config.calc_index_fields)),
            ("valuation", datasets.get("valuation", True), lambda: client.valuation(symbol)),
            ("financial_report", datasets.get("financial_report", False), lambda: client.financial_report(symbol)),
            ("company", datasets.get("company", False), lambda: client.company(symbol)),
            ("executive", datasets.get("executive", False), lambda: client.executive(symbol)),
            ("invest_relation", datasets.get("invest_relation", False), lambda: client.invest_relation(symbol)),
            ("operating", datasets.get("operating", False), lambda: client.operating(symbol)),
            ("dividend", datasets.get("dividend", False), lambda: client.dividend(symbol)),
            ("institution_rating", datasets.get("institution_rating", False), lambda: client.institution_rating(symbol)),
            ("consensus", datasets.get("consensus", False), lambda: client.consensus(symbol)),
        ]
        for dataset, enabled, fetcher in jobs:
            if not enabled:
                continue
            try:
                self._write_dataset(dataset, market, symbol, fetcher())
                written.append(dataset)
            except Exception as exc:
                errors.append(f"{dataset}: {exc}")
                error_payload = {
                    "symbol": symbol,
                    "market": market,
                    "dataset": dataset,
                    "error": str(exc),
                    "updated_at": _now_iso(),
                }
                self._write_dataset("errors", market, f"{symbol}_{dataset}", error_payload)
        return SymbolSyncResult(
            symbol=symbol,
            market=market,
            ok=not errors,
            datasets=written,
            error="; ".join(errors) if errors else None,
        )

    def _ensure_dirs(self) -> None:
        for name in [
            "manifests",
            "quote",
            "kline",
            "static",
            "calc_index",
            "valuation",
            "financial_report",
            "company",
            "executive",
            "invest_relation",
            "operating",
            "dividend",
            "institution_rating",
            "consensus",
            "errors",
        ]:
            (self.config.data_root / "raw" / name).mkdir(parents=True, exist_ok=True)
        (self.config.data_root / "manifests").mkdir(parents=True, exist_ok=True)

    def _write_dataset(self, dataset: str, market: str, symbol: str, payload: Any) -> None:
        updated_at = _now_iso()
        output = self.config.data_root / "raw" / dataset / market / f"{_safe_symbol(symbol)}.json"
        output.parent.mkdir(parents=True, exist_ok=True)
        _atomic_write_json(
            output,
            {
                "symbol": symbol,
                "market": market,
                "dataset": dataset,
                "updated_at": updated_at,
                "payload": payload,
            },
        )
        if self.store is not None and dataset != "errors":
            self.store.upsert_dataset(symbol, market, dataset, payload, _parse_iso_datetime(updated_at))

    def _write_status(self, payload: dict[str, Any]) -> None:
        _atomic_write_json(self.config.data_root / "manifests" / "sync_status.json", payload)


def load_longbridge_sync_config(path: str | Path) -> LongbridgeSyncConfig:
    raw = load_yaml(path)
    markets = {
        str(name): MarketSyncConfig(
            enabled=bool(value.get("enabled", True)),
            indexes=list(value.get("indexes", [])),
            symbols=list(value.get("symbols", [])),
            limit=int(value.get("limit", 100)),
            security_list=bool(value.get("security_list", False)),
            hkex_full_market=bool(value.get("hkex_full_market", False)),
            hkex_list_url=str(value.get("hkex_list_url", DEFAULT_HKEX_LIST_URL)),
            symbol_universe=bool(value.get("symbol_universe", False)),
        )
        for name, value in dict(raw.get("markets", {})).items()
    }
    return LongbridgeSyncConfig(
        data_root=Path(raw.get("data_root", "/home/alwin/data/longbridge")),
        postgres_dsn=raw.get("postgres_dsn"),
        rate_limit_per_second=float(raw.get("rate_limit_per_second", 5)),
        max_workers=int(raw.get("max_workers", 1)),
        kline_count=int(raw.get("kline_count", 260)),
        skip_existing_daily=bool(raw.get("skip_existing_daily", False)),
        include_watchlist=bool(raw.get("include_watchlist", True)),
        exclude_options=bool(raw.get("exclude_options", True)),
        markets=markets,
        datasets={str(k): bool(v) for k, v in dict(raw.get("datasets", {})).items()},
        calc_index_fields=list(raw.get("calc_index_fields", DEFAULT_CALC_INDEX_FIELDS)),
    )


def read_sync_status(data_root: str | Path = "/home/alwin/data/longbridge") -> dict[str, Any] | None:
    path = Path(data_root) / "manifests" / "sync_status.json"
    if not path.exists():
        return None
    return json.loads(path.read_text(encoding="utf-8"))


def _extract_constituents(payload: Any) -> list[str]:
    if isinstance(payload, dict):
        rows = payload.get("stocks") or payload.get("list") or []
    elif isinstance(payload, list):
        rows = payload
    else:
        rows = []
    symbols = []
    for row in rows:
        symbol = row.get("symbol") or row.get("ticker")
        counter_id = row.get("counter_id")
        if not symbol and counter_id:
            symbol = _counter_id_to_symbol(str(counter_id))
        if symbol:
            symbols.append(str(symbol))
    return symbols


def _load_market_symbols_from_postgres(dsn: str, market: str, limit: int | None = None) -> list[str]:
    query = """
        select symbol
        from lb_symbols
        where lower(market) = %s
          and symbol !~ '^\\.'
        order by symbol
    """
    params: tuple[Any, ...]
    if limit:
        query += " limit %s"
        params = (market.lower(), limit)
    else:
        params = (market.lower(),)
    with psycopg.connect(dsn) as conn:
        return [str(row[0]) for row in conn.execute(query, params).fetchall()]


def _filter_symbols_missing_daily_bar(dsn: str, market: str, symbols: list[str]) -> list[str]:
    if not symbols:
        return []
    target_date = _latest_daily_target_date(dsn, market)
    if target_date is None:
        return symbols
    with psycopg.connect(dsn) as conn:
        rows = conn.execute(
            """
            select distinct symbol
            from lb_daily_bars
            where lower(market) = %s
              and trade_date = %s
              and symbol = any(%s)
            """,
            (market.lower(), target_date, symbols),
        ).fetchall()
    existing = {str(row[0]).upper() for row in rows}
    return [symbol for symbol in symbols if symbol.upper() not in existing]


def _latest_daily_target_date(dsn: str, market: str) -> Any | None:
    with psycopg.connect(dsn) as conn:
        row = conn.execute(
            """
            select max(trade_date)
            from lb_daily_bars
            where lower(market) = %s
            """,
            (market.lower(),),
        ).fetchone()
    return row[0] if row else None


def _extract_watchlist_symbols(payload: Any, exclude_options: bool = True) -> list[str]:
    if not isinstance(payload, list):
        return []
    symbols: list[str] = []
    for group in payload:
        securities = group.get("securities", []) if isinstance(group, dict) else []
        for item in securities:
            if not isinstance(item, dict):
                continue
            symbol = item.get("symbol")
            if not symbol:
                continue
            symbol = str(symbol)
            if exclude_options and _looks_like_option_symbol(symbol):
                continue
            symbols.append(symbol)
    return sorted(set(symbols))


def _extract_security_list_symbols(payload: Any, limit: int | None = None) -> list[str]:
    if isinstance(payload, list):
        rows = payload
    elif isinstance(payload, dict):
        rows = payload.get("list") or payload.get("securities") or []
    else:
        rows = []
    symbols = []
    for row in rows:
        if not isinstance(row, dict):
            continue
        symbol = row.get("symbol")
        if symbol and not _looks_like_option_symbol(str(symbol)):
            symbols.append(str(symbol))
    symbols = _unique_preserve_order(symbols)
    return symbols[:limit] if limit else symbols


def fetch_hkex_full_market_symbols(url: str = DEFAULT_HKEX_LIST_URL, limit: int | None = None) -> list[str]:
    with urllib.request.urlopen(url, timeout=120) as response:
        content = response.read()
    rows = _read_xlsx_dict_rows(content)
    symbols = _extract_hkex_symbols_from_rows(rows)
    return symbols[:limit] if limit else symbols


def _read_xlsx_dict_rows(content: bytes) -> list[dict[str, str]]:
    rows = _read_xlsx_rows(content)
    if not rows:
        return []
    header_index = next(
        (
            index
            for index, row in enumerate(rows)
            if any(_normalize_header(cell) == "stock code" for cell in row)
        ),
        None,
    )
    if header_index is None:
        return []
    headers = [_normalize_header(cell) for cell in rows[header_index]]
    result: list[dict[str, str]] = []
    for row in rows[header_index + 1 :]:
        if not any(row):
            continue
        result.append({headers[index]: value.strip() for index, value in enumerate(row) if index < len(headers) and headers[index]})
    return result


def _read_xlsx_rows(content: bytes) -> list[list[str]]:
    with zipfile.ZipFile(BytesIO(content)) as archive:
        shared_strings = _read_shared_strings(archive)
        sheet = ET.fromstring(archive.read("xl/worksheets/sheet1.xml"))
    parsed_rows: list[list[str]] = []
    for row in sheet.findall(".//m:sheetData/m:row", XLSX_NS):
        values: list[str] = []
        for cell in row.findall("m:c", XLSX_NS):
            index = _column_index(cell.attrib.get("r", "A"))
            while len(values) <= index:
                values.append("")
            value_node = cell.find("m:v", XLSX_NS)
            value = "" if value_node is None else value_node.text or ""
            if cell.attrib.get("t") == "s" and value:
                value = shared_strings[int(value)]
            values[index] = value.strip()
        parsed_rows.append(values)
    return parsed_rows


def _read_shared_strings(archive: zipfile.ZipFile) -> list[str]:
    if "xl/sharedStrings.xml" not in archive.namelist():
        return []
    root = ET.fromstring(archive.read("xl/sharedStrings.xml"))
    return ["".join(text.text or "" for text in item.findall(".//m:t", XLSX_NS)) for item in root.findall("m:si", XLSX_NS)]


def _extract_hkex_symbols_from_rows(rows: list[dict[str, str]]) -> list[str]:
    symbols: list[str] = []
    for row in rows:
        category = row.get("category") or row.get("Category") or ""
        if category not in HKEX_ALLOWED_CATEGORIES:
            continue
        code = row.get("stock code") or row.get("Stock Code") or ""
        symbol = _hkex_code_to_symbol(code)
        if symbol:
            symbols.append(symbol)
    return _unique_preserve_order(symbols)


def _hkex_code_to_symbol(code: str) -> str | None:
    digits = "".join(char for char in str(code).strip() if char.isdigit())
    if not digits:
        return None
    return f"{int(digits)}.HK"


def _normalize_header(value: str) -> str:
    return " ".join(str(value).strip().lower().split())


def _column_index(cell_reference: str) -> int:
    letters = "".join(char for char in cell_reference if char.isalpha())
    index = 0
    for char in letters:
        index = index * 26 + ord(char.upper()) - 64
    return index - 1


def _unique_preserve_order(values: list[str]) -> list[str]:
    seen = set()
    result = []
    for value in values:
        if value in seen:
            continue
        seen.add(value)
        result.append(value)
    return result


def _market_key(symbol: str) -> str | None:
    if symbol.endswith((".SH", ".SZ")):
        return "cn"
    if symbol.endswith(".HK"):
        return "hk"
    if symbol.endswith(".US"):
        return "us"
    return None


def _looks_like_option_symbol(symbol: str) -> bool:
    if not symbol.endswith(".US"):
        return False
    code = symbol.removesuffix(".US")
    return any(marker in code for marker in ("260", "250", "270")) and ("C" in code[-8:] or "P" in code[-8:])


def _counter_id_to_symbol(counter_id: str) -> str:
    parts = counter_id.split("/")
    if len(parts) < 3:
        return counter_id
    market = parts[1].upper()
    code = parts[2]
    suffix = {"SH": "SH", "SZ": "SZ", "HK": "HK", "US": "US", "SG": "SG"}.get(market, market)
    return f"{code}.{suffix}"


def _safe_symbol(symbol: str) -> str:
    return symbol.replace("/", "_").replace(".", "_")


def _results_payload(results: list[SymbolSyncResult]) -> list[dict[str, Any]]:
    return [
        {"symbol": item.symbol, "market": item.market, "ok": item.ok, "datasets": item.datasets, "error": item.error}
        for item in results
    ]


def _atomic_write_json(path: Path, payload: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    tmp.replace(path)


def _now_iso() -> str:
    return datetime.now(timezone.utc).astimezone().isoformat(timespec="seconds")


def _parse_iso_datetime(value: str) -> datetime:
    return datetime.fromisoformat(value)
