from __future__ import annotations

import os
import sys
from datetime import datetime, timedelta, timezone
from math import isfinite
from typing import Any, Iterable

from longbridge_stock import clickhouse_realtime
from longbridge_stock.tdx_wave_formula import evaluate_daily_wave_formula, evaluate_intraday_wave_formula


ASIA_SHANGHAI = timezone(timedelta(hours=8))


def build_stock_tags(symbols: Iterable[str], *, lookback_days: int = 60) -> dict[str, Any]:
    symbol_list = _symbols(symbols)
    lookback_days = max(20, min(int(lookback_days), 250))
    realtime_rows = _fetch_realtime_rows(symbol_list)
    daily_bars = fetch_daily_bars_by_symbol(symbol_list, limit=max(lookback_days + 30, 90))
    intraday_bars = fetch_intraday_bars_by_symbol(symbol_list, limit=240)
    items = [
        build_stock_tag(
            symbol,
            bars=daily_bars.get(symbol, []),
            intraday_bars=intraday_bars.get(symbol, []),
            realtime=realtime_rows.get(symbol, {}),
            lookback_days=lookback_days,
        )
        for symbol in symbol_list
    ]
    return {
        "generatedAt": datetime.now(ASIA_SHANGHAI).isoformat(timespec="seconds"),
        "lookbackDays": lookback_days,
        "total": len(items),
        "items": items,
    }


def build_stock_tag(
    symbol: str,
    *,
    bars: list[dict[str, Any]],
    intraday_bars: list[dict[str, Any]] | None = None,
    realtime: dict[str, Any] | None = None,
    lookback_days: int = 60,
) -> dict[str, Any]:
    normalized_symbol = symbol.strip().upper()
    realtime = realtime or {}
    sorted_bars = sorted(bars, key=lambda row: str(row.get("date") or row.get("tradeDate") or ""))
    latest_bar = sorted_bars[-1] if sorted_bars else {}
    previous_bars = sorted_bars[-lookback_days - 1 : -1] if len(sorted_bars) > 1 else []

    last = _num_or_none(realtime.get("last") or realtime.get("last_done")) or _num_or_none(latest_bar.get("close"))
    high = _num_or_none(realtime.get("high")) or _num_or_none(latest_bar.get("high"))
    low = _num_or_none(realtime.get("low")) or _num_or_none(latest_bar.get("low"))
    close = last or _num_or_none(latest_bar.get("close"))
    change = _num_or_none(realtime.get("change_pct") or realtime.get("change_percentage"))
    total_in = _num_or_none(realtime.get("total_in") or realtime.get("totalIn"))
    total_out = _num_or_none(realtime.get("total_out") or realtime.get("totalOut"))
    total_net = _num_or_none(realtime.get("total_net") or realtime.get("totalNet"))
    large_net = _num_or_none(realtime.get("large_net") or realtime.get("largeNet"))
    medium_net = _num_or_none(realtime.get("medium_net") or realtime.get("mediumNet"))
    small_net = _num_or_none(realtime.get("small_net") or realtime.get("smallNet"))
    large_net_ratio = _num_or_none(realtime.get("large_net_ratio") or realtime.get("largeNetRatio"))
    small_net_ratio = _num_or_none(realtime.get("small_net_ratio") or realtime.get("smallNetRatio"))
    flow_15m = _num_or_none(realtime.get("flow_15m") or realtime.get("flow15m"))
    flow_30m = _num_or_none(realtime.get("flow_30m") or realtime.get("flow30m"))
    flow_today = _num_or_none(realtime.get("flow_today") or realtime.get("flowToday"))
    flow_points = _int_or_none(realtime.get("flow_points") or realtime.get("flowPoints"))
    closes = [_num(row.get("close")) for row in sorted_bars if _num_or_none(row.get("close")) is not None]
    ma20 = _rolling_mean(closes, 20)
    ma60 = _rolling_mean(closes, 60)
    volume_ratio = _volume_ratio(sorted_bars, realtime)
    box = _box_state(previous_bars, close=close, high=high, low=low, volume_ratio=volume_ratio)
    technical_labels = _technical_labels(closes, close=close, ma20=ma20, ma60=ma60, volume_ratio=volume_ratio)
    daily_formula = evaluate_daily_wave_formula(sorted_bars, current=close)
    if daily_formula.get("state") and daily_formula.get("state") != "无":
        technical_labels["tdxWave"] = str(daily_formula.get("state"))
    technical = _technical_state_from_labels(technical_labels)
    divergence, divergence_evidence, divergence_score = _divergence(change, total_net, large_net, volume_ratio)
    main_force, force_evidence, force_score = _main_force(
        change=change,
        total_net=total_net,
        large_net=large_net,
        close=close,
        ma20=ma20,
        box_structure=box["label"],
        divergence=divergence,
        technical_state=technical,
    )
    confidence = _confidence(
        base=38,
        box_score=box["score"],
        divergence_score=divergence_score,
        force_score=force_score,
        has_daily=bool(previous_bars),
        has_realtime=bool(realtime),
    )
    evidence = [
        *box["evidence"],
        *divergence_evidence,
        *force_evidence,
    ]
    if flow_30m is not None:
        evidence.append(f"尾盘30分钟资金{_money_10k(flow_30m)}")
    intraday = _intraday_signal(
        intraday_bars or [],
        realtime=realtime,
        close=close,
        total_net=total_net,
        large_net=large_net,
        flow_15m=flow_15m,
        flow_30m=flow_30m,
    )
    capital_flow = _capital_flow_snapshot(
        realtime=realtime,
        last=close,
        change=change,
        total_in=total_in,
        total_out=total_out,
        total_net=total_net,
        large_net=large_net,
        medium_net=medium_net,
        small_net=small_net,
        large_net_ratio=large_net_ratio,
        small_net_ratio=small_net_ratio,
        flow_15m=flow_15m,
        flow_30m=flow_30m,
        flow_today=flow_today,
        flow_points=flow_points,
    )
    metrics = {
        "last": close,
        "changePct": change,
        "totalIn": total_in,
        "totalOut": total_out,
        "totalNet": total_net,
        "largeNet": large_net,
        "mediumNet": medium_net,
        "smallNet": small_net,
        "flow15m": flow_15m,
        "flow30m": flow_30m,
        "flowToday": flow_today,
        "ma20": ma20,
        "ma60": ma60,
        "volumeRatio20": volume_ratio,
        "boxUpper": box.get("upper"),
        "boxLower": box.get("lower"),
        "boxWidthPct": box.get("widthPct"),
        "boxPosition": box.get("position"),
    }
    trade_advice = _trade_advice(
        symbol=normalized_symbol,
        metrics=metrics,
        main_force=main_force,
        divergence=divergence,
        box_structure=box["label"],
        technical_labels=technical_labels,
        technical_state=technical,
        intraday=intraday,
        capital_flow=capital_flow,
        confidence=confidence,
    )
    return {
        "symbol": normalized_symbol,
        "mainForce": main_force,
        "divergence": divergence,
        "boxStructure": box["label"],
        "technicalState": technical,
        "labels": {
            "mainForce": main_force,
            "divergence": divergence,
            "boxStructure": box["label"],
            "intradayAction": intraday["actionBias"],
            **technical_labels,
        },
        "intraday": intraday,
        "formulaSignals": {"daily": daily_formula, "intraday": intraday.get("formulaSignals")},
        "capitalFlow": capital_flow,
        "tradeAdvice": trade_advice,
        "confidence": confidence,
        "metrics": metrics,
        "evidence": evidence[:8] or ["现有数据未形成一致标签"],
    }


def fetch_daily_bars_by_symbol(symbols: list[str], *, limit: int) -> dict[str, list[dict[str, Any]]]:
    if not symbols:
        return {}
    dsn = os.getenv("POSTGRES_DSN") or os.getenv("LONGBRIDGE_PG_DSN") or "dbname=longbridge_stock user=alwin host=/var/run/postgresql"
    try:
        import psycopg
    except Exception:
        return {}
    placeholders = ",".join(["%s"] * len(symbols))
    sql = f"""
        select symbol, trade_date, open, high, low, close, volume, turnover
        from lb_daily_bars
        where symbol in ({placeholders})
        order by symbol, trade_date desc
    """
    try:
        with psycopg.connect(dsn, connect_timeout=5) as conn:
            with conn.cursor() as cur:
                cur.execute(sql, tuple(symbols))
                rows = cur.fetchall()
    except Exception:
        return {}
    grouped: dict[str, list[dict[str, Any]]] = {}
    for symbol, trade_date, open_, high, low, close, volume, turnover in rows:
        normalized = str(symbol).strip().upper()
        bucket = grouped.setdefault(normalized, [])
        if len(bucket) >= limit:
            continue
        bucket.append(
            {
                "date": trade_date.isoformat() if hasattr(trade_date, "isoformat") else str(trade_date),
                "open": _num_or_none(open_),
                "high": _num_or_none(high),
                "low": _num_or_none(low),
                "close": _num_or_none(close),
                "volume": _num_or_none(volume),
                "turnover": _num_or_none(turnover),
            }
        )
    return {symbol: list(reversed(items)) for symbol, items in grouped.items()}


def fetch_intraday_bars_by_symbol(symbols: list[str], *, limit: int = 240) -> dict[str, list[dict[str, Any]]]:
    if not symbols or not clickhouse_realtime.enabled():
        return {}
    try:
        database = clickhouse_realtime._ident(clickhouse_realtime._database())
        symbol_filter = clickhouse_realtime._symbol_tuple(_symbols(symbols))
        rows = clickhouse_realtime._query_json_each_row(
            f"""
            with (
              select toStartOfDay(max(line_time))
              from {database}.lb_intraday_lines
              where symbol in {symbol_filter}
            ) as trade_start
            select
              symbol,
              toString(toStartOfInterval(line_time, interval 1 minute)) as bucket,
              argMin(price, line_time) as open,
              max(price) as high,
              min(price) as low,
              argMax(price, line_time) as close,
              argMax(avg_price, line_time) as avg_price,
              sum(volume) as volume,
              sum(turnover) as turnover
            from {database}.lb_intraday_lines
            where symbol in {symbol_filter}
              and line_time >= trade_start
              and line_time < trade_start + interval 1 day
            group by symbol, bucket
            order by symbol, bucket desc
            limit {int(limit)} by symbol
            """
        )
    except Exception:
        return {}
    grouped: dict[str, list[dict[str, Any]]] = {}
    for row in rows:
        symbol = str(row.get("symbol") or "").strip().upper()
        if not symbol:
            continue
        grouped.setdefault(symbol, []).append(
            {
                "time": str(row.get("bucket") or ""),
                "date": str(row.get("bucket") or ""),
                "open": _num_or_none(row.get("open")),
                "high": _num_or_none(row.get("high")),
                "low": _num_or_none(row.get("low")),
                "close": _num_or_none(row.get("close")),
                "avgPrice": _num_or_none(row.get("avg_price")),
                "volume": _num_or_none(row.get("volume")),
                "turnover": _num_or_none(row.get("turnover")),
            }
        )
    return {symbol: list(reversed(items)) for symbol, items in grouped.items()}


def _fetch_realtime_rows(symbols: list[str]) -> dict[str, dict[str, Any]]:
    try:
        return clickhouse_realtime.fetch_realtime_signal_rows(
            symbols,
            now=datetime.now(ASIA_SHANGHAI),
            max_quote_age_minutes=24 * 60,
        )
    except Exception as exc:
        print(f"stock_tags realtime fetch failed: {exc}", file=sys.stderr, flush=True)
        return {}


def _box_state(
    previous_bars: list[dict[str, Any]],
    *,
    close: float | None,
    high: float | None,
    low: float | None,
    volume_ratio: float | None,
) -> dict[str, Any]:
    highs = [_num(row.get("high")) for row in previous_bars if _num_or_none(row.get("high")) is not None]
    lows = [_num(row.get("low")) for row in previous_bars if _num_or_none(row.get("low")) is not None]
    if not highs or not lows or close is None:
        return {"label": "数据不足", "score": 0, "evidence": ["箱体数据不足"]}
    upper = max(highs)
    lower = min(lows)
    mid = (upper + lower) / 2 if upper and lower else None
    width_pct = (upper - lower) / mid if mid and mid > 0 else None
    position = (close - lower) / (upper - lower) if upper > lower else 0.5
    evidence = [f"近{len(previous_bars)}日区间上沿{_price(upper)}，下沿{_price(lower)}"]
    if width_pct is not None:
        evidence.append(f"区间宽度约{width_pct * 100:.1f}%")
    high = close if high is None else high
    low = close if low is None else low
    if close > upper and (volume_ratio is None or volume_ratio >= 1.2):
        evidence.append("收盘突破箱体上沿")
        if volume_ratio is not None:
            evidence.append(f"量比约{volume_ratio:.2f}")
        return {"label": "有效突破箱体", "score": 16, "upper": upper, "lower": lower, "widthPct": width_pct, "position": position, "evidence": evidence}
    if high > upper and close <= upper:
        evidence.append("盘中突破箱体上沿但收回箱体内")
        return {"label": "假突破回落", "score": 18, "upper": upper, "lower": lower, "widthPct": width_pct, "position": position, "evidence": evidence}
    if close < lower:
        evidence.append("收盘跌破箱体下沿")
        return {"label": "跌破箱体下沿", "score": 16, "upper": upper, "lower": lower, "widthPct": width_pct, "position": position, "evidence": evidence}
    if close >= upper * 0.98:
        evidence.append("靠近箱体上沿但尚未有效突破")
        return {"label": "箱体上沿承压", "score": 8, "upper": upper, "lower": lower, "widthPct": width_pct, "position": position, "evidence": evidence}
    if low <= lower * 1.02 and close >= lower:
        evidence.append("回踩箱体下沿后仍收回箱体内")
        return {"label": "箱体下沿支撑", "score": 10, "upper": upper, "lower": lower, "widthPct": width_pct, "position": position, "evidence": evidence}
    if width_pct is not None and width_pct > 0.45:
        evidence.append("区间过宽，暂不视为收敛箱体")
        return {"label": "宽幅区间内", "score": 3, "upper": upper, "lower": lower, "widthPct": width_pct, "position": position, "evidence": evidence}
    return {"label": "箱体震荡中", "score": 4, "upper": upper, "lower": lower, "widthPct": width_pct, "position": position, "evidence": evidence}


def _divergence(
    change: float | None,
    total_net: float | None,
    large_net: float | None,
    volume_ratio: float | None,
) -> tuple[str, list[str], int]:
    if change is not None and change >= 0.5 and total_net is not None and total_net < 0:
        return "价涨资流出", [f"上涨{change:+.2f}%但资金净流出{_money_10k(total_net)}"], 14
    if change is not None and change <= -0.5 and total_net is not None and total_net > 0:
        return "价跌资流入", [f"下跌{change:+.2f}%但资金净流入{_money_10k(total_net)}"], 14
    if volume_ratio is not None and volume_ratio >= 1.5 and (change is None or abs(change) < 0.6):
        return "放量不涨", [f"量比约{volume_ratio:.2f}但价格推动有限"], 12
    if total_net is not None and large_net is not None and total_net * large_net < 0:
        return "资金分歧", ["总资金与大单方向不一致"], 8
    return "无明显背离", [], 0


def _main_force(
    *,
    change: float | None,
    total_net: float | None,
    large_net: float | None,
    close: float | None,
    ma20: float | None,
    box_structure: str,
    divergence: str,
    technical_state: str,
) -> tuple[str, list[str], int]:
    capital_in = total_net is not None and total_net > 0 and large_net is not None and large_net > 0
    capital_out = total_net is not None and total_net < 0 and large_net is not None and large_net < 0
    above_ma20 = close is not None and ma20 is not None and close >= ma20
    below_ma20 = close is not None and ma20 is not None and close < ma20
    if box_structure == "假突破回落" and (capital_out or divergence in {"价涨资流出", "放量不涨"}):
        return "疑似派发", ["假突破叠加资金或量价压力"], 16
    if capital_out and (box_structure == "跌破箱体下沿" or below_ma20 or "MACD转弱" in technical_state):
        return "疑似撤退", ["资金流出且结构转弱"], 15
    if capital_in and divergence == "价跌资流入" and (box_structure == "箱体下沿支撑" or above_ma20):
        return "疑似洗盘", ["下跌时资金承接，结构未破"], 15
    if capital_in and box_structure in {"箱体下沿支撑", "箱体震荡中", "有效突破箱体"} and (change is None or change < 2.5):
        return "疑似吸筹", ["资金流入且价格未过度拉升"], 12
    return "无明显主力迹象", [], 0


def _intraday_signal(
    intraday_bars: list[dict[str, Any]],
    *,
    realtime: dict[str, Any],
    close: float | None,
    total_net: float | None,
    large_net: float | None,
    flow_15m: float | None,
    flow_30m: float | None,
) -> dict[str, Any]:
    bars = sorted(intraday_bars, key=lambda row: str(row.get("time") or row.get("date") or ""))
    prices = [_num_or_none(row.get("close") or row.get("price")) for row in bars]
    prices = [price for price in prices if price is not None]
    current = close or (prices[-1] if prices else None)
    if current is None or len(prices) < 3:
        capital_state = _intraday_capital_label(total_net, large_net, flow_15m, flow_30m)
        return {
        "buyPoint": "无明确买点",
        "sellPoint": "无明确卖点",
        "actionBias": "持有观察",
        "intradayTrend": "盘中数据不足",
            "intradayTrendState": "盘中数据不足",
            "intradayMainForce": "盘中数据不足",
            "intradayPosition": "位置数据不足",
        "intradayCapital": capital_state,
        "intradayRisk": "数据不足",
        "macdWindows": {},
        "macdGoldenCrossWindows": [],
        "macdBuySignal": False,
        "formulaSignals": _empty_formula_signals(),
        "tags": {
            "trendState": "盘中数据不足",
            "mainForceState": "盘中数据不足",
            "positionState": "位置数据不足",
            "capitalState": capital_state,
            "riskState": "数据不足",
            "macdState": "MACD数据不足",
            "formulaState": "公式数据不足",
        },
            "levels": {},
            "evidence": ["分钟线数据不足"],
        }

    highs = [_num(row.get("high") or row.get("close") or row.get("price")) for row in bars if _num_or_none(row.get("high") or row.get("close") or row.get("price")) is not None]
    lows = [_num(row.get("low") or row.get("close") or row.get("price")) for row in bars if _num_or_none(row.get("low") or row.get("close") or row.get("price")) is not None]
    day_high = max(highs) if highs else max(prices)
    day_low = min(lows) if lows else min(prices)
    avg_price = _intraday_avg_price(bars, prices)
    ret_5m = _window_return(prices, 5)
    ret_15m = _window_return(prices, 15)
    position = (current - day_low) / (day_high - day_low) if day_high > day_low else 0.5
    capital = _intraday_capital_label(total_net, large_net, flow_15m, flow_30m)
    macd_signals = _intraday_macd_signals(prices)
    realtime_high = _num_or_none(realtime.get("high"))
    realtime_low = _num_or_none(realtime.get("low"))
    formula_signals = evaluate_intraday_wave_formula(
        bars,
        current=current,
        high=realtime_high if realtime_high is not None else (max(highs) if highs else current),
        low=realtime_low if realtime_low is not None else (min(lows) if lows else current),
        prev_close=_num_or_none(realtime.get("prev_close")),
    )
    above_avg = avg_price is not None and current >= avg_price
    near_low = position <= 0.35
    near_high = position >= 0.72
    recovered_from_low = current > min(prices[-min(len(prices), 8) :]) * 1.01
    low_rebound_zone = recovered_from_low and position <= 0.62
    rolling_down_from_high = current < day_high * 0.985 and max(prices[-min(len(prices), 8) :]) >= day_high * 0.995

    if ret_15m is not None and ret_15m >= 0.8 and above_avg:
        trend = "盘中转强"
    elif ret_15m is not None and ret_15m <= -0.8 and not above_avg:
        trend = "盘中转弱"
    elif ret_5m is not None and ret_5m >= 0.35:
        trend = "短线反弹"
    elif ret_5m is not None and ret_5m <= -0.35:
        trend = "短线回落"
    else:
        trend = "盘中震荡"

    if near_high:
        intraday_position = "接近日内高位"
    elif near_low:
        intraday_position = "接近日内低位"
    elif position >= 0.55:
        intraday_position = "中部偏上"
    elif position <= 0.45:
        intraday_position = "中部偏下"
    else:
        intraday_position = "日内中部"
    trend_state = _intraday_trend_state(
        trend=trend,
        position=position,
        above_avg=above_avg,
        capital=capital,
        rolling_down_from_high=rolling_down_from_high,
    )
    intraday_main_force = _intraday_main_force_state(
        trend_state=trend_state,
        position=position,
        capital=capital,
        rolling_down_from_high=rolling_down_from_high,
        low_rebound_zone=low_rebound_zone,
        near_high=near_high,
    )

    buy_point = "无明确买点"
    sell_point = "无明确卖点"
    action_bias = "持有观察"
    risk = "风险中性"
    evidence: list[str] = [
        f"日内高点{_price(day_high)}，低点{_price(day_low)}，当前{_price(current)}",
    ]
    if avg_price is not None:
        evidence.append(f"分时均价约{_price(avg_price)}")
    if flow_15m is not None or flow_30m is not None:
        evidence.append(f"15/30分钟资金：{_money_or_dash(flow_15m)} / {_money_or_dash(flow_30m)}")
    if macd_signals["goldenCrossWindows"]:
        evidence.append(f"MACD金叉周期：{','.join(macd_signals['goldenCrossWindows'])}")

    formula_buy_confirmed = (
        bool(formula_signals.get("buySignal"))
        and capital in {"资金流入", "资金转强"}
        and position <= 0.62
        and not bool(formula_signals.get("sellSignal"))
    )
    if formula_buy_confirmed:
        buy_point = "波段低吸买点"
        action_bias = "低吸观察"
        risk = "公式低位反转，需资金延续"
        evidence.append("顶底公式出现低位反转，资金同步转强")
    elif (near_low or low_rebound_zone) and capital in {"资金流入", "资金转强"}:
        buy_point = "低吸买点"
        action_bias = "低吸观察"
        risk = "支撑有效"
        evidence.append("靠近日内低位后反弹，且资金承接")
    elif macd_signals["buySignal"] and capital in {"资金流入", "资金转强"}:
        buy_point = "MACD金叉买点"
        action_bias = "金叉跟踪"
        risk = "需资金延续"
        evidence.append("多周期MACD金叉且资金同步转强")
    elif near_high and trend in {"盘中转强", "短线反弹"} and capital in {"资金流入", "资金转强"}:
        buy_point = "突破买点"
        action_bias = "突破跟踪"
        risk = "追高需确认"
        evidence.append("接近日内高位且价量资金同步转强")

    if bool(formula_signals.get("sellSignal")) and capital in {"资金流出", "资金转弱"}:
        sell_point = "公式高抛卖点"
        action_bias = "不追高"
        risk = "公式超买叠加资金转弱"
        evidence.append("顶底公式进入高位区，资金同步转弱")
    elif rolling_down_from_high and capital in {"资金流出", "资金转弱"}:
        sell_point = "冲高卖点"
        action_bias = "不追高"
        risk = "冲高回落风险"
        evidence.append("冲高后回落且资金转弱")
    elif current <= day_low * 1.005 and capital in {"资金流出", "资金转弱"}:
        sell_point = "破位卖点"
        action_bias = "减仓防守"
        risk = "日内破位风险"
        evidence.append("接近日内低点且资金流出")

    return {
        "buyPoint": buy_point,
        "sellPoint": sell_point,
        "actionBias": action_bias,
        "intradayTrend": trend,
        "intradayTrendState": trend_state,
        "intradayMainForce": intraday_main_force,
        "intradayPosition": intraday_position,
        "intradayCapital": capital,
        "intradayRisk": risk,
        "macdWindows": macd_signals["windows"],
        "macdGoldenCrossWindows": macd_signals["goldenCrossWindows"],
        "macdBuySignal": macd_signals["buySignal"],
        "formulaSignals": formula_signals,
        "tags": {
            "trendState": trend_state,
            "mainForceState": intraday_main_force,
            "positionState": intraday_position,
            "capitalState": capital,
            "riskState": risk,
            "macdState": macd_signals["state"],
            "formulaState": _formula_state_text(formula_signals),
        },
        "windows": {"trend": "5m/15m", "capital": "15m/30m", "position": "day"},
        "levels": {
            "intradayHigh": day_high,
            "intradayLow": day_low,
            "avgPrice": avg_price,
            "support": day_low,
            "resistance": day_high,
            "tdxSupport": formula_signals.get("support"),
            "tdxResistance": formula_signals.get("resistance"),
        },
        "evidence": evidence[:8],
    }


def _intraday_capital_label(total_net: float | None, large_net: float | None, flow_15m: float | None, flow_30m: float | None) -> str:
    if flow_15m is not None and flow_30m is not None and flow_15m > 0 and flow_30m > 0:
        return "资金转强"
    if flow_15m is not None and flow_30m is not None and flow_15m < 0 and flow_30m < 0:
        return "资金转弱"
    if total_net is not None and large_net is not None and total_net > 0 and large_net > 0:
        return "资金流入"
    if total_net is not None and large_net is not None and total_net < 0 and large_net < 0:
        return "资金流出"
    return "资金中性"


def _empty_formula_signals() -> dict[str, Any]:
    return {
        "buySignal": False,
        "sellSignal": False,
        "buyState": "数据不足",
        "sellState": "数据不足",
        "trendLine": None,
        "previousTrendLine": None,
        "support": None,
        "resistance": None,
        "middle": None,
        "repaintSignalsExcluded": ["ZIG波段顶底"],
        "evidence": ["数据不足"],
    }


def _formula_state_text(signals: dict[str, Any]) -> str:
    buy_state = _text(signals.get("buyState"))
    sell_state = _text(signals.get("sellState"))
    if buy_state not in {"", "无", "数据不足"}:
        return buy_state
    if sell_state not in {"", "无", "数据不足"}:
        return sell_state
    return buy_state or sell_state or "无"


def _intraday_macd_signals(prices: list[float]) -> dict[str, Any]:
    windows: dict[str, dict[str, Any]] = {}
    golden: list[str] = []
    for minutes in (5, 15, 30, 60):
        key = f"{minutes}m"
        closes = prices[-minutes:] if len(prices) >= minutes else []
        signal = _fast_macd_window_signal(closes)
        windows[key] = signal
        if signal["state"] == "金叉":
            golden.append(key)
    state = "MACD金叉" if golden else ("MACD多头延续" if any(item["state"] == "多头" for item in windows.values()) else "MACD无金叉")
    return {
        "windows": windows,
        "goldenCrossWindows": golden,
        "buySignal": bool(golden),
        "state": state,
    }


def _fast_macd_window_signal(closes: list[float]) -> dict[str, Any]:
    if len(closes) < 5:
        return {"state": "数据不足", "histogram": None, "previousHistogram": None}
    fast = max(3, min(8, len(closes) // 4))
    slow = max(fast + 2, min(17, len(closes) // 2))
    signal = max(3, min(6, len(closes) // 5))
    hist = _macd_hist_with_periods(closes, fast=fast, slow=slow, signal=signal)
    if len(hist) < 2:
        return {"state": "数据不足", "histogram": None, "previousHistogram": None}
    previous = hist[-2]
    current = hist[-1]
    if previous <= 0 < current:
        state = "金叉"
    elif current > 0:
        state = "多头"
    elif previous >= 0 > current:
        state = "死叉"
    else:
        state = "空头"
    return {
        "state": state,
        "histogram": current,
        "previousHistogram": previous,
        "fast": fast,
        "slow": slow,
        "signal": signal,
    }


def _capital_flow_snapshot(
    *,
    realtime: dict[str, Any],
    last: float | None,
    change: float | None,
    total_in: float | None,
    total_out: float | None,
    total_net: float | None,
    large_net: float | None,
    medium_net: float | None,
    small_net: float | None,
    large_net_ratio: float | None,
    small_net_ratio: float | None,
    flow_15m: float | None,
    flow_30m: float | None,
    flow_today: float | None,
    flow_points: int | None,
) -> dict[str, Any]:
    return {
        "quoteMinute": realtime.get("snapshot_minute") or realtime.get("quoteMinute"),
        "capitalMinute": realtime.get("capital_minute") or realtime.get("capitalMinute"),
        "lastFlowTime": realtime.get("last_flow_time") or realtime.get("lastFlowTime"),
        "lastDone": last,
        "changePct": change,
        "totalIn": total_in,
        "totalOut": total_out,
        "totalNet": total_net,
        "largeNet": large_net,
        "mediumNet": medium_net,
        "smallNet": small_net,
        "largeNetRatio": large_net_ratio,
        "smallNetRatio": small_net_ratio,
        "flow15m": flow_15m,
        "flow30m": flow_30m,
        "flowToday": flow_today,
        "flowPoints": flow_points,
        "state": _intraday_capital_label(total_net, large_net, flow_15m, flow_30m),
    }


def _trade_advice(
    *,
    symbol: str,
    metrics: dict[str, Any],
    main_force: str,
    divergence: str,
    box_structure: str,
    technical_labels: dict[str, str],
    technical_state: str,
    intraday: dict[str, Any],
    capital_flow: dict[str, Any],
    confidence: int,
) -> dict[str, Any]:
    last = _num_or_none(metrics.get("last"))
    box_upper = _num_or_none(metrics.get("boxUpper"))
    box_lower = _num_or_none(metrics.get("boxLower"))
    box_position = _num_or_none(metrics.get("boxPosition"))
    ma20 = _num_or_none(metrics.get("ma20"))
    total_net = _num_or_none(metrics.get("totalNet"))
    large_net = _num_or_none(metrics.get("largeNet"))
    flow_15m = _num_or_none(metrics.get("flow15m"))
    flow_30m = _num_or_none(metrics.get("flow30m"))
    levels = intraday.get("levels") if isinstance(intraday.get("levels"), dict) else {}
    intraday_low = _num_or_none(levels.get("intradayLow"))
    intraday_high = _num_or_none(levels.get("intradayHigh"))
    avg_price = _num_or_none(levels.get("avgPrice"))
    support = intraday_low or box_lower or ma20 or last
    resistance = intraday_high or box_upper or last
    capital_state = _text(capital_flow.get("state") or intraday.get("intradayCapital"))
    capital_strong = capital_state in {"资金流入", "资金转强"} or (
        total_net is not None and total_net > 0 and large_net is not None and large_net > 0
    )
    capital_weak = capital_state in {"资金流出", "资金转弱"} or (
        total_net is not None and total_net < 0 and large_net is not None and large_net < 0
    )
    flow_recent_strong = flow_15m is not None and flow_30m is not None and flow_15m > 0 and flow_30m > 0
    flow_recent_weak = flow_15m is not None and flow_30m is not None and flow_15m < 0 and flow_30m < 0
    trend_label = technical_labels.get("trend", "")
    rsi_label = technical_labels.get("rsi", "")
    macd_label = technical_labels.get("macd", "")
    technical_weak = "跌破MA20" in trend_label or "MACD转弱" in macd_label
    technical_hot = rsi_label == "RSI偏热"
    leveraged_etf = _is_leveraged_etf(symbol)
    macd_buy_signal = bool(intraday.get("macdBuySignal"))
    golden_cross_windows = list(intraday.get("macdGoldenCrossWindows") or [])
    macd_windows = intraday.get("macdWindows") if isinstance(intraday.get("macdWindows"), dict) else {}
    formula_signals = intraday.get("formulaSignals") if isinstance(intraday.get("formulaSignals"), dict) else {}
    above_avg = last is not None and avg_price is not None and last >= avg_price
    above_ma20 = last is not None and ma20 is not None and last >= ma20
    near_high = box_position is not None and box_position >= 0.72
    near_low_or_mid = box_position is None or box_position <= 0.58
    signal_confidence = _signal_confidence_detail(
        capital_state=capital_state,
        capital_strong=capital_strong,
        capital_weak=capital_weak,
        flow_recent_strong=flow_recent_strong,
        flow_recent_weak=flow_recent_weak,
        golden_cross_windows=golden_cross_windows,
        macd_windows=macd_windows,
        trend_label=trend_label,
        macd_label=macd_label,
        rsi_label=rsi_label,
        above_avg=above_avg,
        above_ma20=above_ma20,
        box_position=box_position,
        intraday_buy_point=_text(intraday.get("buyPoint")),
        intraday_sell_point=_text(intraday.get("sellPoint")),
        formula_signals=formula_signals,
        main_force=main_force,
        divergence=divergence,
        leveraged_etf=leveraged_etf,
    )
    reasons: list[str] = []
    action = "继续持有"
    bias = "hold"
    strength = "中"
    score = signal_confidence["score"]

    if intraday.get("sellPoint") in {"破位卖点", "冲高卖点", "公式高抛卖点"} or (
        main_force in {"疑似撤退", "疑似派发"} and (capital_weak or technical_weak)
    ):
        action = "减仓避险"
        bias = "sell"
        strength = "高" if capital_weak and technical_weak else "中"
        score = max(score, confidence + 12)
        reasons.append("资金转弱叠加结构走弱")
    elif (
        near_high
        and (capital_weak or divergence == "价涨资流出" or technical_hot)
    ):
        action = "做T高抛"
        bias = "trim"
        strength = "中"
        score = max(score, confidence + 8)
        reasons.append("价格靠近区间高位，继续追高性价比下降")
    elif (
        intraday.get("buyPoint") in {"低吸买点", "突破买点", "波段低吸买点"}
        or macd_buy_signal
        or (main_force in {"疑似吸筹", "疑似洗盘"} and capital_strong)
        or (box_structure == "箱体下沿支撑" and capital_strong)
    ) and capital_strong and near_low_or_mid and signal_confidence["score"] >= 68 and main_force not in {"疑似撤退", "疑似派发"}:
        action = "加仓/低吸"
        bias = "buy"
        strength = "高" if signal_confidence["score"] >= 85 else ("中" if signal_confidence["score"] >= 74 else "低")
        if golden_cross_windows:
            reasons.append(f"{'/'.join(golden_cross_windows)} MACD金叉，资金同步转强")
        elif intraday.get("buyPoint") == "波段低吸买点":
            reasons.append("顶底公式低位反转，资金同步转强")
        else:
            reasons.append("资金承接，盘中出现低吸或转强信号")
    elif signal_confidence["score"] >= 62 and capital_strong:
        action = "暂不操作"
        bias = "watch"
        strength = "中"
        reasons.append("有局部转强，但共振不足，先等确认")
    elif capital_weak or flow_recent_weak:
        action = "暂不操作"
        bias = "watch"
        strength = "中"
        score -= 4
        reasons.append("资金偏弱，等企稳后再动")
    else:
        reasons.append("未出现明确买卖触发")

    if leveraged_etf and bias == "buy":
        action = "继续持有"
        bias = "hold"
        strength = "中"
        score = min(score, 70)
        reasons = ["杠杆ETF不默认加仓，资金转强也只做持有观察"]

    if not reasons:
        reasons.append("现有信号不足")
    risk_line = _risk_line(last=last, support=support, ma20=ma20)
    buy_low, buy_high = _buy_zone(last=last, support=support, avg_price=avg_price)
    sell_low, sell_high = _sell_zone(last=last, resistance=resistance, avg_price=avg_price)
    return {
        "action": action,
        "bias": bias,
        "strength": strength,
        "confidence": max(0, min(95, round(score))),
        "signalConfidence": signal_confidence,
        "priceZone": {
            "buyLow": buy_low,
            "buyHigh": buy_high,
            "sellLow": sell_low,
            "sellHigh": sell_high,
            "riskLine": risk_line,
            "confirmLine": _round_price(max(value for value in [last, avg_price, ma20] if value is not None)) if any(value is not None for value in [last, avg_price, ma20]) else None,
        },
        "reason": "；".join(reasons[:2]),
        "drivers": {
            "capital": capital_state,
            "mainForce": main_force,
            "divergence": divergence,
            "box": box_structure,
            "trend": trend_label,
            "macd": macd_label,
            "intradayBuyPoint": _text(intraday.get("buyPoint")),
            "intradaySellPoint": _text(intraday.get("sellPoint")),
            "intradayMacd": _text((intraday.get("tags") or {}).get("macdState") if isinstance(intraday.get("tags"), dict) else ""),
            "macdGoldenCrossWindows": ",".join(golden_cross_windows),
            "tdxWave": _text((intraday.get("tags") or {}).get("formulaState") if isinstance(intraday.get("tags"), dict) else ""),
        },
    }


def _buy_zone(*, last: float | None, support: float | None, avg_price: float | None) -> tuple[float | None, float | None]:
    anchors = [value for value in [support, avg_price, last] if value is not None and value > 0]
    if not anchors:
        return None, None
    center = min(anchors)
    high = min(max(anchors), center * 1.018)
    return _round_price(center * 0.995), _round_price(high)


def _signal_confidence_detail(
    *,
    capital_state: str,
    capital_strong: bool,
    capital_weak: bool,
    flow_recent_strong: bool,
    flow_recent_weak: bool,
    golden_cross_windows: list[str],
    macd_windows: dict[str, Any],
    trend_label: str,
    macd_label: str,
    rsi_label: str,
    above_avg: bool,
    above_ma20: bool,
    box_position: float | None,
    intraday_buy_point: str,
    intraday_sell_point: str,
    formula_signals: dict[str, Any],
    main_force: str,
    divergence: str,
    leveraged_etf: bool,
) -> dict[str, Any]:
    components: list[dict[str, Any]] = []
    positive: list[str] = []
    risks: list[str] = []

    if capital_strong and flow_recent_strong:
        capital_score = 30
        positive.append("实时资金15m/30m同步转强")
    elif capital_strong:
        capital_score = 22
        positive.append(f"实时资金{capital_state}")
    elif capital_weak:
        capital_score = 0
        risks.append(f"实时资金{capital_state}")
    else:
        capital_score = 8
    components.append({"name": "实时资金", "score": capital_score, "max": 30, "state": capital_state})

    bullish_macd_count = sum(1 for item in macd_windows.values() if isinstance(item, dict) and item.get("state") in {"金叉", "多头"})
    if len(golden_cross_windows) >= 2:
        technical_score = 25
        positive.append(f"{'/'.join(golden_cross_windows)} MACD多周期金叉")
    elif len(golden_cross_windows) == 1:
        technical_score = 19
        positive.append(f"{golden_cross_windows[0]} MACD金叉")
    elif bullish_macd_count >= 2 or macd_label == "MACD转强":
        technical_score = 13
        positive.append("MACD多头延续或日线转强")
    else:
        technical_score = 5
    if rsi_label == "RSI偏热":
        technical_score = max(0, technical_score - 4)
        risks.append("RSI偏热")
    components.append({"name": "多周期技术", "score": technical_score, "max": 25, "state": ",".join(golden_cross_windows) or macd_label or "无金叉"})

    trend_parts: list[str] = []
    trend_score = 0
    if above_avg:
        trend_score += 8
        trend_parts.append("站上分时均价")
    if above_ma20:
        trend_score += 8
        trend_parts.append("站上MA20")
    if "中期多头" in trend_label:
        trend_score += 4
        trend_parts.append("中期多头")
    if trend_score == 0 and ("跌破MA20" in trend_label or "中期空头" in trend_label):
        risks.append("趋势仍偏弱")
    components.append({"name": "趋势/均价", "score": min(20, trend_score), "max": 20, "state": "、".join(trend_parts) or trend_label or "趋势不足"})

    formula_buy_state = _text(formula_signals.get("buyState"))
    formula_sell_state = _text(formula_signals.get("sellState"))
    if intraday_buy_point in {"低吸买点", "MACD金叉买点", "波段低吸买点"}:
        position_score = 15
        positive.append(intraday_buy_point)
    elif box_position is None:
        position_score = 8
    elif box_position <= 0.35:
        position_score = 14
        positive.append("处于区间低位")
    elif box_position <= 0.58:
        position_score = 11
        positive.append("处于区间中低位")
    elif box_position >= 0.72:
        position_score = 3
        risks.append("位置接近区间高位")
    else:
        position_score = 7
    components.append({"name": "位置合理性", "score": position_score, "max": 15, "state": intraday_buy_point or _position_text(box_position)})

    formula_score = 0
    formula_state = formula_buy_state if formula_buy_state not in {"", "无", "数据不足"} else formula_sell_state
    if formula_buy_state == "低位上穿":
        formula_score = 20
        positive.append("顶底公式低位上穿")
    elif formula_buy_state == "准备买入":
        formula_score = 14
        positive.append("顶底公式准备买入")
    elif formula_sell_state == "准备卖出":
        risks.append("顶底公式准备卖出")
    components.append({"name": "顶底公式", "score": formula_score, "max": 20, "state": formula_state or "无"})

    penalty = 0
    if capital_weak or flow_recent_weak:
        penalty += 18
    if intraday_sell_point in {"破位卖点", "冲高卖点", "公式高抛卖点"}:
        penalty += 18
        risks.append(intraday_sell_point)
    if formula_sell_state == "准备卖出":
        penalty += 10
    if main_force in {"疑似撤退", "疑似派发"}:
        penalty += 14
        risks.append(main_force)
    if divergence == "价涨资流出":
        penalty += 8
        risks.append("价涨资流出")
    if leveraged_etf:
        penalty += 8
        risks.append("杠杆ETF降权")

    raw_score = sum(int(item["score"]) for item in components)
    final_score = max(0, min(95, raw_score - penalty))
    grade = "高" if final_score >= 85 else ("中" if final_score >= 68 else ("低" if final_score >= 55 else "弱"))
    return {
        "score": final_score,
        "grade": grade,
        "components": components,
        "riskPenalty": penalty,
        "positiveSignals": positive[:6],
        "riskSignals": risks[:6],
    }


def _position_text(box_position: float | None) -> str:
    if box_position is None:
        return "位置数据不足"
    return f"区间位置{box_position * 100:.0f}%"


def _sell_zone(*, last: float | None, resistance: float | None, avg_price: float | None) -> tuple[float | None, float | None]:
    anchors = [value for value in [last, resistance, avg_price] if value is not None and value > 0]
    if not anchors:
        return None, None
    center = max(anchors)
    low = max(min(anchors), center * 0.985)
    return _round_price(low), _round_price(center * 1.005)


def _risk_line(*, last: float | None, support: float | None, ma20: float | None) -> float | None:
    anchors = [value for value in [support, ma20, last] if value is not None and value > 0]
    if not anchors:
        return None
    return _round_price(min(anchors) * 0.985)


def _round_price(value: float | None) -> float | None:
    if value is None:
        return None
    return round(value, 3 if value < 100 else 2)


def _is_leveraged_etf(symbol: str) -> bool:
    code = symbol.rsplit(".", 1)[0].upper()
    return code in {"TSLL", "TSLQ", "NVDL", "NVDS", "TQQQ", "SQQQ", "SOXL", "SOXS", "LABU", "LABD", "YINN", "YANG"}


def _intraday_trend_state(*, trend: str, position: float, above_avg: bool, capital: str, rolling_down_from_high: bool) -> str:
    capital_strong = capital in {"资金流入", "资金转强"}
    capital_weak = capital in {"资金流出", "资金转弱"}
    if trend == "盘中转强" and above_avg and capital_strong and position >= 0.65:
        return "盘中强势上行"
    if trend in {"盘中转强", "短线反弹"} and above_avg and capital_strong:
        return "盘中震荡偏强"
    if trend in {"盘中转弱", "短线回落"} and not above_avg and capital_weak and position <= 0.35:
        return "盘中弱势下行"
    if rolling_down_from_high and capital_weak:
        return "盘中震荡偏弱"
    if trend in {"盘中转弱", "短线回落"} and (not above_avg or capital_weak):
        return "盘中震荡偏弱"
    if trend in {"盘中转强", "短线反弹"} and above_avg:
        return "盘中震荡偏强"
    return "盘中震荡"


def _intraday_main_force_state(
    *,
    trend_state: str,
    position: float,
    capital: str,
    rolling_down_from_high: bool,
    low_rebound_zone: bool,
    near_high: bool,
) -> str:
    capital_strong = capital in {"资金流入", "资金转强"}
    capital_weak = capital in {"资金流出", "资金转弱"}
    if trend_state == "盘中强势上行" and capital_strong and near_high:
        return "盘中疑似拉升"
    if trend_state == "盘中弱势下行" and capital_weak:
        return "盘中疑似撤退"
    if rolling_down_from_high and capital_weak:
        return "盘中疑似派发"
    if low_rebound_zone and capital_strong:
        return "盘中疑似吸筹"
    if trend_state == "盘中震荡偏强" and capital_strong and position <= 0.55:
        return "盘中疑似洗盘"
    return "盘中无明显主力迹象"


def _intraday_avg_price(bars: list[dict[str, Any]], prices: list[float]) -> float | None:
    latest_avg = _num_or_none(bars[-1].get("avgPrice") or bars[-1].get("avg_price")) if bars else None
    if latest_avg:
        return latest_avg
    total_turnover = sum(_num(row.get("turnover")) for row in bars)
    total_volume = sum(_num(row.get("volume")) for row in bars)
    if total_turnover > 0 and total_volume > 0:
        return round(total_turnover / total_volume, 4)
    return round(sum(prices) / len(prices), 4) if prices else None


def _window_return(prices: list[float], minutes: int) -> float | None:
    if len(prices) < 2:
        return None
    index = max(0, len(prices) - minutes - 1)
    base = prices[index]
    if not base:
        return None
    return round((prices[-1] / base - 1) * 100, 4)


def _money_or_dash(value: float | None) -> str:
    return "-" if value is None else _money_10k(value)


def _technical_labels(
    closes: list[float],
    *,
    close: float | None,
    ma20: float | None,
    ma60: float | None,
    volume_ratio: float | None,
) -> dict[str, str]:
    labels: dict[str, str] = {}
    if close is not None and ma20 is not None:
        trend_parts = ["站上MA20" if close >= ma20 else "跌破MA20"]
        if ma60 is not None:
            trend_parts.append("中期多头" if ma20 >= ma60 else "中期空头")
        labels["trend"] = "；".join(trend_parts)
    else:
        labels["trend"] = "趋势数据不足"

    rsi = _rsi(closes, 14)
    if rsi is None:
        labels["rsi"] = "RSI数据不足"
    elif rsi >= 70:
        labels["rsi"] = "RSI偏热"
    elif rsi <= 30:
        labels["rsi"] = "RSI偏冷"
    else:
        labels["rsi"] = "RSI中性"

    macd = _macd_hist(closes)
    labels["macd"] = "MACD转强" if len(macd) >= 2 and macd[-1] > macd[-2] else ("MACD转弱" if len(macd) >= 2 else "MACD数据不足")

    boll = _boll_label(closes, close=close)
    labels["boll"] = boll

    if volume_ratio is None:
        labels["volume"] = "量能数据不足"
    elif volume_ratio >= 1.5:
        labels["volume"] = "放量"
    elif volume_ratio <= 0.7:
        labels["volume"] = "缩量"
    else:
        labels["volume"] = "量能温和"
    return labels


def _technical_state_from_labels(labels: dict[str, str]) -> str:
    ordered = [labels.get(key, "") for key in ("trend", "rsi", "macd", "boll", "volume")]
    useful = [label for label in ordered if label and "数据不足" not in label]
    return "；".join(useful) if useful else "技术数据不足"


def _technical_state(
    closes: list[float],
    *,
    close: float | None,
    ma20: float | None,
    ma60: float | None,
    volume_ratio: float | None,
) -> str:
    return _technical_state_from_labels(_technical_labels(closes, close=close, ma20=ma20, ma60=ma60, volume_ratio=volume_ratio))


def _boll_label(closes: list[float], *, close: float | None) -> str:
    if close is None or len(closes) < 20:
        return "BOLL数据不足"
    window = closes[-20:]
    middle = sum(window) / 20
    variance = sum((value - middle) ** 2 for value in window) / 20
    width = (variance**0.5) * 4
    if width <= 0:
        return "BOLL数据不足"
    lower = middle - width / 2
    upper = middle + width / 2
    position = (close - lower) / (upper - lower)
    if position >= 0.85:
        return "靠近布林上轨"
    if position <= 0.15:
        return "靠近布林下轨"
    return "布林中轨区"


def _confidence(
    *,
    base: int,
    box_score: int,
    divergence_score: int,
    force_score: int,
    has_daily: bool,
    has_realtime: bool,
) -> int:
    score = base + box_score + divergence_score + force_score
    if has_daily:
        score += 6
    if has_realtime:
        score += 6
    return max(20, min(92, score))


def _volume_ratio(bars: list[dict[str, Any]], realtime: dict[str, Any]) -> float | None:
    if len(bars) < 21:
        return None
    latest_volume = _num_or_none(realtime.get("volume")) or _num_or_none(bars[-1].get("volume"))
    previous = [_num(row.get("volume")) for row in bars[-21:-1] if _num_or_none(row.get("volume")) is not None]
    if latest_volume is None or not previous:
        return None
    average = sum(previous) / len(previous)
    return round(latest_volume / average, 2) if average else None


def _rolling_mean(values: list[float], window: int) -> float | None:
    if len(values) < window:
        return None
    return round(sum(values[-window:]) / window, 4)


def _rsi(closes: list[float], period: int) -> float | None:
    if len(closes) <= period:
        return None
    gains: list[float] = []
    losses: list[float] = []
    for previous, current in zip(closes[-period - 1 : -1], closes[-period:], strict=True):
        diff = current - previous
        gains.append(max(diff, 0))
        losses.append(abs(min(diff, 0)))
    avg_loss = sum(losses) / period
    if avg_loss == 0:
        return 100.0
    rs = (sum(gains) / period) / avg_loss
    return round(100 - (100 / (1 + rs)), 2)


def _macd_hist(closes: list[float]) -> list[float]:
    if len(closes) < 26:
        return []
    return _macd_hist_with_periods(closes, fast=12, slow=26, signal=9)


def _macd_hist_with_periods(closes: list[float], *, fast: int, slow: int, signal: int) -> list[float]:
    if len(closes) < slow:
        return []
    fast_ema = _ema_series(closes, fast)
    slow_ema = _ema_series(closes, slow)
    diffs = [fast_value - slow_value for fast_value, slow_value in zip(fast_ema, slow_ema, strict=True)]
    dea = _ema_series(diffs, signal)
    return [round((diff - signal) * 2, 4) for diff, signal in zip(diffs, dea, strict=True)]


def _ema_series(values: list[float], period: int) -> list[float]:
    if not values:
        return []
    alpha = 2 / (period + 1)
    ema = values[0]
    output = [ema]
    for value in values[1:]:
        ema = value * alpha + ema * (1 - alpha)
        output.append(ema)
    return output


def _symbols(symbols: Iterable[str]) -> list[str]:
    return sorted({str(symbol).strip().upper() for symbol in symbols if str(symbol).strip()})


def _text(value: Any) -> str:
    return str(value or "").strip()


def _num(value: Any) -> float:
    parsed = _num_or_none(value)
    return 0.0 if parsed is None else parsed


def _num_or_none(value: Any) -> float | None:
    if value is None or value == "":
        return None
    try:
        number = float(value)
    except (TypeError, ValueError):
        return None
    return number if isfinite(number) else None


def _int_or_none(value: Any) -> int | None:
    number = _num_or_none(value)
    return None if number is None else int(number)


def _price(value: float) -> str:
    return f"{value:.3f}".rstrip("0").rstrip(".")


def _money_10k(value: float) -> str:
    sign = "+" if value > 0 else ""
    if abs(value) >= 10_000:
        return f"{sign}{value / 10_000:.2f}亿"
    return f"{sign}{value:.0f}万"
