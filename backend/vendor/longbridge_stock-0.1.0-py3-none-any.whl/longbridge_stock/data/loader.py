from __future__ import annotations

import pandas as pd

from longbridge_stock.config import DataConfig
from longbridge_stock.data.local_csv import load_csv_dir
from longbridge_stock.data.qlib_provider import load_qlib_features


def load_market_data(
    config: DataConfig,
    start_time: str,
    end_time: str,
    source: str = "auto",
) -> pd.DataFrame:
    """Load market data from Qlib on 10.28, or local CSV snapshots during development."""
    if source not in {"auto", "qlib", "csv"}:
        raise ValueError("source must be one of: auto, qlib, csv")

    if source in {"auto", "qlib"} and config.provider_uri.exists():
        try:
            return load_qlib_features(
                provider_uri=config.provider_uri,
                market=config.market,
                fields=config.fields,
                start_time=start_time,
                end_time=end_time,
                region=config.region,
            )
        except Exception:
            if source == "qlib":
                raise

    return load_csv_dir(config.local_csv_dir, start_time=start_time, end_time=end_time)
