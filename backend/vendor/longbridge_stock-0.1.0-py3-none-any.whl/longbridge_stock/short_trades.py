from __future__ import annotations

import json
import subprocess
from datetime import datetime
from typing import Any
from zoneinfo import ZoneInfo


def normalize_symbol(value: str) -> str:
    text = str(value or "").strip().upper()
    if not text:
        return text
    if "." in text:
        return text
    if text.isdigit():
        return f"{int(text)}.HK"
    return f"{text}.US"


def market_from_symbol(symbol: str) -> str:
    normalized = normalize_symbol(symbol)
    if normalized.endswith(".HK"):
        return "hk"
    if normalized.endswith(".US"):
        return "us"
    return normalized.rsplit(".", 1)[-1].lower() if "." in normalized else ""


def parse_longbridge_short_trades(
    payload: dict[str, Any],
    *,
    symbol: str,
    fetched_at: datetime | None = None,
) -> list[dict[str, Any]]:
    fetched_at = fetched_at or datetime.now().astimezone()
    normalized_symbol = normalize_symbol(str(payload.get("symbol") or symbol))
    market = market_from_symbol(normalized_symbol)
    rows = []
    for item in payload.get("data") or []:
        timestamp = int(_num(item.get("timestamp")))
        nus_amount = _int_or_none(item.get("nus_amount"))
        ny_amount = _int_or_none(item.get("ny_amount"))
        amount = _int_or_none(item.get("amount"))
        rows.append(
            {
                "trade_date": _trade_date(timestamp, market),
                "symbol": normalized_symbol,
                "market": market,
                "timestamp": timestamp,
                "amount": amount if amount is not None else _sum_nullable_ints(nus_amount, ny_amount),
                "balance": _num_or_none(item.get("balance")),
                "nus_amount": nus_amount,
                "ny_amount": ny_amount,
                "total_amount": _int_or_none(item.get("total_amount")),
                "rate": _num_or_none(item.get("rate")),
                "close": _num_or_none(item.get("close")),
                "source": "longbridge_short_trades",
                "fetched_at": fetched_at.isoformat(),
            }
        )
    return rows


def fetch_longbridge_short_trades(
    symbol: str,
    *,
    count: int = 100,
    runner=subprocess.run,
) -> dict[str, Any]:
    normalized_symbol = normalize_symbol(symbol)
    command = [
        "longbridge",
        "short-trades",
        normalized_symbol,
        "--count",
        str(max(1, min(100, int(count)))),
        "--format",
        "json",
    ]
    completed = runner(command, capture_output=True, text=True, encoding="utf-8", errors="replace", check=True)
    return json.loads(completed.stdout)


def _trade_date(timestamp: int, market: str) -> str:
    zone = ZoneInfo("Asia/Hong_Kong") if market == "hk" else ZoneInfo("America/New_York")
    return datetime.fromtimestamp(timestamp, tz=zone).date().isoformat()


def _sum_nullable_ints(*values: int | None) -> int | None:
    present = [value for value in values if value is not None]
    return sum(present) if present else None


def _num(value: Any) -> float:
    if value is None or value == "":
        return 0.0
    try:
        return float(value)
    except (TypeError, ValueError):
        return 0.0


def _num_or_none(value: Any) -> float | None:
    if value is None or value == "":
        return None
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def _int_or_none(value: Any) -> int | None:
    parsed = _num_or_none(value)
    return None if parsed is None else int(parsed)
