from __future__ import annotations

import re
from datetime import date, datetime
from html import unescape
from typing import Any
from urllib import parse, request


AASTOCKS_SHORT_SELLING_URL = "https://www.aastocks.com/en/stocks/market/shortselling/stock-short-selling-ratio.aspx"

_TAG_RE = re.compile(r"<[^>]+>")
_AS_AT_RE = re.compile(r"Short Selling Data as at\s*(\d{4})/(\d{2})/(\d{2})", re.IGNORECASE)
_ROW_RE = re.compile(
    r"(?P<month>\d{2})/(?P<day>\d{2})\s+"
    r"(?P<price>-?[\d.]+)\s+"
    r"(?P<change>[+-]?[\d.]+)\s+"
    r"(?P<change_pct>[+-]?[\d.]+)%\s+"
    r"(?P<short_volume>[\d.]+[KMB]?)\s+"
    r"(?P<short_turnover>[\d.]+[KMB]?)\s+"
    r"(?P<turnover>[\d.]+[KMB]?)\s+"
    r"(?P<market_short_value_pct>[\d.]+)%\s+"
    r"(?P<short_selling_ratio>[\d.]+)%\s+"
    r"(?P<ssr_3d_sma>[\d.]+)%\s+"
    r"(?P<ssr_5d_sma>[\d.]+)%"
)


def fetch_aastocks_short_selling_history(symbol: str, *, timeout: float = 30.0) -> str:
    url = report_url(symbol)
    req = request.Request(
        url,
        headers={
            "User-Agent": "Mozilla/5.0",
            "Accept-Language": "en-US,en;q=0.9",
        },
    )
    with request.urlopen(req, timeout=timeout) as response:
        body = response.read()
    return body.decode("utf-8", errors="replace")


def report_url(symbol: str) -> str:
    code = normalize_hk_code(symbol)
    return f"{AASTOCKS_SHORT_SELLING_URL}?{parse.urlencode({'symbol': code})}"


def parse_aastocks_short_selling_history(
    text: str,
    *,
    symbol: str,
    name: str = "",
    source_url: str | None = None,
    fetched_at: datetime | None = None,
) -> list[dict[str, Any]]:
    code_text = normalize_hk_code(symbol)
    code = int(code_text)
    normalized_symbol = f"{code}.HK"
    source_url = source_url or report_url(symbol)
    fetched_at = fetched_at or datetime.now().astimezone()
    plain_text = _html_to_text(text)
    as_at = _parse_as_at_date(plain_text)
    if as_at is None:
        return []
    inferred_name = name or _parse_name(plain_text) or normalized_symbol
    rows: list[dict[str, Any]] = []
    for match in _ROW_RE.finditer(plain_text):
        trade_date = _infer_trade_date(int(match.group("month")), int(match.group("day")), as_at)
        rows.append(
            {
                "trade_date": trade_date,
                "session": "day_close",
                "board": "main",
                "code": code,
                "symbol": normalized_symbol,
                "name": inferred_name,
                "price": float(match.group("price")),
                "change": float(match.group("change")),
                "change_pct": float(match.group("change_pct")),
                "short_volume": int(_scaled_number(match.group("short_volume"))),
                "short_turnover": float(_scaled_number(match.group("short_turnover"))),
                "turnover": float(_scaled_number(match.group("turnover"))),
                "market_short_value_pct": float(match.group("market_short_value_pct")),
                "short_selling_ratio": float(match.group("short_selling_ratio")),
                "ssr_3d_sma": float(match.group("ssr_3d_sma")),
                "ssr_5d_sma": float(match.group("ssr_5d_sma")),
                "currency": "HKD",
                "source": "aastocks_short_selling_history",
                "source_url": source_url,
                "fetched_at": fetched_at,
            }
        )
    return rows


def normalize_hk_code(symbol: str) -> str:
    text = symbol.strip().upper().removesuffix(".HK")
    if not text:
        raise ValueError("empty HK symbol")
    return f"{int(text):05d}"


def _html_to_text(text: str) -> str:
    without_tags = _TAG_RE.sub(" ", text)
    normalized = unescape(without_tags).replace("\xa0", " ")
    return " ".join(normalized.split())


def _parse_as_at_date(text: str) -> date | None:
    match = _AS_AT_RE.search(text)
    if not match:
        return None
    year, month, day = (int(part) for part in match.groups())
    return date(year, month, day)


def _parse_name(text: str) -> str | None:
    match = re.search(r"\b([A-Z][A-Z0-9 &.'-]{1,40})\s+\(\s*\d{5}\.HK\s*\)\s+Last\b", text)
    if not match:
        return None
    return " ".join(match.group(1).split())


def _infer_trade_date(month: int, day: int, as_at: date) -> date:
    year = as_at.year
    if month > as_at.month:
        year -= 1
    return date(year, month, day)


def _scaled_number(value: str) -> float:
    text = value.strip().upper().replace(",", "")
    multiplier = 1.0
    if text.endswith("K"):
        multiplier = 1_000.0
        text = text[:-1]
    elif text.endswith("M"):
        multiplier = 1_000_000.0
        text = text[:-1]
    elif text.endswith("B"):
        multiplier = 1_000_000_000.0
        text = text[:-1]
    return float(text) * multiplier
