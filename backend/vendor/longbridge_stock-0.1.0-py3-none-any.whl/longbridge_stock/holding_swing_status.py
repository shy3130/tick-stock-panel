from __future__ import annotations

import json
import subprocess
from typing import Any, Iterable

import pandas as pd

from longbridge_stock.swing_regime import SwingRegimeConfig, build_current_swing_status


def build_holding_swing_status_map(
    symbols: Iterable[str],
    *,
    runner=subprocess.run,
    timeout_sec: int = 20,
    config: SwingRegimeConfig | None = None,
) -> dict[str, dict[str, Any]]:
    statuses: dict[str, dict[str, Any]] = {}
    for symbol in _unique_symbols(symbols):
        try:
            frame = fetch_daily_bars(symbol, runner=runner, timeout_sec=timeout_sec)
            status = build_current_swing_status(frame, config)
        except Exception:
            continue
        if status.get("phase") and status.get("phase") != "unknown":
            statuses[symbol] = status
    return statuses


def fetch_daily_bars(
    symbol: str,
    *,
    runner=subprocess.run,
    timeout_sec: int = 20,
) -> pd.DataFrame:
    command = ["longbridge", "kline", "history", symbol, "--period", "day", "--format", "json"]
    proc = runner(
        command,
        capture_output=True,
        text=True,
        encoding="utf-8",
        errors="replace",
        timeout=timeout_sec,
    )
    if proc.returncode != 0:
        raise RuntimeError((proc.stderr or proc.stdout or "").strip())
    rows = _extract_json_array(proc.stdout)
    frame = pd.DataFrame(rows)
    if frame.empty:
        return frame
    frame["symbol"] = symbol
    frame = frame.rename(columns={"time": "trade_date"})
    frame["trade_date"] = pd.to_datetime(frame["trade_date"], errors="coerce").dt.date.astype(str)
    return frame


def _extract_json_array(raw: str) -> list[dict[str, Any]]:
    start = raw.find("[")
    end = raw.rfind("]")
    if start < 0 or end < start:
        raise ValueError("Longbridge CLI did not return a JSON array")
    parsed = json.loads(raw[start : end + 1])
    if not isinstance(parsed, list):
        raise ValueError("Longbridge CLI JSON payload is not a list")
    return [row for row in parsed if isinstance(row, dict)]


def _unique_symbols(symbols: Iterable[str]) -> list[str]:
    seen: set[str] = set()
    output: list[str] = []
    for symbol in symbols:
        normalized = str(symbol or "").strip().upper()
        if not normalized or normalized in seen:
            continue
        seen.add(normalized)
        output.append(normalized)
    return output
