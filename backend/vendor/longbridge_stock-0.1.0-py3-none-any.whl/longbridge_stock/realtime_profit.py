from __future__ import annotations

import json
import math
import os
import pickle
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Iterable, Sequence
from zoneinfo import ZoneInfo

import numpy as np
import pandas as pd

from longbridge_stock import clickhouse_realtime
from longbridge_stock.experiment_tracking import log_realtime_profit_training
from longbridge_stock.intraday_pool import IntradayCandidate, rank_intraday_candidates
from longbridge_stock.realtime_sinks import RealtimeSinkConfig, RealtimeSinkRouter


DEFAULT_DSN = "dbname=longbridge_stock user=alwin host=/var/run/postgresql"
DEFAULT_MODEL_ROOT = Path("/home/alwin/data/longbridge/realtime_profit_models")
DEFAULT_MLFLOW_EXPERIMENT = "longbridge-realtime-profit"
DEFAULT_HORIZON_MINUTES = 60
DEFAULT_TARGET_RETURN_BY_MARKET = {"hk": 0.008, "us": 0.007, "cn": 0.008}
DEFAULT_SHORT_TARGET_RETURN_BY_MARKET = {"hk": 0.012, "us": 0.015, "cn": 0.012}
TOP3_FAST_HORIZON_MINUTES_BY_MARKET = {"hk": 990, "us": 1170, "cn": 720}
TOP3_FAST_TARGET_RETURN_BY_MARKET = {"hk": 0.02, "us": 0.02, "cn": 0.02}
TOP3_FAST_SHORT_TARGET_RETURN_BY_MARKET = {"hk": 0.025, "us": 0.03, "cn": 0.025}
US_FAST_TARGET_RETURN_BY_MARKET = {"us": 0.02}
US_FAST_SHORT_TARGET_RETURN_BY_MARKET = {"us": 0.03}
US_FAST_REPLAY_LIMIT = 5
EXCHANGE_TZ = ZoneInfo("Asia/Shanghai")
US_FAST_EXCLUDED_SYMBOLS = (
    "SPY.US",
    "QQQ.US",
    "IWM.US",
    "DIA.US",
    "VTI.US",
    "VOO.US",
    "VEA.US",
    "VWO.US",
    "VT.US",
    "IVV.US",
    "SCHD.US",
    "TLT.US",
    "HYG.US",
    "LQD.US",
    "SHV.US",
    "BIL.US",
    "USFR.US",
    "SGOV.US",
    "SQQQ.US",
    "TQQQ.US",
    "TSLL.US",
    "TSLQ.US",
    "TSLS.US",
    "AMDL.US",
    "SOXL.US",
    "SOXS.US",
    "SPXL.US",
    "SPXS.US",
    "SDOW.US",
    "UDOW.US",
    "SDS.US",
    "SSO.US",
    "UPRO.US",
    "UVXY.US",
    "SVXY.US",
    "BOIL.US",
    "KOLD.US",
    "COPX.US",
    "CONL.US",
    "SMCX.US",
)

FEATURE_NAMES = [
    "change_percentage",
    "return_1m",
    "return_5m",
    "return_15m",
    "volatility_5m",
    "volatility_15m",
    "volume_ratio_5m",
    "turnover_ratio_5m",
    "large_net_ratio",
    "small_net_ratio",
    "total_net_ratio",
    "capital_flow_5m",
    "capital_flow_slope_15m",
    "depth_imbalance",
    "bid_ask_volume_ratio",
    "trade_buy_ratio_5m",
    "trade_volume_5m",
    "intraday_position",
    "price_to_avg_15m",
    "down_momentum_5m",
    "down_momentum_15m",
    "near_day_low",
    "short_selling_ratio",
    "short_rate",
    "short_balance_ratio",
    "days_to_cover",
    "negative_sentiment_score",
    "bearish_event_strength",
]


@dataclass(frozen=True)
class ProfitProfile:
    name: str
    source: str
    horizon_minutes: int
    target_return: float
    exclude_holdings: bool = False


@dataclass(frozen=True)
class RealtimeProfitModel:
    model_type: str
    estimator: Any
    feature_names: list[str]
    horizon_minutes: int
    target_return: float
    market: str
    target_direction: str = "long"
    return_estimator: Any | None = None

    def predict_proba(self, frame: pd.DataFrame) -> np.ndarray:
        features = frame.reindex(columns=self.feature_names).fillna(0)
        if hasattr(self.estimator, "predict_proba"):
            return np.asarray(self.estimator.predict_proba(features))[:, 1]
        scores = np.asarray(self.estimator.predict(features), dtype="float64")
        return np.clip(scores, 0, 1)

    def predict_return(self, frame: pd.DataFrame) -> np.ndarray:
        features = frame.reindex(columns=self.feature_names).fillna(0)
        if self.return_estimator is None:
            return np.zeros(len(features), dtype="float64")
        returns = np.asarray(self.return_estimator.predict(features), dtype="float64")
        return np.clip(returns, -0.12, 0.12)


def resolve_profit_profile(
    profile: str | None,
    market: str,
    *,
    horizon_minutes: int | None = None,
    target_return: float | None = None,
    target_direction: str = "long",
) -> ProfitProfile:
    name = (profile or "realtime").lower()
    market_key = market.lower()
    direction = normalize_target_direction(target_direction)
    if name == "realtime":
        defaults = DEFAULT_SHORT_TARGET_RETURN_BY_MARKET if direction == "short" else DEFAULT_TARGET_RETURN_BY_MARKET
        return ProfitProfile(
            name="realtime",
            source="realtime_market",
            horizon_minutes=int(horizon_minutes if horizon_minutes is not None else DEFAULT_HORIZON_MINUTES),
            target_return=float(target_return if target_return is not None else defaults.get(market_key, 0.008)),
            exclude_holdings=False,
        )
    if name == "top3_fast":
        defaults = TOP3_FAST_SHORT_TARGET_RETURN_BY_MARKET if direction == "short" else TOP3_FAST_TARGET_RETURN_BY_MARKET
        return ProfitProfile(
            name="top3_fast",
            source="intraday_top3",
            horizon_minutes=int(horizon_minutes if horizon_minutes is not None else TOP3_FAST_HORIZON_MINUTES_BY_MARKET.get(market_key, 990)),
            target_return=float(target_return if target_return is not None else defaults.get(market_key, 0.02)),
            exclude_holdings=True,
        )
    if name == "us_fast_15":
        defaults = US_FAST_SHORT_TARGET_RETURN_BY_MARKET if direction == "short" else US_FAST_TARGET_RETURN_BY_MARKET
        return ProfitProfile(
            name="us_fast_15",
            source="us_fast_intraday",
            horizon_minutes=int(horizon_minutes if horizon_minutes is not None else TOP3_FAST_HORIZON_MINUTES_BY_MARKET.get(market_key, 1170)),
            target_return=float(target_return if target_return is not None else defaults.get(market_key, 0.02)),
            exclude_holdings=True,
        )
    raise ValueError(f"unknown profit profile: {profile}")


def normalize_target_direction(value: Any) -> str:
    direction = str(value or "long").strip().lower()
    if direction in {"long", "up", "buy"}:
        return "long"
    if direction in {"short", "down", "bear", "sell_short"}:
        return "short"
    raise ValueError(f"unknown target direction: {value}")


def profile_for_direction(profile: str | None, target_direction: str) -> str:
    base = (profile or "realtime").lower()
    direction = normalize_target_direction(target_direction)
    return base if direction == "long" else f"{base}_short"


def _prefer_intraday_pool_short_training(target_direction: str) -> bool:
    if normalize_target_direction(target_direction) != "short":
        return False
    raw = os.getenv("REALTIME_PROFIT_SHORT_TRAINING_SOURCE", "intraday_pool").strip().lower()
    return raw not in {"historical", "historical_replay", "replay"}


def _prefer_materialized_training_samples(target_direction: str) -> bool:
    raw = os.getenv("REALTIME_PROFIT_TRAINING_SAMPLE_SOURCE", "").strip().lower()
    if raw in {"historical", "historical_replay", "intraday_pool"}:
        return False
    if raw in {"materialized", "training_samples", "full_market"}:
        return True
    return normalize_target_direction(target_direction) == "short"


@dataclass(frozen=True)
class RealtimeProfitTrainSummary:
    model_run_id: str
    market: str
    model_type: str
    train_count: int
    validation_count: int
    metrics: dict[str, Any]
    model_path: str


@dataclass(frozen=True)
class RealtimeProfitPredictSummary:
    model_run_id: str
    market: str
    total: int
    top: list[dict[str, Any]]


@dataclass(frozen=True)
class RealtimeProfitValidationSummary:
    market: str
    evaluated: int
    hits: int
    hit_rate: float | None
    avg_actual_return: float | None
    avg_max_drawdown: float | None


@dataclass(frozen=True)
class RealtimeProfitOutcomeReviewSummary:
    market: str
    profile: str
    evaluated: int
    hit_count: int
    hit_rate: float | None
    avg_max_return: float | None
    avg_max_drawdown: float | None
    worst_drawdown: float | None
    rows: list[dict[str, Any]]


def label_profit_samples(frame: pd.DataFrame, horizon_minutes: int, target_return: float, target_direction: str = "long") -> pd.DataFrame:
    if frame.empty:
        return frame.copy()
    direction = normalize_target_direction(target_direction)
    data = frame.copy()
    data["snapshot_minute"] = pd.to_datetime(data["snapshot_minute"])
    data["last_done"] = pd.to_numeric(data["last_done"], errors="coerce")
    labeled_parts = []
    for _, group in data.sort_values(["symbol", "snapshot_minute"]).groupby("symbol", sort=False):
        group = group.copy()
        future_max = []
        future_min = []
        for row in group.itertuples():
            end_time = row.snapshot_minute + pd.Timedelta(minutes=horizon_minutes)
            window = group[(group["snapshot_minute"] > row.snapshot_minute) & (group["snapshot_minute"] <= end_time)]
            future_max.append(window["last_done"].max() if not window.empty else np.nan)
            future_min.append(window["last_done"].min() if not window.empty else np.nan)
        group["future_high"] = future_max
        group["future_low"] = future_min
        group["future_price"] = group["last_done"].shift(-horizon_minutes)
        group["future_max_return"] = group["future_high"] / group["last_done"] - 1
        group["future_max_drawdown"] = group["future_low"] / group["last_done"] - 1
        group["future_return"] = group["future_price"] / group["last_done"] - 1
        if direction == "short":
            group["target_profit"] = (group["future_max_drawdown"] <= -target_return).astype("int64")
        else:
            group["target_profit"] = (group["future_max_return"] >= target_return).astype("int64")
        labeled_parts.append(group)
    return pd.concat(labeled_parts, ignore_index=True)


def build_prediction_rows(
    features: pd.DataFrame,
    probabilities: Sequence[float],
    model_run_id: str,
    horizon_minutes: int,
    target_return: float,
    predicted_returns: Sequence[float] | None = None,
    target_direction: str = "long",
) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    direction = normalize_target_direction(target_direction)
    fallback_returns = [None] * len(features)
    returns = list(predicted_returns) if predicted_returns is not None else fallback_returns
    for row, probability, predicted_return in zip(features.to_dict("records"), probabilities, returns):
        probability = float(np.clip(probability, 0, 1))
        if predicted_return is None:
            expected_return = probability * target_return * 1.25
            if direction == "short":
                expected_return = -expected_return
        else:
            expected_return = float(np.clip(predicted_return, -0.12, 0.12))
        risk_score = _risk_score(row, probability, target_direction=direction)
        decision = _decision(probability, risk_score, row, target_direction=direction)
        rows.append(
            {
                "model_run_id": model_run_id,
                "predicted_at": row.get("snapshot_minute"),
                "symbol": row.get("symbol"),
                "market": str(row.get("market") or "").lower(),
                "name": row.get("name"),
                "horizon_minutes": horizon_minutes,
                "target_return": target_return,
                "target_direction": direction,
                "entry_price": _json_number(row.get("last_done")),
                "profit_probability": round(probability, 4),
                "expected_return": round(expected_return, 4),
                "risk_score": round(risk_score, 2),
                "decision": decision,
                "validation_due_at": add_trading_minutes(row.get("snapshot_minute"), horizon_minutes, row.get("market")),
                "feature_snapshot": {name: _json_number(row.get(name)) for name in FEATURE_NAMES},
            }
        )
    return rows


def add_trading_minutes(value: Any, minutes: int, market: Any = None) -> Any:
    if value is None or pd.isna(value):
        return value
    cursor = pd.Timestamp(value).to_pydatetime()
    if cursor.tzinfo is None:
        cursor = cursor.replace(tzinfo=EXCHANGE_TZ)
    cursor = cursor.astimezone(EXCHANGE_TZ).replace(second=0, microsecond=0)
    remaining = max(1, int(minutes))
    while remaining > 0:
        cursor += timedelta(minutes=1)
        cursor = _normalize_trading_cursor(cursor, market)
        if _is_trading_minute(cursor, market):
            remaining -= 1
    return cursor


def _normalize_trading_cursor(cursor: Any, market: Any = None) -> Any:
    if _normalize_market_key(market) == "us":
        while cursor.weekday() >= 5:
            cursor = (cursor + timedelta(days=1)).replace(hour=21, minute=30, second=0, microsecond=0)
        minute_of_day = cursor.hour * 60 + cursor.minute
        if 4 * 60 < minute_of_day < 21 * 60 + 30:
            return cursor.replace(hour=21, minute=30, second=0, microsecond=0)
        return cursor
    while cursor.weekday() >= 5:
        cursor = (cursor + timedelta(days=1)).replace(hour=9, minute=30, second=0, microsecond=0)
    minute_of_day = cursor.hour * 60 + cursor.minute
    if minute_of_day < 9 * 60 + 30:
        return cursor.replace(hour=9, minute=30, second=0, microsecond=0)
    if 12 * 60 <= minute_of_day < 13 * 60:
        return cursor.replace(hour=13, minute=0, second=0, microsecond=0)
    if minute_of_day > 16 * 60:
        next_day = cursor + timedelta(days=1)
        return _normalize_trading_cursor(next_day.replace(hour=9, minute=30, second=0, microsecond=0), market)
    return cursor


def _is_trading_minute(cursor: Any, market: Any = None) -> bool:
    if cursor.weekday() >= 5:
        return False
    minute_of_day = cursor.hour * 60 + cursor.minute
    if _normalize_market_key(market) == "us":
        return minute_of_day <= 4 * 60 or minute_of_day >= 21 * 60 + 30
    return (9 * 60 + 30 <= minute_of_day < 12 * 60) or (13 * 60 <= minute_of_day <= 16 * 60)


def _normalize_market_key(value: Any) -> str:
    market = str(value or "").lower()
    return "us" if market == "us" else market


def ensure_realtime_profit_tables(conn: Any) -> None:
    conn.execute(
        """
        create table if not exists lb_realtime_profit_model_runs (
          model_run_id text primary key,
          market text not null,
          model_type text not null,
          horizon_minutes int not null,
          target_return numeric not null,
          model_path text not null,
          train_count int not null,
          validation_count int not null,
          metrics jsonb not null default '{}'::jsonb,
          feature_names text[] not null,
          trained_at timestamptz not null default now()
        )
        """
    )
    conn.execute(
        """
        create table if not exists lb_realtime_profit_predictions (
          model_run_id text not null references lb_realtime_profit_model_runs(model_run_id),
          predicted_at timestamptz not null,
          symbol text not null,
          market text not null,
          name text,
          horizon_minutes int not null,
          target_return numeric not null,
          entry_price numeric,
          profit_probability numeric,
          expected_return numeric,
          risk_score numeric,
          decision text,
          validation_due_at timestamptz,
          feature_snapshot jsonb not null default '{}'::jsonb,
          created_at timestamptz not null default now(),
          primary key (model_run_id, predicted_at, symbol, horizon_minutes, target_return)
        )
        """
    )
    _add_column_if_missing(conn, "lb_realtime_profit_predictions", "entry_price", "numeric")
    _add_column_if_missing(conn, "lb_realtime_profit_predictions", "validation_due_at", "timestamptz")
    skip_index_ensure = os.getenv("REALTIME_PROFIT_SKIP_INDEX_ENSURE", "").strip().lower() in {"1", "true", "yes"}
    if not skip_index_ensure:
        conn.execute(
            """
            create index if not exists idx_lb_realtime_profit_predictions_market_time_prob
            on lb_realtime_profit_predictions (market, predicted_at desc, profit_probability desc)
            """
        )
    conn.execute(
        """
        create table if not exists lb_realtime_profit_validation (
          model_run_id text not null references lb_realtime_profit_model_runs(model_run_id),
          predicted_at timestamptz not null,
          symbol text not null,
          market text not null,
          name text,
          horizon_minutes int not null,
          target_return numeric not null,
          entry_price numeric,
          profit_probability numeric,
          expected_return numeric,
          risk_score numeric,
          decision text,
          feature_snapshot jsonb not null default '{}'::jsonb,
          validation_due_at timestamptz not null,
          actual_high numeric,
          actual_low numeric,
          actual_return numeric,
          actual_max_drawdown numeric,
          actual_hit boolean,
          actual_observed_until timestamptz,
          actual_filled_at timestamptz,
          created_at timestamptz not null default now(),
          updated_at timestamptz not null default now(),
          primary key (model_run_id, predicted_at, symbol, horizon_minutes, target_return)
        )
        """
    )
    if not skip_index_ensure:
        conn.execute(
            """
            create index if not exists idx_lb_realtime_profit_validation_due
            on lb_realtime_profit_validation (market, validation_due_at, actual_filled_at)
            """
        )
        conn.execute(
            """
            create index if not exists idx_lb_realtime_profit_validation_result
            on lb_realtime_profit_validation (market, predicted_at desc, profit_probability desc, actual_hit)
            """
        )


def _add_column_if_missing(conn: Any, table_name: str, column_name: str, column_type: str) -> None:
    row = conn.execute(
        """
        select 1
        from information_schema.columns
        where table_schema = current_schema()
          and table_name = %s
          and column_name = %s
        limit 1
        """,
        (table_name, column_name),
    ).fetchone()
    if row:
        return
    if table_name != "lb_realtime_profit_predictions" or column_name not in {"entry_price", "validation_due_at"}:
        raise ValueError(f"unsupported realtime profit column migration: {table_name}.{column_name}")
    conn.execute(f"alter table {table_name} add column {column_name} {column_type}")


def train_realtime_profit_model(
    dsn: str = DEFAULT_DSN,
    market: str = "hk",
    model_root: str | Path = DEFAULT_MODEL_ROOT,
    lookback_days: int = 30,
    horizon_minutes: int | None = None,
    target_return: float | None = None,
    max_rows: int = 50000,
    validation_ratio: float = 0.2,
    profile: str | None = None,
    as_of_date: str | None = None,
    target_direction: str = "long",
) -> RealtimeProfitTrainSummary:
    market = market.lower()
    direction = normalize_target_direction(target_direction)
    resolved_profile = resolve_profit_profile(profile, market, horizon_minutes=horizon_minutes, target_return=target_return, target_direction=direction)
    stored_profile = profile_for_direction(resolved_profile.name, direction)
    horizon_minutes = resolved_profile.horizon_minutes
    target_return = resolved_profile.target_return
    sample_source = "historical_top3_replay" if resolved_profile.name in {"top3_fast", "us_fast_15"} else "realtime_windows"
    if _prefer_materialized_training_samples(direction):
        samples = fetch_materialized_training_features(
            market=market,
            profile=stored_profile,
            target_direction=direction,
            lookback_days=lookback_days,
            max_rows=max_rows,
        )
        sample_source = "materialized_full_market"
        if samples.empty and os.getenv("REALTIME_PROFIT_ALLOW_TRAINING_FALLBACK", "").strip().lower() in {"1", "true", "yes"}:
            sample_source = "materialized_empty_fallback"
    else:
        samples = pd.DataFrame()
    if samples.empty and resolved_profile.name in {"top3_fast", "us_fast_15"}:
        if _prefer_intraday_pool_short_training(direction):
            samples = fetch_top3_fast_training_features(
                None,
                market=market,
                lookback_days=lookback_days,
                horizon_minutes=horizon_minutes,
                target_return=target_return,
                max_rows=max_rows,
                target_direction=direction,
            )
            if sample_source != "materialized_empty_fallback":
                sample_source = "intraday_candidate_pool"
        else:
            samples = fetch_historical_top3_fast_training_features(
                market=market,
                lookback_days=lookback_days,
                horizon_minutes=horizon_minutes,
                target_return=target_return,
                max_rows=max_rows,
                as_of_date=as_of_date,
                target_direction=direction,
            )
            if sample_source != "materialized_empty_fallback":
                sample_source = "historical_top3_replay"
    elif samples.empty:
        psycopg, _ = _load_psycopg()
        with psycopg.connect(dsn) as conn:
            samples = fetch_training_features(
                conn,
                market=market,
                lookback_days=lookback_days,
                horizon_minutes=horizon_minutes,
                target_return=target_return,
                max_rows=max_rows,
            )
        if sample_source != "materialized_empty_fallback":
            sample_source = "realtime_windows"
    if samples.empty:
        raise RuntimeError("not enough realtime samples: 0")
    samples = samples[samples["target_profit"].notna()].copy()
    min_samples = 120 if direction == "short" else 200
    if len(samples) < min_samples:
        raise RuntimeError(f"not enough realtime samples: {len(samples)}")
    train, validation = _temporal_split(samples, validation_ratio)
    model, metrics = _train_classifier(train, validation, market, horizon_minutes, target_return)
    return_estimator, return_metrics = _train_return_regressor(train, validation)
    metrics["profile"] = stored_profile
    metrics["base_profile"] = resolved_profile.name
    metrics["target_direction"] = direction
    metrics["profile_source"] = resolved_profile.source
    metrics["exclude_holdings"] = resolved_profile.exclude_holdings
    metrics["lookback_days"] = int(lookback_days)
    metrics["as_of_date"] = as_of_date
    metrics["source"] = sample_source
    metrics["training_samples"] = int(len(samples))
    if len(samples) < 200:
        metrics["min_sample_warning"] = f"training_samples_below_200:{len(samples)}"
    metrics["train_count"] = int(len(train))
    metrics["validation_count"] = int(len(validation))
    metrics["horizon_minutes"] = int(horizon_minutes)
    metrics["target_return"] = float(target_return)
    model = RealtimeProfitModel(
        model_type=f"{model.model_type}+{return_metrics.get('model_type', 'return_regressor')}",
        estimator=model.estimator,
        feature_names=model.feature_names,
        horizon_minutes=model.horizon_minutes,
        target_return=model.target_return,
        market=model.market,
        target_direction=direction,
        return_estimator=return_estimator,
    )
    metrics["return_regression"] = return_metrics
    model_run_id = f"realtime_profit_{direction}_{market}_{datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S')}"
    model_root = Path(model_root)
    model_root.mkdir(parents=True, exist_ok=True)
    model_path = model_root / f"{model_run_id}.pkl"
    with model_path.open("wb") as fh:
        pickle.dump(model, fh)
    mlflow_result = log_realtime_profit_training(
        tracking_uri=os.getenv("LONGBRIDGE_MLFLOW_TRACKING_URI") or os.getenv("MLFLOW_TRACKING_URI") or str(model_root / "mlruns"),
        experiment_name=os.getenv("LONGBRIDGE_MLFLOW_EXPERIMENT", DEFAULT_MLFLOW_EXPERIMENT),
        run_name=f"{model_run_id}_{resolved_profile.name}",
        params={
            "model_run_id": model_run_id,
            "market": market,
            "profile": stored_profile,
            "profile_source": resolved_profile.source,
            "target_direction": direction,
            "model_type": model.model_type,
            "lookback_days": int(lookback_days),
            "horizon_minutes": int(horizon_minutes),
            "target_return": float(target_return),
            "max_rows": int(max_rows),
            "validation_ratio": float(validation_ratio),
            "as_of_date": as_of_date,
            "train_count": int(len(train)),
            "validation_count": int(len(validation)),
            "training_samples": int(len(samples)),
            "model_path": str(model_path),
        },
        metrics=_json_safe(metrics),
        tags={
            "model_family": "realtime_profit",
            "market": market,
            "profile": stored_profile,
            "source": metrics.get("source"),
        },
        artifact_paths=[model_path],
    )
    metrics["mlflow"] = mlflow_result
    clickhouse_realtime.insert_realtime_profit_model_run(
        {
            "model_run_id": model_run_id,
            "market": market,
            "profile": stored_profile,
            "model_type": model.model_type,
            "horizon_minutes": horizon_minutes,
            "target_return": target_return,
            "model_path": str(model_path),
            "train_count": int(len(train)),
            "validation_count": int(len(validation)),
            "metrics": _json_safe(metrics),
            "feature_names": model.feature_names,
            "trained_at": datetime.now(EXCHANGE_TZ),
        }
    )
    return RealtimeProfitTrainSummary(
        model_run_id=model_run_id,
        market=market,
        model_type=model.model_type,
        train_count=int(len(train)),
        validation_count=int(len(validation)),
        metrics=metrics,
        model_path=str(model_path),
    )


def predict_realtime_profit(
    dsn: str = DEFAULT_DSN,
    market: str = "hk",
    model_root: str | Path = DEFAULT_MODEL_ROOT,
    limit: int = 200,
    profile: str | None = None,
    target_direction: str = "long",
) -> RealtimeProfitPredictSummary:
    market = market.lower()
    direction = normalize_target_direction(target_direction)
    resolved_profile = resolve_profit_profile(profile, market, target_direction=direction)
    stored_profile = profile_for_direction(resolved_profile.name, direction)
    run = _latest_model_run(None, market=market, model_root=model_root, profile=stored_profile)
    feature_limit = _prediction_feature_limit(market, resolved_profile.name, limit)
    candidate_symbols = _prediction_candidate_symbols(market, resolved_profile.name, feature_limit)
    try:
        features = fetch_current_features(None, market=market, limit=feature_limit, symbols=candidate_symbols)
    except TypeError:
        features = fetch_current_features(None, market=market, limit=feature_limit)
    features = _apply_symbol_names(None, features)
    if resolved_profile.name == "us_fast_15":
        features = _filter_us_fast_stock_features(features)
    model = _load_model(Path(run["model_path"]))
    if features.empty:
        return RealtimeProfitPredictSummary(run["model_run_id"], market, 0, [])
    probabilities = model.predict_proba(features)
    predicted_returns = model.predict_return(features)
    model_direction = getattr(model, "target_direction", direction)
    rows = build_prediction_rows(features, probabilities, run["model_run_id"], model.horizon_minutes, model.target_return, predicted_returns, target_direction=model_direction)
    dropped_rows = len(rows)
    rows = [row for row in rows if _valid_prediction_row(row)]
    dropped_rows -= len(rows)
    rows.sort(key=lambda item: (item["profit_probability"] or 0, -(item["risk_score"] or 999)), reverse=True)
    sink_config = RealtimeSinkConfig.from_env()
    prediction_sinks = RealtimeSinkRouter(
        RealtimeSinkConfig(
            sinks=("clickhouse",),
            clickhouse_url=sink_config.clickhouse_url,
            clickhouse_database=sink_config.clickhouse_database,
            clickhouse_user=sink_config.clickhouse_user,
            clickhouse_password=sink_config.clickhouse_password,
            redis_url=sink_config.redis_url,
        )
    )
    prediction_sinks.ensure_schema()
    if resolved_profile.name == "us_fast_15":
        prediction_sinks.write_us_fast_profit_predictions(rows)
    else:
        prediction_sinks.write_profit_predictions(rows)
    clickhouse_realtime.insert_realtime_profit_validation_rows(rows)
    if dropped_rows:
        print(json.dumps({"prediction_rows_dropped": dropped_rows}, ensure_ascii=False), flush=True)
    return RealtimeProfitPredictSummary(run["model_run_id"], market, len(rows), rows[:20])


def review_realtime_profit_2pct_outcomes(
    *,
    market: str = "all",
    profile: str = "all",
    lookback_days: int = 30,
    min_probability: float = 0.70,
    target_return: float = 0.02,
    limit: int = 100,
) -> RealtimeProfitOutcomeReviewSummary:
    rows = clickhouse_realtime.fetch_realtime_profit_outcome_review(
        market=market,
        profile=profile,
        lookback_days=lookback_days,
        min_probability=min_probability,
        target_return=target_return,
        limit=limit,
    )
    evaluated = len(rows)
    hit_count = sum(1 for row in rows if row.get("hit_target"))
    avg_max_return = _average(row.get("max_return") for row in rows)
    avg_max_drawdown = _average(row.get("max_drawdown") for row in rows)
    worst_drawdown = min((float(row["max_drawdown"]) for row in rows if row.get("max_drawdown") is not None), default=None)
    return RealtimeProfitOutcomeReviewSummary(
        market=market.lower(),
        profile=profile.lower(),
        evaluated=evaluated,
        hit_count=hit_count,
        hit_rate=round(hit_count / evaluated, 4) if evaluated else None,
        avg_max_return=round(avg_max_return, 4) if avg_max_return is not None else None,
        avg_max_drawdown=round(avg_max_drawdown, 4) if avg_max_drawdown is not None else None,
        worst_drawdown=round(worst_drawdown, 4) if worst_drawdown is not None else None,
        rows=rows,
    )


def _valid_prediction_row(row: dict[str, Any]) -> bool:
    return all(row.get(name) not in (None, "") for name in ("model_run_id", "predicted_at", "symbol", "market"))


def backfill_realtime_profit_actuals(
    dsn: str = DEFAULT_DSN,
    market: str = "hk",
    limit: int = 500,
    max_age_days: int = 3,
) -> RealtimeProfitValidationSummary:
    raise RuntimeError("Realtime profit actual backfill must read ClickHouse realtime quotes; PostgreSQL realtime source has been disabled.")


def _backfill_realtime_profit_actuals_postgres_disabled(
    dsn: str = DEFAULT_DSN,
    market: str = "hk",
    limit: int = 500,
    max_age_days: int = 3,
) -> RealtimeProfitValidationSummary:
    psycopg, _ = _load_psycopg()
    market = market.lower()
    with psycopg.connect(dsn) as conn:
        ensure_realtime_profit_tables(conn)
        conn.execute("set local statement_timeout = '90s'")
        updated = conn.execute(
            """
            with due as materialized (
              select v.model_run_id, v.predicted_at, v.symbol, v.horizon_minutes, v.target_return,
                     v.entry_price, v.validation_due_at
              from lb_realtime_profit_validation v
              where (%(market)s = 'all' or v.market = %(market)s)
                and v.actual_filled_at is null
                and v.validation_due_at <= now()
                and v.validation_due_at >= now() - ((%(max_age_days)s + 1) || ' days')::interval
                and v.predicted_at >= now() - (%(max_age_days)s || ' days')::interval
                and v.entry_price is not null
              order by v.validation_due_at, v.predicted_at
              limit %(limit)s
              for update skip locked
            ),
            actuals as materialized (
              select d.*,
                     q.actual_high,
                     q.actual_low,
                     q.observed_until
              from due d
              join lateral (
                select max(q.last_done) as actual_high,
                       min(q.last_done) as actual_low,
                       max(q.snapshot_minute) as observed_until
                from lb_realtime_quotes q
                where q.symbol = d.symbol
                  and q.snapshot_minute > d.predicted_at
                  and q.snapshot_minute <= d.validation_due_at
                  and q.last_done is not null
              ) q on q.observed_until is not null
            ),
            written as (
              update lb_realtime_profit_validation v
              set actual_high = a.actual_high,
                  actual_low = a.actual_low,
                  actual_return = a.actual_high / nullif(a.entry_price, 0) - 1,
                  actual_max_drawdown = a.actual_low / nullif(a.entry_price, 0) - 1,
                  actual_hit = (a.actual_high / nullif(a.entry_price, 0) - 1) >= a.target_return,
                  actual_observed_until = a.observed_until,
                  actual_filled_at = now(),
                  updated_at = now()
              from actuals a
              where v.model_run_id = a.model_run_id
                and v.predicted_at = a.predicted_at
                and v.symbol = a.symbol
                and v.horizon_minutes = a.horizon_minutes
                and v.target_return = a.target_return
              returning v.actual_hit, v.actual_return, v.actual_max_drawdown
            ),
            missing as (
              update lb_realtime_profit_validation v
              set actual_filled_at = now(),
                  updated_at = now()
              from due d
              where v.model_run_id = d.model_run_id
                and v.predicted_at = d.predicted_at
                and v.symbol = d.symbol
                and v.horizon_minutes = d.horizon_minutes
                and v.target_return = d.target_return
                and not exists (
                  select 1
                  from actuals a
                  where a.model_run_id = d.model_run_id
                    and a.predicted_at = d.predicted_at
                    and a.symbol = d.symbol
                    and a.horizon_minutes = d.horizon_minutes
                    and a.target_return = d.target_return
                )
              returning 1
            )
            select count(*)::int as evaluated,
                   coalesce(sum(case when actual_hit then 1 else 0 end), 0)::int as hits,
                   avg(actual_return)::float as avg_actual_return,
                   avg(actual_max_drawdown)::float as avg_max_drawdown
            from written
            """,
            {"market": market, "limit": limit, "max_age_days": max(1, int(max_age_days))},
        ).fetchone()
    evaluated = int(updated[0] or 0)
    hits = int(updated[1] or 0)
    return RealtimeProfitValidationSummary(
        market=market,
        evaluated=evaluated,
        hits=hits,
        hit_rate=(hits / evaluated if evaluated else None),
        avg_actual_return=float(updated[2]) if updated[2] is not None else None,
        avg_max_drawdown=float(updated[3]) if updated[3] is not None else None,
    )


def fetch_realtime_profit_predictions(dsn: str = DEFAULT_DSN, market: str = "hk", limit: int = 50) -> list[dict[str, Any]]:
    market = market.lower()
    model_rows = clickhouse_realtime.fetch_latest_realtime_profit_model_runs(market=market, limit=20)
    rows: list[dict[str, Any]] = []
    for model_row in model_rows:
        row_market = str(model_row.get("market") or "").lower()
        model_run_id = str(model_row.get("model_run_id") or "")
        if not row_market or not model_run_id:
            continue
        rows.extend(
            clickhouse_realtime.fetch_latest_profit_prediction_rows(
                model_run_id=model_run_id,
                market=row_market,
                limit=int(limit),
            )
        )
    rows.sort(key=lambda item: (item.get("profit_probability") or 0, -(item.get("risk_score") or 999), item.get("symbol") or ""), reverse=True)
    return rows[: int(limit)]


def _upsert_validation_prediction(conn: Any, Jsonb: Any, row: dict[str, Any]) -> None:
    conn.execute(
        """
        insert into lb_realtime_profit_validation
          (model_run_id, predicted_at, symbol, market, name, horizon_minutes, target_return,
           entry_price, profit_probability, expected_return, risk_score, decision, feature_snapshot,
           validation_due_at)
        values (%(model_run_id)s, %(predicted_at)s, %(symbol)s, %(market)s, %(name)s,
                %(horizon_minutes)s, %(target_return)s, %(entry_price)s, %(profit_probability)s,
                %(expected_return)s, %(risk_score)s, %(decision)s, %(feature_snapshot)s,
                %(validation_due_at)s)
        on conflict (model_run_id, predicted_at, symbol, horizon_minutes, target_return)
        do update set
          name = excluded.name,
          market = excluded.market,
          entry_price = excluded.entry_price,
          profit_probability = excluded.profit_probability,
          expected_return = excluded.expected_return,
          risk_score = excluded.risk_score,
          decision = excluded.decision,
          feature_snapshot = excluded.feature_snapshot,
          validation_due_at = excluded.validation_due_at,
          updated_at = now()
        """,
        row | {"feature_snapshot": Jsonb(row["feature_snapshot"])},
    )


def fetch_training_features(
    conn: Any,
    market: str,
    lookback_days: int,
    horizon_minutes: int,
    target_return: float,
    max_rows: int,
) -> pd.DataFrame:
    raise RuntimeError("Realtime profit training has been moved off PostgreSQL realtime tables; build ClickHouse training features before running this job.")


def fetch_materialized_training_features(
    *,
    market: str,
    profile: str,
    target_direction: str,
    lookback_days: int,
    max_rows: int,
) -> pd.DataFrame:
    rows = clickhouse_realtime.fetch_realtime_profit_training_samples(
        market=market,
        profile=profile,
        target_direction=target_direction,
        lookback_days=lookback_days,
        max_rows=max_rows,
    )
    return _coerce_feature_frame(pd.DataFrame(rows))


def fetch_top3_fast_training_features(
    conn: Any,
    market: str,
    lookback_days: int,
    horizon_minutes: int,
    target_return: float,
    max_rows: int,
    target_direction: str = "long",
) -> pd.DataFrame:
    columns = [
        "symbol",
        "market",
        "name",
        "snapshot_minute",
        "last_done",
        "prev_close",
        "change_percentage",
        "high",
        "low",
        "total_net",
        "large_net",
        "turnover",
    ]
    database = clickhouse_realtime._ident(clickhouse_realtime._database())
    market_key = clickhouse_realtime._sql_string(market.lower())
    rows = clickhouse_realtime._query_json_each_row(
        f"""
        select symbol, market, name, run_time as snapshot_minute, last as last_done,
               null as prev_close, change_pct as change_percentage, high, low,
               total_net, large_net, payload
        from {database}.lb_intraday_candidate_pool final
        where trade_date >= today() - interval {max(1, int(lookback_days))} day
          and market = {market_key}
          and rank <= 3
          and last is not null
        order by run_time desc, rank asc
        limit {max(1, int(max_rows))}
        """
    )
    signal_rows = []
    for row in rows:
        payload = _json_dict(row.get("payload"))
        if bool(payload.get("is_holding")):
            continue
        source = payload.get("source") if isinstance(payload.get("source"), dict) else {}
        signal_rows.append(
            [
                row.get("symbol"),
                row.get("market") or market.lower(),
                row.get("name"),
                row.get("snapshot_minute"),
                row.get("last_done"),
                None,
                row.get("change_percentage"),
                row.get("high"),
                row.get("low"),
                row.get("total_net"),
                row.get("large_net"),
                source.get("turnover") or 0,
            ]
        )
    signals = pd.DataFrame(signal_rows, columns=columns)
    if signals.empty:
        return _coerce_feature_frame(signals)
    outcomes = fetch_top3_fast_future_outcomes(signals, horizon_minutes=horizon_minutes, market=market)
    return build_top3_fast_training_features(signals, outcomes, target_return=target_return, target_direction=target_direction)


def fetch_historical_top3_fast_training_features(
    *,
    market: str,
    lookback_days: int,
    horizon_minutes: int,
    target_return: float,
    max_rows: int,
    as_of_date: str | None = None,
    target_direction: str = "long",
) -> pd.DataFrame:
    if market.lower() == "cn":
        return fetch_historical_cn_top3_fast_training_features(
            lookback_days=lookback_days,
            horizon_minutes=horizon_minutes,
            target_return=target_return,
            max_rows=max_rows,
            as_of_date=as_of_date,
            target_direction=target_direction,
        )
    snapshots = fetch_historical_top3_candidate_snapshots(market=market, lookback_days=lookback_days, max_rows=max_rows, as_of_date=as_of_date)
    replay_limit = US_FAST_REPLAY_LIMIT if market.lower() == "us" else 3
    signals = replay_historical_top3_fast_signals(snapshots, limit=replay_limit)
    if signals.empty:
        return _coerce_feature_frame(signals)
    outcomes = fetch_top3_fast_future_outcomes(signals, horizon_minutes=horizon_minutes, market=market)
    return build_top3_fast_training_features(signals, outcomes, target_return=target_return, target_direction=target_direction)


def fetch_historical_cn_top3_fast_training_features(
    *,
    lookback_days: int,
    horizon_minutes: int,
    target_return: float,
    max_rows: int,
    as_of_date: str | None = None,
    target_direction: str = "long",
) -> pd.DataFrame:
    snapshots = fetch_historical_cn_top3_candidate_snapshots(
        lookback_days=lookback_days,
        max_rows=max_rows,
        as_of_date=as_of_date,
    )
    signals = replay_historical_top3_fast_signals(snapshots, limit=3)
    if signals.empty:
        return _coerce_feature_frame(signals)
    outcomes = fetch_top3_fast_future_outcomes(signals, horizon_minutes=horizon_minutes, market="cn")
    return build_top3_fast_training_features(signals, outcomes, target_return=target_return, target_direction=target_direction)


def fetch_historical_cn_top3_candidate_snapshots(*, lookback_days: int, max_rows: int, as_of_date: str | None = None) -> pd.DataFrame:
    database = clickhouse_realtime._ident(clickhouse_realtime._database())
    cleaned_as_of_date = str(as_of_date).replace("'", "") if as_of_date is not None else None
    as_of_clause = "now()" if cleaned_as_of_date is None else f"parseDateTime64BestEffort('{cleaned_as_of_date} 23:59:59', 3, 'Asia/Shanghai')"
    row_limit = max(int(max_rows) * 20, 1000)
    rows = clickhouse_realtime._query_json_each_row(
        f"""
        with quote as (
          select symbol,
                 market,
                 snapshot_minute,
                 argMax(last_done, inserted_at) as last_done,
                 argMax(prev_close, inserted_at) as prev_close,
                 argMax(open, inserted_at) as open,
                 argMax(high, inserted_at) as high,
                 argMax(low, inserted_at) as low,
                 argMax(change_percentage, inserted_at) as change_percentage,
                 argMax(turnover, inserted_at) as turnover,
                 argMax(volume, inserted_at) as volume
          from {database}.lb_realtime_quotes q
          where q.market = 'cn'
            and q.snapshot_minute >= {as_of_clause} - interval {int(lookback_days)} day
            and q.snapshot_minute <= {as_of_clause}
            and q.last_done > 0
            and q.turnover >= 10000000
            and toMinute(q.snapshot_minute) % 15 = 0
            and {_historical_top3_market_hours_sql("q", "cn")}
          group by symbol, market, snapshot_minute
        ),
        ranked as (
          select *,
                 row_number() over (
                   partition by snapshot_minute
                   order by (
                     greatest(coalesce(change_percentage, 0), 0) * 2
                     + log10(greatest(turnover, 1)) / 8
                     + if(prev_close > 0 and open > 0, greatest(open / prev_close - 1, 0) * 80, 0)
                     + if(high > low, greatest((last_done - low) / nullIf(high - low, 0), 0), 0)
                   ) desc,
                   turnover desc
                 ) as rn
          from quote
          where coalesce(change_percentage, 0) >= -2
        )
        select symbol,
               market,
               symbol as name,
               snapshot_minute,
               last_done,
               prev_close,
               open,
               high,
               low,
               coalesce(change_percentage, if(prev_close > 0, (last_done / prev_close - 1) * 100, 0)) as change_percentage,
               turnover,
               1.0 as turnover_ratio20,
               if(high > low, (last_done - low) / nullIf(high - low, 0), 0.5) as close_pos,
               0.0 as return_1m,
               0.0 as return_5m,
               0.0 as return_15m,
               0.0 as volatility_5m,
               0.0 as volatility_15m,
               1.0 as volume_ratio_5m,
               1.0 as turnover_ratio_5m,
               null as upside_probability,
               null as expected_return_5d,
               null as breakout_score,
               0.0 as large_net,
               0.0 as total_net,
               0.0 as capital_flow_5m,
               0.0 as capital_flow_slope_15m,
               0.0 as price_to_avg_15m,
               0.0 as flow_30m
        from ranked
        where rn <= 50
        order by snapshot_minute desc, rn asc
        limit {row_limit}
        """
    )
    return pd.DataFrame(rows)


def fetch_historical_top3_candidate_snapshots(*, market: str, lookback_days: int, max_rows: int, as_of_date: str | None = None) -> pd.DataFrame:
    database = clickhouse_realtime._ident(clickhouse_realtime._database())
    market_key = market.lower().replace("'", "")
    cleaned_as_of_date = str(as_of_date).replace("'", "") if as_of_date is not None else None
    as_of_clause = "now()" if cleaned_as_of_date is None else f"parseDateTime64BestEffort('{cleaned_as_of_date} 23:59:59', 3, 'Asia/Shanghai')"
    filter_sql = _us_fast_candidate_filter_sql("q") if market_key == "us" else "1 = 1"
    market_hours_sql = _historical_top3_market_hours_sql("q", market_key)
    raw_candidate_limit = _historical_raw_candidate_limit(market_key)
    row_limit = _historical_top3_snapshot_row_limit(market_key, max_rows)
    short_feature_ctes, short_feature_select, short_feature_joins = _historical_short_feature_sql(database, as_of_clause, lookback_days)
    rows = clickhouse_realtime._query_json_each_row(
        f"""
        with quote_dedup as (
          select symbol,
                 market,
                 snapshot_minute,
                 argMax(last_done, inserted_at) as last_done,
                 argMax(prev_close, inserted_at) as prev_close,
                 argMax(open, inserted_at) as open,
                 argMax(high, inserted_at) as high,
                 argMax(low, inserted_at) as low,
                 argMax(change_percentage, inserted_at) as change_percentage,
                 argMax(turnover, inserted_at) as turnover
                 ,argMax(volume, inserted_at) as volume
          from {database}.lb_realtime_quotes q
          where q.market = '{market_key}'
            and snapshot_minute >= {as_of_clause} - interval {int(lookback_days)} day
            and snapshot_minute <= {as_of_clause}
            and q.last_done > 0
            and q.turnover >= 1000000
            and {market_hours_sql}
          group by symbol, market, snapshot_minute
        ),
        quote_window as (
          select q.*,
                 coalesce(q.last_done / nullIf(lagInFrame(q.last_done, 1) over w, 0) - 1, 0) as return_1m,
                 coalesce(q.last_done / nullIf(lagInFrame(q.last_done, 5) over w, 0) - 1, 0) as return_5m,
                 coalesce(q.last_done / nullIf(lagInFrame(q.last_done, 15) over w, 0) - 1, 0) as return_15m,
                 coalesce(stddevPop(q.last_done / nullIf(q.prev_close, 0) - 1)
                   over (partition by q.symbol order by q.snapshot_minute rows between 5 preceding and current row), 0) as volatility_5m,
                 coalesce(stddevPop(q.last_done / nullIf(q.prev_close, 0) - 1)
                   over (partition by q.symbol order by q.snapshot_minute rows between 15 preceding and current row), 0) as volatility_15m,
                 greatest(q.volume - coalesce(lagInFrame(q.volume, 1) over w, q.volume), 0) as minute_volume,
                 greatest(q.turnover - coalesce(lagInFrame(q.turnover, 1) over w, q.turnover), 0) as minute_turnover,
                 coalesce(q.last_done / nullIf(avg(q.last_done) over (partition by q.symbol order by q.snapshot_minute rows between 15 preceding and current row), 0) - 1, 0) as price_to_avg_15m
          from quote_dedup q
          window w as (partition by q.symbol order by q.snapshot_minute rows between 15 preceding and current row)
        ),
        quote as (
          select qw.*,
                 coalesce(minute_volume / nullIf(avg(minute_volume) over (partition by symbol order by snapshot_minute rows between 5 preceding and current row), 0), 1) as volume_ratio_5m,
                 coalesce(minute_turnover / nullIf(avg(minute_turnover) over (partition by symbol order by snapshot_minute rows between 5 preceding and current row), 0), 1) as turnover_ratio_5m
          from quote_window qw
        ),
        sampled_quote as (
          select *
          from quote
          where toMinute(snapshot_minute) % 5 = 0
        ),
        ranked_quote as (
          select *,
                 row_number() over (partition by snapshot_minute order by turnover desc) as turnover_rank
          from sampled_quote
        ),
        capital as (
          select symbol,
                 toStartOfInterval(snapshot_minute, interval 5 minute) as capital_bucket,
                 argMax(large_net, inserted_at) as large_net,
                 argMax(total_net, inserted_at) as total_net
          from {database}.lb_realtime_capital
          where market = '{market_key}'
            and snapshot_minute >= {as_of_clause} - interval {int(lookback_days)} day
            and snapshot_minute <= {as_of_clause}
          group by symbol, capital_bucket
        ),
        flow as (
          select symbol,
                 toStartOfMinute(flow_time) as snapshot_minute,
                 sum(inflow) as flow_5m,
                 sum(inflow) as flow_15m,
                 sum(inflow) as flow_30m
          from {database}.lb_realtime_capital_flow
          where flow_time >= {as_of_clause} - interval {int(lookback_days)} day
            and flow_time <= {as_of_clause}
          group by symbol, snapshot_minute
        )
        {short_feature_ctes}
        select q.symbol as symbol,
               q.market,
               q.symbol as name,
               q.snapshot_minute as snapshot_minute,
               q.last_done,
               q.prev_close,
               q.open,
               q.high,
               q.low,
               q.change_percentage,
               q.turnover,
               1.0 as turnover_ratio20,
               if(q.high > q.low, (q.last_done - q.low) / (q.high - q.low), 0.5) as close_pos,
               q.return_1m,
               q.return_5m,
               q.return_15m,
               q.volatility_5m,
               q.volatility_15m,
               q.volume_ratio_5m,
               q.turnover_ratio_5m,
               null as upside_probability,
               null as expected_return_5d,
               null as breakout_score,
               coalesce(c.large_net, 0) as large_net,
               coalesce(c.total_net, 0) as total_net,
               coalesce(f.flow_5m, 0) as capital_flow_5m,
               coalesce(f.flow_15m - f.flow_30m / 2, 0) as capital_flow_slope_15m,
               q.price_to_avg_15m,
               greatest(-q.return_5m, 0) as down_momentum_5m,
               greatest(-q.return_15m, 0) as down_momentum_15m,
               if(q.high > q.low, 1 - (q.last_done - q.low) / (q.high - q.low), 0.5) as near_day_low,
               {short_feature_select},
               0 as flow_30m
        from ranked_quote q
        left join capital c on c.symbol = q.symbol and c.capital_bucket = toStartOfInterval(q.snapshot_minute, interval 5 minute)
        left join flow f on f.symbol = q.symbol and f.snapshot_minute = q.snapshot_minute
        {short_feature_joins}
        where q.turnover_rank <= {raw_candidate_limit}
          and {filter_sql}
        order by q.snapshot_minute desc, q.turnover desc
        limit {row_limit}
        """
    )
    return pd.DataFrame(rows)


def _historical_top3_snapshot_row_limit(market: str, max_signal_rows: int) -> int:
    replay_limit = US_FAST_REPLAY_LIMIT if market.lower() == "us" else 3
    raw_candidates_per_snapshot = _historical_raw_candidate_limit(market)
    multiplier = math.ceil(raw_candidates_per_snapshot / replay_limit)
    return max(raw_candidates_per_snapshot, int(max_signal_rows) * multiplier)


def _historical_raw_candidate_limit(market: str) -> int:
    return 50 if market.lower() == "us" else 200


def _historical_short_feature_sql(database: str, as_of_clause: str, lookback_days: int) -> tuple[str, str, str]:
    enabled = os.getenv("REALTIME_PROFIT_HISTORICAL_SHORT_FEATURE_JOINS", "").strip().lower() in {"1", "true", "yes"}
    if not enabled:
        return (
            "",
            "\n               0 as short_selling_ratio,\n               0 as short_rate,\n               0 as short_balance_ratio,\n               0 as days_to_cover,\n               0 as negative_sentiment_score,\n               0 as bearish_event_strength",
            "",
        )
    return (
        f""",
        hk_short as (
          select symbol,
                 argMax(short_selling_ratio, trade_date) as short_selling_ratio
          from {database}.lb_hk_short_selling_turnover final
          where trade_date >= toDate({as_of_clause}) - interval {int(lookback_days) + 10} day
            and trade_date <= toDate({as_of_clause})
          group by symbol
        ),
        stock_short as (
          select symbol,
                 argMax(rate, trade_date) as short_rate,
                 argMax(balance / nullIf(close * greatest(total_amount, 1), 0), trade_date) as short_balance_ratio
          from {database}.lb_stock_short_trades final
          where trade_date >= toDate({as_of_clause}) - interval {int(lookback_days) + 30} day
            and trade_date <= toDate({as_of_clause})
          group by symbol
        ),
        us_short as (
          select symbol,
                 argMax(short_interest_ratio, report_date) as short_interest_ratio,
                 argMax(days_to_cover, report_date) as days_to_cover
          from {database}.lb_us_short_positions final
          where report_date >= toDate({as_of_clause}) - interval {int(lookback_days) + 45} day
            and report_date <= toDate({as_of_clause})
          group by symbol
        ),
        sentiment as (
          select source_symbol as symbol,
                 maxIf(greatest(-nlp_sentiment_score, 0), impact_direction in ('bearish', 'uncertain', 'neutral') or nlp_sentiment_score < 0) as negative_sentiment_score,
                 maxIf(impact_strength_pct, impact_direction = 'bearish') as bearish_event_strength
          from {database}.lb_sentiment_impact_events final
          where analysis_date >= toDate({as_of_clause}) - interval {int(lookback_days) + 14} day
            and analysis_date <= toDate({as_of_clause})
          group by source_symbol
        )""",
        "\n               coalesce(hks.short_selling_ratio, 0) as short_selling_ratio,\n               coalesce(sts.short_rate, uss.short_interest_ratio, 0) as short_rate,\n               coalesce(sts.short_balance_ratio, 0) as short_balance_ratio,\n               coalesce(uss.days_to_cover, 0) as days_to_cover,\n               coalesce(sent.negative_sentiment_score, 0) as negative_sentiment_score,\n               coalesce(sent.bearish_event_strength, 0) as bearish_event_strength",
        "\n        left join hk_short hks on hks.symbol = q.symbol\n        left join stock_short sts on sts.symbol = q.symbol\n        left join us_short uss on uss.symbol = q.symbol\n        left join sentiment sent on sent.symbol = q.symbol",
    )


def _historical_top3_market_hours_sql(alias: str, market: str) -> str:
    value = f"{alias}.snapshot_minute"
    if market.lower() == "cn":
        return (
            f"((toHour({value}) = 9 and toMinute({value}) >= 30) "
            f"or (toHour({value}) in (10, 13, 14)) "
            f"or (toHour({value}) = 11 and toMinute({value}) <= 30))"
        )
    if market.lower() != "hk":
        return "1 = 1"
    return (
        f"((toHour({value}) = 9 and toMinute({value}) >= 30) "
        f"or (toHour({value}) in (10, 11, 13, 14)) "
        f"or (toHour({value}) = 15 and toMinute({value}) <= 0))"
    )


def replay_historical_top3_fast_signals(snapshots: pd.DataFrame, *, limit: int = 3) -> pd.DataFrame:
    if snapshots.empty:
        return snapshots.copy()
    data = snapshots.copy()
    data["snapshot_minute"] = pd.to_datetime(data["snapshot_minute"])
    rows: list[dict[str, Any]] = []
    for snapshot_minute, group in data.sort_values("snapshot_minute").groupby("snapshot_minute", sort=True):
        source_rows = {str(row.get("symbol")): row for row in group.to_dict("records")}
        candidates = [
            IntradayCandidate(
                symbol=str(row.get("symbol")),
                name=str(row.get("name") or row.get("symbol")),
                last=_float(row.get("last_done")),
                change_pct=_float(row.get("change_percentage")),
                open=_float(row.get("open") if row.get("open") is not None else row.get("last_done")),
                high=_float(row.get("high") if row.get("high") is not None else row.get("last_done")),
                low=_float(row.get("low") if row.get("low") is not None else row.get("last_done")),
                turnover=_float(row.get("turnover")),
                turnover_ratio20=_float(row.get("turnover_ratio20") if row.get("turnover_ratio20") is not None else 1.0),
                close_pos=_float(row.get("close_pos") if row.get("close_pos") is not None else 0.5),
                upside_probability=_optional_float(row.get("upside_probability")),
                expected_return_5d=_optional_float(row.get("expected_return_5d")),
                breakout_score=_optional_float(row.get("breakout_score")),
                large_net=_optional_float(row.get("large_net")),
                total_net=_optional_float(row.get("total_net")),
                flow_30m=_optional_float(row.get("flow_30m")),
            )
            for row in group.to_dict("records")
        ]
        for index, ranked in enumerate(rank_intraday_candidates(candidates, limit=limit), start=1):
            source = ranked.source
            source_row = source_rows.get(source.symbol, {})
            rows.append(
                {
                    "symbol": source.symbol,
                    "market": str(group.iloc[0].get("market") or "hk").lower(),
                    "name": source.name,
                    "snapshot_minute": snapshot_minute,
                    "rank": index,
                    "last_done": source.last,
                    "prev_close": np.nan,
                    "change_percentage": source.change_pct,
                    "open": source.open,
                    "high": source.high,
                    "low": source.low,
                    "total_net": source.total_net,
                    "large_net": source.large_net,
                    "turnover": source.turnover,
                    "turnover_ratio20": source.turnover_ratio20,
                    "close_pos": source.close_pos,
                    "upside_probability": source.upside_probability,
                    "expected_return_5d": source.expected_return_5d,
                    "breakout_score": source.breakout_score,
                    "flow_30m": source.flow_30m,
                    "return_1m": _float(source_row.get("return_1m")),
                    "return_5m": _float(source_row.get("return_5m")),
                    "return_15m": _float(source_row.get("return_15m")),
                    "volatility_5m": _float(source_row.get("volatility_5m")),
                    "volatility_15m": _float(source_row.get("volatility_15m")),
                    "volume_ratio_5m": _float(source_row.get("volume_ratio_5m")) or 1.0,
                    "turnover_ratio_5m": _float(source_row.get("turnover_ratio_5m")) or 1.0,
                    "capital_flow_5m": _float(source_row.get("capital_flow_5m")),
                    "capital_flow_slope_15m": _float(source_row.get("capital_flow_slope_15m")),
                    "price_to_avg_15m": _float(source_row.get("price_to_avg_15m")),
                    "down_momentum_5m": _float(source_row.get("down_momentum_5m")),
                    "down_momentum_15m": _float(source_row.get("down_momentum_15m")),
                    "near_day_low": _float(source_row.get("near_day_low")),
                    "short_selling_ratio": _float(source_row.get("short_selling_ratio")),
                    "short_rate": _float(source_row.get("short_rate")),
                    "short_balance_ratio": _float(source_row.get("short_balance_ratio")),
                    "days_to_cover": _float(source_row.get("days_to_cover")),
                    "negative_sentiment_score": _float(source_row.get("negative_sentiment_score")),
                    "bearish_event_strength": _float(source_row.get("bearish_event_strength")),
                }
            )
    return pd.DataFrame(rows)


def fetch_top3_fast_future_outcomes(signals: pd.DataFrame, horizon_minutes: int, market: str = "hk") -> pd.DataFrame:
    if signals.empty:
        return pd.DataFrame(columns=["symbol", "snapshot_minute", "future_high", "future_low", "future_price"])
    database = clickhouse_realtime._ident(clickhouse_realtime._database())
    data = signals[["symbol", "snapshot_minute"]].copy()
    data["symbol"] = data["symbol"].astype(str)
    data["snapshot_minute"] = pd.to_datetime(data["snapshot_minute"]).apply(_exchange_timestamp)
    market_key = market.lower()
    data["horizon_end"] = data["snapshot_minute"].apply(lambda value: _exchange_timestamp(add_trading_minutes(value, horizon_minutes, market_key)))
    symbols = sorted({str(symbol).replace("'", "") for symbol in data["symbol"] if str(symbol)})
    if not symbols:
        return pd.DataFrame(columns=["symbol", "snapshot_minute", "future_high", "future_low", "future_price"])
    start = _format_exchange_timestamp(data["snapshot_minute"].min())
    end = _format_exchange_timestamp(data["horizon_end"].max())
    symbol_tuple = "(" + ",".join(f"'{symbol}'" for symbol in symbols) + ")"
    sql = f"""
        select symbol,
               snapshot_minute,
               argMax(last_done, inserted_at) as quote_last_done
        from {database}.lb_realtime_quotes
        where symbol in {symbol_tuple}
          and snapshot_minute > parseDateTime64BestEffort('{start}', 3, 'Asia/Shanghai')
          and snapshot_minute <= parseDateTime64BestEffort('{end}', 3, 'Asia/Shanghai')
          and last_done is not null
        group by symbol, snapshot_minute
        order by symbol, snapshot_minute
    """
    quotes = pd.DataFrame(clickhouse_realtime._query_json_each_row(sql))
    if quotes.empty:
        return pd.DataFrame(columns=["symbol", "snapshot_minute", "future_high", "future_low", "future_price"])
    quotes["snapshot_minute"] = pd.to_datetime(quotes["snapshot_minute"]).apply(_exchange_timestamp)
    quotes["last_done"] = pd.to_numeric(quotes["quote_last_done"], errors="coerce")
    rows: list[dict[str, Any]] = []
    quotes_by_symbol = {symbol: group.sort_values("snapshot_minute") for symbol, group in quotes.groupby("symbol")}
    for row in data.to_dict("records"):
        symbol = str(row["symbol"])
        snapshot = row["snapshot_minute"]
        horizon_end = row["horizon_end"]
        group = quotes_by_symbol.get(symbol)
        if group is None or group.empty:
            continue
        window = group[
            (group["snapshot_minute"] > snapshot)
            & (group["snapshot_minute"] <= horizon_end)
        ]
        if window.empty:
            continue
        if window["snapshot_minute"].max() < horizon_end:
            continue
        rows.append(
            {
                "symbol": symbol,
                "snapshot_minute": snapshot,
                "future_high": float(window["last_done"].max()),
                "future_low": float(window["last_done"].min()),
                "future_price": float(window.iloc[-1]["last_done"]),
            }
        )
    return pd.DataFrame(rows)


def _format_exchange_timestamp(value: Any) -> str:
    timestamp = _exchange_timestamp(value)
    return timestamp.strftime("%Y-%m-%d %H:%M:%S")


def _exchange_timestamp(value: Any) -> pd.Timestamp:
    timestamp = pd.Timestamp(value)
    if timestamp.tzinfo is None:
        return timestamp.tz_localize(EXCHANGE_TZ)
    return timestamp.tz_convert(EXCHANGE_TZ)


def build_top3_fast_training_features(signals: pd.DataFrame, outcomes: pd.DataFrame, target_return: float, target_direction: str = "long") -> pd.DataFrame:
    if signals.empty:
        return _coerce_feature_frame(signals)
    data = signals.copy()
    data["snapshot_minute"] = pd.to_datetime(data["snapshot_minute"]).apply(_exchange_timestamp)
    future = outcomes.copy()
    if not future.empty:
        future["snapshot_minute"] = pd.to_datetime(future["snapshot_minute"]).apply(_exchange_timestamp)
    merged = data.merge(future, on=["symbol", "snapshot_minute"], how="inner")
    if merged.empty:
        return _coerce_feature_frame(merged)
    last = pd.to_numeric(merged["last_done"], errors="coerce")
    high = pd.to_numeric(merged.get("high"), errors="coerce")
    low = pd.to_numeric(merged.get("low"), errors="coerce")
    turnover = pd.to_numeric(merged.get("turnover"), errors="coerce").abs()
    large_net = pd.to_numeric(merged.get("large_net"), errors="coerce")
    total_net = pd.to_numeric(merged.get("total_net"), errors="coerce")
    merged["return_1m"] = _numeric_or_default(merged, "return_1m", 0.0)
    merged["return_5m"] = _numeric_or_default(merged, "return_5m", 0.0)
    merged["return_15m"] = _numeric_or_default(merged, "return_15m", 0.0)
    merged["volatility_5m"] = _numeric_or_default(merged, "volatility_5m", 0.0)
    merged["volatility_15m"] = _numeric_or_default(merged, "volatility_15m", 0.0)
    merged["volume_ratio_5m"] = _numeric_or_default(merged, "volume_ratio_5m", 1.0)
    merged["turnover_ratio_5m"] = _numeric_or_default(merged, "turnover_ratio_5m", 1.0)
    merged["large_net_ratio"] = large_net / turnover.replace(0, np.nan)
    merged["small_net_ratio"] = 0.0
    merged["total_net_ratio"] = total_net / turnover.replace(0, np.nan)
    merged["capital_flow_5m"] = _numeric_or_default(merged, "capital_flow_5m", total_net.fillna(0.0))
    merged["capital_flow_slope_15m"] = _numeric_or_default(merged, "capital_flow_slope_15m", 0.0)
    merged["depth_imbalance"] = _numeric_or_default(merged, "depth_imbalance", 0.0)
    merged["bid_ask_volume_ratio"] = _numeric_or_default(merged, "bid_ask_volume_ratio", 1.0)
    merged["trade_buy_ratio_5m"] = _numeric_or_default(merged, "trade_buy_ratio_5m", 0.5)
    merged["trade_volume_5m"] = _numeric_or_default(merged, "trade_volume_5m", 0.0)
    merged["intraday_position"] = _numeric_or_default(merged, "intraday_position", ((last - low) / (high - low).replace(0, np.nan)).fillna(0.5))
    merged["price_to_avg_15m"] = _numeric_or_default(merged, "price_to_avg_15m", 0.0)
    merged["down_momentum_5m"] = _numeric_or_default(merged, "down_momentum_5m", (-merged["return_5m"]).clip(lower=0))
    merged["down_momentum_15m"] = _numeric_or_default(merged, "down_momentum_15m", (-merged["return_15m"]).clip(lower=0))
    merged["near_day_low"] = _numeric_or_default(merged, "near_day_low", (1.0 - merged["intraday_position"]).clip(lower=0, upper=1))
    merged["short_selling_ratio"] = _numeric_or_default(merged, "short_selling_ratio", 0.0)
    merged["short_rate"] = _numeric_or_default(merged, "short_rate", 0.0)
    merged["short_balance_ratio"] = _numeric_or_default(merged, "short_balance_ratio", 0.0)
    merged["days_to_cover"] = _numeric_or_default(merged, "days_to_cover", 0.0)
    merged["negative_sentiment_score"] = _numeric_or_default(merged, "negative_sentiment_score", 0.0)
    merged["bearish_event_strength"] = _numeric_or_default(merged, "bearish_event_strength", 0.0)
    merged["future_max_return"] = pd.to_numeric(merged["future_high"], errors="coerce") / last - 1
    merged["future_max_drawdown"] = pd.to_numeric(merged["future_low"], errors="coerce") / last - 1
    merged["future_return"] = pd.to_numeric(merged["future_price"], errors="coerce") / last - 1
    if normalize_target_direction(target_direction) == "short":
        merged["target_profit"] = (merged["future_max_drawdown"] <= -target_return).astype("int64")
    else:
        merged["target_profit"] = (merged["future_max_return"] >= target_return).astype("int64")
    return _coerce_feature_frame(merged)


def _fetch_training_features_postgres_disabled(
    conn: Any,
    market: str,
    lookback_days: int,
    horizon_minutes: int,
    target_return: float,
    max_rows: int,
) -> pd.DataFrame:
    query = _feature_sql(include_target=True, horizon_minutes=horizon_minutes)
    frame = pd.read_sql(
        query,
        conn,
        params={
            "market": market.lower(),
            "lookback_days": lookback_days,
            "horizon_minutes": horizon_minutes,
            "target_return": target_return,
            "max_rows": max_rows,
        },
    )
    return _coerce_feature_frame(frame)


def fetch_current_features(conn: Any, market: str, limit: int, symbols: Sequence[str] | None = None) -> pd.DataFrame:
    return fetch_current_window_features_from_clickhouse(
        market=market,
        limit=limit,
        max_quote_age_minutes=_current_feature_max_quote_age_minutes(market),
        symbols=symbols,
    )


def _prediction_feature_limit(market: str, profile: str | None, requested_limit: int) -> int:
    if market.lower() in {"hk", "cn"} and (profile or "") == "top3_fast":
        raw = os.getenv("TOP3_FAST_FEATURE_LIMIT", "300")
        try:
            return max(int(requested_limit), int(raw))
        except ValueError:
            return max(int(requested_limit), 300)
    return int(requested_limit)


def _prediction_candidate_symbols(market: str, profile: str | None, limit: int) -> list[str] | None:
    if market.lower() not in {"hk", "cn"} or (profile or "") != "top3_fast":
        return None
    if os.getenv("REALTIME_PROFIT_DISABLE_CANDIDATE_PREFILTER", "").strip().lower() in {"1", "true", "yes"}:
        return None
    return _current_feature_symbols_from_clickhouse(
        market,
        limit,
        max_quote_age_minutes=_current_feature_max_quote_age_minutes(market),
    )


def _current_feature_max_quote_age_minutes(market: str) -> int:
    raw = os.getenv("REALTIME_PROFIT_MAX_QUOTE_AGE_MINUTES")
    if raw:
        try:
            return max(1, int(raw))
        except ValueError:
            pass
    return 90 if market.lower() == "hk" else 30


def _current_feature_scan_minutes(max_quote_age_minutes: int) -> int:
    return max(60, int(max_quote_age_minutes) + 45)


def _apply_symbol_names(conn: Any, frame: pd.DataFrame) -> pd.DataFrame:
    if frame.empty or "symbol" not in frame.columns:
        return frame
    symbols = sorted({str(symbol) for symbol in frame["symbol"].dropna().tolist() if str(symbol)})
    if not symbols:
        return frame
    try:
        rows = conn.execute(
            """
            select symbol, name
            from lb_symbols
            where symbol = any(%s)
              and nullif(trim(name), '') is not null
            """,
            (symbols,),
        ).fetchall()
    except Exception:
        return frame
    names = {str(symbol): str(name) for symbol, name in rows}
    if not names:
        return frame
    enriched = frame.copy()
    enriched["name"] = enriched.apply(
        lambda row: names.get(str(row.get("symbol"))) if not str(row.get("name") or "").strip() or str(row.get("name")).upper() == str(row.get("symbol")).upper() else row.get("name"),
        axis=1,
    )
    return enriched


def _filter_us_fast_stock_features(frame: pd.DataFrame) -> pd.DataFrame:
    if frame.empty or "symbol" not in frame.columns:
        return frame
    names = frame["name"] if "name" in frame.columns else frame["symbol"]
    text = (frame["symbol"].astype(str) + " " + names.astype(str)).str.upper()
    excluded = text.str.contains(
        r"DIREXION|PROSHARES ULTRA|ULTRAPRO|2X|3X|BULL 2X|BULL 3X|BEAR 2X|BEAR 3X|LEVERAGED|INVERSE",
        regex=True,
        na=False,
    )
    return frame.loc[~excluded].copy()


def fetch_current_window_features_from_clickhouse(
    *,
    market: str,
    limit: int,
    max_quote_age_minutes: int = 30,
    symbols: Sequence[str] | None = None,
) -> pd.DataFrame:
    database = clickhouse_realtime._ident(clickhouse_realtime._database())
    market_key = market.lower().replace("'", "")
    filter_sql = _us_fast_candidate_filter_sql("w") if market_key == "us" else "1 = 1"
    symbol_list = [str(symbol).strip().upper() for symbol in (symbols or []) if str(symbol).strip()]
    symbol_filter = f"and q.symbol in {clickhouse_realtime._symbol_tuple(symbol_list)}" if symbol_list else ""
    scan_minutes = _current_feature_scan_minutes(max_quote_age_minutes)
    rows = clickhouse_realtime._query_json_each_row(
        f"""
        with quote_dedup as (
          select symbol,
                 market,
                 snapshot_minute,
                 argMax(last_done, inserted_at) as last_done,
                 argMax(prev_close, inserted_at) as prev_close,
                 argMax(open, inserted_at) as open,
                 argMax(high, inserted_at) as high,
                 argMax(low, inserted_at) as low,
                 argMax(change_percentage, inserted_at) as change_percentage,
                 argMax(volume, inserted_at) as volume,
                 argMax(turnover, inserted_at) as turnover
          from {database}.lb_realtime_quotes q
          where q.market = '{market_key}'
            and q.snapshot_minute >= now() - interval {scan_minutes} minute
            and q.last_done > 0
            {symbol_filter}
          group by symbol, market, snapshot_minute
        ),
        latest_quote as (
          select *
          from (
            select *,
                   row_number() over (partition by symbol order by snapshot_minute desc) as latest_rank
            from quote_dedup
            where snapshot_minute >= now() - interval {int(max_quote_age_minutes)} minute
          )
          where latest_rank = 1
          order by turnover desc
          limit {int(limit)}
        ),
        recent as (
          select q.*
          from quote_dedup q
          inner join latest_quote l on l.symbol = q.symbol
          where q.snapshot_minute <= l.snapshot_minute
            and q.snapshot_minute >= l.snapshot_minute - interval 30 minute
        ),
        delta_windowed as (
          select r.*,
                 lagInFrame(last_done, 1) over w as prev_1,
                 lagInFrame(last_done, 5) over w as prev_5,
                 lagInFrame(last_done, 15) over w as prev_15,
                 coalesce(last_done / nullIf(lagInFrame(last_done, 1) over w, 0) - 1, 0) as return_1m,
                 coalesce(last_done / nullIf(lagInFrame(last_done, 5) over w, 0) - 1, 0) as return_5m,
                 coalesce(last_done / nullIf(lagInFrame(last_done, 15) over w, 0) - 1, 0) as return_15m,
                 stddevPop(last_done / nullIf(prev_close, 0) - 1)
                   over (partition by symbol order by snapshot_minute rows between 5 preceding and current row) as volatility_5m,
                 stddevPop(last_done / nullIf(prev_close, 0) - 1)
                   over (partition by symbol order by snapshot_minute rows between 15 preceding and current row) as volatility_15m,
                 avg(last_done) over (partition by symbol order by snapshot_minute rows between 15 preceding and current row) as avg_price_15m,
                 greatest(volume - coalesce(lagInFrame(volume, 1) over w, volume), 0) as minute_volume,
                 greatest(turnover - coalesce(lagInFrame(turnover, 1) over w, turnover), 0) as minute_turnover
          from recent r
          window w as (partition by symbol order by snapshot_minute rows between 15 preceding and current row)
        ),
        windowed as (
          select d.*,
                 coalesce(minute_volume / nullIf(avg(minute_volume) over (partition by symbol order by snapshot_minute rows between 5 preceding and current row), 0), 1) as volume_ratio_5m,
                 coalesce(minute_turnover / nullIf(avg(minute_turnover) over (partition by symbol order by snapshot_minute rows between 5 preceding and current row), 0), 1) as turnover_ratio_5m
          from delta_windowed d
        ),
        latest_capital as (
          select *
          from (
            select symbol,
                   snapshot_minute as capital_minute,
                   large_net,
                   small_net,
                   total_net,
                   total_in,
                   total_out,
                   large_net_ratio,
                   small_net_ratio,
                   row_number() over (partition by symbol order by snapshot_minute desc, inserted_at desc) as capital_rank
            from {database}.lb_realtime_capital
            where market = '{market_key}'
              and snapshot_minute >= now() - interval {scan_minutes} minute
          )
          where capital_rank = 1
        ),
        flow as (
          select symbol,
                 sumIf(inflow, flow_time >= now() - interval 5 minute) as flow_5m,
                 sumIf(inflow, flow_time >= now() - interval 15 minute) as flow_15m,
                 sumIf(inflow, flow_time >= now() - interval 30 minute) as flow_30m
          from {database}.lb_realtime_capital_flow
          where flow_time >= now() - interval 45 minute
          group by symbol
        ),
        latest_hk_short as (
          select symbol,
                 argMax(short_selling_ratio, trade_date) as short_selling_ratio
          from {database}.lb_hk_short_selling_turnover final
          where trade_date >= today() - interval 10 day
          group by symbol
        ),
        latest_stock_short as (
          select symbol,
                 argMax(rate, trade_date) as short_rate,
                 argMax(balance / nullIf(close * greatest(total_amount, 1), 0), trade_date) as short_balance_ratio
          from {database}.lb_stock_short_trades final
          where trade_date >= today() - interval 30 day
          group by symbol
        ),
        latest_us_short as (
          select symbol,
                 argMax(short_interest_ratio, report_date) as short_interest_ratio,
                 argMax(days_to_cover, report_date) as days_to_cover
          from {database}.lb_us_short_positions final
          where report_date >= today() - interval 45 day
          group by symbol
        ),
        latest_sentiment as (
          select source_symbol as symbol,
                 maxIf(greatest(-nlp_sentiment_score, 0), impact_direction in ('bearish', 'uncertain', 'neutral') or nlp_sentiment_score < 0) as negative_sentiment_score,
                 maxIf(impact_strength_pct, impact_direction = 'bearish') as bearish_event_strength
          from {database}.lb_sentiment_impact_events final
          where analysis_date >= today() - interval 14 day
          group by source_symbol
        )
        select w.symbol as symbol,
               w.market as market,
               w.symbol as name,
               w.snapshot_minute as snapshot_minute,
               w.last_done as last_done,
               w.prev_close as prev_close,
               coalesce(w.change_percentage, if(w.prev_close > 0, (w.last_done / w.prev_close - 1) * 100, 0)) as change_percentage,
               coalesce(w.volume, 0) as volume,
               coalesce(w.turnover, 0) as turnover,
               w.return_1m,
               w.return_5m,
               w.return_15m,
               coalesce(w.volatility_5m, 0) as volatility_5m,
               coalesce(w.volatility_15m, 0) as volatility_15m,
               w.volume_ratio_5m,
               w.turnover_ratio_5m,
               coalesce(c.large_net_ratio, c.large_net / nullIf(abs(w.turnover), 0), 0) as large_net_ratio,
               coalesce(c.small_net_ratio, c.small_net / nullIf(abs(w.turnover), 0), 0) as small_net_ratio,
               coalesce(c.total_net / nullIf(c.total_in + c.total_out, 0), c.total_net / nullIf(abs(w.turnover), 0), 0) as total_net_ratio,
               coalesce(f.flow_5m, f.flow_15m, 0) as capital_flow_5m,
               coalesce(f.flow_15m - f.flow_30m / 2, 0) as capital_flow_slope_15m,
               0 as depth_imbalance,
               1 as bid_ask_volume_ratio,
               0.5 as trade_buy_ratio_5m,
               0 as trade_volume_5m,
               coalesce((w.last_done - w.low) / nullIf(w.high - w.low, 0), 0.5) as intraday_position,
               coalesce(w.last_done / nullIf(w.avg_price_15m, 0) - 1, 0) as price_to_avg_15m,
               greatest(-w.return_5m, 0) as down_momentum_5m,
               greatest(-w.return_15m, 0) as down_momentum_15m,
               coalesce(1 - (w.last_done - w.low) / nullIf(w.high - w.low, 0), 0.5) as near_day_low,
               coalesce(hks.short_selling_ratio, 0) as short_selling_ratio,
               coalesce(sts.short_rate, uss.short_interest_ratio, 0) as short_rate,
               coalesce(sts.short_balance_ratio, 0) as short_balance_ratio,
               coalesce(uss.days_to_cover, 0) as days_to_cover,
               coalesce(sent.negative_sentiment_score, 0) as negative_sentiment_score,
               coalesce(sent.bearish_event_strength, 0) as bearish_event_strength
        from windowed w
        inner join latest_quote l on l.symbol = w.symbol and l.snapshot_minute = w.snapshot_minute
        left join latest_capital c on c.symbol = w.symbol
        left join flow f on f.symbol = w.symbol
        left join latest_hk_short hks on hks.symbol = w.symbol
        left join latest_stock_short sts on sts.symbol = w.symbol
        left join latest_us_short uss on uss.symbol = w.symbol
        left join latest_sentiment sent on sent.symbol = w.symbol
        where {filter_sql}
        order by (
          greatest(coalesce(w.change_percentage, 0), 0) * 2
          + greatest(coalesce(w.return_15m, 0), 0) * 150
          + greatest(coalesce(w.return_5m, 0), 0) * 100
          + coalesce(w.volatility_15m, 0) * 100
          + if(coalesce(w.return_5m, 0) >= 0, greatest(coalesce(w.volume_ratio_5m, 1) - 1, 0), 0)
          + if(coalesce(w.return_5m, 0) >= 0, greatest(coalesce(w.turnover_ratio_5m, 1) - 1, 0), 0)
          + log10(greatest(w.turnover, 1)) / 10
          - greatest(-coalesce(w.change_percentage, 0), 0) * 2
          - greatest(-coalesce(w.return_15m, 0), 0) * 100
        ) desc,
        w.turnover desc
        """
    )
    return _coerce_feature_frame(pd.DataFrame(rows))


def _us_fast_candidate_filter_sql(alias: str) -> str:
    excluded = ", ".join(f"'{symbol}'" for symbol in US_FAST_EXCLUDED_SYMBOLS)
    return f"""
          {alias}.symbol not in ({excluded})
          and {alias}.last_done between 2 and 1200
          and {alias}.turnover >= 10000000
          and {alias}.change_percentage >= -2
          and {alias}.change_percentage < 12
          and {alias}.return_15m >= -0.003
          and (
            {alias}.change_percentage >= 0.5
            or {alias}.return_15m >= 0.004
            or {alias}.return_5m >= 0.003
            or ({alias}.volatility_15m >= 0.002 and {alias}.return_5m >= 0)
            or ({alias}.volume_ratio_5m >= 1.8 and {alias}.return_5m >= 0)
            or ({alias}.turnover_ratio_5m >= 1.8 and {alias}.return_5m >= 0)
          )
    """


def _current_feature_symbols_from_clickhouse(market: str, limit: int, *, max_quote_age_minutes: int | None = None) -> list[str]:
    database = clickhouse_realtime._database()
    scan_minutes = max(60, int(max_quote_age_minutes or _current_feature_max_quote_age_minutes(market)))
    rows = clickhouse_realtime._query_json_each_row(
        f"""
        select symbol
        from (
          select symbol, turnover
          from {database}.lb_realtime_quotes
          where market = '{market.replace("'", "")}'
            and snapshot_minute >= now() - interval {scan_minutes} minute
            and last_done > 0
          order by symbol, snapshot_minute desc, inserted_at desc
          limit 1 by symbol
        )
        order by turnover desc
        limit {int(limit)}
        """
    )
    return [str(row.get("symbol") or "").upper() for row in rows if row.get("symbol")]


def _average(values: Iterable[Any]) -> float | None:
    clean = []
    for value in values:
        try:
            if value is None or pd.isna(value):
                continue
            clean.append(float(value))
        except (TypeError, ValueError):
            continue
    if not clean:
        return None
    return sum(clean) / len(clean)


def _float(value: Any) -> float:
    if value is None or value == "":
        return 0.0
    try:
        return float(value)
    except (TypeError, ValueError):
        return 0.0


def _optional_float(value: Any) -> float | None:
    if value is None or value == "":
        return None
    try:
        if pd.isna(value):
            return None
        return float(value)
    except (TypeError, ValueError):
        return None


def _numeric_or_default(frame: pd.DataFrame, column: str, default: Any) -> pd.Series:
    if column in frame.columns:
        values = pd.to_numeric(frame[column], errors="coerce")
    else:
        values = pd.Series(np.nan, index=frame.index)
    if isinstance(default, pd.Series):
        fallback = default.reindex(frame.index)
    else:
        fallback = pd.Series(default, index=frame.index)
    return values.fillna(fallback)


def _feature_sql(include_target: bool, horizon_minutes: int = DEFAULT_HORIZON_MINUTES) -> str:
    if include_target:
        horizon_rows = max(1, min(int(horizon_minutes), 240))
        return """
          with recent as (
            select q.symbol, q.market, q.snapshot_minute, q.last_done, q.prev_close,
                   q.change_percentage, q.volume, q.turnover
            from (
              select symbol
              from lb_symbols
              where market = %(market)s
              order by symbol
            ) s
            join lateral (
              select q.symbol, q.market, q.snapshot_minute, q.last_done, q.prev_close,
                     q.change_percentage, q.volume, q.turnover
              from lb_realtime_quotes q
              where q.symbol = s.symbol
                and q.market = %(market)s
                and q.snapshot_minute >= now() - (%(lookback_days)s || ' days')::interval
                and q.snapshot_minute < now() - (%(horizon_minutes)s || ' minutes')::interval
                and q.last_done is not null
              order by q.snapshot_minute desc, q.updated_at desc
              limit least(greatest(%(horizon_minutes)s::int * 3, 120), 360)
            ) q on true
          ),
          windowed as (
            select r.*,
                   lag(last_done, 1) over w as prev_1,
                   lag(last_done, 5) over w as prev_5,
                   lag(last_done, 15) over w as prev_15,
                   lag(volume, 5) over w as volume_5,
                   lag(turnover, 5) over w as turnover_5,
                   stddev_pop(last_done / nullif(prev_close, 0) - 1)
                     over (partition by symbol order by snapshot_minute rows between 5 preceding and current row) as volatility_5m,
                   stddev_pop(last_done / nullif(prev_close, 0) - 1)
                     over (partition by symbol order by snapshot_minute rows between 15 preceding and current row) as volatility_15m,
                   max(last_done) over (partition by symbol order by snapshot_minute rows between 1 following and {horizon_rows} following) as future_high,
                   min(last_done) over (partition by symbol order by snapshot_minute rows between 1 following and {horizon_rows} following) as future_low,
                   min(last_done) over (partition by symbol, date_trunc('day', snapshot_minute)) as day_low,
                   max(last_done) over (partition by symbol, date_trunc('day', snapshot_minute)) as day_high,
                   avg(last_done) over (partition by symbol order by snapshot_minute rows between 15 preceding and current row) as avg_price_15m
            from recent r
            window w as (partition by symbol order by snapshot_minute)
          )
          select w.symbol, w.market, coalesce(sym.name, w.symbol) as name,
                 w.snapshot_minute, w.last_done, w.prev_close,
                 coalesce(w.change_percentage, 0) as change_percentage,
                 coalesce(w.last_done / nullif(w.prev_1, 0) - 1, 0) as return_1m,
                 coalesce(w.last_done / nullif(w.prev_5, 0) - 1, 0) as return_5m,
                 coalesce(w.last_done / nullif(w.prev_15, 0) - 1, 0) as return_15m,
                 coalesce(w.volatility_5m, 0) as volatility_5m,
                 coalesce(w.volatility_15m, 0) as volatility_15m,
                 coalesce(w.volume / nullif(w.volume_5, 0), 1) as volume_ratio_5m,
                 coalesce(w.turnover / nullif(w.turnover_5, 0), 1) as turnover_ratio_5m,
                 0::numeric as large_net_ratio,
                 0::numeric as small_net_ratio,
                 0::numeric as total_net_ratio,
                 0::numeric as capital_flow_5m,
                 0::numeric as capital_flow_slope_15m,
                 0::numeric as depth_imbalance,
                 1::numeric as bid_ask_volume_ratio,
                 0.5::numeric as trade_buy_ratio_5m,
                 0::numeric as trade_volume_5m,
                 coalesce((w.last_done - w.day_low) / nullif(w.day_high - w.day_low, 0), 0.5) as intraday_position,
                 coalesce(w.last_done / nullif(w.avg_price_15m, 0) - 1, 0) as price_to_avg_15m,
                 w.future_high / nullif(w.last_done, 0) - 1 as future_max_return,
                 w.future_low / nullif(w.last_done, 0) - 1 as future_max_drawdown,
                 future.future_price / nullif(w.last_done, 0) - 1 as future_return,
                 case when w.future_high / nullif(w.last_done, 0) - 1 >= %(target_return)s then 1 else 0 end as target_profit
          from windowed w
          left join lb_symbols sym on sym.symbol = w.symbol
          join lateral (
            select ranked.last_done as future_price
            from (
              select q2.last_done,
                     row_number() over (order by q2.snapshot_minute asc, q2.updated_at desc) as rn
              from lb_realtime_quotes q2
              where q2.symbol = w.symbol
                and q2.market = w.market
                and q2.snapshot_minute > w.snapshot_minute
                and q2.snapshot_minute <= w.snapshot_minute + interval '2 days'
                and q2.last_done is not null
                and (
                  (extract(hour from q2.snapshot_minute at time zone 'Asia/Shanghai') * 60
                   + extract(minute from q2.snapshot_minute at time zone 'Asia/Shanghai') >= 570
                   and extract(hour from q2.snapshot_minute at time zone 'Asia/Shanghai') * 60
                   + extract(minute from q2.snapshot_minute at time zone 'Asia/Shanghai') < 720)
                  or
                  (extract(hour from q2.snapshot_minute at time zone 'Asia/Shanghai') * 60
                   + extract(minute from q2.snapshot_minute at time zone 'Asia/Shanghai') >= 780
                   and extract(hour from q2.snapshot_minute at time zone 'Asia/Shanghai') * 60
                   + extract(minute from q2.snapshot_minute at time zone 'Asia/Shanghai') <= 960)
                )
            ) ranked
            where ranked.rn = %(horizon_minutes)s::int
            limit 1
          ) future on true
          where w.future_high is not null
        """.format(horizon_rows=horizon_rows)
    else:
        base = """
          select q.*
          from (
            select symbol
            from lb_symbols
            where market = %(market)s
            order by symbol
            limit %(limit)s
          ) s
          join lateral (
            select q.*
            from lb_realtime_quotes q
            where q.symbol = s.symbol
              and q.market = %(market)s
              and q.last_done is not null
            order by q.snapshot_minute desc, q.updated_at desc
            limit 1
          ) q on true
        """
        target_select = ", null::numeric as future_max_return, null::numeric as future_max_drawdown, null::numeric as future_return, null::int as target_profit"
        target_join = ""
    return f"""
      with base as ({base})
      select b.symbol, b.market, coalesce(sym.name, b.symbol) as name,
             b.snapshot_minute, b.last_done, b.prev_close, b.change_percentage, b.volume, b.turnover,
             coalesce(b.last_done / nullif(prev1.last_done, 0) - 1, 0) as return_1m,
             coalesce(b.last_done / nullif(prev5.last_done, 0) - 1, 0) as return_5m,
             coalesce(b.last_done / nullif(prev15.last_done, 0) - 1, 0) as return_15m,
             coalesce(vol5.volatility_5m, 0) as volatility_5m,
             coalesce(vol15.volatility_15m, 0) as volatility_15m,
             coalesce(b.volume / nullif(prev5.volume, 0), 1) as volume_ratio_5m,
             coalesce(b.turnover / nullif(prev5.turnover, 0), 1) as turnover_ratio_5m,
             coalesce(cap.large_net_ratio, 0) as large_net_ratio,
             coalesce(cap.small_net_ratio, 0) as small_net_ratio,
             coalesce(cap.total_net / nullif(cap.total_in + cap.total_out, 0), 0) as total_net_ratio,
             coalesce(flow.flow_5m, 0) as capital_flow_5m,
             coalesce(flow.flow_slope_15m, 0) as capital_flow_slope_15m,
             coalesce(depth.imbalance, 0) as depth_imbalance,
             coalesce(depth.bid_volume / nullif(depth.ask_volume, 0), 1) as bid_ask_volume_ratio,
             coalesce(trades.buy_ratio_5m, 0.5) as trade_buy_ratio_5m,
             coalesce(trades.trade_volume_5m, 0) as trade_volume_5m,
             coalesce((b.last_done - daypos.day_low) / nullif(daypos.day_high - daypos.day_low, 0), 0.5) as intraday_position,
             coalesce(b.last_done / nullif(avg15.avg_price_15m, 0) - 1, 0) as price_to_avg_15m
             {target_select}
      from base b
      left join lb_symbols sym on sym.symbol = b.symbol
      left join lateral (
        select last_done from lb_realtime_quotes q
        where q.symbol = b.symbol and q.snapshot_minute <= b.snapshot_minute - interval '1 minute'
        order by q.snapshot_minute desc limit 1
      ) prev1 on true
      left join lateral (
        select last_done, volume, turnover from lb_realtime_quotes q
        where q.symbol = b.symbol and q.snapshot_minute <= b.snapshot_minute - interval '5 minutes'
        order by q.snapshot_minute desc limit 1
      ) prev5 on true
      left join lateral (
        select last_done from lb_realtime_quotes q
        where q.symbol = b.symbol and q.snapshot_minute <= b.snapshot_minute - interval '15 minutes'
        order by q.snapshot_minute desc limit 1
      ) prev15 on true
      left join lateral (
        select stddev_pop(last_done / nullif(prev_close, 0) - 1) as volatility_5m
        from lb_realtime_quotes q
        where q.symbol = b.symbol and q.snapshot_minute between b.snapshot_minute - interval '5 minutes' and b.snapshot_minute
      ) vol5 on true
      left join lateral (
        select stddev_pop(last_done / nullif(prev_close, 0) - 1) as volatility_15m
        from lb_realtime_quotes q
        where q.symbol = b.symbol and q.snapshot_minute between b.snapshot_minute - interval '15 minutes' and b.snapshot_minute
      ) vol15 on true
      left join lateral (
        select large_net_ratio, small_net_ratio, total_net, total_in, total_out
        from lb_realtime_capital c
        where c.symbol = b.symbol and c.snapshot_minute <= b.snapshot_minute
        order by c.snapshot_minute desc limit 1
      ) cap on true
      left join lateral (
        select sum(inflow) filter (where flow_time >= b.snapshot_minute - interval '5 minutes') as flow_5m,
               regr_slope(inflow::numeric, extract(epoch from flow_time)::numeric) as flow_slope_15m
        from lb_realtime_capital_flow f
        where f.symbol = b.symbol and f.flow_time between b.snapshot_minute - interval '15 minutes' and b.snapshot_minute
      ) flow on true
      left join lateral (
        select imbalance, bid_volume, ask_volume
        from lb_realtime_depth d
        where d.symbol = b.symbol and d.snapshot_minute <= b.snapshot_minute
        order by d.snapshot_minute desc limit 1
      ) depth on true
      left join lateral (
        select avg(case when direction = 'buy' then 1.0 when direction = 'sell' then 0.0 else 0.5 end) as buy_ratio_5m,
               sum(volume) as trade_volume_5m
        from lb_realtime_trades t
        where t.symbol = b.symbol and t.trade_time between b.snapshot_minute - interval '5 minutes' and b.snapshot_minute
      ) trades on true
      left join lateral (
        select min(price) as day_low, max(price) as day_high
        from lb_intraday_lines l
        where l.symbol = b.symbol
          and l.line_time >= date_trunc('day', b.snapshot_minute)
          and l.line_time <= b.snapshot_minute
      ) daypos on true
      left join lateral (
        select avg(price) as avg_price_15m
        from lb_intraday_lines l
        where l.symbol = b.symbol and l.line_time between b.snapshot_minute - interval '15 minutes' and b.snapshot_minute
      ) avg15 on true
      {target_join}
    """


def _coerce_feature_frame(frame: pd.DataFrame) -> pd.DataFrame:
    if frame.empty:
        return frame
    for name in FEATURE_NAMES + ["future_max_return", "future_max_drawdown", "future_return", "target_profit"]:
        if name in frame.columns:
            frame[name] = pd.to_numeric(frame[name], errors="coerce")
    frame[FEATURE_NAMES] = frame.reindex(columns=FEATURE_NAMES).fillna(0)
    return frame


def _train_classifier(
    train: pd.DataFrame,
    validation: pd.DataFrame,
    market: str,
    horizon_minutes: int,
    target_return: float,
) -> tuple[RealtimeProfitModel, dict[str, Any]]:
    candidates: list[tuple[RealtimeProfitModel, dict[str, Any]]] = []
    errors: dict[str, str] = {}
    for model_type, estimator in _candidate_estimators():
        try:
            estimator.fit(train[FEATURE_NAMES].fillna(0), train["target_profit"].astype(int))
            model = RealtimeProfitModel(
                model_type=model_type,
                estimator=estimator,
                feature_names=list(FEATURE_NAMES),
                horizon_minutes=horizon_minutes,
                target_return=target_return,
                market=market,
            )
            probabilities = model.predict_proba(validation) if not validation.empty else np.asarray([])
            metrics = evaluate_probabilities(validation.get("target_profit", pd.Series(dtype=float)), probabilities)
            metrics["model_type"] = model_type
            candidates.append((model, metrics))
        except Exception as exc:
            errors[model_type] = f"{type(exc).__name__}: {exc}"
    if not candidates:
        raise RuntimeError(f"all realtime profit model candidates failed: {errors}")
    candidates.sort(key=lambda item: _model_rank_key(item[1]), reverse=True)
    best_model, best_metrics = candidates[0]
    best_metrics = dict(best_metrics)
    best_metrics["selected_model_type"] = best_model.model_type
    best_metrics["candidate_metrics"] = [metrics for _, metrics in candidates]
    if errors:
        best_metrics["candidate_errors"] = errors
    return best_model, best_metrics


def _train_return_regressor(train: pd.DataFrame, validation: pd.DataFrame) -> tuple[Any | None, dict[str, Any]]:
    train_data = train[train["future_return"].notna()].copy() if "future_return" in train else pd.DataFrame()
    validation_data = validation[validation["future_return"].notna()].copy() if "future_return" in validation else pd.DataFrame()
    if len(train_data) < 100:
        return None, {"samples": int(len(train_data)), "skipped": "not_enough_future_return_samples"}
    candidates: list[tuple[str, Any, dict[str, Any]]] = []
    errors: dict[str, str] = {}
    for model_type, estimator in _candidate_regressors():
        try:
            estimator.fit(train_data[FEATURE_NAMES].fillna(0), train_data["future_return"].clip(-0.12, 0.12))
            predictions = np.asarray(estimator.predict(validation_data[FEATURE_NAMES].fillna(0)), dtype="float64") if not validation_data.empty else np.asarray([])
            metrics = evaluate_return_predictions(validation_data.get("future_return", pd.Series(dtype=float)), predictions)
            metrics["model_type"] = model_type
            candidates.append((model_type, estimator, metrics))
        except Exception as exc:
            errors[model_type] = f"{type(exc).__name__}: {exc}"
    if not candidates:
        return None, {"samples": int(len(train_data)), "candidate_errors": errors}
    candidates.sort(key=lambda item: _regression_rank_key(item[2]))
    best_type, best_estimator, best_metrics = candidates[0]
    best_metrics = dict(best_metrics)
    best_metrics["selected_model_type"] = best_type
    best_metrics["candidate_metrics"] = [metrics for _, _, metrics in candidates]
    if errors:
        best_metrics["candidate_errors"] = errors
    return best_estimator, best_metrics


def _candidate_regressors() -> list[tuple[str, Any]]:
    from sklearn.ensemble import HistGradientBoostingRegressor, RandomForestRegressor

    candidates: list[tuple[str, Any]] = [
        (
            "sklearn_random_forest_regressor",
            RandomForestRegressor(n_estimators=80, max_depth=8, min_samples_leaf=30, n_jobs=4, random_state=42),
        ),
        (
            "sklearn_hist_gradient_boosting_regressor",
            HistGradientBoostingRegressor(max_iter=80, learning_rate=0.055, max_leaf_nodes=20, l2_regularization=0.05, random_state=42),
        ),
    ]
    if os.getenv("REALTIME_PROFIT_DISABLE_XGBOOST", "").strip().lower() in {"1", "true", "yes"}:
        return candidates
    try:
        from xgboost import XGBRegressor

        candidates.append(
            (
                "xgboost_regressor",
                XGBRegressor(
                    n_estimators=90,
                    max_depth=4,
                    learning_rate=0.055,
                    subsample=0.85,
                    colsample_bytree=0.85,
                    min_child_weight=8,
                    objective="reg:squarederror",
                    n_jobs=4,
                    random_state=42,
                ),
            )
        )
    except Exception:
        pass
    return candidates


def _candidate_estimators() -> list[tuple[str, Any]]:
    from sklearn.ensemble import HistGradientBoostingClassifier, RandomForestClassifier

    candidates: list[tuple[str, Any]] = [
        (
            "sklearn_random_forest",
            RandomForestClassifier(
                n_estimators=80,
                max_depth=8,
                min_samples_leaf=30,
                n_jobs=4,
                class_weight="balanced_subsample",
                random_state=42,
            ),
        ),
        (
            "sklearn_hist_gradient_boosting",
            HistGradientBoostingClassifier(max_iter=80, learning_rate=0.06, max_leaf_nodes=20, l2_regularization=0.05, random_state=42),
        ),
    ]
    if os.getenv("REALTIME_PROFIT_DISABLE_XGBOOST", "").strip().lower() in {"1", "true", "yes"}:
        return candidates
    try:
        from xgboost import XGBClassifier

        candidates.append(
            (
                "xgboost",
                XGBClassifier(
                    n_estimators=90,
                    max_depth=4,
                    learning_rate=0.055,
                    subsample=0.85,
                    colsample_bytree=0.85,
                    min_child_weight=8,
                    eval_metric="logloss",
                    objective="binary:logistic",
                    n_jobs=4,
                    random_state=42,
                ),
            )
        )
    except Exception:
        pass
    return candidates


def evaluate_probabilities(target: Iterable[Any], probabilities: Sequence[float]) -> dict[str, Any]:
    target_array = np.asarray(list(target), dtype="float64")
    probability_array = np.asarray(probabilities, dtype="float64")
    if len(target_array) == 0:
        return {"samples": 0}
    metrics: dict[str, Any] = {
        "samples": int(len(target_array)),
        "base_rate": float(np.nanmean(target_array)),
        "avg_probability": float(np.nanmean(probability_array)) if len(probability_array) else None,
    }
    try:
        from sklearn.metrics import average_precision_score, roc_auc_score

        if len(set(target_array.astype(int))) > 1 and len(probability_array):
            metrics["roc_auc"] = float(roc_auc_score(target_array, probability_array))
            metrics["average_precision"] = float(average_precision_score(target_array, probability_array))
    except Exception:
        pass
    if len(probability_array):
        for size in (10, 20, 50):
            if len(target_array) >= size:
                indexes = np.argsort(probability_array)[-size:]
                metrics[f"top{size}_hit_rate"] = float(np.nanmean(target_array[indexes]))
                metrics[f"top{size}_avg_probability"] = float(np.nanmean(probability_array[indexes]))
    return metrics


def evaluate_return_predictions(target: Iterable[Any], predictions: Sequence[float]) -> dict[str, Any]:
    target_array = np.asarray(list(target), dtype="float64")
    prediction_array = np.asarray(predictions, dtype="float64")
    mask = np.isfinite(target_array)
    if len(prediction_array) == len(target_array):
        mask = mask & np.isfinite(prediction_array)
    if not mask.any():
        return {"samples": 0}
    y_true = target_array[mask]
    y_pred = prediction_array[mask]
    error = y_pred - y_true
    metrics: dict[str, Any] = {
        "samples": int(len(y_true)),
        "mae": float(np.mean(np.abs(error))),
        "rmse": float(np.sqrt(np.mean(error * error))),
        "avg_actual_return": float(np.mean(y_true)),
        "avg_predicted_return": float(np.mean(y_pred)),
        "direction_accuracy": float(np.mean((y_true >= 0) == (y_pred >= 0))),
    }
    if len(y_true) > 1:
        correlation = float(np.corrcoef(y_true, y_pred)[0, 1])
        metrics["correlation"] = correlation if math.isfinite(correlation) else None
    return metrics


def _json_safe(value: Any) -> Any:
    if isinstance(value, dict):
        return {key: _json_safe(item) for key, item in value.items()}
    if isinstance(value, list):
        return [_json_safe(item) for item in value]
    if isinstance(value, tuple):
        return [_json_safe(item) for item in value]
    if isinstance(value, float) and not math.isfinite(value):
        return None
    return value


def _model_rank_key(metrics: dict[str, Any]) -> tuple[float, ...]:
    return (
        float(metrics.get("top10_hit_rate") or 0),
        float(metrics.get("top20_hit_rate") or 0),
        float(metrics.get("average_precision") or 0),
        float(metrics.get("top50_hit_rate") or 0),
        float(metrics.get("roc_auc") or 0),
        float(metrics.get("top20_avg_probability") or 0),
    )


def _regression_rank_key(metrics: dict[str, Any]) -> tuple[float, float]:
    return (
        float(metrics.get("mae") if metrics.get("mae") is not None else 999),
        float(metrics.get("rmse") if metrics.get("rmse") is not None else 999),
    )


def _temporal_split(frame: pd.DataFrame, validation_ratio: float) -> tuple[pd.DataFrame, pd.DataFrame]:
    data = frame.sort_values("snapshot_minute").reset_index(drop=True)
    split = max(1, min(len(data) - 1, int(len(data) * (1 - validation_ratio))))
    return data.iloc[:split].copy(), data.iloc[split:].copy()


def _latest_model_run(conn: Any, market: str, model_root: str | Path, profile: str | None = None) -> dict[str, Any]:
    profile_name = (profile or "realtime").lower()
    row = clickhouse_realtime.fetch_latest_realtime_profit_model_run(market=market, profile=profile_name)
    if row is None:
        raise RuntimeError(f"no realtime profit model for market={market} profile={profile_name}")
    path = Path(str(row.get("model_path") or ""))
    if not path.exists():
        fallback = Path(model_root) / path.name
        if fallback.exists():
            path = fallback
    return {"model_run_id": row.get("model_run_id"), "model_path": str(path)}


def _load_model(path: Path) -> RealtimeProfitModel:
    with path.open("rb") as fh:
        return pickle.load(fh)


def _risk_score(row: dict[str, Any], probability: float, target_direction: str = "long") -> float:
    change = abs(float(row.get("change_percentage") or 0))
    volatility = float(row.get("volatility_15m") or 0) * 1000
    large_net_ratio = float(row.get("large_net_ratio") or 0)
    depth_imbalance = float(row.get("depth_imbalance") or 0)
    risk = 45 + change * 3 + volatility - probability * 25
    if normalize_target_direction(target_direction) == "short":
        total_net_ratio = float(row.get("total_net_ratio") or 0)
        near_day_low = float(row.get("near_day_low") or 0)
        short_pressure = max(float(row.get("short_selling_ratio") or 0), float(row.get("short_rate") or 0) * 100)
        negative_sentiment = float(row.get("negative_sentiment_score") or 0)
        bearish_strength = float(row.get("bearish_event_strength") or 0)
        if large_net_ratio < 0:
            risk -= min(15, abs(large_net_ratio) * 35)
        if total_net_ratio < 0:
            risk -= min(10, abs(total_net_ratio) * 25)
        if near_day_low > 0.65:
            risk -= min(10, (near_day_low - 0.65) * 25)
        if short_pressure > 0:
            risk -= min(10, short_pressure / 5)
        if negative_sentiment > 0 or bearish_strength > 0:
            risk -= min(12, negative_sentiment / 10 + bearish_strength / 20)
        if large_net_ratio > 0:
            risk += min(18, large_net_ratio * 40)
        if depth_imbalance > 0:
            risk += min(8, depth_imbalance * 16)
        return float(np.clip(risk, 0, 100))
    if large_net_ratio > 0:
        risk -= min(15, large_net_ratio * 35)
    if depth_imbalance > 0:
        risk -= min(10, depth_imbalance * 20)
    return float(np.clip(risk, 0, 100))


def _decision(probability: float, risk_score: float, row: dict[str, Any], target_direction: str = "long") -> str:
    change = float(row.get("change_percentage") or 0)
    if normalize_target_direction(target_direction) == "short":
        if probability >= 0.68 and risk_score <= 45 and change > -8:
            return "short_zone"
        if probability >= 0.62 and risk_score <= 55 and change > -10:
            return "short_candidate"
        if risk_score >= 70 or change <= -12:
            return "avoid_short"
        return "short_watch"
    if probability >= 0.65 and risk_score <= 45 and change < 4:
        return "buy_zone"
    if probability >= 0.65 and risk_score <= 55 and change < 5:
        return "candidate"
    if risk_score >= 70 or change >= 6:
        return "avoid"
    return "watch"


def _json_number(value: Any) -> float | None:
    try:
        if value is None or pd.isna(value):
            return None
        return float(value)
    except (TypeError, ValueError):
        return None


def _load_psycopg():
    try:
        import psycopg
        from psycopg.types.json import Jsonb
    except ImportError as exc:  # pragma: no cover
        raise RuntimeError("psycopg is required for realtime profit modeling") from exc
    return psycopg, Jsonb


def summary_to_dict(value: Any) -> dict[str, Any]:
    def default(item: Any) -> Any:
        if isinstance(item, np.generic):
            return item.item()
        if isinstance(item, (pd.Timestamp, datetime)):
            return item.isoformat()
        payload = getattr(item, "__dict__", None)
        if payload:
            return payload
        return {
            key: getattr(item, key)
            for key in dir(item)
            if not key.startswith("_") and not callable(getattr(item, key))
        }

    return json.loads(json.dumps(value, default=default, ensure_ascii=False))


def _json_dict(value: Any) -> dict[str, Any]:
    if isinstance(value, dict):
        return value
    if not value:
        return {}
    try:
        parsed = json.loads(str(value))
    except json.JSONDecodeError:
        return {}
    return parsed if isinstance(parsed, dict) else {}
