from __future__ import annotations

import json
from datetime import datetime
from pathlib import Path

import pandas as pd

from longbridge_stock.backtest import BacktestResult


def create_experiment_dir(root: str | Path, name: str) -> Path:
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    path = Path(root) / f"{timestamp}_{name}"
    path.mkdir(parents=True, exist_ok=False)
    return path


def save_backtest_result(path: str | Path, result: BacktestResult, scores: pd.Series) -> None:
    path = Path(path)
    result.daily.to_csv(path / "daily_returns.csv")
    result.positions.to_csv(path / "positions.csv")
    scores.rename("score").to_csv(path / "scores.csv")
    (path / "metrics.json").write_text(json.dumps(result.metrics, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
