from __future__ import annotations

import json
import re
import subprocess
from datetime import datetime, timezone
from typing import Any


def normalize_symbol(value: str) -> str:
    text = str(value or "").strip().upper()
    if not text:
        return text
    if "." not in text:
        text = f"{text}.US"
    return text


def normalize_underlying_symbol(value: str) -> str:
    symbol = str(value or "").strip().upper()
    if not symbol.endswith(".US"):
        return ""
    if _is_us_equity_symbol(symbol):
        return symbol
    match = re.match(r"^([A-Z]+)\d{6,7}[CP]\d+\.US$", symbol)
    if not match:
        return ""
    return f"{match.group(1)}.US"


def extract_us_traded_underlyings(
    *,
    orders: list[dict[str, Any]],
    positions: list[dict[str, Any]],
) -> list[str]:
    symbols = set()
    for row in orders:
        if str(row.get("status") or "").strip().lower() not in {"filled", "partialfilled", "partial-filled", "partial_filled"}:
            continue
        underlying = normalize_underlying_symbol(str(row.get("symbol") or ""))
        if underlying:
            symbols.add(underlying)
    for row in positions:
        underlying = normalize_underlying_symbol(str(row.get("symbol") or ""))
        if underlying:
            symbols.add(underlying)
    return sorted(symbols)


def fetch_order_history(*, start: str, runner=subprocess.run) -> list[dict[str, Any]]:
    command = ["longbridge", "order", "--history", "--start", str(start), "--format", "json"]
    completed = runner(command, capture_output=True, text=True, check=True)
    payload = json.loads(completed.stdout)
    return payload if isinstance(payload, list) else []


def fetch_positions(*, runner=subprocess.run) -> list[dict[str, Any]]:
    completed = runner(["longbridge", "positions", "--format", "json"], capture_output=True, text=True, check=True)
    payload = json.loads(completed.stdout)
    return payload if isinstance(payload, list) else []


def load_traded_us_underlyings(*, start: str) -> list[str]:
    return extract_us_traded_underlyings(orders=fetch_order_history(start=start), positions=fetch_positions())


def fetch_option_expiry_dates(symbol: str, *, runner=subprocess.run) -> list[dict[str, Any]]:
    completed = runner(
        ["longbridge", "option", "chain", normalize_symbol(symbol), "--format", "json"],
        capture_output=True,
        text=True,
        check=True,
    )
    payload = json.loads(completed.stdout)
    return payload if isinstance(payload, list) else []


def fetch_option_chain_by_date(symbol: str, expiry_date: str, *, runner=subprocess.run) -> list[dict[str, Any]]:
    completed = runner(
        ["longbridge", "option", "chain", normalize_symbol(symbol), "--date", str(expiry_date), "--format", "json"],
        capture_output=True,
        text=True,
        check=True,
    )
    payload = json.loads(completed.stdout)
    return payload if isinstance(payload, list) else []


def fetch_option_quotes(contract_symbols: list[str], *, runner=subprocess.run) -> list[dict[str, Any]]:
    if not contract_symbols:
        return []
    completed = runner(
        ["longbridge", "option", "quote", *contract_symbols, "--format", "json"],
        capture_output=True,
        text=True,
        check=True,
    )
    payload = json.loads(completed.stdout)
    return payload if isinstance(payload, list) else []


def fetch_option_volume_daily(symbol: str, *, count: int = 5, runner=subprocess.run) -> dict[str, Any]:
    completed = runner(
        ["longbridge", "option", "volume", "daily", normalize_symbol(symbol), "--count", str(max(1, int(count))), "--format", "json"],
        capture_output=True,
        text=True,
        check=True,
    )
    payload = json.loads(completed.stdout)
    return payload if isinstance(payload, dict) else {}


def parse_option_chain_rows(
    payload: list[dict[str, Any]],
    *,
    underlying_symbol: str,
    expiry_date: str,
    fetched_at: datetime | None = None,
) -> list[dict[str, Any]]:
    fetched_at = fetched_at or datetime.now().astimezone()
    normalized_symbol = normalize_symbol(underlying_symbol)
    rows: list[dict[str, Any]] = []
    for item in payload:
        strike = _num(item.get("strike"))
        standard = _bool(item.get("standard"))
        for direction, key in (("Call", "call_symbol"), ("Put", "put_symbol")):
            contract_symbol = str(item.get(key) or "").strip().upper()
            if not contract_symbol:
                contract_symbol = _contract_symbol(normalized_symbol, expiry_date, direction, strike)
            if not contract_symbol:
                continue
            rows.append(
                {
                    "underlying_symbol": normalized_symbol,
                    "contract_symbol": contract_symbol,
                    "expiry_date": str(expiry_date),
                    "strike_price": strike,
                    "direction": direction,
                    "standard": standard,
                    "source": "longbridge_option_chain",
                    "fetched_at": fetched_at.isoformat(),
                }
            )
    return rows


def normalize_option_quote_rows(
    payload: list[dict[str, Any]],
    *,
    fetched_at: datetime | None = None,
) -> list[dict[str, Any]]:
    fetched_at = fetched_at or datetime.now().astimezone()
    rows: list[dict[str, Any]] = []
    for item in payload:
        contract_symbol = str(item.get("symbol") or "").strip().upper()
        if not contract_symbol:
            continue
        rows.append(
            {
                "contract_symbol": contract_symbol,
                "underlying_symbol": normalize_symbol(str(item.get("underlying_symbol") or "")),
                "direction": str(item.get("direction") or ""),
                "expiry_date": str(item.get("expiry_date") or ""),
                "strike_price": _num(item.get("strike_price")),
                "last": _num_or_none(item.get("last")),
                "open": _num_or_none(item.get("open")),
                "high": _num_or_none(item.get("high")),
                "low": _num_or_none(item.get("low")),
                "prev_close": _num_or_none(item.get("prev_close")),
                "volume": int(_num(item.get("volume"))),
                "turnover": _num_or_none(item.get("turnover")),
                "open_interest": int(_num(item.get("open_interest"))),
                "implied_volatility": _num_or_none(item.get("implied_volatility")),
                "historical_volatility": _num_or_none(item.get("historical_volatility")),
                "quote_timestamp": str(item.get("timestamp") or ""),
                "trade_status": str(item.get("trade_status") or ""),
                "contract_type": str(item.get("contract_type") or ""),
                "contract_size": str(item.get("contract_size") or ""),
                "contract_multiplier": str(item.get("contract_multiplier") or ""),
                "source": "longbridge_option_quote",
                "fetched_at": fetched_at.isoformat(),
            }
        )
    return rows


def normalize_option_volume_rows(
    payload: dict[str, Any],
    *,
    underlying_symbol: str,
    fetched_at: datetime | None = None,
) -> list[dict[str, Any]]:
    fetched_at = fetched_at or datetime.now().astimezone()
    rows: list[dict[str, Any]] = []
    for item in payload.get("stats") or []:
        provider_timestamp = int(_num(item.get("timestamp")))
        rows.append(
            {
                "trade_date": datetime.fromtimestamp(provider_timestamp, tz=timezone.utc).date().isoformat(),
                "underlying_symbol": normalize_symbol(underlying_symbol),
                "underlying_counter_id": str(item.get("underlying_counter_id") or ""),
                "provider_timestamp": provider_timestamp,
                "total_call_volume": int(_num(item.get("total_call_volume"))),
                "total_put_volume": int(_num(item.get("total_put_volume"))),
                "total_volume": int(_num(item.get("total_volume"))),
                "total_call_open_interest": int(_num(item.get("total_call_open_interest"))),
                "total_put_open_interest": int(_num(item.get("total_put_open_interest"))),
                "total_open_interest": int(_num(item.get("total_open_interest"))),
                "put_call_volume_ratio": _num_or_none(item.get("put_call_volume_ratio")),
                "put_call_open_interest_ratio": _num_or_none(item.get("put_call_open_interest_ratio")),
                "source": "longbridge_option_volume_daily",
                "fetched_at": fetched_at.isoformat(),
            }
        )
    return rows


def _bool(value: Any) -> bool:
    if isinstance(value, bool):
        return value
    return str(value).strip().lower() in {"1", "true", "yes", "y"}


def _contract_symbol(underlying_symbol: str, expiry_date: str, direction: str, strike: float) -> str:
    code = str(underlying_symbol or "").split(".", 1)[0].upper()
    expiry = str(expiry_date or "").replace("-", "")
    if len(expiry) == 8:
        expiry = expiry[2:]
    option_type = "C" if direction == "Call" else "P"
    strike_code = str(int(round(strike * 1000)))
    if not code or len(expiry) != 6 or not strike_code:
        return ""
    return f"{code}{expiry}{option_type}{strike_code}.US"


def _is_us_equity_symbol(symbol: str) -> bool:
    code = symbol.removesuffix(".US")
    return code.isalpha()


def _num(value: Any) -> float:
    if value is None or value == "":
        return 0.0
    try:
        return float(value)
    except (TypeError, ValueError):
        return 0.0


def _num_or_none(value: Any) -> float | None:
    if value is None or value == "":
        return None
    try:
        return float(value)
    except (TypeError, ValueError):
        return None
