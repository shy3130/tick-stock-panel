from __future__ import annotations

import json
import os
import pickle
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import pandas as pd
import yaml


DEFAULT_REGISTRY_PATH = Path(os.getenv("LONGBRIDGE_ALGORITHM_REGISTRY", "configs/algorithm_registry.yaml"))
DEFAULT_MAX_ARTIFACTS_PER_ALGORITHM = 20


class ModelRegistryError(RuntimeError):
    pass


class UnsupportedModelError(ModelRegistryError):
    pass


@dataclass(frozen=True)
class RegistryContext:
    path: Path
    config: dict[str, Any]


def load_registry(path: str | Path | None = None) -> RegistryContext:
    registry_path = Path(path or DEFAULT_REGISTRY_PATH)
    if not registry_path.exists():
        return RegistryContext(path=registry_path, config={"version": 1, "algorithms": []})
    with registry_path.open("r", encoding="utf-8") as fh:
        data = yaml.safe_load(fh) or {}
    if not isinstance(data, dict):
        raise ModelRegistryError(f"Registry must be a mapping: {registry_path}")
    data.setdefault("algorithms", [])
    return RegistryContext(path=registry_path, config=data)


def list_models(*, registry_path: str | Path | None = None, max_artifacts_per_algorithm: int = DEFAULT_MAX_ARTIFACTS_PER_ALGORITHM) -> list[dict[str, Any]]:
    context = load_registry(registry_path)
    output: list[dict[str, Any]] = []
    for algorithm in context.config.get("algorithms") or []:
        if not isinstance(algorithm, dict):
            continue
        output.extend(_models_for_algorithm(algorithm, max_artifacts=max_artifacts_per_algorithm))
    return sorted(output, key=lambda item: (item.get("status") != "active", item.get("algorithmId") or "", item.get("createdAt") or ""), reverse=False)


def get_model(model_id: str, *, registry_path: str | Path | None = None) -> dict[str, Any]:
    for model in list_models(registry_path=registry_path, max_artifacts_per_algorithm=100):
        if model.get("modelId") == model_id or model.get("algorithmId") == model_id:
            return model
    raise KeyError(model_id)


def predict(model_id: str, payload: dict[str, Any], *, registry_path: str | Path | None = None) -> dict[str, Any]:
    model = get_model(model_id, registry_path=registry_path)
    artifact = Path(str(model.get("artifactPath") or ""))
    if not artifact.exists():
        raise UnsupportedModelError(f"Model artifact is not available on this host: {model_id}")
    if str(model.get("servingBackend") or "") not in {"fastapi_joblib", "joblib", "sklearn"}:
        raise UnsupportedModelError(f"Model is registered for {model.get('servingBackend') or 'metadata-only'} serving, not direct API prediction.")
    loaded = _load_joblib_model(artifact)
    instances, input_kind = _normalize_prediction_inputs(payload, model)
    prediction = _predict_loaded_model(loaded, instances, input_kind=input_kind, model=model, artifact=artifact)
    return {
        "modelId": model.get("modelId"),
        "algorithmId": model.get("algorithmId"),
        "artifactPath": str(artifact),
        "inputKind": input_kind,
        "predictions": prediction,
    }


def _models_for_algorithm(algorithm: dict[str, Any], *, max_artifacts: int) -> list[dict[str, Any]]:
    artifacts = _discover_artifacts(algorithm, max_artifacts=max_artifacts)
    if not artifacts:
        return [_base_model_payload(algorithm, artifact_path=None, metadata={}, is_latest=False)]
    latest_paths = {str(path.resolve()) for path in _latest_pointer_targets(algorithm)}
    output = []
    for artifact in artifacts:
        metadata = _read_metadata(artifact)
        output.append(
            _base_model_payload(
                algorithm,
                artifact_path=artifact,
                metadata=metadata,
                is_latest=str(artifact.resolve()) in latest_paths or len(artifacts) == 1,
            )
        )
    return output


def _base_model_payload(algorithm: dict[str, Any], *, artifact_path: Path | None, metadata: dict[str, Any], is_latest: bool) -> dict[str, Any]:
    algorithm_id = str(algorithm.get("id") or "unknown")
    run_id = str(metadata.get("model_run_id") or metadata.get("run_id") or _run_id_from_artifact_path(artifact_path))
    model_id = f"{algorithm_id}:{run_id}" if artifact_path else algorithm_id
    metrics = metadata.get("metrics") if isinstance(metadata.get("metrics"), dict) else {}
    feature_names = metadata.get("feature_names")
    if feature_names is None and isinstance(metadata.get("config"), dict):
        feature_names = metadata["config"].get("feature_names")
    created_at = str(metadata.get("created_at") or metadata.get("trained_at") or _mtime_iso(artifact_path))
    return {
        "modelId": model_id,
        "algorithmId": algorithm_id,
        "runId": run_id,
        "name": algorithm.get("name") or algorithm_id,
        "family": algorithm.get("family") or "",
        "status": algorithm.get("status") or "unknown",
        "framework": algorithm.get("framework") or "",
        "servingBackend": algorithm.get("serving_backend") or "",
        "purpose": algorithm.get("purpose") or "",
        "inputs": algorithm.get("inputs") or {},
        "outputs": algorithm.get("outputs") or [],
        "entrypoints": algorithm.get("entrypoints") or {},
        "artifactPath": str(artifact_path) if artifact_path else "",
        "artifactExists": bool(artifact_path and artifact_path.exists()),
        "latest": bool(is_latest),
        "createdAt": created_at,
        "metrics": metrics,
        "featureNames": feature_names or [],
        "metadata": metadata,
    }


def _run_id_from_artifact_path(artifact_path: Path | None) -> str:
    if artifact_path is None:
        return "registered"
    if artifact_path.is_file() and artifact_path.stem.lower() in {"model", "calibrator"}:
        return artifact_path.parent.name
    return artifact_path.stem if artifact_path.is_file() else artifact_path.name


def _discover_artifacts(algorithm: dict[str, Any], *, max_artifacts: int) -> list[Path]:
    candidates: list[Path] = []
    for raw in algorithm.get("artifact_files") or []:
        path = _expand_path(raw)
        if path.exists():
            candidates.append(path)
    candidates.extend(_latest_pointer_targets(algorithm))
    for raw in algorithm.get("artifact_roots") or []:
        root = _expand_path(raw)
        if root.is_file():
            candidates.append(root)
        elif root.is_dir():
            candidates.extend(_artifact_children(root))
    unique: dict[str, Path] = {}
    for path in candidates:
        if path.exists():
            unique[str(path.resolve())] = path
    return sorted(unique.values(), key=lambda path: path.stat().st_mtime, reverse=True)[:max(1, max_artifacts)]


def _artifact_children(root: Path) -> list[Path]:
    direct_model = _model_file_in_dir(root)
    if direct_model:
        return [direct_model]
    children = []
    for item in root.iterdir():
        if item.name.startswith("."):
            continue
        if item.is_dir():
            model_file = _model_file_in_dir(item)
            if model_file:
                children.append(model_file)
        elif item.suffix.lower() in {".joblib", ".pkl", ".pickle"}:
            children.append(item)
    return children


def _model_file_in_dir(path: Path) -> Path | None:
    for name in ("model.joblib", "model.pkl", "model.pickle", "model.pt"):
        candidate = path / name
        if candidate.exists():
            return candidate
    metadata = path / "metadata.json"
    if metadata.exists():
        return path
    return None


def _latest_pointer_targets(algorithm: dict[str, Any]) -> list[Path]:
    targets = []
    for raw in algorithm.get("latest_pointers") or []:
        pointer = _expand_path(raw)
        if not pointer.exists() or not pointer.is_file():
            continue
        target_text = pointer.read_text(encoding="utf-8", errors="ignore").strip()
        if not target_text:
            continue
        target = _expand_path(target_text)
        if target.is_dir():
            target = _model_file_in_dir(target) or target
        if target.exists():
            targets.append(target)
    return targets


def _read_metadata(artifact_path: Path) -> dict[str, Any]:
    metadata_path = artifact_path / "metadata.json" if artifact_path.is_dir() else artifact_path.parent / "metadata.json"
    if metadata_path.exists():
        try:
            data = json.loads(metadata_path.read_text(encoding="utf-8"))
            return data if isinstance(data, dict) else {}
        except json.JSONDecodeError:
            return {}
    if artifact_path.suffix.lower() in {".joblib", ".pkl", ".pickle"}:
        lightweight = _read_embedded_metadata(artifact_path)
        if lightweight:
            return lightweight
    return {}


def _read_embedded_metadata(artifact_path: Path) -> dict[str, Any]:
    try:
        import joblib

        payload = joblib.load(artifact_path)
    except Exception:
        return {}
    if isinstance(payload, dict) and isinstance(payload.get("metadata"), dict):
        return dict(payload["metadata"])
    return {}


def _load_joblib_model(artifact_path: Path) -> Any:
    model_file = artifact_path
    if artifact_path.is_dir():
        model_file = _model_file_in_dir(artifact_path) or artifact_path
    if model_file.is_dir() or model_file.suffix.lower() not in {".joblib", ".pkl", ".pickle"}:
        raise UnsupportedModelError(f"Unsupported artifact format: {artifact_path}")
    try:
        import joblib

        return joblib.load(model_file)
    except Exception:
        with model_file.open("rb") as fh:
            return pickle.load(fh)


def _normalize_prediction_inputs(payload: dict[str, Any], model: dict[str, Any]) -> tuple[Any, str]:
    input_type = str((model.get("inputs") or {}).get("type") or "")
    if "texts" in payload:
        values = payload["texts"]
        return values if isinstance(values, list) else [str(values)], "text"
    if "text" in payload:
        return [str(payload["text"])], "text"
    if input_type == "text" and "instances" in payload:
        values = payload["instances"]
        return [str(item.get("text") if isinstance(item, dict) else item) for item in values], "text"
    if "instances" in payload:
        values = payload["instances"]
        return values if isinstance(values, list) else [values], "tabular"
    if "features" in payload:
        return [payload["features"]], "tabular"
    return [payload], "tabular"


def _predict_loaded_model(loaded: Any, instances: Any, *, input_kind: str, model: dict[str, Any], artifact: Path) -> list[dict[str, Any]]:
    estimator = loaded.get("model") if isinstance(loaded, dict) and "model" in loaded else loaded
    if input_kind == "text":
        return _predict_estimator(estimator, [str(item) for item in instances])
    frame = _instances_to_frame(instances, model)
    predictions = _predict_estimator(estimator, frame)
    calibrator_path = artifact.parent / "calibrator.joblib" if artifact.is_file() else artifact / "calibrator.joblib"
    if calibrator_path.exists():
        try:
            import joblib

            calibrator = joblib.load(calibrator_path)
            raw = [float(item.get("probability", item.get("prediction", 0.0))) for item in predictions]
            calibrated = calibrator.predict(raw)
            for item, probability in zip(predictions, calibrated):
                item["calibratedProbability"] = float(probability)
        except Exception as exc:
            for item in predictions:
                item["calibrationWarning"] = str(exc)
    return predictions


def _instances_to_frame(instances: list[Any], model: dict[str, Any]) -> pd.DataFrame:
    rows = [item if isinstance(item, dict) else {"value": item} for item in instances]
    frame = pd.DataFrame(rows)
    feature_names = [str(item) for item in model.get("featureNames") or []]
    if feature_names:
        for name in feature_names:
            if name not in frame:
                frame[name] = None
        return frame[feature_names]
    return frame


def _predict_estimator(estimator: Any, values: Any) -> list[dict[str, Any]]:
    if hasattr(estimator, "predict_proba"):
        probabilities = estimator.predict_proba(values)
        classes = [str(item) for item in getattr(estimator, "classes_", [])]
        output = []
        for row in probabilities:
            row_values = [float(value) for value in row]
            item: dict[str, Any] = {"probabilities": row_values}
            if classes:
                item["classProbabilities"] = dict(zip(classes, row_values))
                positive_index = _positive_class_index(classes)
                if positive_index is not None and positive_index < len(row_values):
                    item["probability"] = row_values[positive_index]
            elif len(row_values) == 2:
                item["probability"] = row_values[1]
            output.append(item)
        return output
    if hasattr(estimator, "predict"):
        predictions = estimator.predict(values)
        return [{"prediction": _jsonable(value)} for value in predictions]
    raise UnsupportedModelError("Loaded artifact does not expose predict or predict_proba.")


def _positive_class_index(classes: list[str]) -> int | None:
    for preferred in ("1", "true", "positive", "bullish"):
        if preferred in [item.lower() for item in classes]:
            return [item.lower() for item in classes].index(preferred)
    return len(classes) - 1 if classes else None


def _expand_path(value: Any) -> Path:
    return Path(os.path.expandvars(os.path.expanduser(str(value))))


def _mtime_iso(path: Path | None) -> str:
    if not path or not path.exists():
        return ""
    return datetime.fromtimestamp(path.stat().st_mtime, timezone.utc).isoformat(timespec="seconds")


def _jsonable(value: Any) -> Any:
    if hasattr(value, "item"):
        return value.item()
    return value
