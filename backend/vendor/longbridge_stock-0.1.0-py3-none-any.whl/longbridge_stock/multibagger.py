from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import pandas as pd


@dataclass(frozen=True)
class MultibaggerScanConfig:
    min_close: float = 2.0
    min_turnover: float = 10_000_000.0
    min_history_days: int = 60
    limit: int = 30


@dataclass(frozen=True)
class BacktestGateConfig:
    min_precision_at_top5: float = 0.80
    min_evaluated_signals: int = 60
    target_return: float = 0.10
    forward_window_days: int = 20
    risk_line: float = -0.08


def scan_multibagger_candidates(frame: pd.DataFrame, config: MultibaggerScanConfig | None = None) -> dict[str, Any]:
    cfg = config or MultibaggerScanConfig()
    if frame.empty:
        return _empty_report()

    features = _latest_features(frame)
    if features.empty:
        return _empty_report(input_rows=len(frame))

    features["ret_20d_rank"] = features["return_20d"].rank(pct=True)
    features["ret_60d_rank"] = features["return_60d"].rank(pct=True)

    trend_rows: list[dict[str, Any]] = []
    anomaly_rows: list[dict[str, Any]] = []
    for row in features.sort_values("score_seed", ascending=False).to_dict("records"):
        candidate = _build_candidate(row, cfg)
        if candidate["pool"] == "trend":
            trend_rows.append(candidate)
        elif candidate["pool"] == "anomaly":
            anomaly_rows.append(candidate)

    trend_rows.sort(key=lambda item: item["score"], reverse=True)
    anomaly_rows.sort(key=lambda item: item["score"], reverse=True)
    trend_rows = trend_rows[: cfg.limit]
    anomaly_rows = anomaly_rows[: cfg.limit]
    return {
        "summary": {
            "scan_date": _scan_date(features),
            "input_rows": int(len(frame)),
            "symbol_count": int(features["symbol"].nunique()),
            "trend_pool_count": len(trend_rows),
            "anomaly_pool_count": len(anomaly_rows),
            "top_theme_clusters": [],
        },
        "trend_pool": trend_rows,
        "anomaly_pool": anomaly_rows,
    }


def build_after_close_message(report: dict[str, Any], top_n: int = 5) -> str:
    summary = report.get("summary") or {}
    scan_date = summary.get("scan_date") or "-"
    lines = [f"【翻倍潜力池】{scan_date} 收盘"]
    trend_rows = list(report.get("trend_pool") or [])[:top_n]
    if not trend_rows:
        lines.append("今天没有趋势池候选，继续观察。")
    for index, row in enumerate(trend_rows, start=1):
        score = int(round(float(row.get("score") or 0)))
        reasons = _join_labels(row.get("reasons") or [], REASON_LABELS)
        lines.append(f"{index}. {row.get('symbol') or '-'} {score}分：{reasons or '信号待确认'}")

    anomaly_count = int(summary.get("anomaly_pool_count") or len(report.get("anomaly_pool") or []))
    if anomaly_count:
        risks = _top_risk_labels(report.get("anomaly_pool") or [])
        suffix = f"，主要风险：{risks}" if risks else ""
        lines.append(f"妖股隔离池：{anomaly_count}只{suffix}。暂不追。")
    else:
        lines.append("妖股隔离池：0只。")
    return "\n".join(lines)


def evaluate_backtest_gate(metrics: dict[str, Any], config: BacktestGateConfig | None = None) -> dict[str, Any]:
    cfg = config or BacktestGateConfig()
    evaluated = int(metrics.get("evaluated_signals") or 0)
    precision = _safe(metrics.get("precision_at_top5"))
    reasons: list[str] = []
    if evaluated < cfg.min_evaluated_signals:
        reasons.append("insufficient_evaluated_signals")
    if precision is None or precision < cfg.min_precision_at_top5:
        reasons.append("precision_below_threshold")
    if not reasons:
        reasons.append("gate_passed")
    return {
        "intraday_allowed": reasons == ["gate_passed"],
        "reasons": reasons,
        "evaluated_signals": evaluated,
        "precision_at_top5": precision,
        "min_precision_at_top5": cfg.min_precision_at_top5,
        "min_evaluated_signals": cfg.min_evaluated_signals,
        "target_return": cfg.target_return,
        "forward_window_days": cfg.forward_window_days,
        "risk_line": cfg.risk_line,
    }


REASON_LABELS = {
    "rs_20d_top_decile": "20日强度前列",
    "rs_60d_top_decile": "60日强度前列",
    "breakout_60d": "60日新高",
    "breakout_120d": "120日新高",
    "volume_20d_2x": "成交量2倍",
    "turnover_ok": "成交额达标",
}

RISK_LABELS = {
    "risk_low_price": "低价",
    "risk_low_turnover": "低成交额",
    "risk_one_day_extreme": "单日暴涨",
    "risk_overextended": "过热",
    "risk_short_history": "历史不足",
}


def _latest_features(frame: pd.DataFrame) -> pd.DataFrame:
    data = frame.copy()
    data["trade_date"] = pd.to_datetime(data["trade_date"], errors="coerce")
    for column in ["open", "high", "low", "close", "volume", "turnover"]:
        data[column] = pd.to_numeric(data[column], errors="coerce")
    data = data.dropna(subset=["symbol", "trade_date", "close"]).sort_values(["symbol", "trade_date"])
    if data.empty:
        return pd.DataFrame()

    rows: list[dict[str, Any]] = []
    for symbol, part in data.groupby("symbol", sort=False):
        part = part.reset_index(drop=True)
        latest = part.iloc[-1]
        prev_close = _safe(part["close"].iloc[-2]) if len(part) >= 2 else None
        close = _safe(latest["close"])
        if close is None:
            continue
        avg_volume_20 = _mean(part["volume"].iloc[-21:-1])
        avg_turnover_20 = _mean(part["turnover"].iloc[-21:-1])
        prev_high_60 = _max(part["high"].iloc[-61:-1])
        prev_high_120 = _max(part["high"].iloc[-121:-1])
        ma20 = _mean(part["close"].iloc[-21:-1])
        rows.append(
            {
                "symbol": str(symbol),
                "trade_date": latest["trade_date"].date().isoformat(),
                "latest_close": close,
                "latest_turnover": _safe(latest.get("turnover")) or 0.0,
                "return_20d": _return_from(part["close"], 20),
                "return_60d": _return_from(part["close"], 60),
                "latest_day_return": (close / prev_close - 1.0) if prev_close else None,
                "volume_ratio_20d": (float(latest["volume"]) / avg_volume_20) if avg_volume_20 else None,
                "turnover_ratio_20d": (float(latest["turnover"]) / avg_turnover_20) if avg_turnover_20 else None,
                "breakout_60d": bool(prev_high_60 and close > prev_high_60),
                "breakout_120d": bool(prev_high_120 and close > prev_high_120),
                "distance_ma20": (close / ma20 - 1.0) if ma20 else None,
                "history_days": int(len(part)),
                "theme": None,
            }
        )
    result = pd.DataFrame(rows)
    if result.empty:
        return result
    result["score_seed"] = (
        pd.to_numeric(result["return_20d"], errors="coerce").fillna(0)
        + pd.to_numeric(result["return_60d"], errors="coerce").fillna(0)
        + pd.to_numeric(result["volume_ratio_20d"], errors="coerce").fillna(0) / 10
    )
    return result


def _join_labels(codes: list[str], labels: dict[str, str]) -> str:
    return "、".join(labels.get(code, code) for code in codes)


def _top_risk_labels(rows: list[dict[str, Any]]) -> str:
    counts: dict[str, int] = {}
    for row in rows:
        for code in row.get("risk_flags") or []:
            counts[code] = counts.get(code, 0) + 1
    ordered = sorted(counts.items(), key=lambda item: item[1], reverse=True)
    return "、".join(RISK_LABELS.get(code, code) for code, _ in ordered[:3])


def _build_candidate(row: dict[str, Any], config: MultibaggerScanConfig) -> dict[str, Any]:
    reasons: list[str] = []
    risk_flags: list[str] = []

    if (row.get("ret_20d_rank") or 0) >= 0.8:
        reasons.append("rs_20d_top_decile")
    if (row.get("ret_60d_rank") or 0) >= 0.75:
        reasons.append("rs_60d_top_decile")
    if row.get("breakout_60d"):
        reasons.append("breakout_60d")
    if row.get("breakout_120d"):
        reasons.append("breakout_120d")
    if (row.get("volume_ratio_20d") or 0) >= 2.0:
        reasons.append("volume_20d_2x")
    if (row.get("latest_turnover") or 0) >= config.min_turnover:
        reasons.append("turnover_ok")

    if (row.get("latest_close") or 0) < config.min_close:
        risk_flags.append("risk_low_price")
    if (row.get("latest_turnover") or 0) < config.min_turnover:
        risk_flags.append("risk_low_turnover")
    if (row.get("latest_day_return") or 0) >= 0.8:
        risk_flags.append("risk_one_day_extreme")
    if (row.get("distance_ma20") or 0) >= 0.8:
        risk_flags.append("risk_overextended")
    if (row.get("history_days") or 0) < config.min_history_days:
        risk_flags.append("risk_short_history")

    score = _score(row, reasons, risk_flags)
    pool = "ignore"
    hard_risks = {"risk_low_price", "risk_low_turnover", "risk_one_day_extreme", "risk_short_history"}
    if hard_risks.intersection(risk_flags) and reasons:
        pool = "anomaly"
    elif score >= 55 and {"breakout_60d", "volume_20d_2x", "turnover_ok"}.issubset(set(reasons)):
        pool = "trend"

    return {
        "symbol": row["symbol"],
        "pool": pool,
        "score": round(score, 1),
        "latest_close": _round(row.get("latest_close")),
        "latest_turnover": _round(row.get("latest_turnover")),
        "return_20d": _round(row.get("return_20d")),
        "return_60d": _round(row.get("return_60d")),
        "volume_ratio_20d": _round(row.get("volume_ratio_20d")),
        "breakout": bool(row.get("breakout_60d") or row.get("breakout_120d")),
        "theme": row.get("theme"),
        "reasons": reasons,
        "risk_flags": risk_flags,
    }


def _score(row: dict[str, Any], reasons: list[str], risk_flags: list[str]) -> float:
    score = 0.0
    score += min(30.0, max(0.0, (row.get("ret_20d_rank") or 0) * 30.0))
    score += min(25.0, max(0.0, (row.get("ret_60d_rank") or 0) * 25.0))
    score += 15.0 if "breakout_60d" in reasons else 0.0
    score += 10.0 if "breakout_120d" in reasons else 0.0
    score += min(20.0, max(0.0, (row.get("volume_ratio_20d") or 0) * 5.0))
    score += 10.0 if "turnover_ok" in reasons else 0.0
    score -= 20.0 * len(risk_flags)
    return max(0.0, score)


def _empty_report(input_rows: int = 0) -> dict[str, Any]:
    return {
        "summary": {
            "scan_date": None,
            "input_rows": input_rows,
            "symbol_count": 0,
            "trend_pool_count": 0,
            "anomaly_pool_count": 0,
            "top_theme_clusters": [],
        },
        "trend_pool": [],
        "anomaly_pool": [],
    }


def _return_from(series: pd.Series, days: int) -> float | None:
    if len(series) <= days:
        return None
    current = _safe(series.iloc[-1])
    base = _safe(series.iloc[-days - 1])
    if current is None or not base:
        return None
    return current / base - 1.0


def _safe(value: Any) -> float | None:
    try:
        number = float(value)
    except (TypeError, ValueError):
        return None
    if pd.isna(number):
        return None
    return number


def _mean(series: pd.Series) -> float | None:
    numeric = pd.to_numeric(series, errors="coerce").dropna()
    if numeric.empty:
        return None
    return float(numeric.mean())


def _max(series: pd.Series) -> float | None:
    numeric = pd.to_numeric(series, errors="coerce").dropna()
    if numeric.empty:
        return None
    return float(numeric.max())


def _round(value: Any) -> float | None:
    number = _safe(value)
    return None if number is None else round(number, 4)


def _scan_date(features: pd.DataFrame) -> str | None:
    if features.empty:
        return None
    return str(features["trade_date"].max())
