from __future__ import annotations

import json
import time
from dataclasses import dataclass
from datetime import datetime
from typing import Any, Iterable

from longbridge_stock import clickhouse_realtime
from longbridge_stock.market_sessions import SHANGHAI_TZ, is_trading_time, markets_from_symbols
from longbridge_stock.realtime_alerts import AlertState, OpenClawNotifier, RealtimeAlert


@dataclass(frozen=True)
class HoldingCapitalAlertConfig:
    symbols: list[str]
    max_quote_age_minutes: int = 25
    large_net_ratio_threshold: float = 0.05
    flow_30m_threshold: float = 50_000.0
    max_alerts_per_run: int = 20

    @property
    def markets(self) -> list[str]:
        return markets_from_symbols(self.symbols)


class HoldingCapitalAlertMonitor:
    def __init__(
        self,
        dsn: str,
        config: HoldingCapitalAlertConfig,
        notifier: OpenClawNotifier,
        state: AlertState,
    ) -> None:
        self.dsn = dsn
        self.config = config
        self.notifier = notifier
        self.state = state

    def run_once(self, now: datetime | None = None) -> dict[str, Any]:
        current = now or datetime.now(SHANGHAI_TZ)
        markets = self.config.markets
        if not is_trading_time(current, markets):
            return {"status": "outside_trading_time", "checked": 0, "alerts": 0, "sent": 0}

        rows = fetch_holding_capital_rows(
            self.dsn,
            self.config.symbols,
            now=current,
            max_quote_age_minutes=self.config.max_quote_age_minutes,
        )
        alerts = build_holding_capital_alerts(rows, self.config)
        alerts.sort(key=lambda alert: alert.score if alert.score is not None else 0, reverse=True)

        trade_date = current.date().isoformat()
        sent = 0
        skipped = 0
        deferred = 0
        errors: list[str] = []
        for alert in alerts:
            if not self.state.should_send(alert, trade_date):
                skipped += 1
                continue
            if sent >= self.config.max_alerts_per_run:
                deferred += 1
                continue
            try:
                self.notifier.send(alert.message)
            except Exception as exc:
                errors.append(f"{alert.dedupe_key}: {exc}")
                continue
            self.state.mark_sent(alert, trade_date)
            sent += 1
        return {
            "status": "ok",
            "checked": len(rows),
            "alerts": len(alerts),
            "sent": sent,
            "skipped": skipped,
            "deferred": deferred,
            "errors": errors,
        }

    def run_forever(self, interval_seconds: int) -> None:
        if interval_seconds <= 0:
            raise ValueError("interval_seconds must be positive")
        while True:
            started = time.monotonic()
            result = self.run_once()
            print(json.dumps(result, ensure_ascii=False), flush=True)
            time.sleep(max(0, interval_seconds - (time.monotonic() - started)))


def fetch_holding_capital_rows(
    dsn: str,
    symbols: Iterable[str],
    *,
    now: datetime | None = None,
    max_quote_age_minutes: int = 25,
) -> list[dict[str, Any]]:
    normalized_symbols = [symbol.strip().upper() for symbol in symbols if symbol.strip()]
    if not normalized_symbols:
        return []
    current = now or datetime.now(SHANGHAI_TZ)
    return clickhouse_realtime.fetch_holding_capital_rows(
        normalized_symbols,
        now=current,
        max_quote_age_minutes=max_quote_age_minutes,
    )


def build_holding_capital_alerts(
    rows: Iterable[dict[str, Any]],
    config: HoldingCapitalAlertConfig,
) -> list[RealtimeAlert]:
    alerts: list[RealtimeAlert] = []
    for row in rows:
        if row.get("stale"):
            continue
        alert_type = _alert_type(row, config)
        if alert_type:
            alerts.append(_build_alert(row, alert_type))
    return alerts


def build_intraday_capital_assessment(
    row: dict[str, Any],
    config: HoldingCapitalAlertConfig | None = None,
) -> dict[str, Any]:
    cfg = config or HoldingCapitalAlertConfig(symbols=[])
    large_net = _number(row.get("largeNet"))
    total_net = _number(row.get("totalNet"))
    large_net_ratio = _number(row.get("largeNetRatio"))
    flow_30m = _number(row.get("flow30m"))
    flow_15m = _number(row.get("flow15m"))
    flow_today = _number(row.get("flowToday"))
    change_pct = _number(row.get("changePct")) or 0.0
    from_open_pct = _number(row.get("fromOpenPct")) or 0.0
    turnover = _number(row.get("turnover"))

    if row.get("stale"):
        return _capital_assessment(
            "数据过期",
            "资金数据过期，先不参与当日判断",
            "neutral",
            0.0,
            large_net,
            total_net,
            large_net_ratio,
            flow_30m,
            flow_today,
            turnover,
        )
    if large_net is None and total_net is None and flow_30m is None and flow_today is None:
        return _capital_assessment(
            "无资金数据",
            "没有可用的当日资金流数据",
            "neutral",
            0.0,
            large_net,
            total_net,
            large_net_ratio,
            flow_30m,
            flow_today,
            turnover,
        )

    large_ratio = large_net_ratio or 0.0
    recent_flow = flow_30m if flow_30m is not None else 0.0
    total = total_net if total_net is not None else 0.0
    large = large_net if large_net is not None else 0.0
    flow_day = flow_today if flow_today is not None else 0.0
    strength = _capital_strength(total, large, large_ratio, recent_flow, flow_day, turnover)

    if large > 0 and total > 0 and large_ratio >= cfg.large_net_ratio_threshold and recent_flow >= cfg.flow_30m_threshold:
        label = "强流入"
        direction = "inflow"
        reason = "大单、总净额和30分钟资金同步流入"
    elif large < 0 and total < 0 and (recent_flow <= -cfg.flow_30m_threshold or from_open_pct < -1.0):
        label = "主力流出"
        direction = "outflow"
        reason = "大单和总净额同步流出，短线资金偏弱"
    elif total > 0 and large >= 0 and change_pct < 0:
        label = "下跌承接"
        direction = "inflow"
        reason = "股价下跌但资金净流入，有承接迹象"
    elif total > 0 and large >= 0:
        label = "温和流入"
        direction = "inflow"
        reason = "资金净流入，但强度未达到异动级别"
    elif total < 0 and large < 0 and change_pct > 0:
        label = "拉高出货"
        direction = "outflow"
        reason = "股价上涨但大单和总净额流出"
    elif total < 0 and large < 0:
        label = "温和流出"
        direction = "outflow"
        reason = "资金净流出，但强度未达到异动级别"
    elif total * large < 0 or (flow_15m is not None and flow_30m is not None and flow_15m * flow_30m < 0):
        label = "资金分歧"
        direction = "mixed"
        reason = "大单、总净额或短周期资金方向不一致"
    else:
        label = "资金平淡"
        direction = "neutral"
        reason = "当日资金方向不明显"

    return _capital_assessment(
        label,
        reason,
        direction,
        strength,
        large_net,
        total_net,
        large_net_ratio,
        flow_30m,
        flow_today,
        turnover,
    )


def _alert_type(row: dict[str, Any], config: HoldingCapitalAlertConfig) -> str | None:
    large_net = _number(row.get("largeNet"))
    total_net = _number(row.get("totalNet"))
    large_net_ratio = _number(row.get("largeNetRatio")) or 0.0
    flow_30m = _number(row.get("flow30m")) or 0.0
    change_pct = _number(row.get("changePct")) or 0.0
    from_open_pct = _number(row.get("fromOpenPct")) or 0.0
    if (
        large_net is not None
        and total_net is not None
        and large_net > 0
        and total_net > 0
        and large_net_ratio >= config.large_net_ratio_threshold
        and flow_30m >= config.flow_30m_threshold
        and change_pct <= 4.5
    ):
        return "holding_capital_inflow"
    if (
        large_net is not None
        and total_net is not None
        and large_net < 0
        and total_net < 0
        and (flow_30m <= -config.flow_30m_threshold or from_open_pct < -1.0)
    ):
        return "holding_capital_outflow"
    return None


def _capital_strength(
    total_net: float,
    large_net: float,
    large_net_ratio: float,
    flow_30m: float,
    flow_today: float,
    turnover: float | None,
) -> float:
    denominator = max(abs(turnover or 0.0), 1.0)
    turnover_ratio = min(40.0, abs(total_net) / denominator * 1000.0)
    large_ratio_score = min(35.0, abs(large_net_ratio) * 220.0)
    flow_score = min(20.0, abs(flow_30m) / 50_000.0 * 8.0)
    day_score = min(15.0, abs(flow_today) / 200_000.0 * 5.0)
    large_score = min(20.0, abs(large_net) / max(abs(total_net), 1.0) * 10.0) if total_net else 0.0
    return round(min(100.0, turnover_ratio + large_ratio_score + flow_score + day_score + large_score), 2)


def _capital_assessment(
    label: str,
    reason: str,
    direction: str,
    strength: float,
    large_net: float | None,
    total_net: float | None,
    large_net_ratio: float | None,
    flow_30m: float | None,
    flow_today: float | None,
    turnover: float | None,
) -> dict[str, Any]:
    return {
        "label": label,
        "reason": reason,
        "direction": direction,
        "strength": strength,
        "largeNet": large_net,
        "totalNet": total_net,
        "largeNetRatio": large_net_ratio,
        "flow30m": flow_30m,
        "flowToday": flow_today,
        "turnover": turnover,
        "text": _capital_assessment_text(label, strength, reason, large_net, total_net, large_net_ratio, flow_30m),
    }


def _capital_assessment_text(
    label: str,
    strength: float,
    reason: str,
    large_net: float | None,
    total_net: float | None,
    large_net_ratio: float | None,
    flow_30m: float | None,
) -> str:
    return (
        f"{label}，强度{strength:.0f}%；{reason}；"
        f"大单{_fmt_wan(large_net)}，总净额{_fmt_wan(total_net)}，"
        f"大单占比{_fmt_pct(large_net_ratio)}，30分钟{_fmt_wan(flow_30m)}"
    )


def _build_alert(row: dict[str, Any], alert_type: str) -> RealtimeAlert:
    symbol = str(row.get("symbol") or "-")
    market = str(row.get("market") or "").upper()
    name = str(row.get("name") or symbol)
    score = _score(row, alert_type)
    if alert_type == "holding_capital_inflow":
        title = f"{market} {symbol} {name} 持仓资金流入异动"
        action = "建议：进入重点观察；若价格站稳开盘价且资金继续净流入，可考虑加仓或继续持有。"
    else:
        title = f"{market} {symbol} {name} 持仓资金流出风险"
        action = "建议：优先控制仓位；若跌破日内低位或资金继续流出，考虑减仓。"
    message = "\n".join(
        [
            f"[长桥持仓资金提醒] {title}",
            f"现价：{_fmt(row.get('lastDone'))}，涨跌：{_fmt(row.get('changePct'))}%，开盘后：{_fmt(row.get('fromOpenPct'))}%",
            f"大单净额：{_fmt(row.get('largeNet'))}，总净额：{_fmt(row.get('totalNet'))}，大单占比：{_fmt_pct(row.get('largeNetRatio'))}",
            f"30分钟资金：{_fmt(row.get('flow30m'))}，15分钟资金：{_fmt(row.get('flow15m'))}，今日分时累计：{_fmt(row.get('flowToday'))}",
            f"行情分钟：{row.get('quoteMinute') or '-'}，资金分钟：{row.get('capitalMinute') or '-'}，分时分钟：{row.get('lastFlowTime') or '-'}",
            action,
        ]
    )
    return RealtimeAlert(
        alert_type=alert_type,
        symbol=symbol,
        market=market,
        name=name,
        title=title,
        message=message,
        score=score,
        signal=alert_type,
    )


def _score(row: dict[str, Any], alert_type: str) -> float:
    large_ratio = abs(_number(row.get("largeNetRatio")) or 0.0) * 100
    flow_30m = abs(_number(row.get("flow30m")) or 0.0) / 10_000
    change = abs(_number(row.get("changePct")) or 0.0)
    base = 60 + min(25, large_ratio) + min(20, flow_30m)
    return round(base + (change if alert_type.endswith("outflow") else 0), 2)


def _number(value: Any) -> float | None:
    if value is None:
        return None
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def _fmt(value: Any) -> str:
    number = _number(value)
    if number is None:
        return "-"
    return f"{number:.2f}"


def _fmt_wan(value: Any) -> str:
    number = _number(value)
    if number is None:
        return "-"
    return f"{number / 10_000:.2f}万"


def _fmt_pct(value: Any) -> str:
    number = _number(value)
    if number is None:
        return "-"
    return f"{number * 100:.2f}%"


def _iso(value: Any) -> str | None:
    return value.isoformat() if hasattr(value, "isoformat") else None
