from __future__ import annotations

from typing import Any, Iterable

try:
    import torch
    import torch.nn as nn
    import torch.nn.functional as F
except ImportError as exc:  # pragma: no cover - exercised in environments without torch.
    raise ImportError(
        "longbridge_stock.deep_prediction.torch_models requires PyTorch. "
        "Install the optional dependency with `pip install -e .[deep]`."
    ) from exc


class BayesianDropout(nn.Dropout):
    """Dropout that can stay active during eval for MC uncertainty sampling."""

    def __init__(self, p: float = 0.5, mc_dropout: bool = False) -> None:
        super().__init__(p=p, inplace=False)
        self.mc_dropout = mc_dropout

    def forward(self, input: torch.Tensor) -> torch.Tensor:  # type: ignore[override]
        return F.dropout(input, self.p, training=self.training or self.mc_dropout, inplace=self.inplace)

    def set_mc_dropout(self, enabled: bool) -> None:
        self.mc_dropout = bool(enabled)


class GatedResidualNetwork(nn.Module):
    """Layer-normalized residual block with TFT-style contextual gating."""

    def __init__(self, input_dim: int, hidden_dim: int, context_dim: int | None = None, dropout: float = 0.1) -> None:
        super().__init__()
        self.layer_norm = nn.LayerNorm(input_dim)
        self.input_proj = nn.Linear(input_dim, hidden_dim)
        self.context_proj = nn.Linear(context_dim, hidden_dim) if context_dim else None
        self.hidden_proj = nn.Linear(hidden_dim, hidden_dim)
        self.output_proj = nn.Linear(hidden_dim, input_dim)
        self.dropout = nn.Dropout(dropout)
        self.activation = nn.GELU()
        self.gate = nn.Sequential(nn.Linear(input_dim, input_dim), nn.Sigmoid())

    def forward(self, x: torch.Tensor, context: torch.Tensor | None = None) -> torch.Tensor:
        residual = x
        hidden = self.input_proj(self.layer_norm(x))
        if context is not None and self.context_proj is not None:
            hidden = hidden + self.context_proj(context)
        hidden = self.activation(hidden)
        hidden = self.activation(self.hidden_proj(hidden))
        hidden = self.dropout(self.output_proj(hidden))
        return self.gate(hidden) * hidden + residual


class FeatureSelection(nn.Module):
    """Learnable feature gating before temporal encoding."""

    def __init__(self, input_dim: int, hidden_dim: int) -> None:
        super().__init__()
        self.gate_network = nn.Sequential(nn.Linear(input_dim, hidden_dim), nn.ELU(), nn.Linear(hidden_dim, input_dim), nn.Sigmoid())
        self.projection = nn.Linear(input_dim, hidden_dim)

    def forward(self, x: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
        gates = self.gate_network(x)
        return self.projection(x * gates), gates


class ProbTemporalFusionTransformer(nn.Module):
    """PTFT-inspired quantile forecaster for future log returns."""

    def __init__(
        self,
        input_dim: int,
        output_dim: int,
        hidden_dim: int = 160,
        num_heads: int = 4,
        dropout: float = 0.1,
        predict_steps: int = 1,
        quantiles: Iterable[float] = (0.1, 0.5, 0.9),
    ) -> None:
        super().__init__()
        self.output_dim = output_dim
        self.hidden_dim = hidden_dim
        self.predict_steps = max(1, int(predict_steps))
        self.quantiles = tuple(sorted(set(float(q) for q in quantiles) | {0.5}))
        self.median_key = min(self.quantiles, key=lambda q: abs(q - 0.5))
        self._quantile_key_map = {self._format_quantile_key(q): f"{q:.2f}" for q in self.quantiles}

        self.feature_selector = FeatureSelection(input_dim, hidden_dim)
        self.encoder_grn = GatedResidualNetwork(hidden_dim, hidden_dim, dropout=dropout)
        self.encoder = nn.GRU(hidden_dim, hidden_dim, batch_first=True)
        self.attention = nn.MultiheadAttention(hidden_dim, num_heads, dropout=dropout, batch_first=True)
        self.post_attn_grn = GatedResidualNetwork(hidden_dim, hidden_dim, dropout=dropout)
        self.future_proj = nn.Linear(hidden_dim, hidden_dim * self.predict_steps)
        self.context_norm = nn.LayerNorm(hidden_dim)
        self.quantile_layers = nn.ModuleDict({key: nn.Linear(hidden_dim, output_dim) for key in self._quantile_key_map})
        self.dropout = nn.Dropout(dropout)
        self.last_details: dict[str, Any] = {}

    def forward(self, x: torch.Tensor, predict_steps: int | None = None) -> dict[str, Any]:
        steps = self.predict_steps if predict_steps is None else max(1, int(predict_steps))
        features, gates = self.feature_selector(x)
        features = self.encoder_grn(features)
        encoded, _ = self.encoder(features)
        attended, attention = self.attention(encoded, encoded, encoded, need_weights=True)
        fused = self.post_attn_grn(attended + encoded)
        context = self.context_norm(fused[:, -1, :])
        future = torch.tanh(self.future_proj(context).view(x.size(0), steps, self.hidden_dim))
        future = self.dropout(future)
        quantile_outputs = {
            alias: layer(future)
            for key, layer in self.quantile_layers.items()
            for alias in [self._quantile_key_map[key]]
        }
        point = quantile_outputs[f"{self.median_key:.2f}"]
        if steps == 1:
            point = point.squeeze(1)
            quantile_outputs = {key: value.squeeze(1) for key, value in quantile_outputs.items()}
        self.last_details = {
            "feature_gates": gates.mean(dim=1).detach(),
            "attention": attention.detach(),
            "quantiles": quantile_outputs,
            "steps": steps,
        }
        return {"point": point, "quantiles": quantile_outputs, "feature_gates": gates, "attention": attention}

    @staticmethod
    def _format_quantile_key(q: float) -> str:
        return f"q{int(round(q * 100)):03d}"


class VariationalStateSpaceModel(nn.Module):
    """Variational state-space model that emits regime probabilities."""

    def __init__(self, input_dim: int, output_dim: int, state_dim: int = 64, regime_classes: int = 4, predict_steps: int = 1) -> None:
        super().__init__()
        self.output_dim = output_dim
        self.state_dim = state_dim
        self.regime_classes = regime_classes
        self.predict_steps = max(1, int(predict_steps))
        self.encoder = nn.GRU(input_dim, state_dim, batch_first=True, bidirectional=True)
        self.posterior_proj = nn.Linear(state_dim * 2, state_dim * 2)
        self.prior_cell = nn.GRUCell(state_dim, state_dim)
        self.prior_proj = nn.Linear(state_dim, state_dim * 2)
        self.emission = nn.Sequential(nn.LayerNorm(state_dim), nn.GELU(), nn.Linear(state_dim, state_dim), nn.GELU(), nn.Linear(state_dim, output_dim))
        self.regime_head = nn.Sequential(nn.LayerNorm(state_dim), nn.GELU(), nn.Linear(state_dim, regime_classes))
        self.last_details: dict[str, Any] = {}

    def forward(self, x: torch.Tensor, predict_steps: int | None = None) -> dict[str, Any]:
        batch, seq_len, _ = x.shape
        steps = self.predict_steps if predict_steps is None else max(1, int(predict_steps))
        encoded, _ = self.encoder(x)
        posterior_mean, posterior_logvar = torch.chunk(self.posterior_proj(encoded), 2, dim=-1)
        posterior_logvar = torch.clamp(posterior_logvar, min=-10.0, max=5.0)

        samples = []
        kl_terms = []
        prior_hidden = torch.zeros(batch, self.state_dim, device=x.device)
        for step in range(seq_len):
            std_q = torch.exp(0.5 * posterior_logvar[:, step, :])
            z_t = posterior_mean[:, step, :] + std_q * torch.randn_like(std_q)
            if step == 0:
                prior_mean = torch.zeros_like(z_t)
                prior_logvar = torch.zeros_like(z_t)
            else:
                prior_hidden = self.prior_cell(samples[-1], prior_hidden)
                prior_mean, prior_logvar = torch.chunk(self.prior_proj(prior_hidden), 2, dim=-1)
                prior_logvar = torch.clamp(prior_logvar, min=-6.0, max=4.0)
            samples.append(z_t)
            kl_terms.append(_kl_divergence_gaussian(posterior_mean[:, step, :], posterior_logvar[:, step, :], prior_mean, prior_logvar))

        state = samples[-1]
        prior_state = prior_hidden
        future_states = []
        future_regimes = []
        for _ in range(steps):
            prior_state = self.prior_cell(state, prior_state)
            state_mean, state_logvar = torch.chunk(self.prior_proj(prior_state), 2, dim=-1)
            state = state_mean
            future_states.append(state)
            future_regimes.append(self.regime_head(state))
        future_stack = torch.stack(future_states, dim=1)
        prediction = self.emission(future_stack)
        regime_logits = torch.stack(future_regimes, dim=1)
        regime_probs = torch.softmax(regime_logits, dim=-1)
        if steps == 1:
            prediction = prediction.squeeze(1)
            regime_probs = regime_probs.squeeze(1)
        kl = torch.mean(torch.stack(kl_terms, dim=1))
        self.last_details = {"kl": kl.detach(), "regime_probs": regime_probs.detach(), "regime_logits": regime_logits.detach()}
        return {"prediction": prediction, "regime_probs": regime_probs, "regime_logits": regime_logits, "kl": kl}


class PTFTVSSMEnsemble(nn.Module):
    """Regime-aware ensemble that fuses PTFT quantiles and VSSM state forecasts."""

    def __init__(
        self,
        input_dim: int,
        output_dim: int,
        hidden_dim: int = 128,
        state_dim: int = 48,
        regime_classes: int = 4,
        quantiles: tuple[float, ...] = (0.1, 0.5, 0.9),
        predict_steps: int = 1,
        dropout: float = 0.1,
        ensemble_dropout: float = 0.1,
        fusion_hidden_dim: int = 96,
        mc_dropout: bool = False,
        use_symbol_embedding: bool = False,
        symbol_embedding_dim: int = 16,
        max_symbols: int = 4096,
    ) -> None:
        super().__init__()
        self.predict_steps = max(1, int(predict_steps))
        self.output_dim = output_dim
        self.regime_classes = regime_classes
        self.symbol_embedding = nn.Embedding(max_symbols, symbol_embedding_dim) if use_symbol_embedding else None
        self.model_input_dim = input_dim + (symbol_embedding_dim if use_symbol_embedding else 0)
        self.ptft = ProbTemporalFusionTransformer(self.model_input_dim, output_dim, hidden_dim=hidden_dim, dropout=dropout, predict_steps=self.predict_steps, quantiles=quantiles)
        self.vssm = VariationalStateSpaceModel(self.model_input_dim, output_dim, state_dim=state_dim, regime_classes=regime_classes, predict_steps=self.predict_steps)
        self.gate_network = nn.Sequential(nn.Linear(output_dim * 2 + regime_classes, fusion_hidden_dim), nn.GELU(), nn.LayerNorm(fusion_hidden_dim), nn.Linear(fusion_hidden_dim, output_dim * 2))
        self.fusion_dropout = BayesianDropout(p=ensemble_dropout, mc_dropout=mc_dropout)
        self.last_details: dict[str, Any] = {}

    def set_mc_dropout(self, enabled: bool) -> None:
        self.fusion_dropout.set_mc_dropout(enabled)

    def forward(self, x: torch.Tensor, predict_steps: int | None = None, symbol_index: torch.Tensor | None = None) -> torch.Tensor:
        steps = self.predict_steps if predict_steps is None else max(1, int(predict_steps))
        x_augmented, symbol_embed = self._augment_with_symbol(x, symbol_index)
        ptft_result = self.ptft(x_augmented, steps)
        vssm_result = self.vssm(x_augmented, steps)
        ptft_point = _ensure_step_dim(ptft_result["point"])
        vssm_point = _ensure_step_dim(vssm_result["prediction"])
        regime_probs = _ensure_step_dim(vssm_result["regime_probs"])
        fusion_input = torch.cat([ptft_point, vssm_point, regime_probs], dim=-1)
        gate_logits = self.gate_network(fusion_input).view(fusion_input.size(0), steps, self.output_dim, 2)
        fusion_weights = torch.softmax(gate_logits, dim=-1)
        fused = fusion_weights[..., 0] * ptft_point + fusion_weights[..., 1] * vssm_point
        output = self.fusion_dropout(fused).squeeze(1) if steps == 1 else self.fusion_dropout(fused)
        self.last_details = {"ptft": ptft_result, "vssm": vssm_result, "fusion_weights": fusion_weights, "steps": steps}
        if symbol_embed is not None:
            self.last_details["symbol_embed"] = symbol_embed.detach()
        return output

    def _augment_with_symbol(self, x: torch.Tensor, symbol_index: torch.Tensor | None) -> tuple[torch.Tensor, torch.Tensor | None]:
        if self.symbol_embedding is None or symbol_index is None:
            return x, None
        if symbol_index.dim() > 1:
            symbol_index = symbol_index.reshape(symbol_index.size(0), -1)[:, 0]
        symbol_index = symbol_index.to(dtype=torch.long, device=x.device).clamp_(0, self.symbol_embedding.num_embeddings - 1)
        embed = self.symbol_embedding(symbol_index)
        return torch.cat([x, embed.unsqueeze(1).expand(-1, x.size(1), -1)], dim=-1), embed


class PTFTVSSMLoss(nn.Module):
    """Composite training loss for return prediction and risk-aware calibration."""

    def __init__(self, model: PTFTVSSMEnsemble, mse_weight: float = 1.0, kl_weight: float = 1e-3, direction_weight: float = 5e-2, quantile_weight: float = 5e-2) -> None:
        super().__init__()
        self.model = model
        self.mse_weight = mse_weight
        self.kl_weight = kl_weight
        self.direction_weight = direction_weight
        self.quantile_weight = quantile_weight

    def forward(self, prediction: torch.Tensor, target: torch.Tensor) -> torch.Tensor:
        target = target.to(prediction.device)
        prediction_steps = _ensure_step_dim(prediction)
        target_steps = _ensure_step_dim(target)
        total = self.mse_weight * F.mse_loss(prediction_steps, target_steps)
        details = self.model.last_details
        kl = details.get("vssm", {}).get("kl") if details else None
        if isinstance(kl, torch.Tensor):
            total = total + self.kl_weight * kl
        if self.direction_weight > 0:
            total = total + self.direction_weight * F.binary_cross_entropy_with_logits(prediction_steps, (target_steps > 0).float())
        if self.quantile_weight > 0 and details:
            total = total + self.quantile_weight * _quantile_loss(details.get("ptft", {}).get("quantiles", {}), target_steps)
        return total


def _kl_divergence_gaussian(mean_q: torch.Tensor, logvar_q: torch.Tensor, mean_p: torch.Tensor, logvar_p: torch.Tensor) -> torch.Tensor:
    var_q = torch.exp(logvar_q)
    var_p = torch.exp(logvar_p)
    kl = logvar_p - logvar_q + (var_q + (mean_q - mean_p) ** 2) / (var_p + 1e-8) - 1.0
    return 0.5 * torch.sum(kl, dim=-1)


def _ensure_step_dim(tensor: torch.Tensor) -> torch.Tensor:
    return tensor.unsqueeze(1) if tensor.dim() == 2 else tensor


def _quantile_loss(quantiles: dict[str, torch.Tensor], target: torch.Tensor) -> torch.Tensor:
    total = torch.zeros((), device=target.device, dtype=target.dtype)
    count = 0
    for alias, quantile_pred in quantiles.items():
        try:
            q = float(alias)
        except (TypeError, ValueError):
            continue
        pred = _ensure_step_dim(quantile_pred).to(target.device)
        diff = target - pred
        total = total + torch.maximum(q * diff, (q - 1) * diff).mean()
        count += 1
    return total / count if count else total


__all__ = [
    "BayesianDropout",
    "FeatureSelection",
    "GatedResidualNetwork",
    "PTFTVSSMEnsemble",
    "PTFTVSSMLoss",
    "ProbTemporalFusionTransformer",
    "VariationalStateSpaceModel",
]
