from __future__ import annotations

import argparse
import re

import psycopg

_IDENT_RE = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")
_ORDER_BY = {
    "min": "asc",
    "max": "desc",
}


def _validate_ident(value: str, label: str) -> str:
    if not _IDENT_RE.match(value):
        raise ValueError(f"invalid {label}: {value}")
    return value


def fetch_day_bound(
    dsn: str,
    table: str,
    time_col: str,
    aggregate: str,
    cutoff: str,
    statement_timeout: str = "10min",
) -> str:
    table = _validate_ident(table, "table")
    time_col = _validate_ident(time_col, "time column")
    direction = _ORDER_BY.get(aggregate)
    if not direction:
        raise ValueError(f"invalid aggregate: {aggregate}")

    sql = f"""
    select to_char(date_trunc('day', bound_value), 'YYYY-MM-DD')
    from (
      select {time_col} as bound_value
      from {table}
      where {time_col} < %(cutoff)s::timestamptz
      order by {time_col} {direction}
      limit 1
    ) bounds;
    """
    with psycopg.connect(dsn) as conn:
        with conn.cursor() as cur:
            cur.execute(
                "select set_config('statement_timeout', %(statement_timeout)s, false)",
                {"statement_timeout": statement_timeout},
            )
            cur.execute(sql, {"cutoff": cutoff})
            row = cur.fetchone()
    if not row or not row[0]:
        return ""
    return str(row[0])


def main() -> int:
    parser = argparse.ArgumentParser(description="Fetch realtime backfill day bound from PostgreSQL.")
    parser.add_argument("--dsn", required=True)
    parser.add_argument("--table", required=True)
    parser.add_argument("--time-col", required=True)
    parser.add_argument("--aggregate", choices=sorted(_ORDER_BY.keys()), required=True)
    parser.add_argument("--cutoff", required=True)
    parser.add_argument("--statement-timeout", default="10min")
    args = parser.parse_args()
    print(
        fetch_day_bound(
            dsn=args.dsn,
            table=args.table,
            time_col=args.time_col,
            aggregate=args.aggregate,
            cutoff=args.cutoff,
            statement_timeout=args.statement_timeout,
        )
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
